<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
				<?php
                        if ( is_active_sidebar( 'sidebar-1' ) ) :
                                dynamic_sidebar( 'sidebar-1' );
                        endif;
                         ?>
                    </div>
                </div>