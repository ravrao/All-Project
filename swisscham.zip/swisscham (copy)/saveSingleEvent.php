<?php
/////////////////Local//////////////////////

/* $host = "localhost";
$username = "root";
$password = "";
$db = "swisscham"; */

/////////////////Live///////////////////////

/*$host     = "delgencerds.cexs2mezqiyl.us-east-1.rds.amazonaws.com";
$username = "delgencerds";
$password = "RL37pb25";
$db       = "swisscham";*/ 

///////////////////////////////////////////

define('__ROOT__', dirname(dirname(dirname(dirname(__FILE__))))); 
require_once(__ROOT__.'/swisschamlogin/includes/connection.php'); 


$con = mysql_connect($host, $username, $password) or die("connection failed");
mysql_select_db($db, $con) or die("could not connect with database");
$dbLink = mysql_connect($host, $username, $password)or die(mysql_error());
mysql_query("SET character_set_results=utf8", $dbLink)or die(mysql_error());
mb_language('uni'); 
mb_internal_encoding('UTF-8');
mysql_select_db($db, $dbLink)or die(mysql_error());
mysql_query("set names 'utf8'",$dbLink)or die(mysql_error());
$first_name = isset($_REQUEST['first_name'])?addslashes($_REQUEST['first_name']):"";
$sur_name = isset($_REQUEST['sur_name'])?addslashes($_REQUEST['sur_name']):"";
$email = isset($_REQUEST['email'])?addslashes($_REQUEST['email']):"";
$gender = isset($_REQUEST['gender'])?addslashes($_REQUEST['gender']):"";
$company_name = isset($_REQUEST['company_name'])?addslashes($_REQUEST['company_name']):"";
$job_title = isset($_REQUEST['job_title'])?addslashes($_REQUEST['job_title']):"";
$address = isset($_REQUEST['address'])?addslashes($_REQUEST['address']):"";
$phone = isset($_REQUEST['phone'])?addslashes($_REQUEST['phone']):"";
$year_of_birth = isset($_REQUEST['year_of_birth'])?addslashes($_REQUEST['year_of_birth']):"";
$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
$event_title = isset($_REQUEST['event_title'])?addslashes($_REQUEST['event_title']):"";
$add_mailing_list = isset($_REQUEST['add_mailing_list'])?addslashes($_REQUEST['add_mailing_list']):"no";
$sql = "INSERT INTO `sc_c_event_user`
SET `first_name`='".$first_name."',
        `sur_name`='".$sur_name."',
        `email`='".$email."',
        `gender`='".$gender."',
        `company_name`='".$company_name."',
        `job_title`='".$job_title."',
        `address`='".$address."',
        `phone`='".$phone."',
        `year_of_birth`='".$year_of_birth."',
        `event_title`='".$event_title."',
        `add_mailing_list`='".$add_mailing_list."'"; 
	mysql_query($sql);
				
$email_message="<p>Dear ".$first_name." ".$sur_name.",</p>";
$email_message.="<p>Registration information below:</p><br/>";
$email_message.="<p>Event: ".$event_title."</p><br/>";
$email_message.="<p>email: ".$email."</p><br/>";
$email_message.="<p>Gender: ".$gender."</p><br/>";
$email_message.="<p>Company Name: ".$company_name."</p><br/>";
$email_message.="<p>Job Title: ".$job_title."</p><br/>";
$email_message.="<p>Address: ".$address."</p><br/>";
$email_message.="<p>phone: ".$phone."</p><br/>";
$email_message.="<p>year of birth: ".$year_of_birth."</p><br/>";

$message='';
$email_from = 'swisscham.org'; // Who the email is from
//$subject = "New Attachment Message";
$subject = $event_title;
$email_subject =  $subject; // The Subject of the email
$email_txt = $message; // Message that the email has in it
$email_to = $email;
//$email_to = 'infoware.solutions1@gmail.com';
$headers = "From: swisscham.org";
$msg_txt='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<div style="width:500px; border:1px solid #2D4261;">
        <div style="padding:5px;background:#fff;"></div>
        <div style="font-family:Arial, Helvetica, sans-serif;font-size:13px; color:#333; padding:10px; border-top:1px solid #2D4261;">
                '.$email_message.'</div>';        

                $msg_txt.='<p style="padding:0 10px;"><b>Thank you,<br>
                Swisschamp Team</b></p>
</div>

</body>
</html>';
$semi_rand = md5(time());
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
$headers .= "\nMIME-Version: 1.0\n" .
                "Content-Type: multipart/mixed;\n" .
                " boundary=\"{$mime_boundary}\"";
$email_txt .= $msg_txt;
$email_message .= "This is a multi-part message in MIME format.\n\n" .
                        "--{$mime_boundary}\n" .
                        "Content-Type:text/html; charset=\"iso-8859-1\"\n" .
                   "Content-Transfer-Encoding: 7bit\n\n" .
$email_txt . "\n\n";
$cont ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

        <div style="width:500px; border:1px solid #2D4261;">
                <div style="padding:5px;background:#fff;"></div>
                <div style="font-family:Arial, Helvetica, sans-serif;font-size:13px; color:#333; padding:10px; border-top:1px solid #2D4261;">
                        '.$email_message.'</div>';        

                        $cont.='
        </div>

</body>
</html>';
mail($email_to, $email_subject, $cont, $headers);
//header('Location: http://www.swisschamofcommerce.com/events/swiss-innovation-power-a-genetic-code-for-success/');
header('Location: ' . $_SERVER['HTTP_REFERER']);        
?>