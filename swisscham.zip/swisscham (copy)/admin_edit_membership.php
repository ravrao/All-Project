<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 



?>
    <!doctype html>
    <html class="no-js" lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Swisscham | Membership - Common User</title>
        <link rel="stylesheet" href="css/app.css">
        <!-- Favicon -->
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.css" rel="stylesheet">
        <link href="css/dev1.css" rel="stylesheet">
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }
        </style>
        <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="js/dashboard.js">
        </script>
    </head>

    <body>
        <div id="page">

            <?php 
    require_once(__ROOT__.'/includes/header.php'); 
    ?>
                <div class="abc"></div>
                <section class="inner_banner bg-beijing hide-for-small-only">
                    <div class="inner_bredcrumb">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs page_bredcrunb">
                                <li><a href="beijing.html">Home</a></li>
                                <li>
                                    <span class="show-for-sr">Current: </span> Membership login
                                </li>
                            </ul>
                        </nav>
                    </div>
                </section>
<section>
    <div class="row">
        <div class="large-9 medium-8 small-12 columns no_padding margin_top15">
            <div class="large-12 columns dowedo_top">
                <h1 class="common_heading">Membership login <p style="margin-top: -39px; text-align: right; margin-right: 35px;"><a href="admin.php" class="button regnext_btn no_margin_bottom" id="newsLetterSubmit">Back to admin</a></p></h1>

            </div>
            <?php
            $userId=$_REQUEST['id'];
            $userDetails = "SELECT *
            FROM sc_c_userdetails
            LEFT JOIN sc_c_company_details
            ON sc_c_userdetails.userId=sc_c_company_details.userId
            WHERE sc_c_userdetails.userId='".$userId."'";
            $result = mysql_query($userDetails); 
            $row = mysql_fetch_array($result);
        ?>
                <div class="large-12 columns margin_bottom5">
                    <h3 class="login_user_name">Welcome, <span>
        <?php if(!empty($row['given_name'])){echo $row["given_name"].' '.$row["family_name"]; }?>
        </span></h3>
                </div>
<div class="large-12 columns">
    <div id="eventListTab">
        <ul class="resp-tabs-list hor_1 memberdir_tab user_tab_width">

            <li class="tab_active">View Profile</li>
            <li class="">Edit Personal Info</li>
            <li>Edit Company Info</li>
            <li>Newsletters</li>
            <!-- <li>Ask an expert</li>
            <li>Expert's Corner Article</li> -->

        </ul>
<div class="resp-tabs-container hor_1 eventtab_list_details">

    <div>
        <div class="row">
            <div class="large-12 columns">
                <h5>Personal Info</h5>
            </div>
            <div class="large-12 columns no_padding">
                <div class="large-2 columns small_padding">
                    <p class="text-center directory_logo"><img src="<?php if(!empty($row['profile_picture'])){echo $row['profile_picture']; } else{ echo " images/logo.png "; }?>" /></p>
                </div>
                <div class="large-10 columns directory_item_details small_padding">
                    <h2><?php if(!empty($row['given_name'])){echo $row["given_name"].' '.$row["family_name"]; }?></h2>
                    <h3 class="common_subheading"><?php if(!empty($row['positionIn_company'])){echo $row["positionIn_company"]; }?></h3>
                    <hr class="common_devider" />
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Phone</h3>
                        <h5><?php if(!empty($row['direct_phone'])){echo $row["direct_phone"]; } else{ echo "-";}?></h5>
                        <hr class="common_devider" />
                    </div>
                    <!--<div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Company</h3>
                        <h5></h5>
                        <hr class="common_devider" />
                    </div>-->
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Province/Area</h3>
                        <h5><?php if(!empty($row['province_area'])){ echo $row["province_area"]; } else{ echo "-"; }?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Business Scope:</h3>
                        <h5><?php if(!empty($row['business_scope'])){echo $row["business_scope"]; } else{ echo "-";}?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">E-mail</h3>
                        <h5><?php if(!empty($row['direct_email'])){echo $row["direct_email"]; } else{ echo "-"; }?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Nationality</h3>
                        <h5><?php if(!empty($row['nationality'])){echo $row["nationality"]; } else{ echo "-"; }?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Year of Birth</h3>
                        <h5><?php if(!empty($row['year_of_birth'])){
                        $dt=strtotime($row['year_of_birth']);
                        echo date("d-m-Y",$dt); } else{ echo "-"; }?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading">Mobile phone</h3>
                        <h5><?php if(!empty($row['mobile_phone'])){echo $row["mobile_phone"]; } else{ echo "-"; }?></h5>
                        <hr class="common_devider" />
                    </div>
                    <div class="large-6 columns directory_item_details small_padding">
                        <h3 class="common_subheading"></h3>
                        <h5></h5>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
<div class="row">
<div id="ChildVerticalTab_1">
<ul class="resp-tabs-list ver_1">
<li>Account Info *</li>
<li>Personal Details *</li>
<li>Other Contact *</li>
<li>Directory Users *</li>
</ul>

<div class="resp-tabs-container ver_1">
<div>
    <div class="row">
        <div class="large-12 columns">
            <h5 class="tab_subheading">Change your Password and E-mail</h5>
        </div>
        <div class="large-12 columns">
            <hr class="common_devider" />
        </div>
        <div class="large-12 columns no_padding">
            <form name="accountInfoForm" id="accountInfoForm" action="admin_userinfo_process.php?info=account" method="POST"enctype='multipart/form-data'>
                <input type="hidden" value="<?=$userId?>" name="userId" id="userId" />

                <div class="medium-12 columns membership_from">
                    <label>Username<span class="mandatory_tag">*</span>
                        <input type="text" placeholder="" value="<?php if(!empty($row['admin_generated_userId'])){ echo $row['admin_generated_userId']; }?>" name="admin_generated_userId" id="admin_generated_userId">


                        <input type="hidden" value="0" name="chkUserName" id="chkUserName" />
                        <small>Spaces are not allowed; minimum 6 charecters.</small>
                    </label>
                </div>
                <div class="medium-12 columns membership_from">
                    <label>E-mail address <span class="mandatory_tag">*</span>
                        <input type="text" placeholder="" value="<?php if(!empty($row['direct_email'])){echo $row['direct_email']; }?>" name="general_email" id="general_email" />
                        <small>A valid e-mail address. All e-mails from the system will be sent to this address. The e-mail address is not made public and will only be used if you wish to receive a new password or wish to receive certain news or notifications by e-mail.</small>
                    </label>
                </div>
                <div class="medium-12 columns membership_from">
                    <label>Password <span class="password_change_btn"><a href="javascript:void(0)" id="changePassword">Change your password</a><a href="javascript:void(0)" id="cancelPassword" style="display:none;">Cancel</a></span>
                        <input type="password" placeholder="" value="<?php if(!empty($row['admin_generated_password'])){ echo $row['admin_generated_password'];}?>" name="admin_generated_password" id="admin_generated_password" disabled />
                    </label>
                </div>

                <!--<div class="password-strength-title">Password strength:</div>
                                                            <div class="password-indicator"><div class="indicator"></div></div> -->

                <div class="medium-12 columns membership_from">
                    <label>Confirm password
                        <input type="password" placeholder="" value="" name="confirm_admin_generated_password" id="confirm_admin_generated_password" disabled />
                        <small>To change the current user password, enter the new password in both fields.</small>
                    </label>
                </div>
        </div>



        <div class="medium-12 columns membership_from">
        <legend>Status</legend>
        <input type="radio" name="admin_approval" value="No" id="status" <?=($row['admin_approval']=="No")?"checked='checked'":"";?>>
        <label for="chinese"> Blocked</label>
        <input type="radio" name="admin_approval" value="Yes" id="status"  <?=($row['admin_approval']=="Yes")?"checked='checked'":"";?>>
        <label for="english"> Active</label>
    </div>

    <?php

    if(isset($row['assignables_role']))
            $assignable_roles = explode(",", $row['assignables_role']);
            else
                    $assignable_roles = "";

            $con = count($assignable_roles);
    ?>

    <div class="medium-12 columns membership_from">
        <legend>Assignable roles</legend>
        <div>
            <input name="assignables_role[]" id="company_holder" value="company_holder" type="checkbox"
                    <?php
                    if($con> 0){
                            if(in_array("company_holder", $assignable_roles))
                                    echo "checked='checked'";
                            else
                                    echo "";
                    }
                    ?>>
            <label for="general">company holder</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="company_member" value="company_member" type="checkbox" 
            <?php
                    if($con> 0){
                            if(in_array("company_member", $assignable_roles))
                                    echo "checked='checked'";
                            else
                                    echo "";
                    }
                    ?>>
            <label for="checkbox2">company member</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="directory_user" value="directory_user" type="checkbox"
            <?php
                    if($con> 0){
                            if(in_array("directory_user", $assignable_roles))
                        echo "checked='checked'";
                else
                        echo "";
                    }
                    ?>

             >
            <label for="checkbox3">directory user</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="beijing_editor" value="beijing_editor" type="checkbox" 

            <?php
                    if($con> 0){
                            if(in_array("beijing_editor", $assignable_roles))
                                echo "checked='checked'";
                        else
                                echo "";
                    }
                    ?>>
            <label for="guang">Beijing editor</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="shanghai_editor" value="shanghai_editor" type="checkbox" 

            <?php
                    if($con> 0){
                            if(in_array("shanghai_editor", $assignable_roles))
                                    echo "checked='checked'";
                            else
                                    echo "";
                    }
                    ?>>
            <label for="hong_kong">Shanghai editor</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="guangzhou_editor" value="guangzhou_editor" type="checkbox" 

             <?php
                    if($con> 0){
                            if(in_array("guangzhou_editor", $assignable_roles))
                                echo "checked='checked'";
                        else
                                echo "";
                    }
                    ?>>
            <label for="hong_kong">Guangzhou editor</label>
        </div>
        <div>
            <input  name="assignables_role[]" id="hong_kong_editor" value="hong_kong_editor" type="checkbox" 

             <?php
                    if($con> 0){
                            if(in_array("company_holder", $assignable_roles))
                                echo "checked='checked'";
                        else
                                echo "";
                    }
                    ?>
            >
            <label for="hong_kong">Hong Kong editor</label>
        </div>
        <small> The user receives the combined permissions of all roles selected here and the following roles: authenticated user.</small>
    </div>



        <div class="large-12 columns">
            <h5 class="tab_subheading">Language settings</h5>
        </div>
        <div class="large-12 columns">
            <hr class="common_devider" />
        </div>
        <div class="large-12 columns no_padding">
            <!--<form>-->
            <div class="medium-12 columns membership_from">
                <legend>Language</legend>
                <input type="radio" name="language" value="Chinese" id="Chinese" <?php if($row[ 'language']=='' ){ echo "checked"; } else if($row[ 'language']=='Chinese' ){echo "checked"; }?>>
                <label for="Chinese"> Chinese, Simplified (简体中文)</label>

                <input type="radio" name="language" value="English" id="english" <?php if($row['language']=='English' ){echo "checked"; }?>>
                <label for="english"> English</label>
            </div>
            <div class="medium-12 columns membership_from">
                <small>This account's default language for e-mails, and preferred language for site presentation.</small>
            </div>

        </div>
        <div class="medium-12 columns membership_from">
            <p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="accountInfoSave" class="button regnext_btn no_margin_bottom">Save</a></p>
        </div>
        </form>
    </div>
</div>
<div>
<form name="personalInfoForm" id="personalInfoForm" action="admin_userinfo_process.php?info=personal" method="POST"enctype='multipart/form-data'>
<input type="hidden" value="<?=$userId?>" name="userId" id="userId" />

<div class="row">
<div class="medium-12 columns membership_from">
<legend>Title <span class="mandatory_tag">*</span></legend>
<input type="radio" name="user_title" value="Dr" id="Dr" <?php if($row[ 'user_title']=='' ){ echo "checked"; } else if($row[ 'user_title']=='Dr' ){echo "checked"; }?>>
<label for="missus">Dr.</label>
<input type="radio" name="user_title" value="Mr" id="Mr" <?php if($row[ 'user_title']=='Mr' ){echo "checked"; }?>>
<label for="mister"> Mr.</label>
<input type="radio" name="user_title" value="Ms" id="Ms" <?php if($row[ 'user_title']=='Ms' ){echo "checked"; }?>>
<label for="miss">Ms.</label>
</div>
<div class="medium-6 columns membership_from">
<label>Date of Birth<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($row['year_of_birth'])){ echo $row['year_of_birth'];  }?>" name="year_of_birth" id="year_of_birth">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Family name <span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($row['family_name'])){ echo $row['family_name'];}?>" name="family_name" id="family_name">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Given name<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($row['given_name'])){ echo $row['given_name']; }?>" name="given_name" id="given_name">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Chinese name<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['chinese_name'])){ echo $row['chinese_name']; }?>" name="chinese_name" id="chinese_name">
</label>
</div>

<div class="medium-12 columns membership_from second_form_field">
<legend> Nationality:</legend>
<input type="radio" name="nationality" value="Swiss" id="indiv_nationality_swiss" <?php if($row['nationality']=='swiss'){ echo "checked"; }?>>
<label for="indiv_nationality_swiss"> Swiss</label>
<?php if($row['company_chamber']!='HongKong'){?>
<input type="radio" name="nationality" value="Chinese" id="indiv_nationality_chinese" <?php if($row['nationality']=='chinese'){ echo "checked"; }?>>
<label for="indiv_nationality_chinese"> Chinese</label>
<?php } else{?>
<input type="radio" name="nationality" value="HongKong" id="indiv_nationality_HongKong" <?php if($row['nationality']=='HongKong'){ echo "checked"; }?>>
<label for="indiv_nationality_HongKong"> HongKong</label>
                            <?php } ?>
<input type="radio" name="nationality" value="Other" id="indiv_nationality_other" <?php if($row['nationality']=='other'){ echo "checked"; }?>>
<label for="indiv_nationality_other"> Other</label>
</div>

<!--<div class="medium-12 columns membership_from">
<label>Address in English:<span>*</span>
<textarea rows="3" name="address_english" id="address_english">
<?php if(!empty($row['address_english'])){ echo $row['address_english']; }?>
                                    </textarea>
</label>
</div>-->


<div class="medium-12 columns membership_from">
<label>Address in English:<span>*</span>
<textarea rows="3" name="address_english" id="address_english"><?php if(!empty($row['address_english'])){ echo $row['address_english']; }?></textarea>
</label>
</div>





<div class="medium-6 columns membership_from">
<label>City in English<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['city_english'])){ echo $row['city_english']; }?>" name="city_english" id="city_english">
</label>
</div>

<div class="medium-6 columns membership_from">
<label>Province/Area in English<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['province_area'])){ echo $row['province_area']; }?>" name="province_area" id="province_area">

</label>
</div>

<!--<div class="medium-6 columns membership_from">
<label>Province/Area in English<span class="mandatory_tag">*</span>
<select name="province_area" id="province_area" style="margin-top:0px !important;">
<option value="Beijing" <?php if($row['province_area']=='Beijing'){ echo "selected"; }?>>Beijing</option>
<option value="Shanghai" <?php if($row['province_area']=='Shanghai'){ echo "selected"; }?>>Shanghai</option>
<option value="Guangzhou" <?php if($row['province_area']=='Guangzhou'){ echo "selected"; }?>>Guangzhou</option>
<option value="HongKong" <?php if($row['province_area']=='HongKong'){ echo "selected"; }?>>Hong Kong</option>
<option value="ChinaMainland" <?php if($row['province_area']=='ChinaMainland'){ echo "selected"; }?>>China Mainland</option>
</select>
</label>
</div>-->

<!-- <div class="medium-12 columns membership_from">
<label>Address in Chinese:<span>*</span>
<textarea rows="3" name="address_chinese" id="address_chinese">
                                    <?php if(!empty($row['address_chinese'])){ echo $row['address_chinese']; }?>
                                    </textarea>
</label>
</div>-->


<div class="medium-12 columns membership_from">
<label>Address in Chinese:<span>*</span>
<textarea rows="3" name="address_chinese" id="address_chinese"><?php if(!empty($row['address_chinese'])){ echo $row['address_chinese']; }?></textarea>
</label>
</div>

<div class="medium-6 columns membership_from">
<label>City in Chinese<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['city_chinese'])){ echo $row['city_chinese']; }?>" name="city_chinese" id="city_chinese">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Zip code<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['zip_code_english'])){ echo $row['zip_code_english']; }?>" name="zip_code_english" id="zip_code_english">
</label>
</div>


<div class="medium-6 columns membership_from">
<label>Position in company<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($row['positionIn_company'])){ echo $row['positionIn_company']; }?>" name="positionIn_company" id="positionIn_company">
</label>
</div>
<!-- <div class="medium-6 columns membership_from">
<label>Company name <span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="" name="company_name" id="company_name">
</label>
</div> -->

<div class="large-12 columns">
<h5 class="tab_subheading">Picture</h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<div class="large-12 columns">
<div>
<label for="exampleFileUpload" class="button no_margin_bottom">Upload File</label>
<input type="file" id="exampleFileUpload" name="profile_picture" class="show-for-sr" onchange="showImage1(this,0);">
</div>
<small>Your virtual face or picture. Pictures larger than 1024x1024 pixels will be scaled down.</small>
<label for="over_13" class="light" id="preview_label_id1"></label>
<div style="float:left;position:relative;">
<img class="thumbnail" id="preview1" src="" alt="" style="display:none;" />
</div>
</div>

<div class="large-12 columns">
<h5 class="tab_subheading">Contact Details</h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<div class="medium-6 columns membership_from">
<label>Direct Phone<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['direct_phone'])){ echo $row['direct_phone']; }?>" name="direct_phone" id="direct_phone">
</label>
</div>

<div class="medium-6 columns membership_from">
<label>Mobile phone<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['mobile_phone'])){ echo $row['mobile_phone'];}?>" name="mobile_phone" id="mobile_phone">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct E-mail<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['direct_email'])){ echo $row['direct_email']; }?>" name="direct_email" id="direct_email" disabled />
<small>Your public e-mail address. The email address you registered with will be kept private.</small>
</label>
</div>

<div id="forNpo" <?php if(!empty($row['npo_organization_type'])){ echo "style='display:block;'";} else{ echo "style='display:none;'";}?>>
<div class="medium-6 columns membership_from">
<label>Type of organization<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['npo_organization_type'])){ echo $row['npo_organization_type'];}?>" name="npo_organization_type" id="npo_organization_type" <?php if(empty($row['npo_organization_type'])){ echo "disabled";}?> >
</label>
</div>
<div class="medium-12 columns membership_from">
<label>Organization description<span class="mandatory_tag">*</span>
<textarea name="npo_organization_description" id="npo_organization_description" <?php if(empty($row['npo_organization_description'])){ echo "disabled";}?>><?php if(!empty($row['npo_organization_description'])){ echo $row['npo_organization_description'];}?></textarea>
</label>
</div>
</div>
<div id="forJrnl" <?php if(!empty($row['media_type'])){ echo "style='display:block;'";} else{ echo "style='display:none;'";}?>>
<div class="medium-6 columns membership_from">
<label>Type of media<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($row['media_type'])){ echo $row['media_type'];}?>" name="media_type" id="media_type"  <?php if(empty($row['media_type'])){ echo "disabled";}?>>
</label>
</div>
<div class="medium-12 columns membership_from">
<label>Publication description<span class="mandatory_tag">*</span>
<textarea name="media_description" id="media_description" <?php if(empty($row['media_description'])){ echo "disabled";}?>><?php if(!empty($row['media_description'])){ echo $row['media_description'];}?></textarea>
</label>
</div>
</div>


<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0)" class="button regnext_btn no_margin_bottom" id="personalInfoSave">Save</a></p>
</div>

</div>
</form>
</div>
    

    

<!-- Other Contact Details-->
<div>
    <?php
    $i=0;
    $otherContactDetailsQuery = "SELECT * FROM `sc_c_other_contact` WHERE `userId`='$userId'";
    $otherContactResult = mysql_query($otherContactDetailsQuery); 
    ?>
    <form name="contactotherInfoForm" id="contactotherInfoForm" action="admin_userinfo_process.php?info=other" method="POST"enctype='multipart/form-data'>
   <input type="hidden" name="compsnyORnot" id="compsnyORnot" value="<?php if(empty($row['positionIn_company'])){ echo "0";} else{ echo "1";} ?>" />
   <input type="hidden" value="<?=$userId?>" name="userId" id="userId" />

    <div class="row">

        <!-- Loop Start Here -->
        <?php	
        while($otherContactDetails = mysql_fetch_array($otherContactResult)){
        $i++;
        ?>
        <div id="frA" <?php if(!empty($row['positionIn_company'])){ echo "style='display:none'";} else{ echo "style='display:block'";}?>>
                    <div id="adddiv_<?=$i?>">

                        <div class="large-12 columns">
                            <h5 class="tab_subheading">Other Contact <?=$i?></h5>
                        </div>
                        <div class="large-12 columns">
                            <hr class="common_devider" />
                        </div>
                        <div class="medium-12 columns membership_from">
                            <legend>Title <span class="mandatory_tag">*</span></legend>
                            <input type="radio" name="other_contact_title<?=$i?>" value="Dr" id="Dr" <?php if($otherContactDetails[ 'other_contact_title']=='Dr' ){ echo "checked"; }?>>
                            <label for="missus">Mrs.</label>
                            <input type="radio" name="other_contact_title<?=$i?>" value="Mr" id="Mr" <?php if($otherContactDetails[ 'other_contact_title']=='Mr' ){ echo "checked"; }?>>
                            <label for="mister"> Mr.</label>
                            <input type="radio" name="other_contact_title<?=$i?>" value="Ms" id="Ms" <?php if($otherContactDetails[ 'other_contact_title']=='Ms' ){echo "checked"; }?>>
                            <label for="miss">Ms.</label>
                        </div>
                        <div class="medium-6 columns membership_from">
                            <label>Date of Birth: <span class="mandatory_tag">*</span>
                                <input type="text" value="<?php if(!empty($otherContactDetails['other_contact_dob'])){ echo date('m/d/Y',strtotime($otherContactDetails['other_contact_dob'])); }?>" name="other_contact_dob[]" id="other_contact_dob<?=$i?>" class="other_contact_dob">
                            </label>
                        </div>

                        <div class="medium-6 columns membership_from">
                            <label>Family name <span class="mandatory_tag">*</span>
                                <input type="text" value="<?php if(!empty($otherContactDetails['other_contact_familyName'])){ echo $otherContactDetails['other_contact_familyName']; }?>" name="other_contact_familyName[]" id="other_contact_familyName<?=$i?>">
                            </label>
                        </div>
                        <div class="medium-6 columns membership_from">
                            <label>Given name<span class="mandatory_tag">*</span>
                                <input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_givenName'])){ echo $otherContactDetails['other_contact_givenName']; } ?>" name="other_contact_givenName[]" id="other_contact_givenName<?=$i?>">
                            </label>
                        </div>
                        <div class="medium-6 columns membership_from">
                            <label>Chinese name<span class="mandatory_tag">*</span>
                                <input type="text" placeholder="" value="<?php  if(!empty($otherContactDetails['other_contact_chineseName'])){ echo $otherContactDetails['other_contact_chineseName']; }?>" name="other_contact_chineseName[]" id="other_contact_chineseName<?=$i?>">
                            </label>
                        </div>
                        <div class="medium-12 columns membership_from">
                            <label> Nationality:<span class="mandatory_tag">*</span></label>
                            <input type="radio" name="other_contact_nationality<?=$i?>" value="Swiss" id="other_contact_nationality1<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Swiss' ){ echo "checked"; }?>>
                            <label for="other_contact_nationality1<?=$i?>" class="other_contact_nationality"> Swiss</label>
                            <input type="radio" name="other_contact_nationality<?=$i?>" value="Chinese" id="other_contact_nationality2<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Chinese' ){ echo "checked"; }?>>
                            <label for="other_contact_nationality2<?=$i?>" class="other_contact_nationality"> Chinese</label>
                            <input type="radio" name="other_contact_nationality<?=$i?>" value="HongKong" id="other_contact_nationality3<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='HongKong' ){ echo "checked"; }?>>
                            <label for="other_contact_nationality3<?=$i?>" class="other_contact_nationality"> Hong Kong</label>
                            <input type="radio" name="other_contact_nationality<?=$i?>" value="Other" id="other_contact_nationality4<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Other' ){ echo "checked"; }?>>
                            <label for="other_contact_nationality4<?=$i?>" class="other_contact_nationality"> Other</label>



                        </div>


<div class="medium-12 columns membership_from">
<label> Address in English:<span>*</span>
<textarea rows="3" name="other_contact_address_english[]" id="other_contact_address_english<?=$i?>"><?php if(!empty($otherContactDetails['other_contact_address_english'])){ echo $otherContactDetails['other_contact_address_english']; } ?></textarea>
</label>
</div>

<div class="medium-6 columns membership_from">
<label> City in English:<span>*</span>
<input type="text" name="other_contact_city_english[]" id="other_contact_city_english<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_city_english'])){ echo $otherContactDetails['other_contact_city_english']; } ?>" />
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Province/Area in English:<span>*</span>
<input type="text" name="other_contact_province_area[]" id="other_contact_province_area<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_province_area'])){ echo $otherContactDetails['other_contact_province_area']; } ?>" />
</label>
</div>
<div class="medium-12 columns membership_from">
<label> Address in Chinese:<span>*</span>
<textarea rows="3" name="other_contact_address_chinese[]" id="other_contact_address_chinese<?=$i?>"><?php if(!empty($otherContactDetails['other_contact_address_chinese'])){ echo $otherContactDetails['other_contact_address_chinese']; } ?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label> City in Chinese <span>*</span>
<input type="text" name="other_contact_city_chinese[]" id="other_contact_city_chinese<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_city_chinese'])){ echo $otherContactDetails['other_contact_city_chinese']; } ?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>ZIP code:<span>*</span>
<input type="text" name="other_contact_zipCode[]" id="other_contact_zipCode<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_zipCode'])){ echo $otherContactDetails['other_contact_zipCode']; } ?>">
</label>
</div>




<div class="medium-6 columns membership_from">
<label>Mobile<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php  if(!empty($otherContactDetails['other_contact_mobile'])){ echo $otherContactDetails['other_contact_mobile']; }?>" name="other_contact_mobile[]" id="other_contact_mobile<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct phone<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_directPhone'])){ echo $otherContactDetails['other_contact_directPhone']; }?>" name="other_contact_directPhone[]" id="other_contact_directPhone<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct E-mail<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_directEmail'])){ echo $otherContactDetails['other_contact_directEmail']; }?>" name="other_contact_directEmail[]" id="other_contact_directEmail<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>
</label>
</div>
</div>
</div>






<div id="frC" <?php if(!empty($row['positionIn_company'])){ echo "style='display:block'";} else{ echo "style='display:none'";}?>>
<div id="adddiv_<?=$i?>">

<div class="large-12 columns">
<h5 class="tab_subheading">Other Contact <?=$i?></h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<div class="medium-12 columns membership_from">
<legend>Title <span class="mandatory_tag">*</span></legend>
<input type="radio" name="other_contact_titlec<?=$i?>" value="Dr" id="Dr" <?php if($otherContactDetails[ 'other_contact_title']=='Dr' ){ echo "checked"; }?>>
<label for="missus">Dr.</label>
<input type="radio" name="other_contact_titlec<?=$i?>" value="Mr" id="Mr" <?php if($otherContactDetails[ 'other_contact_title']=='Mr' ){ echo "checked"; }?>>
<label for="mister"> Mr.</label>
<input type="radio" name="other_contact_titlec<?=$i?>" value="Ms" id="Ms" <?php if($otherContactDetails[ 'other_contact_title']=='Ms' ){echo "checked"; }?>>
<label for="miss">Ms.</label>
</div>
<div class="medium-6 columns membership_from">
<label>Date of Birth: <span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($otherContactDetails['other_contact_dob'])){ echo date('m/d/Y',strtotime($otherContactDetails['other_contact_dob'])); }?>" name="other_contact_dobc[]" id="other_contact_dobc<?=$i?>" class="other_contact_dob">
</label>
</div>

<div class="medium-6 columns membership_from">
<label>Family name <span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($otherContactDetails['other_contact_familyName'])){ echo $otherContactDetails['other_contact_familyName']; }?>" name="other_contact_familyNamec[]" id="other_contact_familyNamec<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Given name<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_givenName'])){ echo $otherContactDetails['other_contact_givenName']; } ?>" name="other_contact_givenNamec[]" id="other_contact_givenNamec<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Chinese name<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php  if(!empty($otherContactDetails['other_contact_chineseName'])){ echo $otherContactDetails['other_contact_chineseName']; }?>" name="other_contact_chineseNamec[]" id="other_contact_chineseNamec<?=$i?>">
</label>
</div>
<div class="medium-12 columns membership_from">
<label> Nationality:<span class="mandatory_tag">*</span></label>
<input type="radio" name="other_contact_nationalityc<?=$i?>" value="Swiss" id="other_contact_nationality1c<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Swiss' ){ echo "checked"; }?>>
<label for="other_contact_nationality1c<?=$i?>" class="other_contact_nationality"> Swiss</label>
<input type="radio" name="other_contact_nationalityc<?=$i?>" value="Chinese" id="other_contact_nationality2c<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Chinese' ){ echo "checked"; }?>>
<label for="other_contact_nationality2c<?=$i?>" class="other_contact_nationality"> Chinese</label>
<input type="radio" name="other_contact_nationalityc<?=$i?>" value="HongKong" id="other_contact_nationality3c<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='HongKong' ){ echo "checked"; }?>>
<label for="other_contact_nationality3c<?=$i?>" class="other_contact_nationality"> Hong Kong</label>
<input type="radio" name="other_contact_nationalityc<?=$i?>" value="Other" id="other_contact_nationality4c<?=$i?>" class="other_contact_nationality" <?php if($otherContactDetails[ 'other_contact_nationality']=='Other' ){ echo "checked"; }?>>
<label for="other_contact_nationality4c<?=$i?>" class="other_contact_nationality"> Other</label>

</div>

                            <div class="medium-12 columns membership_from">
<label> Position In Company:<span>*</span>
<input type="text" name="other_contact_positionc[]" id="other_contact_positionc<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_position'])){ echo $otherContactDetails['other_contact_position']; } ?>" />
</label>
</div>

<div class="medium-12 columns membership_from">
<label> Address in English:<span>*</span>
<textarea rows="3" name="other_contact_address_englishc[]" id="other_contact_address_englishc<?=$i?>"><?php if(!empty($otherContactDetails['other_contact_address_english'])){ echo trim($otherContactDetails['other_contact_address_english']); } ?></textarea>
</label>
</div>

<div class="medium-6 columns membership_from">
<label> City in English:<span>*</span>
<input type="text" name="other_contact_city_englishc[]" id="other_contact_city_englishc<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_city_english'])){ echo $otherContactDetails['other_contact_city_english']; } ?>" />
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Province/Area in English:<span>*</span>
<input type="text" name="other_contact_province_areac[]" id="other_contact_province_areac<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_province_area'])){ echo $otherContactDetails['other_contact_province_area']; } ?>" />
</label>
</div>
<div class="medium-12 columns membership_from">
<label> Address in Chinese:<span>*</span>
<textarea rows="3" name="other_contact_address_chinesec[]" id="other_contact_address_chinesec<?=$i?>"><?php if(!empty($otherContactDetails['other_contact_address_chinese'])){ echo trim($otherContactDetails['other_contact_address_chinese']); } ?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label> City in Chinese <span>*</span>
<input type="text" name="other_contact_city_chinesec[]" id="other_contact_city_chinesec<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_city_chinese'])){ echo $otherContactDetails['other_contact_city_chinese']; } ?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>ZIP code:<span>*</span>
<input type="text" name="other_contact_zipCodec[]" id="other_contact_zipCodec<?=$i?>" value="<?php if(!empty($otherContactDetails['other_contact_zipCode'])){ echo $otherContactDetails['other_contact_zipCode']; } ?>">
</label>
</div>




<div class="medium-6 columns membership_from">
<label>Mobile<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php  if(!empty($otherContactDetails['other_contact_mobile'])){ echo $otherContactDetails['other_contact_mobile']; }?>" name="other_contact_mobilec[]" id="other_contact_mobilec<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct phone<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_directPhone'])){ echo $otherContactDetails['other_contact_directPhone']; }?>" name="other_contact_directPhonec[]" id="other_contact_directPhonec<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct E-mail<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_contact_directEmail'])){ echo $otherContactDetails['other_contact_directEmail']; }?>" name="other_contact_directEmailc[]" id="other_contact_directEmailc<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>
</label>
</div>
</div>
</div>





<?php } ?>
                                                                            <!-- Loop End Here -->
<div class="medium-12 columns membership_from">
<p class="add_field user_add_field" id="addmore" <?php if($i==3){ echo "style='display:none;'"; }else{ echo "style='display:block;'";}?>>
<a href="javascript:void(0)" class="holo_button">
<i class="fa fa-plus-circle" aria-hidden="true"></i> Add new contact
</a>
</p>
<p class="add_field user_add_field" id="removebtn" <?php if($i>1){ echo "style='display:block;'"; }else{ echo "style='display:none;'";}?>>
<a href="javascript:void(0)" class="holo_button">
<i class="fa fa-times-circle" aria-hidden="true"></i> Remove last contact
</a>
</p>
<input type="hidden" name="addcnt" value="<?=$i?>" id="addcnt">
</div>
<div id="appenddiv"></div>
<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="otherContactSave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>   
</div>
</form>

</div>


    
<!------------------------ Member Directory------------------------------------->




<div>
    
<form name="memberdirectory" id="memberdirectoryForm" action="admin_userinfo_process.php?info=memberderectory" method="POST" enctype='multipart/form-data'>
   <input type="hidden" name="compsnyORnot" id="compsnyORnot" value="<?php if(empty($row['positionIn_company'])){ echo "0";} else{ echo "1";} ?>" />
   <input type="hidden" value="<?=$userId?>" name="userId" id="userId" />
   <input type="hidden" value="<?php echo $_GET['Userid'] ?>" name="userIdForMemberdiretcory" id="userIdForMemberdiretcory" />

   <?php
 
   $rowmember_dire = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$_GET['Userid']."'")); 
   ?>
<div class="row">

    <!-- Loop Start Here -->


<div class="large-12 columns">
<h5 class="tab_subheading">Member Directory </h5>
</div>
<div class="large-12 columns">
    <hr class="common_devider" />
</div>
<div class="medium-12 columns membership_from">
    <legend>Title <span class="mandatory_tag">*</span></legend>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Dr' ){ echo "checked"; }?> value="Dr" id="Dr" >
    <label for="missus">Dr.</label>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Mr' ){ echo "checked"; }?> value="Mr" id="Mr" >
    <label for="mister"> Mr.</label>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Ms' ){ echo "checked"; }?> value="Ms" id="Ms" >
    <label for="miss">Ms.</label>
</div>
<div class="medium-6 columns membership_from">
    <label>Date of Birth: <span class="mandatory_tag">*</span>
        <input type="text" name="other_contact_dob_dir" id="other_contact_dob_dir" value="<?php if(!empty($rowmember_dire['year_of_birth'])){ echo date('m/d/Y',strtotime($rowmember_dire['year_of_birth'])); }?>" class="other_contact_dob">
    </label>
</div>

<div class="medium-6 columns membership_from">
    <label>Family name <span class="mandatory_tag">*</span>
        <input type="text" name="other_contact_familyName_dir" value="<?php echo $rowmember_dire['family_name']; ?>" id="other_contact_familyName_dir">
    </label>
</div>
<div class="medium-6 columns membership_from">
    <label>Given name<span class="mandatory_tag">*</span>
        <input type="text" placeholder=""  name="other_contact_givenName_dir" value="<?php echo $rowmember_dire['given_name'];?>" id="other_contact_givenName_dir">
    </label>
</div>
<div class="medium-6 columns membership_from">
    <label>Chinese name<span class="mandatory_tag">*</span>
        <input type="text" placeholder=""  name="other_contact_chineseName_dir" value="<?php echo $rowmember_dire['chinese_name']; ?>" id="other_contact_chineseName_dir">
    </label>
</div>
<div class="medium-12 columns membership_from">
    <label> Nationality:<span class="mandatory_tag">*</span></label>
<input type="radio" <?php if($rowmember_dire[ 'nationality']=='Swiss' ){ echo "checked"; }?> name="other_contact_nationality_dir" value="Swiss" id="other_contact_nationality_dir" class="other_contact_nationality" >
<label for="other_contact_nationality1" class="other_contact_nationality"> Swiss</label>
<input type="radio" <?php if($rowmember_dire[ 'nationality']=='Chinese' ){ echo "checked"; }?> name="other_contact_nationality_dir" value="Chinese" id="other_contact_nationality_dir" class="other_contact_nationality" >
<label for="other_contact_nationality2" class="other_contact_nationality"> Chinese</label>
<input type="radio" <?php if($rowmember_dire[ 'nationality']=='HongKong' ){ echo "checked"; }?> name="other_contact_nationality_dir" value="HongKong" id="other_contact_nationality_dir" class="other_contact_nationality" >
<label for="other_contact_nationality3" class="other_contact_nationality"> Hong Kong</label>
<input type="radio" <?php if($rowmember_dire[ 'nationality']=='Other' ){ echo "checked"; }?> name="other_contact_nationality_dir" value="Other" id="other_contact_nationality_dir" class="other_contact_nationality" >
<label for="other_contact_nationality4" class="other_contact_nationality"> Other</label>



</div>


<div class="medium-12 columns membership_from">
<label> Position In Company:<span>*</span>
<input type="text" name="other_contact_position_dir" value="<?php echo $rowmember_dire['positionIn_company']; ?>" id="other_contact_position_dir" />
</label>
</div>

<div class="medium-12 columns membership_from">
<label> Address in English:<span>*</span>
<textarea rows="3" name="other_contact_address_english_dir" id="other_contact_address_english_dir"><?php echo $rowmember_dire['address_english'];?></textarea>
</label>
</div>

<div class="medium-6 columns membership_from">
<label> City in English:<span>*</span>
<input type="text" name="other_contact_city_english_dir" value="<?php echo $rowmember_dire['city_english']; ?>" id="other_contact_city_english_dir" />
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Province/Area in English:<span>*</span>
<input type="text" name="other_contact_province_area_dir" value="<?php echo $rowmember_dire['province_area']; ?>" id="other_contact_province_area_dir"  />
</label>
</div>
<div class="medium-12 columns membership_from">
<label> Address in Chinese:<span>*</span>
<textarea rows="3" name="other_contact_address_chinese_dir" id="other_contact_address_chinese_dir"><?php  echo $rowmember_dire['address_chinese']; ?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label> City in Chinese <span>*</span>
<input type="text" name="other_contact_city_chinese_dir" value="<?php echo $rowmember_dire['city_chinese']; ?>" id="other_contact_city_chinese_dir" >
</label>
</div>
<div class="medium-6 columns membership_from">
<label>ZIP code:<span>*</span>
<input type="text" name="other_contact_zipCode_dir" value="<?php echo $rowmember_dire['zip_code_english']; ?>" id="other_contact_zipCode_dir" >
</label>
</div>




<div class="medium-6 columns membership_from">
<label>Mobile<span class="mandatory_tag">*</span>
<input type="text" placeholder=""  name="other_contact_mobile_dir" value="<?php echo $rowmember_dire['mobile_phone']; ?>" id="other_contact_mobile_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct phone<span class="mandatory_tag">*</span>
<input type="text" placeholder="" name="other_contact_directPhone_dir" value="<?php echo $rowmember_dire['direct_phone']; ?>" id="other_contact_directPhone_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct E-mail<span class="mandatory_tag">*</span>
<input type="text" placeholder="" name="other_contact_directEmail_dir" value="<?php echo $rowmember_dire['direct_email']; ?>" id="other_contact_directEmail_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>
</label>
</div>
</div>
<div class="medium-12 columns membership_from">
        <legend>Status </legend>
        <input <?php if($rowmember_dire['admin_approval']=='No' ){ echo "checked"; }?> type="radio" id="status" value="No" name="admin_approval">
        <label for="chinese"> Blocked</label>
        <input <?php if($rowmember_dire['admin_approval']=='Yes' ){ echo "checked"; }?> type="radio" <?php if($_GET['Userid']=='') { ?>checked="checked" <?php } ?> id="status" value="Yes" name="admin_approval">
        <label for="english"> Active</label>
</div>   
   <div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom">
    <a href="javascript:void(0);" id="memberDirectorySave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>  
</form>
</div>  




<!----------------------- Member Directory End ---------------------------------->
</div>
</div>
</div>
</div>

<?php
$companyDetailsQuery = "SELECT * FROM sc_c_company_details WHERE `userId`='".$userId."'";
$companyResult = mysql_query($companyDetailsQuery); 
$companyDetails = mysql_fetch_array($companyResult);
?>

<div>
<div class="row">
<div id="companyInfoTab">
<ul class="resp-tabs-list ver_1">
<li>Company Info</li>
<li>Headquarters Address</li>
<li>Membership</li>
<li>Other Company Info</li>
</ul>
<div class="resp-tabs-container ver_1">



<?php if(!empty($companyDetails['company_name_english'])){?>
<div>
    
<form name="companyBasicInfoForm" id="companyBasicInfoForm" action="admin_companyInfo_process.php?info=basic" method="POST"enctype='multipart/form-data'>
<input type="hidden" value="<?=$userId?>" name="userId" id="userId" />

<div class="row">
<div class="large-12 columns no_padding">
<input type="hidden" name="company_id" id="company_id" value="<?php if(!empty($companyDetails['company_id'])){echo $companyDetails['company_id']; }?>">
<div class="medium-12 columns membership_from">
<label>Business Scope<span class="mandatory_tag">*</span>
<select name="business_scope" id="business_scope">
    <option value="Agriculture / Food / Beverages" <?php if($companyDetails['business_scope']=='Agriculture / Food / Beverages'){ echo "selected"; }?>>Agriculture / Food / Beverages</option>
    <option value="Banking / Insurance" <?php if($companyDetails['business_scope']=='Banking / Insurance'){ echo "selected"; }?>>Banking / Insurance</option>
    <option value="Chemical / Pharmaceuticals" <?php if($companyDetails['business_scope']=='Chemical / Pharmaceuticals'){ echo "selected"; }?>>Chemical / Pharmaceuticals</option>
    <option value="Construction / Civil Engineering" <?php if($companyDetails['business_scope']=='Construction / Civil Engineering'){ echo "selected"; }?>>Construction / Civil Engineering</option>
    <option value="Education / Training" <?php if($companyDetails['business_scope']=='Education / Training'){ echo "selected"; }?>>Education / Training</option>
    <option value="Government / NGO / NPO / Economic Zone" <?php if($companyDetails['business_scope']=='Government / NGO / NPO / Economic Zone'){ echo "selected"; }?>> Government / NGO / NPO / Economic Zone</option>
    <option value="Hospitality / Hotels / Tourism Services" <?php if($companyDetails['business_scope']=='Hospitality / Hotels / Tourism Services'){ echo "selected"; }?>> Hospitality / Hotels / Tourism Services</option>
    <option value="Information Technology / Telecommunications" <?php if($companyDetails['business_scope']=='Information Technology / Telecommunications'){ echo "selected"; }?>>Information Technology / Telecommunications</option>
    <option value="Jewellery / Watches" <?php if($companyDetails['business_scope']=='Jewellery / Watches'){ echo "selected"; }?>> Jewellery / Watches</option>
    <option value="Machinery / Equipment" <?php if($companyDetails['business_scope']=='Machinery / Equipment'){ echo "selected"; }?>> Machinery / Equipment</option>
    <option value="Manufacturing / Electronic" <?php if($companyDetails['business_scope']=='Manufacturing / Electronic'){ echo "selected"; }?>> Manufacturing / Electronic</option>
    <option value="Media / Publication" <?php if($companyDetails['business_scope']=='Media / Publication'){ echo "selected"; }?>> Media / Publication</option>
    <option value="Medical / Precision / Optical Instruments" <?php if($companyDetails['business_scope']=='Medical / Precision / Optical Instruments'){ echo "selected"; }?>> Medical / Precision / Optical Instruments</option>
    <option value="Quality Control / Standards / Testing" <?php if($companyDetails['business_scope']=='Quality Control / Standards / Testing'){ echo "selected"; }?>>Quality Control / Standards / Testing</option>
    <option value="Trading / Logistics / Transportation" <?php if($companyDetails['business_scope']=='Trading / Logistics / Transportation'){ echo "selected"; }?>>Trading / Logistics / Transportation</option>
    <option value="Sales / Marketing / Retail" <?php if($companyDetails['business_scope']=='Sales / Marketing / Retail'){ echo "selected"; }?>>Sales / Marketing / Retail</option>
    <option value="Other" <?php if($companyDetails['business_scope']=='Other'){ echo "selected"; }?>>Other</option>
</select>
</label>
</div>

<div class="medium-12 columns membership_from" id="otherDiv" <?php if(!empty($companyDetails['other_business_scope'])){?>style="display:block" <?php } else{?>style="display:none"<?php } ?>>
<label for="other"> Other</label>
<input type="text" placeholder="" value="<?php if(!empty($companyDetails['other_business_scope'])){ echo $companyDetails['other_business_scope']; }?>" name="other_business_scope" id="other_business_scope">
</div>
<div class="medium-12 columns membership_from">
<label>
150 words in English<span class="mandatory_tag">*</span>
<textarea placeholder="" rows="2" name="business_description_english" id="business_description_english"><?php if(!empty($companyDetails['business_description_english'])){ echo trim($companyDetails['business_description_english']); }?></textarea>
<small></small>
</label>
</div>

<div class="medium-12 columns membership_from">
<label>
100 characters in Chinese<span class="mandatory_tag">*</span>
<textarea placeholder="" rows="2" name="business_description_chinese" id="business_description_chinese"><?php if(!empty($companyDetails['business_description_chinese'])){ echo trim($companyDetails['business_description_chinese']); }?></textarea>
<small></small>
</label>
</div>

<div class="medium-6 columns membership_from">
<label>Company name ( English )<span class="mandatory_tag">*</span>
<input type="text" value="<?=isset($companyDetails['company_name_english'])?$companyDetails['company_name_english']:"";?>" name="company_name_english" id="company_name_english">
<small></small>
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Company name ( Chinese )<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['company_name_chinese'])){echo $companyDetails['company_name_chinese']; }?>" name="company_name_chinese" id="company_name_chinese">
<small></small>
</label>
</div>

<div class="medium-12 columns membership_from">
<label>Address in English:<span class="mandatory_tag">*</span>
<textarea rows="3" name="company_address" id="company_address"><?php if(!empty($companyDetails['company_address'])){echo $companyDetails['company_address']; }?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label>City in English<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['company_city'])){echo $companyDetails['company_city']; }?>" name="company_city" id="company_city">
</label>
</div>


<div class="medium-6 columns membership_from">
<label>Province/Area in English<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['province_area_english'])){echo $companyDetails['province_area_english']; }?>" name="province_area_english" id="province_area_english">

</label>
</div>


<!-- <div class="medium-6 columns membership_from">
<label>Province/Area in English<span class="mandatory_tag">*</span>
<select name="province_area_english" id="province_area_english" style="margin-top:0px !important;">
    <option value="Beijing" <?php if($companyDetails['province_area_english']=='Beijing'){ echo 'selected'; }?>>Beijing</option>
    <option value="Shanghai" <?php if($companyDetails['province_area_english']=='Shanghai'){ echo 'selected'; }?>>Shanghai</option>
    <option value="Guangzhou" <?php if($companyDetails['province_area_english']=='Guangzhou'){ echo 'selected'; }?>>Guangzhou</option>
    <option value="HongKong" <?php if($companyDetails['province_area_english']=='HongKong'){ echo 'selected'; }?>>Hong Kong</option>
    <option value="ChinaMainland" <?php if($companyDetails['province_area_english']=='ChinaMainland'){ echo 'selected'; }?>>China Mainland</option>
</select>
</label>
</div>-->

<div class="medium-12 columns membership_from">
<label>Address in Chinese:<span class="mandatory_tag">*</span>
<textarea rows="3" name="china_office_address" id="china_office_address"><?php if(!empty($companyDetails['china_office_address'])){ echo trim($companyDetails['china_office_address']); }?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label>City in Chinese<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['china_office_city'])){ echo $companyDetails['china_office_city']; }?>" name="china_office_city" id="china_office_city">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Zip code<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['company_zipCode'])){ echo $companyDetails['company_zipCode']; }?>" name="company_zipCode" id="company_zipCode">
</label>
</div>

<div class="medium-6 columns application_form">
<label> General phone:<span>*</span>
<input type="text" name="company_generalPhone" id="company_generalPhone" value="<?php if(!empty($companyDetails['company_generalPhone'])){ echo $companyDetails['company_generalPhone']; }?>">
</label>
</div>
<div class="medium-6 columns application_form">
<label> General E-mail:<span>*</span>
<input type="text" value="<?php if(!empty($companyDetails['company_email'])){ echo $companyDetails['company_email']; }?>" name="company_email" id="company_email">
</label>
</div>
<div class="medium-6 columns application_form">
<label> General website:<span>*</span>
<input type="text" value="<?php if(!empty($companyDetails['company_website'])){ echo $companyDetails['company_website']; }?>" name="company_website" id="company_website">
</label>
</div>
<div class="medium-6 columns application_form">
<label>Legal entity <span>*</span>
<select name="legal_entity" id="legal_entity" style="margin-top:0px !important;">
    <option value=""> -Select-</option>
    <option value="domestic" <?php if($companyDetails['legal_entity']=='domestic'){ echo 'selected'; }?>> Chinese Domestic</option>
    <option value="joint" <?php if($companyDetails['legal_entity']=='joint'){ echo 'selected'; }?>>Joint-Venture</option>
    <option value="foreign" <?php if($companyDetails['legal_entity']=='foreign'){ echo 'selected'; }?>>Wholly Foreign-Owned</option>
    <option value="represent" <?php if($companyDetails['legal_entity']=='represent'){ echo 'selected'; }?>> Representative Office</option>
</select>
</label>
</div>
<div class="medium-12 columns membership_from" id="pre_logo" <?php if(!empty($companyDetails['logo_name'])){?> style="display:block"
<?php } else{?> style="display:none"
<?php }?>>
    <h5 class="tab_subheading">Logo</h5>
    <div class="upload_img_cont">
        <img src="<?php if(!empty($companyDetails['logo_name'])){echo $companyDetails['logo_name'];} else{echo " images/home-logo.png ";}?>" />
    </div>
    <div class="remove_btn"><a href="#" class="button holo_btn" id="removelogo">Remove</a></div>
</div>

<div class="large-12 columns" id="uplogo" <?php if(!empty($companyDetails[ 'logo_name'])){?> style="display:none;"
<?php }else{?> style="display:block;"
<?php }?>>
    <div class="margin_top10">
        <label for="exampleFileUpload2" class="button no_margin_bottom">Upload File</label>
        <input type="file" id="exampleFileUpload2" name="logo_name" class="show-for-sr" onchange="showImage(this,0);">
    </div>
    <small>Your virtual face or picture. Pictures larger than 1024x1024 pixels will be scaled down.</small>
    <label for="over_13" class="light" id="preview_label_id"></label>
    <div style="float:left;position:relative;">
        <img class="thumbnail" id="preview" src="" alt="" style="display:none;" />
    </div>

</div>
<div class="medium-6 columns application_form">
<label>Number of employees in <strong id="nmcmpno">Mainland China</strong><span>*</span>
<input type="text" name="no_of_employees" id="no_of_employees" value="<?php if(!empty($companyDetails['no_of_employees'])){ echo $companyDetails['no_of_employees']; }?>">
</label>
</div>
<?php if($companyDetails['company_chamber']!='HongKong'){?>
<div id="forAllOther">
<div class="medium-12 columns membership_from second_form_field">
<legend>Is your company Swiss-registered?</legend>
<input type="radio" name="is_company_swiss_registered" value="yes" id="sr_yes" <?php if($companyDetails['is_company_swiss_registered']=='yes'){ echo "checked"; }?>>
<label for="sr_yes"> Yes</label>
<input type="radio" name="is_company_swiss_registered" value="no" id="sr_no" <?php if($companyDetails['is_company_swiss_registered']=='no'){ echo "checked"; }?>>
<label for="sr_no"> No</label>
</div>


<div class="medium-12 columns membership_from second_form_field">
<legend>Is your company Swiss-registered?</legend>
<input type="radio" name="is_company_registered_PRC" value="yes" id="prc_reg_yes" <?php if($companyDetails['is_company_registered_PRC']=='yes'){ echo "checked"; }?>>
<label for="sr_yes"> Yes</label>
<input type="radio" name="is_company_registered_PRC" value="no" id="prc_reg_no" <?php if($companyDetails['is_company_registered_PRC']=='no'){ echo "checked"; }?>>
<label for="sr_no"> No</label>
</div>



<!--<div class="medium-12 columns membership_from second_form_field">
<legend>Are you registered in PRC with a valid business licence?</legend>
<input type="radio" name="is_company_registered_PRC" value="yes" id="prc_reg_yes" <?php if($companyDetails['is_company_registered_PRC']=='yes'){ echo "checked"; }?>
<label for="sr_yes"> Yes</label>
<input type="radio" name="is_company_registered_PRC" value="no" id="prc_reg_no" <?php if($companyDetails['is_company_registered_PRC']=='no'){ echo "checked"; }?>
<label for="sr_no"> No</label>
</div>-->
</div>
<?php } ?>
<?php if($companyDetails['company_chamber']=='HongKong'){?>
<div id="forOnlyHongKong">
<div class="medium-12 columns application_form">
<label>Year of Establishment in Hong Kong:<span>*</span>
    <input type="text" value="<?php if(!empty($companyDetails['establishment_hongkong'])){ echo $companyDetails['establishment_hongkong']; }?>" name="establishment_hongkong" id="establishment_hongkong">
</label>
</div>

<div class="medium-12 columns application_form">
<label>Geographical Responsibility of your company in Hong Kong:<span>*</span>
    <input type="text" value="<?php if(!empty($companyDetails['geographical_responsibility_hongkong'])){ echo $companyDetails['geographical_responsibility_hongkong']; }?>" name="geographical_responsibility_hongkong" id="geographical_responsibility_hongkong">
</label>
</div>
</div>
<?php } ?>

</div>
<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="basicInfoSave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>
</div>
                                                </form>
</div>




<div>
<form name="headquarterInfoForm" id="headquarterInfoForm" action="admin_companyInfo_process.php?info=headquarter" method="POST"enctype='multipart/form-data'>
<input type="hidden" value="<?=$userId?>" name="userId" id="userId" />



<div class="row">
<input type="hidden" name="company_id" id="company_id" value="<?php if(!empty($companyDetails['company_id'])){echo $companyDetails['company_id']; }?>">
<div class="large-12 columns">
<h5 class="tab_subheading">Headquarters</h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<div class="medium-12 columns application_form">
<label> Company Name:<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['headquarter_name'])){ echo $companyDetails['headquarter_name']; }?>" name="headquarter_name" id="headquarter_name">
</label>
</div>
<div class="medium-12 columns membership_from">
<label>Address in English:<span class="mandatory_tag">*</span>
<textarea rows="3" id="headquarter_address" name="headquarter_address"><?php if(!empty($companyDetails['headquarter_address'])){ echo $companyDetails['headquarter_address']; }?></textarea>
</label>
</div>
<div class="medium-6 columns membership_from">
<label>City in English<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['headquarter_city'])){ echo $companyDetails['headquarter_city']; }?>" name="headquarter_city" id="headquarter_city">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Zip code<span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($companyDetails['headquarter_zipCode'])){ echo $companyDetails['headquarter_zipCode']; }?>" name="headquarter_zipCode" id="headquarter_zipCode">
</label>
</div>
<!--<div class="medium-12 columns application_form">
<label> General phone:<span class="mandatory_tag">*</span>
<input type="text"value="<?php if(!empty($companyDetails['headquarter_phone'])){ echo $companyDetails['headquarter_phone']; }?>" name="headquarter_phone" id="headquarter_phone">
</label>
</div>-->

<div class="medium-6 columns application_form">
<label> General phone:<span class="mandatory_tag">*</span>
<input type="text"value="<?php if(!empty($companyDetails['headquarter_phone'])){ echo $companyDetails['headquarter_phone']; }?>" name="headquarter_phone" id="headquarter_phone">
</label>
</div>
<div class="medium-6 columns application_form">
<label> Province Area In English:<span class="mandatory_tag">*</span>
<input type="text"value="<?php if(!empty($companyDetails['headquarter_province_area_english'])){ echo $companyDetails['headquarter_province_area_english']; }?>" name="headquarter_province_area_english" id="headquarter_province_area_english">
</label>
</div>

<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="headquarterInfoSave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>
</div>
        </form>
</div>


<div>
<div class="row">
<div class="medium-12 columns membership_from">
<legend>Chamber</legend>
<div>
<input id="general" type="radio" name="company_chamber" value="General" <?php if($companyDetails[ 'company_chamber']=='General' ){ echo "checked";}?>>
<label for="general">General</label>
</div>
<div>
<input id="beijing" type="radio" name="company_chamber" value="Beijing" <?php if($companyDetails[ 'company_chamber']=='Beijing' ){ echo "checked";}?>>
<label for="checkbox2">Beijing</label>
</div>
<div>
<input id="shanghai" type="radio" name="company_chamber" value="Shanghai" <?php if($companyDetails[ 'company_chamber']=='Shanghai' ){ echo "checked";}?>>
<label for="checkbox3">Shanghai</label>
</div>
<div>
<input id="guangzhou" type="radio" name="company_chamber" value="Guangzhou" <?php if($companyDetails[ 'company_chamber']=='Guangzhou' ){ echo "checked";}?>>
<label for="guang">Guangzhou</label>
</div>
<div>
<input id="hong_kong" type="radio" name="company_chamber" value="HongKong" <?php if($companyDetails[ 'company_chamber']=='HongKong' ){ echo "checked";}?>>
<label for="hong_kong">Hong Kong</label>
</div>
<small>Used to filtered results by the global filter. Will be display only if chamber ticked correspond to the chamber chosen on the top left corner. </small>
</div>
<div class="medium-12 columns membership_from">
<label>Membership
<select id="company_membership" name="company_membership" class="form-select">
<option value="">- None -</option>
<option value="19" <?php if($companyDetails[ 'company_membership']==19){echo "selected";}?>>Large Corporate</option>
<option value="10" <?php if($companyDetails[ 'company_membership']==10){echo "selected";}?>>Small / Medium Corporate</option>
<option value="37" <?php if($companyDetails[ 'company_membership']==37){echo "selected";}?>>Individual</option>
<option value="26" <?php if($companyDetails[ 'company_membership']==26){echo "selected";}?>>Large Corporate Associate</option>
<option value="218" <?php if($companyDetails[ 'company_membership']==218){echo "selected";}?>>Small / Medium Corporate Associate</option>
<option value="27" <?php if($companyDetails[ 'company_membership']==27){echo "selected";}?>>Individual Associate</option>
<option value="55" <?php if($companyDetails[ 'company_membership']==55){echo "selected";}?>>Young Professional</option>
<option value="219" <?php if($companyDetails[ 'company_membership']==219){echo "selected";}?>>Honorary</option>
<option value="230" <?php if($companyDetails[ 'company_membership']==230){echo "selected";}?>>Corporate A</option>
<option value="231" <?php if($companyDetails[ 'company_membership']==231){echo "selected";}?>>Corporate B</option>
<option value="232" <?php if($companyDetails[ 'company_membership']==232){echo "selected";}?>>Corporate C</option>
<option value="112" <?php if($companyDetails[ 'company_membership']==112){echo "selected";}?>>---</option>
</select>
</label>
</div>
<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="accountSave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>
</div>
</div>



<div>

<?php
$i=0;
$otherContactDetailsQuery = "SELECT * FROM `sc_c_company_other_contact_details` WHERE `company_id`='".$companyDetails['company_id']."'";
$otherContactResult = mysql_query($otherContactDetailsQuery); 
?>
<form name="companyContactOtherInfoForm" id="companyContactOtherInfoForm" action="admin_companyInfo_process.php?info=other" method="POST" enctype='multipart/form-data'>
<input type="hidden" name="company_id" id="company_id" value="<?php if(!empty($companyDetails['company_id'])){echo $companyDetails['company_id']; }?>">
<input type="hidden" value="<?=$userId?>" name="userId" id="userId" />
<div class="row">

        <!-- Loop Start Here -->
        <?php	
                while($otherContactDetails = mysql_fetch_array($otherContactResult)){
                $i++;
        ?>
        <div id="companyAdddiv_<?=$i?>">

<div class="large-12 columns">
<h5 class="tab_subheading">Other Contact <?=$i?></h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>


<div class="medium-6 columns membership_from">
<label>Company Name in English <span class="mandatory_tag">*</span>
<input type="text" value="<?php if(!empty($otherContactDetails['other_company_name_english'])){ echo $otherContactDetails['other_company_name_english']; }?>" name="other_company_name_english[]" id="other_company_name_english<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Company Name in Chinese<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_company_name_chinese'])){ echo $otherContactDetails['other_company_name_chinese']; } ?>" name="other_company_name_chinese[]" id="other_company_name_chinese<?=$i?>">
</label>
</div>


                <div class="medium-12 columns membership_from">
<label> Address in English:<span>*</span>
<textarea rows="3" name="other_company_address[]" id="other_company_address<?=$i?>"><?php if(!empty($otherContactDetails['other_company_address'])){ echo $otherContactDetails['other_company_address']; } ?></textarea>
</label>
                </div>

                <div class="medium-6 columns membership_from">
<label> City in English:<span>*</span>
<input type="text" name="other_company_city[]" id="other_company_city<?=$i?>" value="<?php if(!empty($otherContactDetails['other_company_city'])){ echo $otherContactDetails['other_company_city']; } ?>" />
</label>
                </div>
                <div class="medium-6 columns membership_from">
<label>Province/Area in English:<span>*</span>
<input type="text" name="other_province_area_english[]" id="other_province_area_english<?=$i?>" value="<?php if(!empty($otherContactDetails['other_province_area_english'])){ echo $otherContactDetails['other_province_area_english']; } ?>" />


</label>
                </div>
                <div class="medium-12 columns membership_from">
<label> Address in Chinese:<span>*</span>
<textarea rows="3" name="other_china_office_address[]" id="other_china_office_address<?=$i?>"><?php if(!empty($otherContactDetails['other_china_office_address'])){ echo $otherContactDetails['other_china_office_address']; } ?></textarea>
</label>
                </div>
                <div class="medium-6 columns membership_from">
<label> City in Chinese <span>*</span>
<input type="text" name="other_china_office_city[]" id="other_china_office_city<?=$i?>" value="<?php if(!empty($otherContactDetails['other_china_office_city'])){ echo $otherContactDetails['other_china_office_city']; } ?>">
</label>
                </div>
                <div class="medium-6 columns membership_from">
<label>ZIP code:<span>*</span>
<input type="text" name="other_company_zipCode[]" id="other_company_zipCode<?=$i?>" value="<?php if(!empty($otherContactDetails['other_company_zipCode'])){ echo $otherContactDetails['other_company_zipCode']; } ?>">
</label>
                </div>
<div class="medium-6 columns membership_from">
<label>General phone<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php  if(!empty($otherContactDetails['other_company_generalPhone'])){ echo $otherContactDetails['other_company_generalPhone']; }?>" name="other_company_generalPhone[]" id="other_company_generalPhone<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>General E-mail<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_company_email'])){ echo $otherContactDetails['other_company_email']; }?>" name="other_company_email[]" id="other_company_email<?=$i?>">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>General website<span class="mandatory_tag">*</span>
<input type="text" placeholder="" value="<?php if(!empty($otherContactDetails['other_company_website'])){ echo $otherContactDetails['other_company_website']; }?>" name="other_company_website[]" id="other_company_website<?=$i?>">
</label>
</div>
                <div class="medium-6 columns membership_from">
<label>
</label>
</div>
</div>
        <?php } ?>
                <!-- Loop End Here -->
<div class="medium-12 columns membership_from">
<p class="add_field user_add_field" id="CompanyAddmore" <?php if($i>2){ echo "style='display:none;'"; }else{ echo "style='display:block;'";}?>>
<a href="javascript:void(0)" class="holo_button">
<i class="fa fa-plus-circle" aria-hidden="true"></i> Add new contact
</a>
</p>
<p class="add_field user_add_field" id="CompanyRemovebtn" <?php if($i>0){ echo "style='display:block;'"; }else{ echo "style='display:none;'";}?>>
<a href="javascript:void(0)" class="holo_button">
<i class="fa fa-times-circle" aria-hidden="true"></i> Remove last contact
</a>
</p>
                        <input type="hidden" name="CompanyAddcnt" value="<?=$i?>" id="CompanyAddcnt">
</div>
                <div id="companyAppenddiv"></div>
<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0);" id="otherCompanyContactSave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>   
</div>
        </form>

</div>






<?php } ?>
</div>
</div>
</div>
</div>
<div>
<?php $newsletter=explode(',',$row['newsletter']);
$newsletterArray=array();
$ctn=count($newsletter);
for($i=0;$i<$ctn;$i++){
array_push($newsletterArray,$newsletter[$i]);
}
                ?>
<div class="row">
<div class="large-12 columns">
<h5 class="tab_subheading">Tick the box to subscribe to the following newsletter:</h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<form name="newsLetterForm" id="newsLetterForm" action="newsletter_process.php" method="POST">
<div class="medium-12 columns membership_from">
<legend>Check these out</legend>
<div>
<input id="bj_news" value="bj_news" type="checkbox" name="newsletter[]" <?php if(in_array( 'bj_news', $newsletterArray)){ echo "checked";}?>>
<label for="bj_news">Reader's Digest + BJ Newsletter</label>
</div>
<small>Compilation of Sino-Swiss Business related news sent every other Fridays + BJ Newsletter</small>
<div>
<input id="sha_news" value="sha_news" type="checkbox" name="newsletter[]" <?php if(in_array( 'sha_news', $newsletterArray)){ echo "checked";}?>>
<label for="sha_news">Reader's Digest + SHA Newsletter</label>
</div>
<small>Compilation of Sino-Swiss Business related news sent every other Fridays + SHA Newsletter</small>
<div>
<input id="gz_news" value="gz_news" type="checkbox" name="newsletter[]" <?php if(in_array( 'gz_news', $newsletterArray)){ echo "checked";}?>>
<label for="gz_news"> Reader's Digest + GZ Newsletter</label>
</div>
<small>Compilation of Sino-Swiss Business related news sent every other Fridays + GZ Newsletter</small>
</div>
<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0)" class="button regnext_btn no_margin_bottom" id="newsLetterSubmit">Save</a></p>
</div>
</form>

</div>
</div>

        <!-- Changes Done Start | 2-11-2016 -->

        <!--  <div>
<div class="row">
                        <form name="questionForm" id="questionForm" action="question_process.php" method="POST">
<div class="large-12 columns">
<h5 class="tab_subheading">SUBMIT A QUESTION</h5>
</div>
<div class="large-12 columns">
<hr class="common_devider" />
</div>
<div class="medium-12 columns membership_from">
<small>If you have a question for the Experts' Corner, please enter it below.</small>
<label>
    Enter your question below<span class="mandatory_tag">*</span>
    <textarea placeholder="" rows="2" name="question" id="question"><?php if(!empty($row['question'])){echo $row['question']; }?></textarea>
    <small>Please write down a short introduction of your company and describe what your core business is (for corporate members only).</small>
</label>
</div>

<div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom"><a href="javascript:void(0)" class="button regnext_btn no_margin_bottom" id="questionSubmit">Save</a></p>
</div>
                                </form>
</div>
</div>



        <div>
            <?php /*
                $cornerQuery="SELECT * FROM `sc_c_expert_corner_article` WHERE `userId`='$userId'";
                $CornerResult=mysql_query($cornerQuery);
                $ExpertResult=mysql_fetch_array($CornerResult);*/
                ?>
                <form name="expertCornerForm" id="expertCornerForm" action="expert_corner_process.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="medium-12 columns membership_from">
                            <label>Title <span class="mandatory_tag">*</span>
                                <input type="text" placeholder="" value="<?php //if(!empty($ExpertResult)){ echo $ExpertResult['corner_title']; }?>" name="corner_title" id="corner_title">

                            </label>
                        </div>
                        <div class="medium-12 columns membership_from">

                            <label>
                                Body (Edit summary)
                                <textarea placeholder="" rows="2" name="corner_body" id="corner_body">
                                    <?php //if(!empty($ExpertResult)){ echo $ExpertResult['corner_body']; }?>
                                </textarea>
                                <small>Disable rich-text</small>
                            </label>
                        </div>
                        <div class="medium-12 columns membership_from">
                            <label>Text format
                                <select name="text_format" id="text_format">
                                    <option value="husker" <?php // if(!empty($ExpertResult)){ if($ExpertResult[ 'text_format']=='husker' ){ echo "selected"; } }?>>Filtered HTML</option>
                                    <option value="starbuck" <?php // if(!empty($ExpertResult)){ if($ExpertResult[ 'text_format']=='starbuck' ){ echo "selected"; } }?>>Plain Text</option>
                                </select>
                            </label>
                        </div>
                        <div class="medium-12 columns membership_from">
                            <ul class="tab_list">
                                <li>Web page addresses and e-mail addresses turn into links automatically.</li>
                                <li>
                                    <p class="no_margin_bottom">Allowed HTML tags:
                                        <br> &lt;a&gt; &lt;em&gt; &lt;strong&gt; &lt;cite&gt; &lt;blockquote&gt; &lt;code&gt; &lt;ul&gt; &lt;ol&gt; &lt;li&gt; &lt;dl&gt; &lt;dt&gt; &lt;dd&gt; &lt;p&gt; &lt;br&gt;
                                    </p>
                                </li>
                                <li>Lines and paragraphs break automatically.</li>
                            </ul>
                        </div>
                        <div class="medium-12 columns membership_from">
                            <label>Tags
                                <input type="text" placeholder="" value="<?php // if(!empty($ExpertResult)){ echo $ExpertResult['tag_name']; }?>" name="tag_name" id="tag_name">

                            </label>
                        </div>

                        <div class="large-12 columns">
                            <h5 class="tab_subheading">Add a new file</h5>
                        </div>
                        <div class="large-12 columns">
                            <hr class="common_devider">
                        </div>
                        <div class="large-12 columns">
                            <div>
                                <label for="exampleFileUpload1" class="button no_margin_bottom">Upload File</label>
                                <input type="file" id="exampleFileUpload1" class="show-for-sr" name="expert_file" onchange="showImage2(this,0);">
                            </div>
                            <div id="expert_corner_process_file">

                            </div>
                            <small>Files must be less than 20 MB. <br>
       Allowed file types: jpg jpeg gif png pdf mp4 doc docx xls xlsx.</small>
                        </div>
                        <div class="medium-12 columns membership_from">
                            <p class="text-right no_margin_bottom"><a href="#" class="button holo_btn">Preview</a> <a href="javascript:void(0)" class="button regnext_btn" id="expertCornerSave">Save</a></p>
                        </div>
                </form>
                </div>
        </div> -->

        <!-- Changes Done end | 2-11-2016 -->




</div>

        <div>
            <p style="text-align: right; margin-right: 35px;"><a href="admin.php" class="button regnext_btn no_margin_bottom" id="newsLetterSubmit">Back to admin</a></p>
        </div>

    </div>
</div>

        </div>

        <div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
            <div class="large-12 columns inner_right_panel">
                <div class="large-12 columns right_y_join margin_top10">
                    <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                    <p class="text-center">Because Connections Matter.</p>
                    <ul class="fa-ul join_button_group">
                        <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                        <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                    </ul>
                </div>
                <div class="large-12 columns right_y_join margin_top10">
                    <div class="flex-video right_panel_video">
                        <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="large-12 columns right_y_join margin_top10">
                    <h3 class="common_subheading">Strategic Partner</h3>
                    <ul class="fa-ul inner_sponser_img">
                        <li><img src="images/inner_sponser1.jpg" /></li>
                        <li><img src="images/inner_sponser2.jpg" /></li>
                        <li><img src="images/inner_sponser3.jpg" /></li>
                    </ul>
                </div>
                <div class="large-12 columns">
                    <hr class="right_devider" />
                </div>
                <div class="large-12 columns right_y_join margin_top10">
                    <h3 class="common_subheading">Upcoming events</h3>
                    <div class="tab_list_item">
                        <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                        <h5>Venue Name</h5>
                        <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                    </div>
                    <div class="tab_list_item">
                        <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                        <h5>Venue Name</h5>
                        <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                    </div>
                    <div class="tab_list_item">
                        <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                        <h5>Venue Name</h5>
                        <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                    </div>
                    <a class="see_more_link" href="#">read more</a>
                </div>
                <div class="large-12 columns">
                    <hr class="right_devider" />
                </div>
                <div class="large-12 columns right_y_join margin_top10">
                    <h3 class="common_subheading">NEWSLETTER</h3>
                    <p class="">Interested in trying one? Use the form below to get in touch.</p>
                    <form>
                        <ul class="fa-ul right_newsletter_form">
                            <li>
                                <label>
                                    <input type="text" placeholder="Name">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="Surname">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="Company">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="Email">
                                </label>
                            </li>
                            <li class="text-left newsletter_button_sec">
                                <a href="#" class="button newsletter_button">Subscribe</a>
                            </li>
                        </ul>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
                <!--<section class="main_sponsor_sec">
                    <div class="row">
                        <div class="large-12 columns">
                            <div class="mainSponsor">
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                                </div>
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                                </div>
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                                </div>
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                                </div>
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                                </div>
                                <div class="">
                                    <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>-->

                <?php 
    require_once(__ROOT__.'/includes/footer.php'); 
    ?><!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please fill the information to Login</h1>
                        <p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                    </label>
                                </div>
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
                    <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


                    <nav id="log_togg">
                        <ul class="logsec_sidenav">
                            <li><a href="#">Login</a></li>
                            <li class="side_joinnow"><a href="#">Join US</a></li>
                            <li class="right_menu_heading show-for-medium-only">Select Language</li>
                            <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
                        </ul>
                    </nav>

                    <nav id="menu">
                        <ul>
                            <!--
            <li class="region_side_icon"><a href="index.html">Home</a></li>
            <li class="region_side_icon"><a href="beijing.html">Beijing</a></li>
            <li class="region_side_icon"><a href="shanghai.html">Shanghai</a></li>
            <li class="region_side_icon"><a href="guangzhou.html">Guangzhou</a></li>
            <li class="region_side_icon"><a href="hongkong.html">Hong Kong</a></li>
-->
                            <!--                <li class="right_menu_heading show-for-small-only">Select Language</li>-->
                            <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                            <!--                <li class="right_menu_heading inlineblock_element">Select Location</li>-->
                            <li class="region_side_icon">
                                <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                                    <option value="index.html">Home</option>
                                    <option value="beijing.html">Beijing</option>
                                    <option value="shanghai.html">Shanghai</option>
                                    <option value="guangzhou.html">Guangzhou</option>
                                    <option value="hongkong.html">Hong Kong</option>
                                </select>
                            </li>
                            <li><a href="#about">ABOUT US</a>
                                <ul>
                                    <li><a href="b-whatwedo.html">Who are we?</a></li>
                                    <li><a href="#">History</a></li>
                                    <li><a href="#">Rules</a></li>
                                    <li><a href="#">Board of Directors</a></li>
                                    <li><a href="#">Management</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </li>
                            <li><a href="#about">MEMBERSHIP</a>
                                <ul>
                                    <li>
                                        <a href="#">Why join us?</a>
                                    </li>
                                    <li>
                                        <a href="#">Online Application</a>
                                    </li>
                                    <li>
                                        <a href="#">Members Directory</a>
                                    </li>
                                    <li>
                                        <a href="#">Investment Zones</a>
                                    </li>
                                    <li>
                                        <a href="#">Member Benefits Program</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#about">EVENTS</a>
                                <ul>
                                    <li>
                                        <a href="b-events.html">Upcoming Events</a>
                                    </li>
                                    <li>
                                        <a href="#">Events Calendar</a>
                                    </li>
                                    <li>
                                        <a href="#">Events Overview</a>
                                    </li>
                                    <li>
                                        <a href="#">Company Visits</a>
                                    </li>
                                </ul>
                            </li>


                            <li><a href="#about">PUBLICATIONS</a>
                                <ul>
                                    <li>
                                        <a href="#">The Bridge</a>
                                    </li>
                                    <li>
                                        <a href="b-news.html">Sino-Swiss Business News</a>
                                    </li>
                                    <li>
                                        <a href="b-reader-digest.html">Reader’s Digest</a>
                                    </li>
                                    <li>
                                        <a href="#">Legal & Investment Updates</a>
                                    </li>
                                    <li>
                                        <a href="#">Invest in Switzerland</a>
                                    </li>
                                    <li>
                                        <a href="#">Business Publications</a>
                                    </li>
                                    <li>
                                        <a href="#">Other Links</a>
                                    </li>
                                </ul>
                            </li>

                            <li><a href="#about">SERVICES</a>
                                <ul>
                                    <li>
                                        <a href="#">Our services</a>
                                    </li>
                                    <li>
                                        <a href="#">Job Opportunities</a>
                                    </li>
                                    <li>
                                        <a href="#">Advertise With Us</a>
                                    </li>
                                    <li>
                                        <a href="#">Training</a>
                                    </li>
                                    <li>
                                        <a href="#">Lobbying Activities</a>
                                    </li>
                                    <li>
                                        <a href="#">Wechat?</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>

                    </nav>


        </div>

        <a href="#0" class="cd-top">Top</a>




        <script src="bower_components/jquery/dist/jquery.js"></script>
        <script src="bower_components/what-input/what-input.js"></script>
        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/easyResponsiveTabs.js"></script>
        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
        <script type="text/javascript" src="js/pace.js"></script>
        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        <script>
            setTimeout(function () {
                $("#other_contact_dobc1").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1950:'+(new Date).getFullYear() 
                });
            }, 1000);
        </script>
        <script>
            setTimeout(function () {
                    $("#other_contact_dob_dir").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1950:'+(new Date).getFullYear()  
                });
            }, 1000);
        </script>
        
        <script type="text/javascript">
            $(function () {
                $('nav#menu').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: true,
                    counters: false,
                    "offCanvas": {
                        "position": "left"
                    },
                    navbar: {
                        title: 'SWISSCHAM'
                    },
                    navbars: [{
                        position: 'top',
                        content: ['searchfield']
                    }, {
                        position: 'top',
                        content: [
                            'prev',
                            'title',
                            'close'
                        ]
                    }, {
                        position: 'bottom',
                        content: [
                            //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                        ]
                    }]
                });
                $('nav#log_togg').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: false,
                    counters: false,
                    navbar: {
                        title: 'Welcome to Swisscham'
                    },
                    navbars: [{
                        position: 'bottom',
                        content: [
                            '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /> Wechat</a></span>',
                            '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /> LinkedIn</a></span>'
                        ]
                    }]

                });

            });
        </script>
        <script src="js/app.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                //Horizontal Tab
                $('#eventListTab').easyResponsiveTabs({
                    type: 'default', //Types: default, vertical, accordion
                    width: 'auto', //auto or any width like 600px
                    fit: true, // 100% fit in a container
                    tabidentify: 'hor_1', // The tab groups identifier
                    activate: function (event) { // Callback function if tab is switched
                        var $tab = $(this);
                        var $info = $('#nested-tabInfo');
                        var $name = $('span', $info);
                        $name.text($tab.text());
                        $info.show();
                    }
                });
                // Child Tab
                $('#ChildVerticalTab_1').easyResponsiveTabs({
                    type: 'vertical',
                    width: 'auto',
                    fit: true,
                    tabidentify: 'ver_1', // The tab groups identifier
                    activetab_bg: '#fff', // background color for active tabs in this group
                    inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
                    active_border_color: '#c1c1c1', // border color for active tabs heads in this group
                    active_content_border_color: '#aa0008' // border color for active tabs contect in this group so that it matches the tab head border
                });
                $('#companyInfoTab').easyResponsiveTabs({
                    type: 'vertical',
                    width: 'auto',
                    fit: true,
                    tabidentify: 'ver_1', // The tab groups identifier
                    activetab_bg: '#fff', // background color for active tabs in this group
                    inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
                    active_border_color: '#c1c1c1', // border color for active tabs heads in this group
                    active_content_border_color: '#aa0008' // border color for active tabs contect in this group so that it matches the tab head border
                });

            });
        </script>
 <script>
            $('document').ready(function() {


                $('.stateDrop').change(function() {
                    $('.b_no_member').hide();
                });
                $('#removebtn').click(function() {
                    var addcnt = $('#addcnt').val();
                    if (addcnt > 0) {
                        var rmvid = 'adddiv_' + addcnt;
                        $('#' + rmvid).remove();
                        addcnt--;
						$('#addcnt').val(addcnt);
                        if (addcnt == 1) {
                            $('#removebtn').hide();
                            //$('#addmore').show();
                        }
						if (addcnt >= 1) {
                            $('#addmore').show();
                        }
                    }
                });
                $('#addmore').click(function() {
                	
                	var addcnt = $('#addcnt').val();
					var cmp=$('#compsnyORnot').val();
                    if (addcnt < 3) {
                        addcnt++;
                        if (addcnt >= 3) {
                            $('#addmore').hide();
                        }
                        $('#addcnt').val(addcnt);
                        $('#removebtn').show();
                        if(cmp==0){
                                $('#appenddiv').append('<div id="adddiv_' + addcnt + '"><div class="large-12 columns"><h5 class="tab_subheading">Other Contact' + addcnt + '</h5></div><div class="large-12 columns"><hr class="common_devider" /></div><div class="medium-12 columns membership_from second_form_field"><label></label><input type="radio" name="other_contact_title' + addcnt + '" value="Ms" checked><label for="info_asst_contact_miss"> Ms.</label><input type="radio" name="other_contact_title' + addcnt + '" value="Mr"><label for="info_asst_contact_mister"> Mr.</label><input type="radio" name="other_contact_title' + addcnt + '" value="Dr"><label for="info_asst_contact_doctor"> Dr.</label></div><div class="medium-6 columns application_form"><label>Date of Birth: <span class="mandatory_tag">*</span><input type="text" value="" name="other_contact_dob[]" id="other_contact_dob' + addcnt + '" class="other_contact_dob" placeholder="Please Enter Date of Birth"></label></div><div class="medium-6 columns application_form"><label> Family name:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter family name" name="other_contact_familyName[]" id="other_contact_familyName' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Given name(s):<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter given name(s)" name="other_contact_givenName[]" id="other_contact_givenName' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Chinese name:<span>*</span><div class="input-group"><input type="text" placeholder="请输入您的姓名" name="other_contact_chineseName[]" id="other_contact_chineseName' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-12 columns membership_from second_form_field"><label> Nationality:<span class="mandatory_tag">*</span></label><input type="radio" name="other_contact_nationality' + addcnt + '" value="Swiss" id="other_contact_nationality1' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality1' + addcnt + '>" class="other_contact_nationality"> Swiss</label><input type="radio" name="other_contact_nationality' + addcnt + '" value="Chinese" id="other_contact_nationality2' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality2' + addcnt + '" class="other_contact_nationality"> Chinese</label><input type="radio" name="other_contact_nationality' + addcnt + '" value="HongKong" id="other_contact_nationality3' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality3' + addcnt + '" class="other_contact_nationality"> Hong Kong</label><input type="radio" name="other_contact_nationality' + addcnt + '" value="Other" id="other_contact_nationality4' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality4' + addcnt + '" class="other_contact_nationality"> Other</label></div><div class="medium-12 columns application_form"><label> Address in English:<span>*</span><textarea rows="3" name="other_contact_address_english[]" id="other_contact_address_english' + addcnt + '" placeholder="Please Enter Address In English"></textarea></label></div><div class="medium-6 columns application_form"><label> City in English:<span>*</span><input type="text" name="other_contact_city_english[]" id="other_contact_city_english' + addcnt + '" value="" placeholder="Please Enter City In english"/></label></div><div class="medium-6 columns application_form"><label>Province/Area in English:<span>*</span><input type="text" name="other_contact_province_area[]" id="other_contact_province_area' + addcnt + '" value="" placeholder="Please Enter Province/Area In English"></label></div><div class="medium-12 columns application_form"><label> Address in Chinese:<span>*</span><textarea rows="3" name="other_contact_address_chinese[]" id="other_contact_address_chinese' + addcnt + '" placeHolder="Please Enter Address In Chinese"></textarea></label></div><div class="medium-6 columns application_form"><label> City in Chinese <span>*</span><input type="text" name="other_contact_city_chinese[]" id="other_contact_city_chinese' + addcnt + '" value="" placeholder="Please Enter City In Chinese"></label></div><div class="medium-6 columns application_form"><label>ZIP code:<span>*</span><input type="text" name="other_contact_zipCode[]" id="other_contact_zipCode' + addcnt + '" value="" placeholder="Please Enter Zip Code"></label></div><div class="medium-6 columns application_form"><label> Mobile:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter mobile number" name="other_contact_mobile[]" id="other_contact_mobile' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Direct Phone:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter direct phone number" name="other_contact_directPhone[]" id="other_contact_directPhone' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Direct E-mail:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct E-mail" name="other_contact_directEmail[]" id="other_contact_directEmail' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label></label></div></div>');
                        } else if(cmp==1){
                                $('#appenddiv').append('<div id="adddiv_' + addcnt + '"><div class="large-12 columns"><h5 class="tab_subheading">Other Contact' + addcnt + '</h5></div><div class="large-12 columns"><hr class="common_devider" /></div><div class="medium-12 columns membership_from second_form_field"><label></label><input type="radio" name="other_contact_titlec' + addcnt + '" value="Ms" checked><label for="info_asst_contact_miss"> Ms.</label><input type="radio" name="other_contact_titlec' + addcnt + '" value="Mr"><label for="info_asst_contact_mister"> Mr.</label><input type="radio" name="other_contact_titlec' + addcnt + '" value="Dr"><label for="info_asst_contact_doctor"> Dr.</label></div><div class="medium-6 columns application_form"><label>Date of Birth: <span class="mandatory_tag">*</span><input type="text" value="" name="other_contact_dobc[]" id="other_contact_dobc' + addcnt + '" class="other_contact_dob" placeholder="Please Enter Date of Birth"></label></div><div class="medium-6 columns application_form"><label> Family name:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter family name" name="other_contact_familyNamec[]" id="other_contact_familyNamec' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Given name(s):<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter given name(s)" name="other_contact_givenNamec[]" id="other_contact_givenNamec' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Chinese name:<span>*</span><div class="input-group"><input type="text" placeholder="请输入您的姓名" name="other_contact_chineseNamec[]" id="other_contact_chineseNamec' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-12 columns membership_from second_form_field"><label> Nationality:<span class="mandatory_tag">*</span></label><input type="radio" name="other_contact_nationalityc' + addcnt + '" value="Swiss" id="other_contact_nationality1c' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality1c' + addcnt + '>" class="other_contact_nationality"> Swiss</label><input type="radio" name="other_contact_nationalityc' + addcnt + '" value="Chinese" id="other_contact_nationality2c' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality2c' + addcnt + '" class="other_contact_nationality"> Chinese</label><input type="radio" name="other_contact_nationalityc' + addcnt + '" value="HongKong" id="other_contact_nationality3c' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality3c' + addcnt + '" class="other_contact_nationality"> Hong Kong</label><input type="radio" name="other_contact_nationalityc' + addcnt + '" value="Other" id="other_contact_nationality4c' + addcnt + '" class="other_contact_nationality"><label for="other_contact_nationality4c' + addcnt + '" class="other_contact_nationality"> Other</label></div><div class="medium-12 columns application_form"><label> Position In Company:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Position In Company" name="other_contact_positionc[]" id="other_contact_positionc' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-12 columns application_form"><label> Address in English:<span>*</span><textarea rows="3" name="other_contact_address_englishc[]" id="other_contact_address_englishc' + addcnt + '" placeholder="Please Enter Address In English"></textarea></label></div><div class="medium-6 columns application_form"><label> City in English:<span>*</span><input type="text" name="other_contact_city_englishc[]" id="other_contact_city_englishc' + addcnt + '" value="" placeholder="Please Enter City In english"/></label></div><div class="medium-6 columns application_form"><label>Province/Area in English:<span>*</span><input type="text" name="other_contact_province_areac[]" id="other_contact_province_areac' + addcnt + '" value="" placeholder="Please Enter Province/Area In English"></label></div><div class="medium-12 columns application_form"><label> Address in Chinese:<span>*</span><textarea rows="3" name="other_contact_address_chinesec[]" id="other_contact_address_chinesec' + addcnt + '" placeHolder="Please Enter Address In Chinese"></textarea></label></div><div class="medium-6 columns application_form"><label> City in Chinese <span>*</span><input type="text" name="other_contact_city_chinesec[]" id="other_contact_city_chinesec' + addcnt + '" value="" placeholder="Please Enter City In Chinese"></label></div><div class="medium-6 columns application_form"><label>ZIP code:<span>*</span><input type="text" name="other_contact_zipCodec[]" id="other_contact_zipCodec' + addcnt + '" value="" placeholder="Please Enter Zip Code"></label></div><div class="medium-6 columns application_form"><label> Mobile:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter mobile number" name="other_contact_mobilec[]" id="other_contact_mobilec' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Direct Phone:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter direct phone number" name="other_contact_directPhonec[]" id="other_contact_directPhonec' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label> Direct E-mail:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct E-mail" name="other_contact_directEmailc[]" id="other_contact_directEmailc' + addcnt + '" class="otherValidate"></div></label></div><div class="medium-6 columns application_form"><label></label></div></div>');
                        }
                        
                    }
                });
            });


        </script>
        
        
        
        <script>
            $('document').ready(function() {
                $('#CompanyRemovebtn').click(function() {
                    var CompanyAddcnt = $('#CompanyAddcnt').val();
                    if (CompanyAddcnt > 0) {
                        var rmvid = 'companyAdddiv_' + CompanyAddcnt;
                        $('#' + rmvid).remove();
                        CompanyAddcnt--;
                        $('#CompanyAddcnt').val(CompanyAddcnt);
                        if (CompanyAddcnt == 0) {
                            $('#CompanyRemovebtn').hide();
                            //$('#addmore').show();
                        }
                        if (CompanyAddcnt >= 1) {
                            $('#CompanyAddmore').show();
                        }
                    }
                });
                $('#CompanyAddmore').click(function() {
                    var addcnt = $('#CompanyAddcnt').val();
                    
                    if (addcnt < 2) {
                        addcnt++;
                        $('#CompanyAddcnt').val(addcnt);
                        $('#CompanyRemovebtn').show();
                        $('#companyAppenddiv').append('<div id="companyAdddiv_' + addcnt + '"><div class="large-12 columns"><h5 class="tab_subheading">Other Contact' + addcnt + '</h5></div><div class="large-12 columns"><hr class="common_devider" /></div><div class="medium-6 columns membership_from"><label>Company Name in English <span class="mandatory_tag">*</span><input type="text" value="" name="other_company_name_english[]" id="other_company_name_english' + addcnt + '"></label></div><div class="medium-6 columns membership_from"><label>Company Name in Chinese<span class="mandatory_tag">*</span><input type="text" placeholder="" value="" name="other_company_name_chinese[]" id="other_company_name_chinese' + addcnt + '"></label></div><div class="medium-12 columns membership_from"><label> Address in English:<span>*</span><textarea rows="3" name="other_company_address[]" id="other_company_address' + addcnt + '"></textarea></label></div><div class="medium-6 columns membership_from"><label> City in English:<span>*</span><input type="text" name="other_company_city[]" id="other_company_city' + addcnt + '" value=""></label></div><div class="medium-6 columns membership_from"><label>Province/Area in English:<span>*</span><input type="text" name="other_province_area_english[]" id="other_province_area_english' + addcnt + '" value=""></label></div><div class="medium-12 columns membership_from"><label> Address in Chinese:<span>*</span><textarea rows="3" name="other_china_office_address[]" id="other_china_office_address' + addcnt + '"></textarea></label></div><div class="medium-6 columns membership_from"><label> City in Chinese <span>*</span><input type="text" name="other_china_office_city[]" id="other_china_office_city' + addcnt + '" value=""></label></div><div class="medium-6 columns membership_from"><label>ZIP code:<span>*</span><input type="text" name="other_company_zipCode[]" id="other_company_zipCode' + addcnt + '" value=""></label></div><div class="medium-6 columns membership_from"><label>General phone<span class="mandatory_tag">*</span><input type="text" placeholder="" value="" name="other_company_generalPhone[]" id="other_company_generalPhone' + addcnt + '"></label> </div><div class="medium-6 columns membership_from"><label>General E-mail<span class="mandatory_tag">*</span><input type="text" placeholder="" value="" name="other_company_email[]" id="other_company_email' + addcnt + '"></label></div><div class="medium-6 columns membership_from"><label>General website<span class="mandatory_tag">*</span><input type="text" placeholder="" value="" name="other_company_website[]" id="other_company_website' + addcnt + '"></label></div><div class="medium-6 columns membership_from"><label></label></div></div>');
                    
                    }
                });
            });

        </script>
        
        
    </body>

    </html>


