<?php 
/*
template name: Event calender General

*/

get_header();
    $swisschkr = multisite_globalizer(); ?>
    
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
           <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>                        <?php if(is_singular( 'news' )) { ?>
                        <li><a href="<?php echo home_url(); ?>/news/">Events</a></li>
                        <!-- <li>
                                <span class="show-for-sr">Current: </span>News
                        </li> -->
                        <?php } else { ?>
                        <li>
                           <?php if( have_posts() ); ?>
                                 <?php 
                                       while( have_posts() ) : the_post(); ?>
                                          <span class="show-for-sr">Current: </span>Events
                                  <?php endwhile; ?>        
                        </li>
                        <li><span class="show-for-sr">Current: </span>Event Calendar</li>
                        <?php }
                         ?>
                    </ul>
                </nav>
            </div>-->
            <?php  echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
   

    <div class="legend" style="margin-left:16px;">
<?php //colours for the different cells
$beijing = "#ff8080"; $shanghai = "#66a3ff"; $guangzhou = "#47d147"; $hongkong = "#d580ff"; ?>

       <!--<p> Colours of the events in the calendar: </p>-->
       <table style="width:40%;">
         <tr>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $beijing; ?>"></td><td width="10%">Beijing</td>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $shanghai; ?>"></td><td width="10%">Shanghai</td>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $guangzhou; ?>"></td><td width="10%">Guangzhou</td>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $hongkong; ?>"></td><td width="10%">Hongkong</td>
         </tr>
       </table>
    </div>
                    <div class="large-12 columns dowedo_top">
                        <?php echo do_shortcode('[events_calendar full=1 long_events=1]'); ?>
                        <?php //echo do_shortcode('[events_calendar full=1 long_events=1 category="51"]'); ?>
                    </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>
        
        
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>    
   <script>  
       
    $('.fullcalendar .eventful li a.hongkong').click(function()
    { 
        var mb = $('#eve_id').text();
        var array = mb.split(",");
        //alert(array[0]);
        
        
     $(this).attr("href","<?php bloginfo('url')?>/hk/event-details/?id="+array[0]);
    });   
       
    

   </script>​​
   
    <script>  
       
    $('.fullcalendar .eventful li a.beijing').click(function()
    { 
        var mb = $('#eve_id').text();
        var array = mb.split(",");
        //alert(array[0]);
        
        
     $(this).attr("href","<?php bloginfo('url')?>/bei/event-details/?id="+array[0]);
    });   
       
    

   </script>​​
   
   <script>  
       
    $('.fullcalendar .eventful li a.shanghai').click(function()
    { 
        var mb = $('#eve_id').text();
        var array = mb.split(",");
        //alert(array[0]);
        
        
     $(this).attr("href","<?php bloginfo('url')?>/sha/event-details/?id="+array[0]);
    });   
       
    

   </script>​​
   
   <script>  
       
    $('.fullcalendar .eventful li a.guangzhou').click(function()
    { 
        var mb = $('#eve_id').text();
        var array = mb.split(",");
        //alert(array[0]);
        
        
     $(this).attr("href","<?php bloginfo('url')?>/gz/event-details/?id="+array[0]);
    });   
       
    

   </script>​​
        
        
        
<?php 
          get_footer('event');
         ?>