<?php
/*
    Template Name: WhorweHK
*/

    get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
<li>
  <span class="show-for-sr">Current: </span> About Us 
</li>
                        <li>
        <?php if ( $swisschkr==1 ) { ?>
            <span class="show-for-sr">Current: </span> SwissCham Hong Kong - What do we do?
        <?php } if ( $swisschkr==2 ) { ?>
            <span class="show-for-sr">Current: </span> SwissCham Beijing - What do we do?
        <?php } if ( $swisschkr==3 ) { ?>
            <span class="show-for-sr">Current: </span> SwissCham Shanghai - What do we do?
        <?php } if ( $swisschkr==4 ) { ?>
            <span class="show-for-sr">Current: </span> SwissCham Guangzhou - What do we do?
        <?php } if ( $swisschkr==5 ) { ?>
            <span class="show-for-sr">Current: </span> SwissCham Hong Kong - What do we do?
        <?php } ?>

                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                
        <?php if ( $swisschkr==1 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $swawhk = get_post( 93 ); ?>
                    <?php $swawhkimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swawhk->ID ), 'single-post-thumbnail' ); ?>
                        <h1 class="common_heading"><?php echo $swawhk->post_title; ?></h1>
                        <?php if (!($swawhkimg=='')) { ?>
                            <p class="text-right"><img src="<?php echo $swawhkimg[0]; ?>" /></p>
                        <?php } ?>
                        <?php echo get_field( "content", 93 ); ?>
                    </div>
        <?php } if ( $swisschkr==2 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $swawhk = get_post( 173 ); ?>
                    <?php $swawhkimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swawhk->ID ), 'single-post-thumbnail' ); ?>
                        <h1 class="common_heading"><?php echo $swawhk->post_title; ?></h1>
                        <?php if (!($swawhkimg=='')) { ?>
                            <p class="text-right"><img src="<?php echo $swawhkimg[0]; ?>" /></p>
                        <?php } ?>
                        <?php echo get_field( "content", 173 ); ?>
                    </div>
        <?php } if ( $swisschkr==3 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $swawhk = get_post( 137 ); ?>
                    <?php $swawhkimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swawhk->ID ), 'single-post-thumbnail' ); ?>
                        <h1 class="common_heading"><?php echo $swawhk->post_title; ?></h1>
                        <?php if (!($swawhkimg=='')) { ?>
                            <p class="text-right"><img src="<?php echo $swawhkimg[0]; ?>" /></p>
                        <?php } ?>
                        <?php echo get_field( "content", 137 ); ?>
                    </div>
        <?php } if ( $swisschkr==4 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $swawhk = get_post( 108 ); ?>
                    <?php $swawhkimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swawhk->ID ), 'single-post-thumbnail' ); ?>
                        <h1 class="common_heading"><?php echo $swawhk->post_title; ?></h1>
                        <?php if (!($swawhkimg=='')) { ?>
                            <p class="text-right"><img src="<?php echo $swawhkimg[0]; ?>" /></p>
                        <?php } ?>
                        <?php echo get_field( "content", 108 ); ?>
                    </div>
        <?php } if ( $swisschkr==5 ) { ?>
        <?php
        	 global $switched;
         switch_to_blog(5); ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $swawhk = get_post( 131 ); ?>
                    <?php $swawhkimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swawhk->ID ), 'single-post-thumbnail' ); ?>
                        <h1 class="common_heading"><?php echo $swawhk->post_title; ?></h1>
                        <?php if (!($swawhkimg=='')) { ?>
                            <p class="text-right"><img src="<?php echo $swawhkimg[0]; ?>" /></p>
                        <?php } ?>
                        <?php echo get_field( "content", 131 ); ?>
                    </div>
                   <?php restore_current_blog(); ?>
        <?php } ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>


                </div>
        <?php get_sidebar(); ?>
                <!--<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="images/inner_sponser1.jpg" /></li>
                                <li><img src="images/inner_sponser2.jpg" /></li>
                                <li><img src="images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>-->
            </div>
        </section>
        <?php if ( $swisschkr==1 ) {
            get_footer();
         } if ( $swisschkr==2 ) {
            get_footer('bei');
         } if ( $swisschkr==3 ) {
            get_footer('sha');
         } if ( $swisschkr==4 ) {
            get_footer('gz');
         } if ( $swisschkr==5 ) {
            get_footer('hk');
         } ?>