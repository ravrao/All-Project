<?php 
/*
Template Name: WhyJoinUs SwissCham Hong Kong
*/
	get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                         <li>
                            <span class="show-for-sr">Current: </span> Membership
                        </li> 
                        <li>
                            <span class="show-for-sr">Current: </span> Why Join Us - SwissCham Hong Kong
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 651 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 651); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('member_benifites_title', 651); ?></h3>
                        <?php echo get_field('member_benefits', 651); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('meet,_learn,_exchange_and_celebrate_title', 651); ?></h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 651); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading"><?php echo get_field('make_your_voice_heard_title!', 651); ?></h3>
                        <?php echo get_field('make_your_voice_heard!', 651); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 651); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('be_visible_title', 651); ?></h3>
                        <?php echo get_field('be_visible!', 651); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('fees_title', 651); ?></h3>
                        <?php echo get_field('fees', 651); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 651); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    
                    <?php if(get_field('blank_title', 651, true)) {?>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"> <?php echo get_field('blank_title', 651); ?></h3>
                        <?php echo get_field('blank_description', 651); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 651); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <?php } ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>


                </div>

                <?php get_sidebar(); ?>

                            </div>
        </section>

                <?php get_footer(); ?>