<?php
/*
	Template Name: Legal & Investment
*/
	get_header();
	$swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Legal And Investment Updates
                        </li>
                    </ul>
                </nav>
            </div>-->
        <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
        <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_725 = get_post( 725 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_725->post_title; ?></h1>
						<?php $pagebgz725 = $post_725->post_content;

                            $pagebgz725 = apply_filters('the_content', $pagebgz725);
                            $pagebgz725 = str_replace(']]>', ']]&gt;', $pagebgz725);
                            echo $pagebgz725;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                        <?php echo get_field('for_further_advice', 725); ?>
                        </div>
                        <?php echo get_field('contact_details', 725); ?>
                    </div>
                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_725 = get_post( 222 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_725->post_title; ?></h1>
						<?php $pagebgz725 = $post_725->post_content;

                            $pagebgz725 = apply_filters('the_content', $pagebgz725);
                            $pagebgz725 = str_replace(']]>', ']]&gt;', $pagebgz725);
                            echo $pagebgz725;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                        <?php echo get_field('for_further_advice', 222); ?>
                        </div>
                        <?php echo get_field('contact_details', 222); ?>
                    </div>
                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_725 = get_post( 180 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_725->post_title; ?></h1>
						<?php $pagebgz725 = $post_725->post_content;

                            $pagebgz725 = apply_filters('the_content', $pagebgz725);
                            $pagebgz725 = str_replace(']]>', ']]&gt;', $pagebgz725);
                            echo $pagebgz725;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                        <?php echo get_field('for_further_advice', 180); ?>
                        </div>
                        <?php echo get_field('contact_details', 180); ?>
                    </div>
                </div>
        <?php } if ( $swisschkr==4 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_725 = get_post( 147 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_725->post_title; ?></h1>
						<?php $pagebgz725 = $post_725->post_content;

                            $pagebgz725 = apply_filters('the_content', $pagebgz725);
                            $pagebgz725 = str_replace(']]>', ']]&gt;', $pagebgz725);
                            echo $pagebgz725;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                        <?php echo get_field('for_further_advice', 147); ?>
                        </div>
                        <?php echo get_field('contact_details', 147); ?>
                    </div>
                </div>
        <?php } if ( $swisschkr==5 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_725 = get_post( 153 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_725->post_title; ?></h1>
						<?php $pagebgz725 = $post_725->post_content;

                            $pagebgz725 = apply_filters('the_content', $pagebgz725);
                            $pagebgz725 = str_replace(']]>', ']]&gt;', $pagebgz725);
                            echo $pagebgz725;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                        <?php echo get_field('for_further_advice', 153); ?>
                        </div>
                        <?php echo get_field('contact_details', 153); ?>
                    </div>
                </div>
        <?php } ?>
        
                <?php get_sidebar(); ?>
            </div>
        </section>
        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>