<?php
/*
	Template Name: Company Visits
*/
	get_header(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Events
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Company Visits
                        </li>
                    </ul>
                </nav>
            </div>-->
           <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_70 = get_post( 297 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_70->post_title; ?></h1>
                        <?php $pagebgz70 = $post_70->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>

                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <p>See our past Company Visits:</p>
                    </div>
                    <div class="large-12 columns" data-equalizer="boardDetailsAlign">
                        <div class="row" data-equalizer="boardOuter">
                            <?php global $switched;
                                        switch_to_blog(1);
             $spnbtarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $spnbt_array = get_posts( $spnbtarg );
           
            foreach ($spnbt_array as $spnbt_arr) {

            $spnbtimg = wp_get_attachment_image_src( get_post_thumbnail_id( $spnbt_arr->ID ), '' );  ?>

<?php $colors = get_field('do_you_want', $spnbt_arr->ID);

    if( $colors ): 

         foreach( $colors as $color ):

                    if ($color=='yes') { ?>
    
                            <div class="large-4 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">
                                    <div class="com_visit_img">
                                        <p class="text-center">
                                        <?php if (!($spnbtimg[0]=='')) { ?>
                                            <img src="<?php echo $spnbtimg[0]; ?>" />
                                        <?php } else { ?>
                                            <img src="<?php echo web_url(); ?>wp-content/uploads/2016/12/imgpsh_fullsize.jpeg" />
                                        <?php } ?>
                                        </p>
                                    </div>
                                    <div class="com_visit_details" data-equalizer-watch="boardDetailsAlign">
                                        <h3><a href="<?php echo esc_url( get_permalink($spnbt_arr->ID) ); ?>"><i class="fa fa-check-square-o" aria-hidden="true"></i> <?php echo $spnbt_arr->post_title; ?></a></h3>
                                    </div>

                                    <div class="com_visit_details">
                                        <h5 class="text-right"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo do_shortcode('[event post_id="'.$spnbt_arr->ID.'"]#d #F #Y[/event]'); ?></h5>
                                    </div>
                                </div>
                            </div>

            <?php }  endforeach;  endif; ?>

            <?php } restore_current_blog(); ?>

                        </div>
                    </div>

                </div>

        <?php get_sidebar(); ?>

           </div>
        </section>

        <?php get_footer('bei'); ?>