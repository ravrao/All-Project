<?php
/*
template name: Single Event Shanghai

*/
get_header();

switch_to_blog(1);

query_posts("p=1802");
 $swisschkr = multisite_globalizer(); 
//$fetchtid = get_the_ID();
$fetchtid =1802;
//echo $fetchtid;

?>


    <?php $getrecipedetail = get_post_meta($fetchtid,'pm_enterroute'); 
    $getspeakername = get_post_meta($fetchtid,'pm_speaker'); 
    
    $getcontactetail = get_post_meta($fetchtid,'contact');
    
    $getcontUS = get_post_meta($fetchtid,'pm_enterroute');
    
    //print_r($getcontUS);
    
    $getspeakername_ravi = get_post_meta($fetchtid,'pm_seteventtype'); 
    

    $getlatituteandlongitude = get_post_meta($fetchtid,'pm_taxidirection'); 
$getlocation = get_post_meta($fetchtid,'pm_chinese');

     $enviradetails= get_post_meta($fetchtid, 'pm_envgallery'); 
     $fetchcode= $enviradetails[0][0]['envira-gallery-shortcode'];
     $speakercode= $getspeakername[0][0]['enter-speaker-details'];

 //print_r($getrecipedetail);
//$getlatuitute= $getlatituteandlongitude[0][0]['enter-latitiute'];
//$getlongitute= $getlatituteandlongitude[0][0]['enter-longititute'];
 $uploadedimage =  get_post_meta($getrecipedetail[0][0]['map-image'],'_wp_attached_file');
 // print_r($uploadedimage);
 $upload_dir = wp_upload_dir();
 //print_r($upload_dir);
 // echo $upload_dir['baseurl']; 
 ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <?php if(is_singular( 'news' )) { ?>
                            <li><a href="<?php echo home_url(); ?>/news/">Events</a></li>
                            <!-- <li><span class="show-for-sr">Current: </span>News</li> -->
                            <?php } else { ?>
                            <?php if( have_posts() ); ?>
                            <?php while( have_posts() ) : the_post(); ?>
                                <li><span class="show-for-sr">Current: </span><?php echo "Events"; ?></li>
                                <li><span class="show-for-sr">Current: </span><?php the_title(); ?></li>
                            <?php endwhile; ?>
                        <?php } ?>
                    </ul>
                </nav>
            </div>--> 
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo get_the_title($fetchid);?></h1>
                    </div>
                    <div class="large-12 columns no_padding" data-equalizer="event_box_align">
                        <div class="large-8 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">
                                <ul class="fa-ul no-bullet event_list_details">
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <span class="event_list_name">TIME</span>
                                            <?php echo do_shortcode('[event]#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME[/event]'); 
											
											
											
                                                ?>
                                                <?php $dt=do_shortcode('[event]#d #F #Y[/event]');

                                                $ctadte=date('d F Y');
                                                ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span> <span class="event_list_name">Venue</span>
                                            <?php echo do_shortcode('[event]#_LOCATIONNAME[/event]'); ?>
                                            
                                            <?php echo do_shortcode('[event post_id="1802"]#_LOCATIONNAME[/event]' );?>
                                            
                                            <?php echo do_shortcode('[event post_id="1802"]My selected event is called #_EVENTNAME[/event]');?>
                                            
                                            
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span>
                                            <?php echo do_shortcode('[event]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>
                                            
                                             <?php echo do_shortcode('[event post_id="1802"]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]');?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">PRICE</span> Member
                                            <?php $minprice= do_shortcode('[event]#_EVENTPRICEMIN[/event]'); 
 $minexploded=explode(".",$minprice); echo $minexploded[0];
                                             ?> | Non Members
                                                <?php $maxprice= do_shortcode('[event]#_EVENTPRICEMAX[/event]');
 $maxexploded=explode(".",$maxprice); echo $maxexploded[0];
                                                 ?>
                                        </p>
                                    </li>

                                </ul>
                            </div>

                        </div>

<?php $createstartdate= do_shortcode('[event]#Y#m#d T #H#i#s[/event]'); $withoutspacestart=str_replace(' ', '', $createstartdate); ?>
<?php $createenddatedate= do_shortcode('[event]#@Y#@m#@d T #@H#@i#@s[/event]'); $withoutspaceend=str_replace(' ', '', $createenddatedate); 

$sendtitle=get_the_title($fetchid);
    

?>

                        <div class="large-4 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">
							
							
							<?php $ctadte=strtotime($ctadte); ?>
							<?php $dt=strtotime($dt); ?>
                                <p class="register_button">
                                <?php if($ctadte<=$dt){?>
                                <a href="javascript:void(0);" class="button expanded common_button" data-toggle="eventRegModal">Register Now</a>
                               
                                
                               
 <?php } else{?>
                                <a href="javascript:void(0);" class="button expanded common_button disabled">Register Now</a>
                                <?php }?>
                                </p>
                                <ul class="fa-ul no-bullet register_sublist">
                                    <li><a href="<?php echo web_url(); ?>calendercreator/?withoutspacestart=<?php echo $withoutspacestart; ?>&withoutspaceend=<?php echo $withoutspaceend ;?>&sendtitle=<?php echo $sendtitle ;?>" class="">Add to calendar</a></li>
                                    <li><a  target="_blank" href="<?php echo web_url(); ?>baidu-test/?contentval=<?php echo get_the_ID();?>" class="">Taxi directions</a></li>
                                </ul>
 
                             
                            </div>

                        </div>
                    </div>
                    <div class="large-12 columns">
                        <div id="eventListTab">
                             <?php if($getspeakername_ravi[0][0]['select-event']=='Workshop') {?>
                            <ul class="resp-tabs-list hor_1 innerpage_tab min_ul_width">
                             <?php } else { ?>
                                <ul class="resp-tabs-list hor_1 innerpage_tab">
                             <?php } 
                             
                             ?>
                                
                                <li class="tab_active">Event Info</li>
                                <li>agenda</li>
                                <li class="lcn">location</li>
                                <li>contact</li>
                                <?php if($getspeakername_ravi[0][0]['select-event']=='Workshop') {?>
                                 <li>Speakers</li>
                                <?php } ?>
                            </ul>
                            <div class="resp-tabs-container hor_1 eventtab_list_details">
                                <div>
                                    <div class="eventtab_list_item">
                                        <?php if( have_posts() ); ?>

                                            <?php 
                               while( have_posts() ) : the_post(); ?>

                                                <?php the_content(); ?>
                                                    <?php endwhile; ?>



<?php if($fetchcode != ''){ ?>
   <div class="innercontentdesign"><i class="fa fa-picture-o" aria-hidden="true"></i> Gallery:</div> 
 <?php  echo do_shortcode($fetchcode); 
    } ?>

                                    </div>
                                </div>

                                <div>
                                    <div class="eventtab_list_item">
                                        <?php //echo do_shortcode('[event]#_CATEGORYALLEVENTS[/event]'); ?>
                                        
                                        <?php $getlatituteandlongitude_cont = get_post_meta($fetchtid,'related_content_field'); 
                                        //var_dump($getlatituteandlongitude_cont);
                                        echo $getlatituteandlongitude_cont[0][0]['agenda-items'];;
                                        ?>

                                    </div>
                                </div>

                                <div>
                                    <div class="eventtab_list_item">
                                        <?php //echo do_shortcode('[event]#_LOCATIONFULLBR[/event]'); ?>
                                            <p>
                                                <?php //echo $getrecipedetail[0][0]['enter-route-description'];?>
                                            </p>
					<?php $getlocationforchines =$getlocation[0][0]['enter-chinese-location']; 
//echo $getlocationforchines;
                                            ?>
                            <input type="hidden" name="address" id="address1" value="<?=$getlocationforchines?>"/>
                            <div style="width:100%;height:300px;border:#ccc solid 1px;float:left;" id="dituContent1"></div><br/>
                           <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
                            
                           
                           <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
                            <script type="text/javascript">
                                    $(document).ready(function(){
                                    //$('.lcn').click(function(){
                                    /* var lang=113.52897592105;
                                    var lat=23.142106886029;	
                                    var point = new BMap.Point(lang,lat);	
                                    var address='上海大酒店，上海，中国';
                                    geocoder = new BMap.Geocoder();

                                            //alert(geocoder)
                                            geocoder.getPoint(address, function(res){
                                            console.log(res)
                                            //console.log(res)

                                    }) */

                                    var address=$('#address1').val();
                                    //var city=$('#city').val();
                                    //alert(address);
                                    //var lat=$('#lat').val();
                                    var map = new BMap.Map("dituContent1");
                                    geocoder = new BMap.Geocoder(); 

                                    //geocoder.getPoint('北京市东城区长巷二�?�乙5�?�', function(res){



                                    geocoder.getPoint(address, function(res){
                                            console.log(res)
                                            //console.log(res)
                                    console.log(res.lat)
                                            var lng=res.lng;
                                            var lat=res.lat;
                                            //alert(res.address);
                                            //var address=res.address;
                                            //$('#address').html(address);

                                            var point = new BMap.Point(lng,lat);
                                            //log(res.lat)
                                            var sContent =
                                                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                                                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
                                            //var icon = new BMap.Icon('http://www.transcommgroup.com/assets/img/pin1.png', new BMap.Size(20, 32), {//
                                            //                   anchor: new BMap.Size(10, 30),
                                            //                 infoWindowAnchor: new BMap.Size(10, 0)
                                            //});

                                            var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                                                            anchor: new BMap.Size(10, 30),
                                                            infoWindowAnchor: new BMap.Size(10, 0)
                                            });
                                            var marker = new BMap.Marker(point, {
                                                            icon: icon,
                                                            title: address
                                            }); 

                                            <!--AXIUS: opts variable has been included and the same has been set below -->
                                            /* var opts = {
                                            //width : 500,
                                            //height: 70,
                                            title : "Shanghai Office" ,
                                            enableMessage:true,
                                            message:"北京市�?阳区光�?�路4�?�东方梅地亚中心A座903室"
                                            } */

                                            <!--AXIUS: opts variable set here below -->

                                            //var marker = new BMap.Marker(point);
                                            var infoWindow = new BMap.InfoWindow(sContent);
                                            map.centerAndZoom(point, 15);
                                            map.enableScrollWheelZoom();
                                            map.addOverlay(marker);
                                            marker.addEventListener("click", function(){
                                            this.openInfoWindow(infoWindow);
                                            document.getElementById('imgDemo').onload = function (){
                                            infoWindow.redraw();
      
    }
    </script>
    <?php
     restore_current_blog();   
     
     ?>