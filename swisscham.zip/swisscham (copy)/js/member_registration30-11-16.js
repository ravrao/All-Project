
$(document).ready(function () {
	
	//alert();
	$(".all_drop_content").hide();
	$("#beQ1").hide();
	$("#beQ2").hide();
	$("#beQ3").hide();	
	$("#beQ4").hide();
	$("#beQ5").hide();
	/*$("#beQ6").hide();
	$("#beQ7").hide();
	$("#beQ8").hide();*/
	
	$("#shQ1").hide();
	$("#shQ2").hide();
	$('#shQ3').hide();
	$("#shQ3_sec").hide();
	$('#shQ4').hide();
	/* $('#shQ5').hide();
	$('#shQ6').hide();
	$('#shQ7').hide();
	$('#shQ8').hide();
	$('#shQ9').hide(); */
	
	$("#hkQ1").hide();
	$("#hkQ2").hide();
	$("#hkQ3").hide();
	$("#hkQ4").hide();
	
	$("#cmQ1").hide();
	$("#cmQ2").hide();
	$("#cmQ3").hide();
	$("#cmQ4").hide();
	
	$("#guaQ1").hide();
	$("#guaQ2").hide();
	$("#guaQ3").hide();
	$("#guaQ3_sec").hide();
	$("#guaQ4").hide();
	
	
	$('body').on('change','#stateDrop',function(){
		var a = $(this).val();
		//alert(a);
		if (a == "Beijing")
		{		
		$(".all_drop_content").hide();
		$(".beijing_drop_content").show();
		$("#beQ1").show();
        }
		
        else if (a == "Shanghai")
		{		
		$(".all_drop_content").hide();
		$(".shanghai_drop_content").show();
		$("#shQ1").show();
        }
		
		else if (a == "HongKong")
		{		
		$(".all_drop_content").hide();
		$(".hongkong_drop_content").show();
		$("#hkQ1").show();
        }
		
		else if (a == "ChinaMainland")
		{		
		$(".all_drop_content").hide();
		$(".china_mainland_drop_content").show();
		$("#cmQ1").show();
        }
		
		else if (a == "Guangzhou")
		{		
		$(".all_drop_content").hide();
		$(".guangzhou_drop_content").show();
		$("#guaQ1").show();
        }
		
        else
		{
		 $(".all_drop_content").hide();
		}		
		
	});
	
	$(".aurSection").hide();
	$('.button_for_advanced').click(function() {		
			$('.ulSection').hide();
			$('.aurSection').show();		
	});
	
	$('.button_for_user_list').click(function() {
			$('.aurSection').hide();
			$('.ulSection').show();		
	});
	
	
});




