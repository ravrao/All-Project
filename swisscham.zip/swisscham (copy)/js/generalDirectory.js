$('document').ready(function () {

	$('.chemberClass').click(function(){
		var company_chamber = $(this).data("id");
		$('#company_chamber').val(company_chamber);
		$('#business_scope').val('');
		$('#searchName').val('');
		//alert($('#business_scope').val());
		$("#searchForm").submit();
	});
	$('.nameClass').click(function(){
		var searchName = $(this).data("id");
		$('#searchName').val(searchName);
		$('#business_scope').val('');
		$('#company_chamber').val('');
		$("#searchForm").submit();
	});
	$('.businessScopeClass').click(function(){
		var business_scope = $(this).data("id");
		console.log(business_scope);
		$('#business_scope').val(business_scope);
		$('#company_chamber').val('');
		$('#searchName').val('');
		$("#searchForm").submit();
	});
	$("#searchButton").click(function(){
		$("#searchForm").submit();
	});

});
