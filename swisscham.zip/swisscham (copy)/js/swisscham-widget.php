<?php 
/*Plugin Name: Subpages Widget
Description: This widget checks if the current page has parent or child pages and if so, outputs a list of the highest ancestor page and its descendants. This file supports part 1 of the series to create the widget and doesn't give you a functioning widget.
Version: 0.1
Author: Sandeep Kumar
Author URI: http://54.152.108.131/SwissCham/
License: GPLv2
*/

class Swisscham_Widget extends WP_Widget {
     
    function __construct() {
    	parent::__construct('Swisscham_Widget','swisscham partner');
        parent::__construct('Swisscham_Widget','upcoming events');
         
    
    }
     
    function form( $instance ) {

    }
     
    function update( $new_instance, $old_instance ) {       
    }
     
    function widget( $args, $instance ) {
         ?>
            <div class="partners">
            <h3 class=common heading>STRATEGIC PARTNER</h3>
            <ul class=images>
             
                 <?php
                 
                    $query = new WP_Query("post_type=strategicpartner");
                    while($query->have_posts()) : $query->the_post(); 
                   
                    
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), '');
                  // print_r($image);
                ?>

                            
              </ul>
               <ul class="banner"><img src="<?php echo $image[0]; ?>" alt="">
                 <?php endwhile; ?>
             </ul> 
             </div>   



             <div class="events">
            <h3 class=common heading>upcoming events</h3>
            <ul class=images>
             
                 <?php
                 
                    $query1 = new WP_Query("post_type=upcomingevent");
                    while($query1->have_posts()) : $query1->the_post(); 
                     the_date();
                      the_title();
                      
                      
                    
                   // $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), '');
                   // print_r($image);
                ?>
              <h5><?php the_content(); ?></h5>  
                            
              </ul>
               
                 <?php endwhile; ?>
               
             </div>   
         <?php
    }
     
}

function swisscham_register_widget() {
 
    register_widget('Swisscham_Widget');
    //register_widget('Upcomingevent_Widget');
 
}
add_action('widgets_init', 'swisscham_register_widget');

?>