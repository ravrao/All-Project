  var $=jQuery;
$(document).ready(function(){

	var prev=$('#dgtouch').html(); 
	//alert(prev);

    //$(".custom_directory_name_list li a").click(function(event){
    $('body').on('click', '.custom_directory_name_list li a', function(event) {
        
	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);
	$('.alppha').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	//var slug=$(this).attr('data-term');
	var alpha = $(this).text();
	//alert(alpha);
	//var obj=$(this);

	$.ajax({
		url: base_url+'/wp-admin/admin-ajax.php',
		type: 'POST',
		dataType: 'html',
		data: {action: 'swissmd', slug: alpha},
	})
	.done(function(xhr) {

		$('#dgtouch').html(xhr);
		console.log("success");
	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});

        //alert("The paragraph was clicked.");
    });


        //$(".custom_directory_name_list li a").click(function(event){
    $('body').on('click', '.mdsearch', function(event) {
        
	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);transform:
	//<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">
	$('#dgtouch').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	//var slug=$(this).attr('data-term');
	var alpha2 = $('#mdsrchkeywrd').val();
	//alert(alpha2);
	//var obj=$(this);

	$.ajax({
		url: base_url+'/wp-admin/admin-ajax.php',
		type: 'POST',
		dataType: 'html',
		data: {action: 'swissmdkeyword', slug2: alpha2},
	})
	.done(function(xhr2) {

		$('#dgtouch').html(xhr2);
		console.log("success");
	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});

        //alert("The paragraph was clicked.");
    });

// Members by chapter

    $('body').on('click', '.mdmi', function(event) {
        
	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);transform:
	//<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">
	$('#dgtouch').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	var alpha3=$(this).attr('data-value');

			$.ajax({
				url: base_url+'/wp-admin/admin-ajax.php',
				type: 'POST',
				dataType: 'html',
				data: {action: 'swissmdbychapter', slug3: alpha3},
			})
			.done(function(xhr3) {

				$('#dgtouch').html(xhr3);
				console.log("success");
			})
			.fail(function() {
				console.log("error");
			})
			.always(function() {
				console.log("complete");
			});

    });

// News Filter cat

$(document).on('change', '#snb', function(event) {

	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);transform:
	//<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">
	$('.newsfilter').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	//var alpha5=$(this).attr('data-value');
	var alpha5=$('#snb option:selected').text();
	//alert(slug3);
	//var alpha3 = $('#mdsrchkeywrd').val();
	//alert(alpha2);
	//var obj=$(this);
	if (!(alpha5=='select')) {
	$.ajax({
		url: base_url+'/wp-admin/admin-ajax.php',
		type: 'POST',
		dataType: 'html',
		data: {action: 'swissnews', slug5: alpha5},
	})
	.done(function(xhr5) {

		if (!(xhr5=='')) {
			$('.newsfilter').html(xhr5);
			console.log("success");
		} else {
			$('.newsfilter').html('<div class="large-12 columns directory_sort"><div class="large-9 columns directory_item_details small_padding"><h2>No result found...</h2></div></div>');
			console.log("success");
		}

	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});

		}
});

// News Filter year

$(document).on('change', '#swny', function(event) {

	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);transform:
	//<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">
	$('.newsfilter').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	//var alpha5=$(this).attr('data-value');
	var alpha6=$('#swny option:selected').text();
	//alert(slug3);
	//var alpha3 = $('#mdsrchkeywrd').val();
	//alert(alpha2);
	//var obj=$(this);
	$.ajax({
		url: base_url+'/wp-admin/admin-ajax.php',
		type: 'POST',
		dataType: 'html',
		data: {action: 'swissnewsy', slug6: alpha6},
	})
	.done(function(xhr6) {

		if (!(xhr6=='')) {
			$('.newsfilter').html(xhr6);
			console.log("success");
		} else {
			$('.newsfilter').html('<div class="large-12 columns directory_sort"><div class="large-9 columns directory_item_details small_padding"><h2>No result found...</h2></div></div>');
			console.log("success");
		}

	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
});

// News Filter keyword

$(document).on('click', '#nwkbut', function(event) {

	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
	//alert(base_url);transform:
	//<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">
	$('.newsfilter').html('<img style="position:absolute;top:50%;left:50%;translate(-50%, -50%);" class="cat-loader-img" src="'+templ_url+'6.gif">');
	var alpha9 = $('#newkeywordnyc').val();
	//alert(alpha2);
	//var obj=$(this);
	$.ajax({
		url: base_url+'/wp-admin/admin-ajax.php',
		type: 'POST',
		dataType: 'html',
		data: {action: 'swissnewsk', slug9: alpha9},
	})
	.done(function(xhr9) {

		if (!(xhr9=='')) {
			$('.newsfilter').html(xhr9);
			console.log("success");
		} else {
			$('.newsfilter').html('<div class="large-12 columns directory_sort"><div class="large-9 columns directory_item_details small_padding"><h2>No result found. Try with another keyword...</h2></div></div>');
			console.log("success");
		}

	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
});

////////

$('#dgtouch').on('click', '#backtomd', function(event) {
	//alert(prev);

	$('#dgtouch').html(prev);
	event.preventDefault();
	//e.preventDefault();
	/* Act on the event */
});


});