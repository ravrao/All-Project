<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swisscham | Home</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/app.css">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="57x57">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="72x72">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="114x114">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="144x144">
    <?php wp_head(); ?>
</head>

<body>
    <div id="page">

        <section class="top_strip">
            <div class="row">
                <div class="large-7 medium-7 columns">
                    <ul class="menu simple top_site_buttom">
                        <li class="active"><a href="index.html">Home</a></li>
                        <li><a href="beijing.html">Beijing</a></li>
                        <li><a href="shanghai.html">Shanghai</a></li>
                        <li><a href="guangzhou.html">Guangzhou</a></li>
                        <li><a href="hongkong.html">Hong Kong</a></li>
                    </ul>
                </div>
                <div class="large-5 medium-5 columns top_log_sec">
                    <ul class="menu simple top_log_buttom ">
                        <li class="top_fix_btn"><a href="#">Login</a></li>
                        <li class="top_fix_btn"><a href="#" class="join_active">Join Us</a></li>
                        <li class="language_selector top_fix_btn"><a href="#">EN</a> | <a href="#">中文</a></li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="small_top_strip">
            <div class="row show-for-small-only">
                <div class="large-12 columns text-right no_padding">
                    <ul class="menu simple small_login_field">
                        <li class=""><a href="#">Login</a></li>
                        <li class="small_join_btn"><a href="#" class="button">Join Us</a></li>
                        <!--
                            <li class="small_social_button">
    <a class=""><img src="images/wechat.png" /></a>
</li>
<li class="small_social_button">
    <a class=""><img src="images/linkdin.png" /></a>
</li>
-->
                    </ul>
                </div>
            </div>
        </section>
        <section class="top_fixed_strip">
            <header>
                <a class="menu_toogler " href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
                <div class="row">
                    <div class="large-7 medium-6 columns">
                        <p class="main_logo">
                            <a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" /></a>
                        </p>
                    </div>


                    <div class="large-5 medium-6 columns no_padding">
                        <div class="large-6 medium-6 columns">
                        
                            <?php get_search_form(); ?>

                        </div>
                        <div class="large-6 medium-6 columns">
                            <!--
                            <ul class="menu simple ad_sponsor_item">
                                <li class=""><img src="images/sponser1.jpg" /></li>
                                <li class=""><img src="images/sponser2.png" /></li>
                            </ul>
-->
                            <div class="large-12 medium-12 small-6 columns small_support_text show-for-small-only">
                                <h3 class="text-right"><?php _e( 'supported by', 'swisscham' ); ?></h3>
                            </div>
                            <div class="large-12 medium-12 small-6 columns no_padding">
                                <div class="adSponsorItem">
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.nestle.com.cn/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/slider_sponsor1.jpg" /></a>
                                        </p>
                                    </div>
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.vischer.com/en/home/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/slider_sponsor2.jpg" /></a>
                                        </p>
                                    </div>
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.swiss.com/web/EN/Pages/index.aspx?WT.mc_id=SwissCham" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/slider_sponsor3.jpg" /></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section class="relative_sec">
                <div class="row">
                    <div class="large-12 columns main_navbar">
                        <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
                            <button class="menu-icon" type="button" data-toggle></button>
                            <div class="title-bar-title"><?php _e( 'Menu', 'swisscham' ); ?></div>
                        </div>

                        <div class="top-bar main_nav" id="main-menu">
                            <div class="top-bar-left">
                                <!--
                        <ul class="dropdown menu" data-dropdown-menu>
    <li class="menu-text">Site Title</li>
</ul>
-->
                            </div>





                            <div class="top-bar-left main_nav_list">
                        <?php wp_nav_menu( array( 'menu' =>'Main Menu','container'=> 'li','container_class' => '','container_id' => '','items_wrap' =>'<ul class="menu main_nav_list_item dropdown" data-responsive-menu="drilldown medium-dropdown">%3$s</ul>','walker' => new wp_pmcustom_navwalker(array( 'in_top_bar' => true, 'item_type' => 'li', 'menu_type' => 'top-menu' )) ) ); ?>
                        </div>







</div>
                    </div>
                </div>
            </section>
        </section>