<?php
/*
  Template Name: Booking edit
 */

get_header();
    $swisschkr = multisite_globalizer(); ?>
<?php
$booking_details=$wpdb->get_row("SELECT  * FROM  `sc_em_bookings` where `booking_id`='".$_GET['booking_id']."'");
$userdetails=$booking_details->booking_meta;

$mydata_booking = unserialize($userdetails);
//print_r($mydata_booking);
$ser=  maybe_serialize($mydata_booking);

 //var_dump($ser);

$booking_user=$wpdb->get_row("SELECT  * FROM  `sc_users` where `ID`='".$booking_details->person_id."'");

if (isset($_REQUEST['update'])){
   
    $metas=array(
    'sur_name'               =>   $_REQUEST['sur_name'],
    'user_company'           =>   $_REQUEST['user_company'],
    'user_gender'            =>   $_REQUEST['user_gender'],
    'user_jobtitle'          =>   $_REQUEST['user_jobtitle'],
    'user_yearofbirth'       =>   $_REQUEST['user_yearofbirth'],
    'user_address'           =>   $_REQUEST['user_address'],
);
$arrreg= array( 'registration' => $metas );
//print_r($metas);
//print_r($arrreg);
$ser_convert_val_ser=  maybe_serialize($arrreg);

update_user_meta( $booking_user->ID, 'first_name', $_REQUEST['user_name'] );
update_user_meta( $booking_user->ID, 'dbem_phone', $_REQUEST['dbem_phone'] );

$update = "UPDATE `sc_em_bookings`
SET `booking_meta`='".$ser_convert_val_ser."'
WHERE `booking_id` = '".$_GET['booking_id']."'";	 
$wpdb->query($update); 
?>
<script language="javascript" type="text/javascript">

window.location.href="<?php bloginfo('url') ?>/event-booking-edit/?booking_id=<?php echo $_GET['booking_id'];?>";
</script>
<?php    
}
?>
<div class="abc"></div>
<section class="inner_banner bg-beijing hide-for-small-only">

    <?php echo get_post_breadcrumbs(); ?> 
</section>
    <section>
        <div class="row" data-equalizer data-equalize-on="medium">
            <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <div class="large-12 columns dowedo_top">
                <div class="table-scroll">
                    <h3><center>View/Edit Your Booking Information.</center></h3>
                    <div class="em-booking css-booking" id="em-booking">
    <form action="" method="post" name="booking-form" class="em-booking-form">
        <input type="hidden" value="booking_add" name="action">
        <input type="hidden" value="74" name="event_id">
        <input type="hidden" value="7903404bf6" name="_wpnonce">
        <div class="em-booking-form-details">
            			
            <input type="hidden" class="em-ticket-select" value="1" name="em_tickets[66][spaces]">
            <style>
                .em-booking-form-details{ width:100%; }
                .em-booking-form label{ width:100%; }
                .em-booking-form-details input.input, .em-booking-form-details textarea{ width:100%; }
                #em-booking-submit {
                    background-color: #aa0008;
                    border: 1px solid transparent;
                    border-radius: 0;
                    color: #fff;
                    cursor: pointer;
                    display: inline-block;
                    font-size: 0.9rem;
                    line-height: 1;
                    margin: 0 0 1rem;
                    padding: 0.85em 1em;
                    text-align: center;
                    transition: background-color 0.25s ease-out 0s, color 0.25s ease-out 0s;
                    vertical-align: middle;
                    float:right;
                }
                body {

                    color: #000;
                    font-family: "robotomedium",Helvetica,Roboto,Arial,sans-serif;

                }
                .em-tickets-spaces label{ font-weight:700; }
                label {
                    color: #000;
                    display: block;
                    font-size: 0.875rem;

                    line-height: 18px;
                    margin: 0;
                }
                .ticket-price label{ float: left; width: 60px; margin-bottom: 15px; }
                .ticket-price strong{ float: left; }
            </style>

            <input type="hidden" value="1" name="register_user">
            <div class="medium-12 columns no_padding">
                <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_name">Name <span class="requirered">*</span></label>
                    <input required="true" type="text" value="<?php echo get_user_meta($booking_user->ID, 'first_name', true); ?>" class="input" id="user_name" name="user_name">

                </div>


                <div class="clearfix"></div>

                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="dbem_phone">Phone                        
                        <input type="text" value="<?php echo get_user_meta($booking_user->ID, 'dbem_phone', true); ?>" class="input" id="dbem_phone" name="dbem_phone">
                    </label>
                </div>
            </div>
            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_email">E-mail <span class="requirered">*</span></label>
                    <input type="text" value="<?php echo $booking_user->user_email; ?>" readonly="true" class="input" id="user_email" name="user_email">

                    <small>The email to associate with this registration.</small>
                </div>
            </div>

            <div class="medium-6 columns no_padding surput">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="sur_name">Surname <span class="requirered">*</span>
                        <input type="text" value="<?php echo $mydata_booking['registration']['sur_name']; ?>" class="input" id="sur_name" name="sur_name" required="true">
                    </label>
                </div>
            </div>

            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_company">Company Name <span class="requirered">*</span>
                        <input type="text" value="<?php echo $mydata_booking['registration']['user_company']; ?>" class="input" id="user-company" name="user_company">
                    </label>
                </div>
            </div>

            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_gender">Gender
                        <select id="user-gender" name="user_gender">
                            <option value="">- None -</option>
                            <option value="Male" <?php if($mydata_booking['registration']['user_gender']=='Male') { ?>selected <?php } ?>>Male</option>
                            <option value="Female" <?php if($mydata_booking['registration']['user_gender']=='Female') { ?>selected <?php } ?>>Female</option>
                        </select>
                    </label>
                </div>
            </div>

            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_jobtitle">Job Title            
                        <input type="text" value="<?php echo $mydata_booking['registration']['user_jobtitle']; ?>" class="input" id="user-jobtitle" name="user_jobtitle">
                    </label>
                </div>
            </div>

            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_yearofbirth">Year Of Birth           

                        <input type="text" value="<?php echo $mydata_booking['registration']['user_yearofbirth']; ?>" class="input" id="user-yearofbirth" name="user_yearofbirth">
                    </label>
                </div>
            </div>

            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_address">Address           
                        <textarea id="user-address" name="user_address" placeholder="None" rows="2"><?php echo $mydata_booking['registration']['user_address']; ?></textarea>
                    </label>
                </div>
            </div>

            <!--<div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <fieldset class="large-12 columns no_padding margin_bottom5">

                        <label for="checkbox1" class="event_reg_term">
                            <input type="checkbox" id="checkbox1" name="add_mailing_list" value="yes">
                            Add me to your mailing list.</label>
                    </fieldset>
                    <fieldset class="large-12 columns no_padding margin_bottom5">

                        <label for="checkbox2" class="event_reg_term agree">
                            <input type="checkbox" id="checkbox2" name="agree" value="yes" class="agree" required="true"> I agree to the terms and conditions, and understand there might be a fee involved.</label>
                    </fieldset>
                    <small>In case you want to cancel your registration please contact us at least 24 hours (or otherwise stated in the invitation) before the event. Failure to cancel or attend the event will require the payment of a no show bill of the full amount of the event.</small>
                </div>
            </div>-->




<!--<p>
<label for='booking_comment'>Comment</label>
<textarea name='booking_comment' rows="2" cols="20"></textarea>
</p>-->	
              <div class="clearfix"></div>
            <div class="em-booking-buttons">
                <input type="submit" name="update" value="Edit your booking" id="em-booking-submit" class="em-booking-submit">
            </div>
        </div>
    </form>	
    <br style="clear:left;" class="clear">  
</div>
                    </div>
                </div>

            </div>
             <?php get_sidebar(); ?>
        </div>
    </section>


 <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>