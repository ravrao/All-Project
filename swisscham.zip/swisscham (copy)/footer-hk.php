<section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                    <?php global $switched;
                        switch_to_blog(1); ?>
<?php $spnbtarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'sponsorbottom',
                'meta_key'          => 'image_status',
                'meta_value'        => 'active',    
                'post_status'      => 'publish',
                'suppress_filters' => 0,

                'tax_query' => array(
      array(
         'taxonomy' => 'footerbranchname',
         'field' => 'slug',
         'terms' => 'hong-kong'
      )
   )    
            );

            $spnbt_array = get_posts( $spnbtarg );
           
            foreach ($spnbt_array as $spnbt_arr) {

            $spnbtimg = wp_get_attachment_image_src( get_post_thumbnail_id( $spnbt_arr->ID ), 'single-post-thumbnail' );  ?>        
                        <div class="">
                            <p class="main_sponsor_item"><a href="<?php echo get_post_meta($spnbt_arr->ID, 'url', true); ?>" target="_blank"><img src="<?php echo $spnbtimg[0]; ?>" /></a></p>
                        </div>
            <?php } ?>
            <?php restore_current_blog(); ?>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <div class="row">
                <div class="large-12 columns">
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>About us</h4>
                       <p> 
                        <?php
                        // query for the about page
                        $your_query = new WP_Query( 'pagename=Home' );
                       
                        // "loop" through query (even though it's just one page) 
                        while ( $your_query->have_posts() ) : $your_query->the_post(); 
                        
                           // the_content();
                        echo get_post_meta($post->ID, 'aboutuscontent', true); 
                        endwhile;
                        // reset post data (important!)
                        wp_reset_postdata();
?>
                       </p>
                        
                       
                        <p><a href="<?php echo web_url(); ?>hk/our-services/"><i class="fa fa-caret-right" aria-hidden="true"></i> Learn more about our services</a></p>
                    </div>
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>Contact us</h4>
                        <div class="large-12 columns no_padding">
                            <ul class="fa-ul no-bullet footer_content">
                                <li><a href="<?php echo web_url(); ?>hk/">SwissCham Hong Kong</a></li>
                                <li><a href="javascript:void(0)"><i class="fa fa-phone" aria-hidden="true"></i> <?php echo get_field('contact_us_content_footer_nmbr', 5); ?></a></li>
                                <li><a href="mailto:<?php echo get_field('contact_us_content_footer_email', 5); ?>"><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo get_field('contact_us_content_footer_email', 5); ?></a></li>
                                <li>
                                    <p><a href="#">Find us</a> | <a href="<?php echo web_url(); ?>contact-us/">Contact form</a> | <a href="<?php echo home_url(); ?>/wechat/">Follow us on wechat</a></p>
                                </li>
                            </ul>
                        </div>
                        <!--
                        <div class="large-6 columns ">
                            <ul class="fa-ul no-bullet footer_list">
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Hong kong</a></li>

                            </ul>
                        </div>
-->
                    </div>
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>Quick links</h4>
                        <div class="large-12 columns no_padding">
                            <ul class="fa-ul no-bullet footer_list">
                                <li><a href="<?php echo get_field('upcoming_event', 5); ?>">Upcoming Events</a></li>
                                <li><a href="<?php echo get_field('exposure', 5); ?>">Exposure</a></li>
                                <li><a href="<?php echo get_field('member_directory', 5); ?>">Member Directory</a></li>
                                <li><a href="<?php echo get_field('job_opportunities', 5); ?>">Job Opportunities</a></li>
                                <li><a href="<?php echo get_field('membership_application', 5); ?>">Membership Application</a></li>
                                <li><a href="<?php echo get_field('site_map', 5); ?>">Site Map</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_separetor" />
                    </div>
                    <div class="large-12 columns">
                        <div class="menu-centered">
                            <ul class="menu simple copyright_text">
                                <li>Copyright © 2016 Swiss Chinese Chamber of Commerce</li>
                                <li><a href="<?php echo get_field('terms_of_use', 5); ?>">Terms of use</a></li>
                                <li><a href="<?php echo get_field('privacy_policy', 5); ?>">Privacy policy</a></li>
                                <li>Website design by Axiussoft</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
        <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


        <nav id="log_togg">
            <ul class="logsec_sidenav">
                <li><a href="#">Login</a></li>
                <li class="side_joinnow"><a href="#">Join US</a></li>
                <li class="right_menu_heading show-for-medium-only">Select Language</li>
                <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
            </ul>
        </nav>

        <nav id="menu">
            <ul>
                <!--
                <li class="region_side_icon"><a href="index.html">Home</a></li>
                <li class="region_side_icon"><a href="beijing.html">Beijing</a></li>
                <li class="region_side_icon"><a href="shanghai.html">Shanghai</a></li>
                <li class="region_side_icon"><a href="guangzhou.html">Guangzhou</a></li>
                <li class="region_side_icon"><a href="hongkong.html">Hong Kong</a></li>
-->
                <!--                <li class="right_menu_heading show-for-small-only">Select Language</li>-->
                <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                <!--                <li class="right_menu_heading inlineblock_element">Select Location</li>-->
                <li class="region_side_icon">
                <?php $current_website_url = web_url(); ?>
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                        <option value="">Select Menu</option>
                        <option value="<?php echo $current_website_url; ?>">Home</option>
                        <option value="<?php echo $current_website_url.'bei'; ?>">Beijing</option>
                        <option value="<?php echo $current_website_url.'sha'; ?>">Shanghai</option>
                        <option value="<?php echo $current_website_url.'gz'; ?>">Guangzhou</option>
                        <option value="<?php echo $current_website_url.'hk'; ?>">Hong Kong</option>
                        <option value="#">Switzerland</option>
                    </select>
                </li>
                <li><a href="#">ABOUT US</a>
                    <ul>
                        <li><a href="<?php echo $current_website_url; ?>hk/swisscham-hong-kong-who-are-we/">Who are we?</a></li>
                        <li><a href="<?php echo $current_website_url; ?>hk/history-hong-kong/">History</a></li>
                        <li><a href="<?php echo $current_website_url; ?>hk/swisscham-board-hong-kong/">Board of Directors</a></li>
                        <li><a href="<?php echo $current_website_url; ?>contact-us/">Contact Us</a></li>
                    </ul>
                </li>
                <li><a href="#">MEMBERSHIP</a>
                    <ul>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/why-join-us/">Why join us?</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/membership-young-professional/">Membership Young Professional</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>swisschamlogin/online_application.php">Online Application</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>swisschamlogin/member_directory_general_page.php">Members Directory</a>
                        </li>
                    </ul>
                </li>
                <li><a href="#">EVENTS</a>
                    <ul>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hongkong-upcoming-events/">Upcoming Events</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hongkong-event-calendar/">Events Calendar</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hongkong-events-overview/">Events Overview</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/swisscham-apac-event-calendar/">SwissCham APAC Events</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>events-archive/">Events Archives & Photos</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/other-events-in-hong-kong-switzerland/">Other Events in HK/CH</a>
                        </li>
                    </ul>
                </li>


                <li><a href="#">PUBLICATIONS</a>
                    <ul>
                        <li>
                            <a href="<?php echo $current_website_url; ?>the-bridge-magazine/">The Bridge</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>readers-digest/">Sino-Swiss Business News</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>news/">News</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/legal-and-investment-updates/">Legal & Investment Updates</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/invest-in-switzerland/">Invest in Switzerland</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/business-publications/">Business Publications</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/other-links/">Other Links</a>
                        </li>
                    </ul>
                </li>

                <li><a href="#">SERVICES</a>
                    <ul>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/our-services/">Our services</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>jobs/">Job</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/advertise-with-us/">Advertise With Us</a>
                        </li>
                        <li>
                            <a href="<?php echo $current_website_url; ?>hk/wechat/">Webchat</a>
                        </li>
                    </ul>
                </li>
            </ul>

        </nav>


    </div>


    <a href="#0" class="cd-top">Top</a>

    <script src="<?php echo get_template_directory_uri(); ?>/bower_components/jquery/dist/jquery.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/bower_components/what-input/what-input.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/bower_components/foundation-sites/dist/foundation.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/slick.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/easyResponsiveTabs.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.mmenu.all.min.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.viewportchecker.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/pace.js"></script>
    <script type="text/javascript">
        $(function() {
            $('nav#menu').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: true,
                counters: false,
                "offCanvas": {
                    "position": "left"
                },
                navbar: {
                    title: 'SWISSCHAM'
                },
                navbars: [{
                    position: 'top',
                    content: ['searchfield']
                }, {
                    position: 'top',
                    content: [
                        'prev',
                        'title',
                        'close'
                    ]
                }, {
                    position: 'bottom',
                    content: [
                        //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                    ]
                }]
            });
            $('nav#log_togg').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: false,
                counters: false,
                navbar: {
                    title: 'Welcome to Swisscham'
                },
                navbars: [{
                    position: 'bottom',
                    content: [
                        '<span class="side_footer_link"><a class=""><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /> LinkedIn</a></span>'
                    ]
                }]

            });

        });

    </script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/app.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            //Horizontal Tab
            $('#parentHorizontalTab').easyResponsiveTabs({
                type: 'default', //Types: default, vertical, accordion
                width: 'auto', //auto or any width like 600px
                fit: true, // 100% fit in a container
                tabidentify: 'hor_1', // The tab groups identifier
                activate: function(event) { // Callback function if tab is switched
                    var $tab = $(this);
                    var $info = $('#nested-tabInfo');
                    var $name = $('span', $info);
                    $name.text($tab.text());
                    $info.show();
                }
            });
        });
        $(window).load(function() {
            var viewportWidth = $(window).width();
            if (viewportWidth >= 766) {
                var firstDiv = $(".resp-tab-content").innerHeight();
                var secondDiv = $(".body_inner_content").innerHeight();
                var thirdDiv = $(".bridge_height").innerHeight();
                var fourthDiv = $(".member_slider").innerHeight();
                var ulHeightFirstDiv = $(".resp-tab-item").outerHeight();
                var maxHeight = Math.max(firstDiv, secondDiv, thirdDiv, fourthDiv);
                var tabContentFirstDiv = maxHeight - parseInt(ulHeightFirstDiv);
                $(".resp-tab-content").innerHeight(tabContentFirstDiv)
                $(".body_inner_content").innerHeight(maxHeight)
                $(".bridge_height").innerHeight(maxHeight)
                $(".member_slider").innerHeight(maxHeight)

            }
            // Run code
        });
        $(window).scroll(function() {
            var viewportWidth = $(window).width();
            if (viewportWidth >= 766) {
                var firstDiv = $(".resp-tab-content").innerHeight();
                var secondDiv = $(".body_inner_content").innerHeight();
                var thirdDiv = $(".bridge_height").innerHeight();
                var fourthDiv = $(".member_slider").innerHeight();
                var ulHeightFirstDiv = $(".resp-tab-item").outerHeight();
                var maxHeight = Math.max(firstDiv, secondDiv, thirdDiv, fourthDiv);
                var tabContentFirstDiv = maxHeight - parseInt(ulHeightFirstDiv);
                $(".resp-tab-content").innerHeight(tabContentFirstDiv)
                $(".body_inner_content").innerHeight(maxHeight)
                $(".bridge_height").innerHeight(maxHeight)
                $(".member_slider").innerHeight(maxHeight)
            }

        });

    </script>
    
    
  <script>

function ePro(){
document.getElementById('ePro').style.display='block';document.getElementById('fade').style.display='block'}

function eProX(){
document.getElementById('ePro').style.display='none';document.getElementById('fade').style.display='none'}
 
function nCol(){
document.getElementById('nCol').style.display='block';document.getElementById('fade').style.display='block'}

function nColX(){
document.getElementById('nCol').style.display='none';document.getElementById('fade').style.display='none'}
//-->
</script>

<!-- light-box form starts -->
  <div id="nCol" class="WhtBoxCont">
  	<img src="<?php echo get_template_directory_uri(); ?>/images/close.png" width="14" height="14" alt="" onclick="nColX()" align="right" style="cursor:pointer; margin-bottom: 15px;" /> 
  	
        <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg" class="qrCode">
        <div class="mfp-bottom-bar"><div class="mfp-title">
                <div id="wechat-hint">Scan the QR Code with your WeChat App to start following us.</div></div>
            <div class="mfp-counter"></div></div>
  </div>
  <div id="fade" class="blackBg"></div>
  
  <div id="fade" class="blackBg"></div>   
<?php wp_footer(); ?>

</body>

</html>
