<?php 
get_header();
$swisschkr = multisite_globalizer(); ?>

<div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <?php if(is_singular( 'news' )) { ?>
                        <li><a href="<?php echo home_url(); ?>/news/">News</a></li>
                        <!-- <li>
                                <span class="show-for-sr">Current: </span>News
                        </li> -->
                        <?php } else { ?>
                        <li>
                           <?php if( have_posts() ); ?>
                                 <?php 
                                       while( have_posts() ) : the_post(); ?>
                                          <span class="show-for-sr">Current: </span><?php the_title(); ?>

                                  <?php endwhile; ?>

                        </li>
                        <?php }
                         ?>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
        <?php $newsarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'news',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $news_array = get_posts( $newsarg );

            //foreach ($news_array as $news_arr) { ?>
            <?php if(has_post_thumbnail()){
               $newsimg = wp_get_attachment_image_src( get_post_thumbnail_id( $news_array->ID ), 'single-post-thumbnail' );  
            	}
            	else{
            		$newsimg="";
            		}?>

            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                      <div class="large-12 columns no_padding">     
                      <div class="large-2 columns small_padding">
                          <img src="<?php echo $newsimg[0]; ?>">
                          <!-- <a class="text-center directory_logo" style="height: auto; border: none; padding: 0px;" href="<?php //echo get_field('news_title_link', $news_array->ID); ?>"><img src="<?php //echo $newsimg[0]; ?>"></a> -->
                      </div> 
                 <div class="large-10 columns small_padding">
                    <?php if( have_posts() ); ?>

                         <?php 
                               while( have_posts() ) : the_post(); ?>
                        <h1 class="common_heading"><a target="_blank" href="<?php echo get_field('news_title_link', $news_array->ID); ?>"><?php $orgtit = get_the_title(); echo $oprtit = strtoupper($orgtit); ?></a></h1>
                        <h5 class="light_text">Published by <?php echo get_field('published_by', $news_array->ID); ?> |  <?php echo get_the_date('d F Y', $news_arr->ID); ?>  <?php /*|  n category of SwissCham Publications. English, Chinese */ ?></h5>
                      
                   <?php endwhile; ?>
                                      
                    </div>
                    <div class="large-12 columns no_padding"> 
                      <?php if( have_posts() ); ?>

                         <?php 
                               while( have_posts() ) : the_post(); ?>
                               <?php the_content(); ?>
                             <?php endwhile; ?>
                             <?php if(!empty($newsimg)){ ?>
                              <!--<p class="text-center"><img src="<?php //echo $newsimg[0]; ?>" /></p>-->
                            <?php } ?>
                             <a href="<?php echo web_url(); ?>news/" class="button newsletter_button">Read More News</a>
                    </div>
                    </div>
                    </div>





                    <div class="large-12 columns dowedo_top">
                            <ul class="fa-ul all_social_icons">
                                <li>
                                    <span>Share the page : </span>
                                </li>
                                <li>
                                    <a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a href="#" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a href="#" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
                                </li>
                                 <li>
                                

                                    <a href="#" class="email_icon"> <i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </li>                               


                            </ul>
                        </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
          <?php/* }*/ ?>

             

        </section>

        <?php if ( $swisschkr==1 ) {
          get_footer();
         } if ( $swisschkr==2 ) {
          get_footer('bei');
         } if ( $swisschkr==3 ) {
          get_footer('sha');
         } if ( $swisschkr==4 ) {
          get_footer('gz');
         } if ( $swisschkr==5 ) {
          get_footer('hk');
         } ?>