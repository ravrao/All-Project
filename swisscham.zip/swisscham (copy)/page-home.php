<?php
/*
	Template Name: Home
*/
	get_header();
    $swisschkr = multisite_globalizer();
    @session_start(); 
    
    ?>
        <?php
        $events_all_count = EM_Events::get(array('scope'=>'future'));
        $events_all_count_Beijing = EM_Events::get(array('scope'=>'future','category'=>51));
        $events_all_count_Shanghai = EM_Events::get(array('scope'=>'future','category'=>52));
        $events_all_count_Guan = EM_Events::get(array('scope'=>'future','category'=>53));
        $events_all_count_Hong = EM_Events::get(array('scope'=>'future','category'=>54));
          $today = date( 'Y-m-d' );
       if ( $swisschkr==1 ) {  
        $_SESSION["events_all_count_session"] = count($events_all_count);
        $_SESSION["events_all_count_Beijing_session"] = count($events_all_count_Beijing);
        $_SESSION["events_all_count_Shanghai_session"] = count($events_all_count_Shanghai);
        $_SESSION["events_all_count_Guan_session"] = count($events_all_count_Guan);
        $_SESSION["events_all_count_Hong_session"] = count($events_all_count_Hong);
       }
       
      
       ?>

        <div class="abc"></div>
        <?php if ( $swisschkr==1 ) { ?>
        <section class="main_banner bg-home">
        <?php } if ( $swisschkr==2 ) { ?>
        <section class="main_banner bg-beijing">
        <?php } if ( $swisschkr==3 ) { ?>
        <section class="main_banner bg-shanghai">
        <?php } if ( $swisschkr==4 ) { ?>
        <section class="main_banner bg-guangzhou">
        <?php } if ( $swisschkr==5 ) { ?>
        <section class="main_banner bg-hongkong">
        <?php } ?>
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainBanner">

            <?php
                //global $switched;
                //switch_to_blog(1);
             $smtarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'summit',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $summits_array = get_posts( $smtarg );
           
            foreach ($summits_array as $summits_arr) {

            $smtimg = wp_get_attachment_image_src( get_post_thumbnail_id( $summits_arr->ID ), 'single-post-thumbnail' );  ?>
                      
            <div class="">
                <p class="banner_slider_item"> <a href="<?php echo get_post_meta($summits_arr->ID, 'link', true); ?>"><img src="<?php echo $smtimg[0]; ?>" /></a></p>
            </div>

            <?php } //restore_current_blog(); ?>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-8 columns no_padding">
                    <div class="large-9 medium-6 columns">

                        <div class="doc_top_banner">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/eventsecbanner.jpg" />
                            <div class="doc_top_banner_title"><?php _e( 'EVENTS', 'swisscham' ); ?></div>
                        </div>
                        
                        
                        
                        <?php if ( $swisschkr==1 ) { ?>
                        <div id="parentHorizontalTab">

<?php $argev = array(
                'posts_per_page'   => 3,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_array = get_posts( $argev );

$argevv2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_arrayv2 = get_posts( $argevv2 );

                 $acount = count($evt_arrayv2); 
             ?>





<?php $argev1 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1 = get_posts( $argev1 );

    $argev1_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1_v2 = get_posts( $argev1_v2 );

                 $becount = count($evt_array1_v2);
                 //$_SESSION["fbei"] = $becount;
                 //echo $_SESSION["fbei"];
             ?>





<?php $argev2 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2 = get_posts( $argev2 );

    $argev2_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2_v2 = get_posts( $argev2_v2 );

            $shacount = count($evt_array2_v2); ?>





<?php $argev3 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3 = get_posts( $argev3 );

    $argev3_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3_v2 = get_posts( $argev3_v2 );

            $gzcount = count($evt_array3_v2);
//echo $gzcount;

             ?>




<?php $argev5 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5 = get_posts( $argev5 );

    $argev5_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'event_start_date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5_v2 = get_posts( $argev5_v2 );

            $hkcount = count($evt_array5_v2); 
            
               
               
        
        
            ?>

                            <ul class="resp-tabs-list hor_1 event_tab">
                            <li class="tab_active"><?php _e( 'All', 'swisscham' ); ?>
                            <?php if(!($acount=='')) { ?>
                                <br />(<?php //echo $acount; 
                                echo count($events_all_count);
                                ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>Beijing
                           
                                <br />(<?php echo count($events_all_count_Beijing); ?>)</li>
                           
                            <li>SHANGHAI
                                <br />(<?php echo count($events_all_count_Shanghai); ?>)</li>
                          
                            
                            <li>GUANGZHOU
                            <br />(<?php echo count($events_all_count_Guan); ?>)</li>
                          
                            <li>HONG KONG
                                <br />(<?php echo count($events_all_count_Hong); ?>)</li>
                          
                            </ul>
                            <div class="resp-tabs-container hor_1 tab_list_details">
                                <div>
           
                               
 <?php echo do_shortcode('[events_list scope="future" category="51,52,53,54" limit="3"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/#_CATEGORYSLUG/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>                                   

                                    
                            
                                    
                                    
                                    
                        <?php if($_SESSION["events_all_count_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                                <div>
          
<?php echo do_shortcode('[events_list scope="future" category="51" limit="3"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/bei/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
           
           
                        <?php if($_SESSION["events_all_count_Beijing_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>bei/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
           
           <?php echo do_shortcode('[events_list scope="future" category="52" limit="3"]'
                   . '<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME'
                   . '<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span>'
                   . '</h4><h5>#_LOCATIONADDRESS</h5><a href="/sha/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Shanghai_session"]>4) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>sha/upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>
<div>
<?php echo do_shortcode('[events_list scope="future" category="53" limit="3"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/gz/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
           
                        <?php if($_SESSION["events_all_count_Guan_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>gz/upcoming-events/">See more events</a>
                        <?php }?>
                                </div>

                                <div>
           <?php echo do_shortcode('[events_list scope="future" category="54" limit="3"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/hk/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Hong_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>hk/upcoming-events/">See more events</a>
                        <?php }?>
                                </div>

                            </div>
                        </div>
                        <?php }
                            global $switched;
                            switch_to_blog(1);
                         if ( $swisschkr==2 ) { ?>
                        
                        
                        <div id="parentHorizontalTab">

<?php $argev = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_array = get_posts( $argev );

$argevv2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 ,
    
                'meta_query' => array(
                    array(
                        'key' => 'event_start_date',
                        'value' => $today,
                        'compare' => '>=',
                        'type' => 'DATE'
                    )
                )    
            );

           // $evt_arrayv2 = get_posts( $argevv2 );
            $evt_arrayv2=new WP_Query( $argevv2 );

            $acount = count($evt_arrayv2); 
                 
          
                 
                 
             ?>
<?php $argev1 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1 = get_posts( $argev1 );

    $argev1_v2 = new WP_Query (array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing',
                          
                      )
                   ),
                   
               'meta_query' => array(
                    array(
                        'key' => 'event_start_date',
                        'value' => $today,
                        'compare' => '>=',
                        'type' => 'DATE'
                    )
                ) 
            ));

           // $evt_array1_v2 = new WP_Query( $argev1_v2 );

                 $becount = count($argev1_v2);
                 //$_SESSION["fbei"] = $becount;
                 //echo $_SESSION["fbei"];
             ?>
<?php $argev2 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2 = get_posts( $argev2 );

    $argev2_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                          
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'sha',
                          
                      )
                   ),
               'meta_query' => array(
                    array(
                        'key' => 'event_start_date',
                        'value' => $today,
                        'compare' => '>=',
                        'type' => 'DATE'
                    )
                ) 
            );

            $evt_array2_v2 = new WP_Query( $argev2_v2 );

            $shacount = count($evt_array2_v2);
            
         
            
            ?>

<?php $argev3 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3 = get_posts( $argev3 );

    $argev3_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3_v2 = get_posts( $argev3_v2 );

            $gzcount = count($evt_array3_v2); ?>

<?php $argev5 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5 = get_posts( $argev5 );

    $argev5_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5_v2 = get_posts( $argev5_v2 );

            $hkcount = count($evt_array5_v2); ?>
                            
 
                            <ul class="resp-tabs-list hor_1 event_tab">
                                
                            
                            <li class="tab_active"><?php _e( 'All', 'swisscham' ); ?>
                           
                                <br />(<?php //echo ($beijing_count); 
                                echo $_SESSION["events_all_count_session"];
                                ?>)</li>
                            <li>Beijing
                          
                                <br />(<?php //echo count($events_Bejing_branch_beijing);
                                echo $_SESSION["events_all_count_Beijing_session"];
                                ?>)</li>
                            <li>SHANGHAI
                            
                                <br />(<?php //echo count($eventsssssssssssss); 
                                echo $_SESSION["events_all_count_Shanghai_session"]
                                ?>)</li>
                           
                            <li>GUANGZHOU
                            
                                <br />(<?php //echo count($events_Bejing_branch_All_guan); 
                               echo $_SESSION["events_all_count_Guan_session"];
                                ?>)</li>
                           
                            <li>HONG KONG
                            
                                <br />(<?php //echo count($events_Bejing_branch_All_hong); 
                                
                                echo $_SESSION["events_all_count_Hong_session"];
                                ?>)</li>
                          
                            </ul>
                            
                            
                            <div class="resp-tabs-container hor_1 tab_list_details">
                                <div>
             <?php echo do_shortcode('[events_list scope="future" category="51,52,53,54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
           
                        <?php if($_SESSION["events_all_count_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
          <?php echo do_shortcode('[events_list scope="future" category="51" limit="3" blog="1"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/bei/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>

                        <?php if($_SESSION["events_all_count_Beijing_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>bei/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
           <?php echo do_shortcode('[events_list scope="future" category="52" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Shanghai_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>shanghai-upcomingevents/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
             <?php echo do_shortcode('[events_list scope="future" category="53" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Guan_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>guangzhou-upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                                <div>
            <?php echo do_shortcode('[events_list scope="future" category="54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Hong_session"]>4) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>hongkong-upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                            </div>
                        </div>
                        <?php } if ( $swisschkr==3 ) {  
                           
                            ?>
                        <div id="parentHorizontalTab">

<?php $argev = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_array = get_posts( $argev );

$argevv2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_arrayv2 = get_posts( $argevv2 );

                 $acount = count($evt_arrayv2); 
             ?>
<?php $argev1 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1 = get_posts( $argev1 );

    $argev1_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1_v2 = get_posts( $argev1_v2 );

                 $becount = count($evt_array1_v2);
                 //$_SESSION["fbei"] = $becount;
                 //echo $_SESSION["fbei"];
             ?>
<?php $argev2 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2 = get_posts( $argev2 );

    $argev2_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2_v2 = get_posts( $argev2_v2 );

            $shacount = count($evt_array2_v2); ?>

<?php $argev3 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3 = get_posts( $argev3 );

    $argev3_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3_v2 = get_posts( $argev3_v2 );

            $gzcount = count($evt_array3_v2); ?>

<?php $argev5 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5 = get_posts( $argev5 );

    $argev5_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5_v2 = get_posts( $argev5_v2 );

            $hkcount = count($evt_array5_v2); ?>

                            <ul class="resp-tabs-list hor_1 event_tab">
                            <li class="tab_active"><?php _e( 'All', 'swisscham' ); ?>
                            <?php if(!($_SESSION["events_all_count_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>Beijing
                            <?php if(!($_SESSION["events_all_count_Beijing_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Beijing_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>SHANGHAI
                            <?php if(!($_SESSION["events_all_count_Shanghai_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Shanghai_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>GUANGZHOU
                            <?php if(!($_SESSION["events_all_count_Guan_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Guan_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>HONG KONG
                            <?php if(!($_SESSION["events_all_count_Hong_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Hong_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            </ul>
                            <div class="resp-tabs-container hor_1 tab_list_details">
                                <div>
                                  
           
           <?php echo do_shortcode('[events_list scope="future" category="51,52,53,54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
             <?php echo do_shortcode('[events_list scope="future" category="51" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Beijing_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>beijing-upcomingevents/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
             <?php echo do_shortcode('[events_list scope="future" category="52" limit="3" blog="1"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/sha/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        
                
                 
                 <?php if($_SESSION["events_all_count_Shanghai_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>sha/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
            <?php echo do_shortcode('[events_list scope="future" category="53" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Guan_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>guangzhou-upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                                <div>
             <?php echo do_shortcode('[events_list scope="future" category="54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Hong_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>hongkong-upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                            </div>
                        </div>
                        <?php } if ( $swisschkr==4 ) {  ?>
                        <div id="parentHorizontalTab">

<?php $argev = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_array = get_posts( $argev );

$argevv2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_arrayv2 = get_posts( $argevv2 );

                 $acount = count($evt_arrayv2); 
             ?>
<?php $argev1 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1 = get_posts( $argev1 );

    $argev1_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1_v2 = get_posts( $argev1_v2 );

                 $becount = count($evt_array1_v2);
                 //$_SESSION["fbei"] = $becount;
                 //echo $_SESSION["fbei"];
             ?>
<?php $argev2 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2 = get_posts( $argev2 );

    $argev2_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2_v2 = get_posts( $argev2_v2 );

            $shacount = count($evt_array2_v2); ?>

<?php $argev3 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3 = get_posts( $argev3 );

    $argev3_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3_v2 = get_posts( $argev3_v2 );

            $gzcount = count($evt_array3_v2); ?>

<?php $argev5 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5 = get_posts( $argev5 );

    $argev5_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5_v2 = get_posts( $argev5_v2 );

            $hkcount = count($evt_array5_v2); ?>

                            <ul class="resp-tabs-list hor_1 event_tab">
                            <li class="tab_active"><?php _e( 'All', 'swisscham' ); ?>
                            <?php if(!($_SESSION["events_all_count_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>Beijing
                            <?php if(!($_SESSION["events_all_count_Beijing_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Beijing_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>SHANGHAI
                            <?php if(!($_SESSION["events_all_count_Shanghai_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Shanghai_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>GUANGZHOU
                            <?php if(!($_SESSION["events_all_count_Guan_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Guan_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>HONG KONG
                            <?php if(!($_SESSION["events_all_count_Hong_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Hong_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            </ul>
                            <div class="resp-tabs-container hor_1 tab_list_details">
                                <div>
           
         <?php echo do_shortcode('[events_list scope="future" category="51,52,53,54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
          <?php echo do_shortcode('[events_list scope="future" category="51" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Beijing_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>beijing-upcomingevents/">See more events</a>
                        <?php }  ?>
                                </div>

                                <div>
            <?php echo do_shortcode('[events_list scope="future" category="52" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Shanghai_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>shanghai-upcomingevents/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
           <?php echo do_shortcode('[events_list scope="future" category="53" limit="3" blog="1"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/gz/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if( $_SESSION["events_all_count_Guan_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>gz/upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                                <div>
              <?php echo do_shortcode('[events_list scope="future" category="54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
            <?php /*  test */ ?>
                        <?php if($_SESSION["events_all_count_Hong_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>hongkong-upcoming-events/">See more events</a>
                        <?php }  ?>
                                </div>

                            </div>
                        </div>
                        <?php } if ( $swisschkr==5 ) {  ?>
                        <div id="parentHorizontalTab">

<?php $argev = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_array = get_posts( $argev );

$argevv2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $evt_arrayv2 = get_posts( $argevv2 );

                 $acount = count($evt_arrayv2); 
             ?>
<?php $argev1 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1 = get_posts( $argev1 );

    $argev1_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )
            );

            $evt_array1_v2 = get_posts( $argev1_v2 );

                 $becount = count($evt_array1_v2);
                 //$_SESSION["fbei"] = $becount;
                 //echo $_SESSION["fbei"];
             ?>
<?php $argev2 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2 = get_posts( $argev2 );

    $argev2_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )
            );

            $evt_array2_v2 = get_posts( $argev2_v2 );

            $shacount = count($evt_array2_v2); ?>

<?php $argev3 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3 = get_posts( $argev3 );

    $argev3_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )
            );

            $evt_array3_v2 = get_posts( $argev3_v2 );

            $gzcount = count($evt_array3_v2); ?>

<?php $argev5 = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5 = get_posts( $argev5 );

    $argev5_v2 = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                      array(
                         'taxonomy' => 'event-categories',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )
            );

            $evt_array5_v2 = get_posts( $argev5_v2 );

            $hkcount = count($evt_array5_v2); ?>

                            <ul class="resp-tabs-list hor_1 event_tab">
                            <li class="tab_active"><?php _e( 'All', 'swisscham' ); ?>
                            <?php if(!($_SESSION["events_all_count_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>Beijing
                            <?php if(!($_SESSION["events_all_count_Beijing_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Beijing_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>SHANGHAI
                            <?php if(!($_SESSION["events_all_count_Shanghai_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Shanghai_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>GUANGZHOU
                            <?php if(!($_SESSION["events_all_count_Guan_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Guan_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            <li>HONG KONG
                            <?php if(!($_SESSION["events_all_count_Hong_session"]=='')) { ?>
                                <br />(<?php echo $_SESSION["events_all_count_Hong_session"]; ?>)</li>
                            <?php } else { ?>
                                <br />(0)</li>
                            <?php } ?>
                            </ul>
                            <div class="resp-tabs-container hor_1 tab_list_details">
                                <div>
           
           <?php echo do_shortcode('[events_list scope="future" category="51,52,53,54" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
        
<?php echo do_shortcode('[events_list scope="future" category="51" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>

                        <?php if($_SESSION["events_all_count_Beijing_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>beijing-upcomingevents/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
           <?php echo do_shortcode('[events_list scope="future" category="52" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Shanghai_session"]>4) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>shanghai-upcomingevents/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
            <?php echo do_shortcode('[events_list scope="future" category="53" limit="3" blog="1,2,3,4,5"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="#_EVENTURL"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
                        <?php if($_SESSION["events_all_count_Guan_session"]>3) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>guangzhou-upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                                <div>
           <?php echo do_shortcode('[events_list scope="future" category="54" limit="3" blog="1"]<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/hk/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>[/events_list]'); ?>
            
                                                        
                        <?php if($_SESSION["events_all_count_Hong_session"]>4) { ?>
                                    <a class="see_more_link" href="<?php echo web_url(); ?>hk/upcoming-events/">See more events</a>
                        <?php } ?>
                                </div>

                            </div>
                        </div>
                        <?php } restore_current_blog(); ?>
                    </div>
                    <div class="large-3 medium-6 columns">
                        <div class="eualize_align">
                            <div class="doc_top_banner">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/newsbanner.jpg" />
                                <div class="doc_top_banner_title"><?php _e( 'NEWS', 'swisscham' ); ?></div>
                            </div>
                            <div class="body_inner_content" data-equalizer-watch>
    <?php
    global $switched;
    switch_to_blog(1);

         $nwsarg = array(
                'posts_per_page'   => 3,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'news',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $nws_array = get_posts( $nwsarg );
           
            foreach ($nws_array as $nws_arr) { ?>
                                <div class="inner_text_group">
                                <?php $nwp = get_the_date('d F, Y', $nws_arr->ID);
                                        $exdp = explode(" ",$nwp);
                                        $swissday = $exdp[0].'';                
                                        $swissmonth = substr($exdp[1],0,-1);
                                        $nwmfd = $swissday.' '.$swissmonth.' '.$exdp[2];
                                 ?>
                                    <h4><?php echo $nwmfd; ?></h4>
                                    <a target="_blank" href="<?php echo get_the_permalink($nws_arr);/*echo get_field('news_title_link', $nws_arr->ID);*/ ?>">
                                        <h3><?php 
                                         $news_title = substr($nws_arr->post_title, 0, 60);
                                        echo $news_title .'....'; ?></h3></a>
                                </div>
                        <?php
                 }
                    restore_current_blog();
        ?>

                                <a class="see_more_link" href="<?php echo web_url(); ?>news/"><?php _e( 'Read More', 'swisscham' ); ?></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="large-4 columns no_padding">
                    <div class="large-6 medium-6 columns">
                        <div class="eualize_align">
                            <div class="doc_top_banner">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/bridgebanner.jpg" />
                                <div class="doc_top_banner_title"><?php _e( 'The Bridge', 'swisscham' ); ?></div>
                            </div>
                            <div class="body_inner_content bridge_height" data-equalizer-watch>
                                <div class="inner_text_group">
                                    <h5>
        <style type="text/css">
                .inner_text_group h5 strong {
                color: #000;
                font-family: "robotomedium",Helvetica,Roboto,Arial,sans-serif;
                font-size: 13px;
                font-weight: bold;
                }
        </style>
                                    
    <?php
    global $switched;
    switch_to_blog(1);

         $bridgearg = array(
                'posts_per_page'   => 1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'bridge_magazine',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $bridge_array = get_posts( $bridgearg );
           
            foreach ($bridge_array as $bridge_arr) { ?>

                        <?php
                        
                        $pagepds = $bridge_arr->post_content;
                        $pagep = substr($pagepds, 0, 409);
                        $pageshb = $pagep.'...';
                         

                            $pageshb = apply_filters('the_content', $pageshb);
                            $pageshb = str_replace(']]>', ']]&gt;', $pageshb);
                            
                                echo $pageshb;

                 }
                    restore_current_blog();
        ?>

</h5>
                                </div>
                                <a class="see_more_link" href="<?php echo web_url(); ?>the-bridge-magazine/"><?php _e( 'Read More', 'swisscham' ); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="large-6 medium-6 columns">

                        <div class="doc_top_banner">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/memberbanner.jpg" />
                            <div class="doc_top_banner_title"><?php _e( 'NEW MEMBERS', 'swisscham' ); ?></div>
                        </div>
                        <?php  
                        define('__SITEROOT__', dirname(dirname(dirname(dirname(__FILE__)))));  
                        require_once(__SITEROOT__."/swisschamlogin/includes/connection.php"); ?>
                        <div class="member_slider">
                            <div class="memberList">

        <?php 
             /*$spnbtarg = array(
                'posts_per_page'   => 50,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'members',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );*/

            $spnbt_array = get_posts( $spnbtarg );
            
            $results = mysql_query("SELECT * FROM `sc_c_userdetails` WHERE admin_approval='yes' AND `admin_generated_password`!='abcd1234' ORDER BY userId DESC");
                          
            while($res = mysql_fetch_assoc($results)){
                
                
             if ( $swisschkr==1 ) { 
                
            $results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = 0 AND  `logo_name`!= ''");

            //$results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = '".$res['userId']."' AND  `logo_name`!= ''");
            
             }
             if ( $swisschkr==2 ) { 
                
            $results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = '".$res['userId']."' AND `company_chamber`='Beijing' AND `logo_name`!= '' ORDER BY userId DESC");
             }
             if ( $swisschkr==3 ) { 
                
            $results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = '".$res['userId']."' AND `company_chamber`='Shanghai' AND `logo_name`!= '' ORDER BY userId DESC");
             }
             if ( $swisschkr==4 ) { 
            $results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = '".$res['userId']."' AND `company_chamber`='Guangzhou' AND `logo_name`!= '' ORDER BY userId DESC");
             }
              if ( $swisschkr==5 ) { 
            $results_fetch = mysql_query("SELECT * FROM `sc_c_company_details` WHERE `userId` = '".$res['userId']."' AND `company_chamber`='HongKong' AND `logo_name`!= '' ORDER BY userId DESC");
             }
             
             $count_num=mysql_num_rows($results_fetch);
            $row_show = mysql_fetch_assoc($results_fetch);
          
            //foreach ($spnbt_array as $spnbt_arr) {
                if($count_num>0) {
               $cu_date=date('Y-m-d');
               
               $dt = new DateTime($res['created_date']);

                  $pub_date= $dt->format('Y-m-d').'<br/>';
                
            
                $effectiveDate = strtotime("+3 months", strtotime($res['created_date'])); // returns timestamp
                 $Beforedate=date('Y-m-d',$effectiveDate); // formatted version
             
                //$spnbtimg = wp_get_attachment_image_src( get_post_thumbnail_id( $spnbt_arr->ID ), 'single-post-thumbnail' );  ?>
                                <?php if($cu_date!=$Beforedate) { ?>
                                <div class="">
                                   
                <?php if($row_show['logo_name']!='')
                {?>
                 <p class="member_slide_item"><img  src="<?php echo web_url(); ?>swisschamlogin/<?php echo $row_show['logo_name']; ?>" /></p>
                <?php } else {?> 
                 <p class="member_slide_item"><img  src="<?php echo web_url(); ?>swisschamlogin/uploads/no-image-available.jpg" /></p>
                <?php } ?> 
             </div>
                                <?php } ?>
                               
            <?php } } ?>      


                            </div>
                            <span class="pagingInfo"></span>

                        </div>

                    </div>
                </div>
            </div>
        </section>
        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>
