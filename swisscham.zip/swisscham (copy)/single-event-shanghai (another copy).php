<?php
/*
  template name: Single Event Shanghai

 */
get_header();
switch_to_blog(1);

$EID = $_GET['id'];
query_posts($EID);
$swisschkr = multisite_globalizer();
//$fetchtid = get_the_ID();
$fetchtid = $EID;
//echo $fetchtid;
?>
<?php
$getrecipedetail = get_post_meta($fetchtid, 'pm_enterroute');
$getspeakername = get_post_meta($fetchtid, 'pm_speaker');
$getcontactetail = get_post_meta($fetchtid, 'contact');
$getcontUS = get_post_meta($fetchtid, 'pm_enterroute');
$getspeakername_ravi = get_post_meta($fetchtid, 'pm_seteventtype');
$getlatituteandlongitude = get_post_meta($fetchtid, 'pm_taxidirection');
$getlocation = get_post_meta($fetchtid, 'pm_chinese');
$enviradetails = get_post_meta($fetchtid, 'pm_envgallery');
$fetchcode = $enviradetails[0][0]['envira-gallery-shortcode'];
$speakercode = $getspeakername[0][0]['enter-speaker-details'];
$uploadedimage = get_post_meta($getrecipedetail[0][0]['map-image'], '_wp_attached_file');
$upload_dir = wp_upload_dir();
?>

<div class="abc"></div>
<section class="inner_banner bg-beijing hide-for-small-only">

    <?php echo get_post_breadcrumbs(); ?> 
</section>
<section>
    <div class="row" data-equalizer data-equalize-on="medium">
        <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
            <div class="large-12 columns dowedo_top">
                <div class="table-scroll">

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo do_shortcode('[event post_id="' . $EID . '"]#_EVENTNAME[/event]'); ?></h1></div>
                    <div class="large-12 columns no_padding" data-equalizer="event_box_align">
                        <div class="large-8 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">
                                <ul class="fa-ul no-bullet event_list_details">
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <span class="event_list_name">TIME</span>
                                            <?php echo do_shortcode('[event post_id="' . $EID . '"]#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME[/event]');
                                            ?>
                                            <?php
                                            $dt = do_shortcode('[event post_id="' . $EID . '"]#d #F #Y[/event]');

                                            $ctadte = date('d F Y');
                                            ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span> <span class="event_list_name">Venue</span>
                                            <?php echo do_shortcode('[event post_id="' . $EID . '"]#_LOCATIONNAME[/event]'); ?>

                                            <?php echo do_shortcode('[event post_id="' . $EID . '"]#_LOCATIONNAME[/event]'); ?>


                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span>
                                            <?php echo do_shortcode('[event post_id="' . $EID . '"]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>

                                            <?php //echo do_shortcode('[event post_id="1802"]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">PRICE</span> Member
                                            <?php
                                            $minprice = do_shortcode('[event post_id="' . $EID . '"]#_EVENTPRICEMIN[/event]');
                                            $minexploded = explode(".", $minprice);
                                            echo $minexploded[0];
                                            ?> | Non Members
                                                <?php
                                                $maxprice = do_shortcode('[event post_id="' . $EID . '"]#_EVENTPRICEMAX[/event]');
                                                $maxexploded = explode(".", $maxprice);
                                                echo $maxexploded[0];
                                                ?>
                                        </p>
                                    </li>

                                </ul>
                            </div>

                        </div>

                        <?php
                        $createstartdate = do_shortcode('[event post_id="' . $EID . '"]#Y#m#d T #H#i#s[/event]');
                        $withoutspacestart = str_replace(' ', '', $createstartdate);
                        ?>
                        <?php
                        $createenddatedate = do_shortcode('[event post_id="' . $EID . '"]#@Y#@m#@d T #@H#@i#@s[/event]');
                        $withoutspaceend = str_replace(' ', '', $createenddatedate);

                        $sendtitle = get_the_title($fetchid);
                        ?>

                        <div class="large-4 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">


                                <?php $ctadte = strtotime($ctadte); ?>
                                    <?php $dt = strtotime($dt); ?>
                                <p class="register_button">
<?php if ($ctadte <= $dt) { ?>
                                        <a href="javascript:void(0);" class="button expanded common_button" data-toggle="eventRegModal">Register Now</a>



                                    <?php } else { ?>
                                        <a href="javascript:void(0);" class="button expanded common_button disabled">Register Now</a>
<?php } ?>
                                </p>
                                <ul class="fa-ul no-bullet register_sublist">
                                    <li><a href="<?php echo web_url(); ?>calendercreator/?withoutspacestart=<?php echo $withoutspacestart; ?>&withoutspaceend=<?php echo $withoutspaceend; ?>&sendtitle=<?php echo $sendtitle; ?>" class="">Add to calendar</a></li>
                                    <li><a  target="_blank" href="<?php echo web_url(); ?>baidu-test/?contentval=<?php echo $EID; ?>" class="">Taxi directions</a></li>
                                </ul>


                            </div>

                        </div>
                    </div>


                    <!--- Tab Section Here ---------------------------->

                     <div class="large-12 columns">
                        <div id="eventListTab">
                             <?php if($getspeakername_ravi[0][0]['select-event']=='Workshop') {?>
                            <ul class="resp-tabs-list hor_1 innerpage_tab min_ul_width">
                             <?php } else { ?>
                                <ul class="resp-tabs-list hor_1 innerpage_tab">
                             <?php } 
                             
                             ?>
                                
                                <li class="tab_active">Event Info</li>
                                <li>agenda</li>
                                <li class="lcn">location</li>
                                <li>contact</li>
                                <?php if($getspeakername_ravi[0][0]['select-event']=='Workshop') {?>
                                 <li>Speakers</li>
                                <?php } ?>
                            </ul>
                            <div class="resp-tabs-container hor_1 eventtab_list_details">
                                <div>
                                    <div class="eventtab_list_item">
                                        <?php if( have_posts() ); ?>

                                            <?php 
                               while( have_posts() ) : the_post(); ?>

                                                <?php the_content(); ?>
                                                    <?php endwhile; ?>
                                        
                                        <?php
                                        $my_id = $EID;
                                        $post_id_5369 = get_post($my_id);
                                        $content = $post_id_5369->post_content;
                                        $content = apply_filters('the_content', $content);
                                        $content = str_replace(']]>', ']]>', $content);
                                        echo $content;
                                        ?>



<?php if($fetchcode != ''){ ?>
   <div class="innercontentdesign"><i class="fa fa-picture-o" aria-hidden="true"></i> Gallery:</div> 
 <?php  echo do_shortcode($fetchcode); 
    } ?>

                                    </div>
                                </div>

                                <div>
                                    <div class="eventtab_list_item">
                                        <?php //echo do_shortcode('[event]#_CATEGORYALLEVENTS[/event]'); ?>
                                        
                                        <?php $getlatituteandlongitude_cont = get_post_meta($fetchtid,'related_content_field'); 
                                        //var_dump($getlatituteandlongitude_cont);
                                        echo $getlatituteandlongitude_cont[0][0]['agenda-items'];;
                                        ?>

                                    </div>
                                </div>

                                <div>
                                    <div class="eventtab_list_item">
                                        <?php //echo do_shortcode('[event]#_LOCATIONFULLBR[/event]'); ?>
                                            <p>
                                                <?php //echo $getrecipedetail[0][0]['enter-route-description'];?>
                                            </p>
					<?php $getlocationforchines =$getlocation[0][0]['enter-chinese-location']; 
//echo $getlocationforchines;
                                            ?>
                            <input type="hidden" name="address" id="address1" value="<?=$getlocationforchines?>"/>
                            <div style="width:100%;height:300px;border:#ccc solid 1px;float:left;" id="dituContent1"></div><br/>
                           <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
                            
                           
                           <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
                            <script type="text/javascript">
                                    $(document).ready(function(){
                                    //$('.lcn').click(function(){
                                    /* var lang=113.52897592105;
                                    var lat=23.142106886029;	
                                    var point = new BMap.Point(lang,lat);	
                                    var address='上海大酒店，上海，中国';
                                    geocoder = new BMap.Geocoder();

                                            //alert(geocoder)
                                            geocoder.getPoint(address, function(res){
                                            console.log(res)
                                            //console.log(res)

                                    }) */

                                    var address=$('#address1').val();
                                    //var city=$('#city').val();
                                    //alert(address);
                                    //var lat=$('#lat').val();
                                    var map = new BMap.Map("dituContent1");
                                    geocoder = new BMap.Geocoder(); 

                                    //geocoder.getPoint('北京市东城区长巷二�?�乙5�?�', function(res){



                                    geocoder.getPoint(address, function(res){
                                            console.log(res)
                                            //console.log(res)
                                    console.log(res.lat)
                                            var lng=res.lng;
                                            var lat=res.lat;
                                            //alert(res.address);
                                            //var address=res.address;
                                            //$('#address').html(address);

                                            var point = new BMap.Point(lng,lat);
                                            //log(res.lat)
                                            var sContent =
                                                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                                                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
                                            //var icon = new BMap.Icon('http://www.transcommgroup.com/assets/img/pin1.png', new BMap.Size(20, 32), {//
                                            //                   anchor: new BMap.Size(10, 30),
                                            //                 infoWindowAnchor: new BMap.Size(10, 0)
                                            //});

                                            var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                                                            anchor: new BMap.Size(10, 30),
                                                            infoWindowAnchor: new BMap.Size(10, 0)
                                            });
                                            var marker = new BMap.Marker(point, {
                                                            icon: icon,
                                                            title: address
                                            }); 

                                            <!--AXIUS: opts variable has been included and the same has been set below -->
                                            /* var opts = {
                                            //width : 500,
                                            //height: 70,
                                            title : "Shanghai Office" ,
                                            enableMessage:true,
                                            message:"北京市�?阳区光�?�路4�?�东方梅地亚中心A座903室"
                                            } */

                                            <!--AXIUS: opts variable set here below -->

                                            //var marker = new BMap.Marker(point);
                                            var infoWindow = new BMap.InfoWindow(sContent);
                                            map.centerAndZoom(point, 15);
                                            map.enableScrollWheelZoom();
                                            map.addOverlay(marker);
                                            marker.addEventListener("click", function(){
                                            this.openInfoWindow(infoWindow);
                                            document.getElementById('imgDemo').onload = function (){
                                            infoWindow.redraw();
                                            }
                                            });
                                    }) 

                              });
                            //  });
                            </script>
                                            

                                            
                                    </div>
                                </div>
                                <div>
                                    <div class="eventtab_list_item">
                                        <span class="contact-label">Contact Us:</span>
                                        <div class="contact-custom">
                                        
                                            <?php echo $getcontUS[0][0]['add-contact-details'];?>
                                        
                                        </div>
                                            
                                        <p>Contact</p>
                                        <div class="contactperson-details">
                                        
                                            <?php echo $getcontactetail[0][0]['content1'];?>
                                        
                                        </div>
                                        <div class="contactperson-details">
                                            <?php echo $getcontactetail[0][0]['contact-2'];?>
                                        </div>
                                        
                                    </div>
                               
                                </div>

                                
                                <div>
                                    <div class="eventtab_list_item">
                                         <?php if($getspeakername_ravi[0][0]['select-event']=='Workshop') {?>
                                       <?php if($speakercode != ''){ ?>
                                        
                                      <?php echo $speakercode; 
                                         } } ?>

                                    </div>
                                </div>

                            </div>

                            <div class="large-12 columns dowedo_top">
                            <ul class="fa-ul all_social_icons">
                             <li><span>Share the event : </span></li>
                             <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
                             <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                             <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
                             <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                             <li>
                                 <!--<a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>-->
                                 <a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
                                 
                             </li>
                             <li><a href="#" class="email_icon"> <i class="fa fa-envelope" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>

                        </div>


                    </div>
                    <?php
                    restore_current_blog();
                    ?>

                    <!-- Tab Section End Here ------------------------->





                </div>
            </div>

        </div>

<?php get_sidebar(); ?>

    </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                      
                    </div>

                </div>



            </div>
        </section>
		<!-- Event Register Modal Start -->
    <div class="reveal event_reg_modal" id="eventRegModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
        <h1>Please fill up the information to register</h1>
        <p class='lead'><?php echo get_the_title($fetchid);?><!--COMPANY VISIT - ABB: IN CHINA FOR CHINA, INNOVATION FOR A BETTER WORLD--></p>
        
            <!--<div class="row">
			<form name="eventUserRegForm" id="eventUserRegForm" action="<?php echo get_template_directory_uri(); ?>/saveSingleEvent.php" method="POST">
                <div class="medium-12 columns no_padding">
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>First Name <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="first_name" id="first_name" value="">
                        </label>
                    </div>
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Surname <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="sur_name" id="sur_name" >
                        </label>
                    </div>
                </div>
                <div class="medium-12 columns no_padding">
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Email <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="email" id="email" >
                        </label>
                        <small>The email to associate with this registration.</small>
                    </div>
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Gender
                            <select name="gender" id="gender" >
                                <option value="">- None -</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </label>
                    </div>
                </div>
                <div class="medium-12 columns no_padding">
                    <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Company Name <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="company_name" id="company_name" >
                        </label>
                    </div>
                </div>
                <div class="medium-12 columns no_padding">
                    <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Job Title
                            <input type="text" placeholder="" name="job_title" id="job_title" >
                        </label>
                    </div>
                </div>
                <div class="medium-12 columns no_padding">
                    <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Address
                            <textarea rows="2" placeholder="None" name="address" id="address" ></textarea>
                        </label>
                    </div>
                </div>
                <div class="medium-12 columns no_padding">
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Phone
                            <input type="text" placeholder="" name="phone" id="phone" >
                        </label>
                    </div>
                    <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                        <label>Year of Birth
                            <input type="text" placeholder="" name="year_of_birth" id="year_of_birth" >
                        </label>
                    </div>
                </div>
				 <input type="hidden" placeholder="" name="event_title" id="event_title" value="<?php echo get_the_title($fetchid);?>">
                <div class="medium-12 columns no_padding">
                    <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                        <fieldset class="large-12 columns no_padding margin_bottom5">
                            
                            <label for="checkbox1" class="event_reg_term">
							<input id="checkbox1" type="checkbox" name="add_mailing_list" id="add_mailing_list" value="yes" >
							Add me to your mailing list.</label>
                        </fieldset>
                        <fieldset class="large-12 columns no_padding margin_bottom5">
                            
                            <label for="checkbox2" class="event_reg_term agree">
							<input id="checkbox2" type="checkbox" name="agree" value="yes" class="agree"> I agree to the terms and conditions, and understand there might be a fee involved.</label>
                        </fieldset>
                        <small>In case you want to cancel your registration please contact us at least 24 hours (or otherwise stated in the invitation) before the event. Failure to cancel or attend the event will require the payment of a no show bill of the full amount of the event.</small>
                    </div>
                </div>
                <div class="medium-12 columns membership_from no_padding">
                    <p class="text-right">
					
					<a href="javascript:void(0);" class="button regnext_btn no_margin_top no_margin_bottom disabled" id="sendRegMail">Send Registration</a></p>
                </div>
				</form>
            </div>-->
        
        <!--<button class="close-button" data-close aria-label="Close reveal" type="button">
            <span aria-hidden="true">&times;</span>
        </button>-->
        
        
         <?php echo do_shortcode('[event]#_BOOKINGFORM[/event]'); ?>
        
        
    </div>
	<div class="tiny reveal event_reg_modal" id="eventRegModalE" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
        <h1>Event date expired.</h1>  
        <button class="close-button" data-close aria-label="Close reveal" type="button">
            <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js?v=<?php echo time(); ?>"></script>
	<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js?v=<?php echo time(); ?>"></script>-->
        <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js?v=<?php echo time(); ?>"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.css" rel="stylesheet">
    <!-- Event Register Modal End -->
	<style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }
			.blk{
				cursor:none;
				text-decoration:none !important;
			}
        </style>
		
<script>
$(document).ready(function(){
	$("#year_of_birth").on('focus',function(){
		$(this).datepicker();
	})
$('.agree').on('change', function(e){
	//$("#sendRegMail").removeClass("disabled")
	if(e.target.checked){
		$("#sendRegMail").removeClass("disabled")
		} else {
			
			$("#sendRegMail").addClass("disabled")
			} 
  
});


	$('#sendRegMail').click(function(){
		//var isDisabled = $('#sendRegMail').prop('disabled');
		//alert(isDisabled);
		//alert($( "#sendRegMail" ).hasClass( "disabled" ));
		if($( "#sendRegMail" ).hasClass( "disabled" )){
			return false;
		} else{
		var flag=0;
		var first_name=$('#first_name').val();
		if (first_name == '') {
                $("#first_name").focus();
                $("#first_name").addClass("error_cl");
                flag = 1;
                return false;
            } else {
                $("#first_name").removeClass("error_cl");
            }
		var sur_name=$('#sur_name').val();
		if (sur_name == '') {
                $("#sur_name").focus();
                $("#sur_name").addClass("error_cl");
                flag = 1;
                return false;
            } else {
                $("#sur_name").removeClass("error_cl");
            }
		var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		var email=$('#email').val();
		if ((!emailPattern.test(email)) || (email == '')) {
                $("#email").focus();
                $("#email").addClass("error_cl");
                flag = 1;
                return false;
            } else {
                $("#email").removeClass("error_cl");
            }
			var company_name=$('#company_name').val();
			if (company_name == '') {
                $("#company_name").focus();
                $("#company_name").addClass("error_cl");
                flag = 1;
                return false;
            } else {
                $("#company_name").removeClass("error_cl");
            }
			if($("#agree"). prop("checked") == false){
				$("#agree").focus();
                $("#agree").addClass("error_cl");
                flag = 1;
                return false;
            } else {
                $("#agree").removeClass("error_cl");
            }
			if(flag==0){
				$('#eventUserRegForm').submit();
			}
		}
	});
}); 
</script>
        <?php 
          get_footer('event');
         ?>
