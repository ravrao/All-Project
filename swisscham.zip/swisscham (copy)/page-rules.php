<?php
/*
    Template Name: Rules
*/

    get_header();
    	$swisschkr = multisite_globalizer();
     ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li><span class="show-for-sr">Current: </span> About Us</li>
                        <li><span class="show-for-sr">Current: </span> Rules </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">

       <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 36 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 36 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 36 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 36 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 36 ); ?>"><?php echo get_field( "national_articles_of_association", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 36 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 36 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 36 ); ?>"><?php echo get_field( "beijing_bylaws", 36 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 36 ); ?>"><?php echo get_field( "shanghai_bylaws", 36 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 36 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 36 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 36 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 36 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 36 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 102 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 102 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 102 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 102 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 102 ); ?>"><?php echo get_field( "national_articles_of_association", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 102 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 102 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 102 ); ?>"><?php echo get_field( "beijing_bylaws", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 102 ); ?>"><?php echo get_field( "shanghai_bylaws", 102 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 102 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 102 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 102 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 102 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 102 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 75 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 75 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 75 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 75 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 75 ); ?>"><?php echo get_field( "national_articles_of_association", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 75 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 75 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 75 ); ?>"><?php echo get_field( "beijing_bylaws", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 75 ); ?>"><?php echo get_field( "shanghai_bylaws", 75 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 75 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 75 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 75 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 75 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 75 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==4 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 61 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 61 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 61 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 61 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 61 ); ?>"><?php echo get_field( "national_articles_of_association", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 61 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 61 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 61 ); ?>"><?php echo get_field( "beijing_bylaws", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 61 ); ?>"><?php echo get_field( "shanghai_bylaws", 61 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 61 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 61 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 61 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 61 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 61 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==5 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 68 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 68 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 68 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 68 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 68 ); ?>"><?php echo get_field( "national_articles_of_association", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 68 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 68 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 68 ); ?>"><?php echo get_field( "beijing_bylaws", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 68 ); ?>"><?php echo get_field( "shanghai_bylaws", 68 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 68 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 68 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 68 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 68 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 68 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } ?>



                <?php get_sidebar(); ?>

                <!-- <div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser1.jpg" /></li>
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser2.jpg" /></li>
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div> -->

            </div>
        </section>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>
