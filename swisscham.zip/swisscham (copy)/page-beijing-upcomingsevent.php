<?php 
/*
template name: Beijing Upcomingevents

*/

get_header();
    $swisschkr = multisite_globalizer(); ?>

    <div class="abc"></div>
    <section class="inner_banner bg-beijing hide-for-small-only">
        <div class="inner_bredcrumb">
            <nav aria-label="You are here:" role="navigation">
                <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>/bei/">Beijing</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>              <?php if(is_singular( 'news' )) { ?>
                        <li><a href="<?php //echo home_url(); ?>/news/">Events</a></li>
                        <!--<li><span class="show-for-sr">Current: </span>News</li> -->
                        <?php } else { ?>
                            <?php if( have_posts() ); ?>
                                    <?php 
                                       while( have_posts() ) : the_post(); ?>
                            <li>
                                        <span class="show-for-sr">Current: </span>
                                        <?php echo "Events"; ?>
                            </li>           
                            <li>
                                        <span class="show-for-sr">Current: </span>
                                        <?php echo "Upcoming Events"; ?>
                            </li>
                             <?php endwhile; ?>
                            <?php }
                         ?>
                </ul>
            </nav>
        </div>
        <?php //echo get_post_breadcrumbs(); ?>
    </section>
    <section>
        <div class="row" data-equalizer data-equalize-on="medium">
            <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <div class="large-12 columns dowedo_top">
                    <div class="table-scroll">
                        <table class="upcom_list">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="" class="">Date</th>
                                    <th width="" class="">Time</th>
                                    <th width="" class="">Place</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php //echo do_shortcode('[events_list scope="future" category="51"]<tr><td>#_EVENTLINK</td><td class=""><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td class=""><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td class=""><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/events_list]'); ?>

                                
                                <?php
                               
                                $args=array(
                                    'blog'=>'1',
                                    'bookings'=>'0',
                                    'category'=>'51',
                                    'scope'=>'future',
                                    'format'=>'<tr><td><a href="/bei/event-details/?id=#_EVENTPOSTID">#_EVENTNAME </a></td>'. 
                                              '<td><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td>'.
                                              '<td><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td>'.
                                              '<td><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td></tr>',
                                    
                                );
                                 em_events($args);
                                ?>
                                
                                
                                
                                
                                

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

            <?php get_sidebar(); ?>

        </div>
    </section>
    <?php 
          get_footer('event');
         ?>
