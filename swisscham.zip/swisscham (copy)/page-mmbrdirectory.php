<?php
/*
    Template Name: Members Directory
*/
    get_header(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Membership
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Members Directory
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_md = get_post( 1073 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_md->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns dowedo_top">
                            <?php $pagemd = $post_md->post_content;

                            $pagemd = apply_filters('the_content', $pagemd);
                            $pagemd = str_replace(']]>', ']]&gt;', $pagemd);
                            echo $pagemd;  
                        	?>
                        </div>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns margin_bottom15">
                            <div class="large-12 columns pattern_bg">
                                <div class="large-12 columns news_dropmenu">
                                    <label>SEARCH
                                        <div class="input-group">
                                            <input id="mdsrchkeywrd" class="input-group-field news_search_field" type="text" placeholder="Type any keywords (Title, industry, etc.)">
                                            <div class="input-group-button">
                                                <a href="#" class="button news_search_button mdsearch"><i class="fa fa-search" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="dgtouch" style="position:relative; float: left; width: 100%;">
                    <div class="large-12 columns no_padding">
                        <div class="large-6 columns dowedo_top">
                            <h3 class="common_subheading border_subheading">Members by Chapter</h3>
                            <ul class="fa-ul custom_directory_list">
								<?php
								$sctaxonomy = 'memberin';
								$termsmdin = get_terms( array(
								    'taxonomy' => 'memberin',
								    'hide_empty' => false,
								) );
									foreach ($termsmdin as $termsmd) { ?>
                                <li><a class="mdmi" data-value="<?php echo $termsmd->slug; ?>"><?php echo $termsmd->name; ?></a></li>
                                <!--  href="<?php //echo esc_attr(get_term_link($termsmd, $sctaxonomy)); ?>" -->
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="large-6 columns dowedo_top">
                            <h3 class="common_subheading border_subheading">Members by name</h3>
                            <div class="alppha" style="position:relative; float: left; width: 100%;">
                            <ul class="fa-ul custom_directory_name_list">
                                <li><a href="javascript:void(0)">A</a></li>
                                <li><a href="javascript:void(0)">B</a></li>
                                <li><a href="javascript:void(0)">C</a></li>
                                <li><a href="javascript:void(0)">D</a></li>
                                <li><a href="javascript:void(0)">E</a></li>
                                <li><a href="javascript:void(0)">F</a></li>
                                <li><a href="javascript:void(0)">G</a></li>
                                <li><a href="javascript:void(0)">H</a></li>
                                <li><a href="javascript:void(0)">I</a></li>
                                <li><a href="javascript:void(0)">J</a></li>
                                <li><a href="javascript:void(0)">K</a></li>
                                <li><a href="javascript:void(0)">L</a></li>
                                <li><a href="javascript:void(0)">M</a></li>
                                <li><a href="javascript:void(0)">N</a></li>
                                <li><a href="javascript:void(0)">O</a></li>
                                <li><a href="javascript:void(0)">P</a></li>
                                <li><a href="javascript:void(0)">Q</a></li>
                                <li><a href="javascript:void(0)">R</a></li>
                                <li><a href="javascript:void(0)">S</a></li>
                                <li><a href="javascript:void(0)">T</a></li>
                                <li><a href="javascript:void(0)">U</a></li>
                                <li><a href="javascript:void(0)">V</a></li>
                                <li><a href="javascript:void(0)">W</a></li>
                                <li><a href="javascript:void(0)">X</a></li>
                                <li><a href="javascript:void(0)">Y</a></li>
                                <li><a href="javascript:void(0)">Z</a></li>
                                <li><a href="javascript:void(0)">#</a></li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns dowedo_top">
                            <h3 class="common_subheading border_subheading">Members by industry</h3>
                            <ul class="fa-ul directory_industry_list">
                            <?php
								$sctaxonomy2 = 'industry';
								$termsmdin2 = get_terms( array(
								    'taxonomy' => 'industry',
								    'hide_empty' => false,
								) );
									foreach ($termsmdin2 as $termsmd2) { ?>
										<li><a><?php echo $termsmd2->name; ?></a></li>
									<?php } ?>
                                <!--
<li><a class="mdmi" data-value="<?php //echo $termsmd2->slug; ?>" href="javascript:void(0)<?php //echo esc_attr(get_term_link($termsmd2, $sctaxonomy2)); ?>"><?php //echo $termsmd2->name; ?></a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li>
                                <li><a href="#">Agriculture/Food/Beverage</a></li> -->
                            </ul>
                        </div>
                    </div>
                    </div>
                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

      <script type="text/javascript">
      var base_url = "<?php echo get_bloginfo('url'); ?>"
      var templ_url= "<?php echo web_url(); ?>wp-content/uploads/2016/11/";
      </script>
 <script type="text/javascript" src='<?php echo get_bloginfo('template_directory'); ?>/js/swiss.js'></script>
        <?php get_footer(); ?>