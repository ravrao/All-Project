<?php
/*
  Template Name: set baidu
*/
?>

<html class="no-js" lang="en">

<head>
    <!--added on 10th nov for seo plugin-->
    <meta name="google-site-verification" content="EoHiBQ3VqXUuo-kpSFaLnz2Z9Etb2tZrypls-rd9RuE" />

    <?php $swisschkr = multisite_globalizer(); ?>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<div class="medium-12 columns margin_top10 membership_from no_padding">
<div class="large-12 columns margin_top10">
<?php
$EID=$_GET['contentval'];
query_posts('post_id=$EID&post_type=event');
while (have_posts()): the_post();

  //$EID=$_GET['contentval'];
 //$cpost = get_post($fetchingid);
query_posts( array('p' => $EID) );
$fetchingid = $EID;

 $fetchingtitle= get_the_title($EID);
 
 $fetcingvaluechinese = get_post_meta($EID,'pm_chinese');
//echo get_post_meta(323, 'enter-chinese-location', true);
 //print_r($fetcingvaluechinese);
 $locationinchinese= $fetcingvaluechinese[0][0]['enter-chinese-location']; 
//echo 'gdgdgddgdgdgdgd'.$locationinchinese;
 //echo  "<h1 class='common_heading'><span class='taxi-dir-icon'><i class='fa fa-taxi' aria-hidden='true'></i></span> ".$fetchingtitle."</h1>";
 ?>
 <h1 class='common_heading'>
     <span class='taxi-dir-icon'><i class='fa fa-taxi' aria-hidden='true'></i></span>
         <?php echo do_shortcode('[event post_id="'.$fetchingid.'"]#_LOCATIONNAME[/event]'); ?>
         <?php //echo $fetchingtitle; ?></h1>
     <p class="taxi-address">请带我去 <?php echo $locationinchinese; ?></p>
<?php endwhile; ?>
</div>

<input type="hidden" name="address" id="address1" value="<?php echo $locationinchinese; ?>" />
<input type="hidden" name="city" id="city" value="<?php echo do_shortcode('[event post_id="'.$fetchingid.'"]#_LOCATIONTOWN[/event]'); ?>" />
<div class="large-12 columns margin_top10">
<div style="width:100%;height:350px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
</div>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
	
	var address=$('#address1').val();
	//var city=$('#city').val();
	//alert(city);
	//var lat=$('#lat').val();
	var map = new BMap.Map("dituContent1");
	geocoder = new BMap.Geocoder(); 
	// geocoder.getPoint('北京市东城区长巷二�?�乙5�?�', function(res){
	
	
    
	geocoder.getPoint(address, function(res){
		console.log(res)
		//console.log(res)
	console.log(res.lat)
		var lng=res.lng;
		var lat=res.lat;
		//alert(res.address);
		//var address=res.address;
		//$('#address').html(address);
		
		var point = new BMap.Point(lng,lat);
		//log(res.lat)
		var sContent =
			"<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
			"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
		var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
				anchor: new BMap.Size(10, 30),
				infoWindowAnchor: new BMap.Size(10, 0)
		});
		var marker = new BMap.Marker(point, {
				icon: icon,
				title: address
		}); 

		<!--AXIUS: opts variable has been included and the same has been set below -->
		/* var opts = {
		//width : 500,
		//height: 70,
		title : "Shanghai Office" ,
		enableMessage:true,
		message:"北京市�?阳区光�?�路4�?�东方梅地亚中心A座903室"
		} */

		<!--AXIUS: opts variable set here below -->
													
		//var marker = new BMap.Marker(point);
		var infoWindow = new BMap.InfoWindow(sContent);
                 map.addControl(new BMap.NavigationControl());
		map.centerAndZoom(point, 15);
                map.enableScrollWheelZoom(); 
		map.addOverlay(marker);
		marker.addEventListener("click", function(){
		this.openInfoWindow(infoWindow);
		document.getElementById('imgDemo').onload = function (){
		infoWindow.redraw();
		}
		});
	}) 

  });
</script>
<link rel="stylesheet" href="<?php echo web_url();?>wp-content/themes/swisscham/css/app.css">
    <link rel="stylesheet" href="<?php echo web_url();?>wp-content/themes/swisscham/css/swiss.css">
   <div class="large-12 columns margin_bottom15 margin_top10">
   <div class="pattern_bg">
        <ul class="fa-ul no-bullet event_list_details taxi_baidu_icon">
            
                    
                    <li>
                            <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <span class="event_list_name">TIME</span></p>
                               <p class="second_singel_eventdesc"> <?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME[/event]'); 



                                    ?>
                                    <?php $dt=do_shortcode('[event post_id="' . $fetchingid . '"]#d #F #Y[/event]');

                                    $ctadte=date('d F Y');
                                    ?>
                            </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span> <span class="event_list_name">Venue</span></p>
                            <p class="second_singel_eventdesc"><?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#_LOCATIONNAME[/event]'); ?>
                        </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span></p>
                            <p class="second_singel_eventdesc"><?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>
                        </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">PRICE</span></p>
                        <p class="second_singel_eventdesc">Member
                            <?php $minprice= do_shortcode('[event post_id="' . $fetchingid . '"]#_EVENTPRICEMIN[/event]'); 
$minexploded=explode(".",$minprice); echo $minexploded[0];
                             ?> | Non Members
                                <?php $maxprice= do_shortcode('[event post_id="' . $fetchingid . '"]#_EVENTPRICEMAX[/event]');
$maxexploded=explode(".",$maxprice); echo $maxexploded[0];
                                 ?>
                        </p>
                    </li>

                </ul>
                            </div>
							</div>
</div>

 <style>
 .taxi-dir-icon
 {
	 padding: 4px 8px;
	 border-radius: 5px;
	 border: #ccc 1px solid;
	 background-color:#aa0008;
	 color: #fff;
 }
 </style>
 </html>