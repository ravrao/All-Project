<?php
/*
	Template Name: Test
*/
	get_header('test'); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Rules
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">SWISSCHAM China – Rules</h1>
                        <p>SwissCham China is governed by a set of Rules and its members meet once a year during the Annual General Assembly (AGA). From top to bottom SwissCham China is subject to Chinese law and governed by three sets of rules: two at the national level and one at the regional level.</p>
                        <p>Foreign Chambers of Commerce in China are governed by the Provisional Regulations for the Administration of Foreign Chambers of Commerce in China of 14 June 1989 ("<strong>Foreign Chambers Regulations</strong>").</p>
                        <p>SwissCham China national rules include the <strong>National Articles of Association</strong> and the <strong>National Bylaws</strong>. The latter detailing the former.</p>
                        <p>Regional rules include the <strong>Regional Bylaws</strong>. In case of silence of the Regional Rules, the National Rules apply. Finally, the decisions by which the Regional BOD implements the Rules are recorded in Minutes of the BOD Meetings. They also form part of SwissCham China Rules at large.</p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="#">Foreign Chambers Regulations [en]</a></li>
                            <li><a href="#">Foreign Chambers Regulations [cn]</a></li>
                            <li><a href="#">National Articles of Association (version 14.04.2006)</a></li>
                            <li><a href="#">National Articles of Association (version 27.03.2015)</a></li>
                            <li><a href="#">National Bylaws (version 12.04.2006)</a></li>
                            <li><a href="#">National Bylaws (version 27.03.2015)</a></li>
                            <li><a href="#">Beijing Bylaws</a></li>
                            <li><a href="#">Shanghai Bylaws</a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                        <p>SwissCham China and its regional organizations call its members for an Annual General Assembly once a year. The activity report is submited and any important changes and decisions are voted on. The <strong>National Annual General Assembly (NAGA)</strong> concludes and ratifies the decisions as well as the elections held during the three <strong>Regional Annual General Assembly (RAGA)</strong> , which also marks the beginning of a new SwissCham China business year.</p>
                        <p>On this occasion members are remitted a package of documents related to the AGA. The AGA is then recorder in <strong>Minutes</strong>, the latest of which you can read under the links below.</p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                            <li><a href="#">Click here to access the RAGA/NAGA Archives</a></li>
                            <li><a href="#">Click here to access SwissCham Beijing RAGA page</a></li>
                        </ul>
                    </div>
                </div>

                <div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser1.jpg" /></li>
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser2.jpg" /></li>
                                <li><img src="<?php echo get_template_directory_uri(); ?>/images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

	<?php get_footer(); ?>