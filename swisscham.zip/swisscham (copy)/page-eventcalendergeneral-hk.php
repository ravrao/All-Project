<?php 
/*
template name: Event calender HingKong

*/

get_header();
    $swisschkr = multisite_globalizer(); ?>
    
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
          
            <?php  echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>

    <div class="legend" style="margin-left:16px;">
<?php //colours for the different cells
$beijing = "#ff8080"; $shanghai = "#66a3ff"; $guangzhou = "#47d147"; $hongkong = "#d580ff"; ?>

       <!--<p> Colours of the events in the calendar: </p>-->
       <table style="width:10%;">
         <tr>
         <!--<td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $beijing; ?>"></td><td width="10%">Beijing</td>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $shanghai; ?>"></td><td width="10%">Shanghai</td>
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $guangzhou; ?>"></td><td width="10%">Guangzhou</td>-->
         <td width="6%"><span style="float:left; height:15px; width:20px; margin: 0 0 0 10px; background-color:<?php echo $hongkong; ?>"></td><td width="10%">Hongkong</td>
         </tr>
       </table>
    </div>
                    <div class="large-12 columns dowedo_top">
                        <?php //echo do_shortcode('[events_calendar full=1 long_events=1]'); ?>
                        <?php echo do_shortcode('[events_calendar blog=1 full=1 long_events=1 category="54"]'); ?>
                    </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>
            <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>    
   <script>  
       
    $('.fullcalendar .eventful li a.hongkong').click(function()
    { 
        var mb = $('#eve_id').text();
        var array = mb.split(",");
        //alert(array[0]);
        
        
     $(this).attr("href","<?php bloginfo('url')?>/hk/event-details/?id="+array[0]);
    });   
       
    

   </script>​​
<?php 
          get_footer('event');
         ?>
