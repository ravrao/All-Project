<?php
/**
 * The template for displaying search results pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package SwissCham
 */

get_header();
    $swisschkr = multisite_globalizer(); ?>
    
<section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        
                        <li>
                            <span class="show-for-sr">Current: </span> SEARCH RESULTS
                        </li>
                    </ul>
                </nav>
            </div>
   </section>
	<section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">

		<?php
		if ( have_posts() ) : ?>

			 <h1 class="common_heading"><?php printf( esc_html__( 'Search Results for: %s', 'swisscham' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
			
			<?php
			
			while ( have_posts() ) : the_post();

				
				get_template_part( 'template-parts/content', 'search' );

			endwhile;


		else: ?>
		          <h1 class="common_heading"><?php printf( esc_html__( 'Search Results for: %s', 'swisscham' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
      <?php
			get_template_part( 'template-parts/content', 'none' );

		endif; ?>

		</div>
    
	</div>
	<?php get_sidebar(); ?>
</div>
</section>

        <?php if ( $swisschkr==1 ) {
          get_footer();
         } if ( $swisschkr==2 ) {
          get_footer('bei');
         } if ( $swisschkr==3 ) {
          get_footer('sha');
         } if ( $swisschkr==4 ) {
          get_footer('gz');
         } if ( $swisschkr==5 ) {
          get_footer('hk');
         } ?>