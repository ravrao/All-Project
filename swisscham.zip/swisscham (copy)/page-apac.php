<?php
/*
	Template Name: APAC
*/
	get_header(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo site_url(); ?>">Hong Kong</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Events
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> SwissCham APAC Events
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $armed = get_post( 213 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $armed->post_title; ?></h1>
                        <?php $pagebgz70 = $armed->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top text-center">
                        <p class="text-center"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" /></p>
                        <ul class="fa-ul no-bullet apac_calendar_loc">
                            <li><a href="<?php echo web_url(); ?>bei/upcoming-events/"><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</a></li>
                            <li><a href="<?php echo web_url(); ?>sha/upcoming-events/"><i class="fa fa-map-marker" aria-hidden="true"></i> Shanghai</a></li>
                            <li><a href="<?php echo web_url(); ?>gz/upcoming-events/"><i class="fa fa-map-marker" aria-hidden="true"></i> Guangzhou</a></li>
                        </ul>
                    </div>
                    <?php echo get_field( "content_below_upcoming_events_links", 213 ); ?>
                </div>

                <?php get_sidebar(); ?>

                            </div>
        </section>

         <?php get_footer('hk'); ?>