<?php
/*
    Template Name: Other Links
*/
    get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Other Links
                        </li>
                    </ul>
                </nav>
            </div>-->
        <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
        <?php if ( $swisschkr==1 ) { ?>
                    <?php $post_919 = get_post( 919 );
                        $pagebgz919 = $post_919->post_content;

                            $pagebgz919 = apply_filters('the_content', $pagebgz919);
                            $pagebgz919 = str_replace(']]>', ']]&gt;', $pagebgz919);
                            echo $pagebgz919;
                    ?>
        <?php } if ( $swisschkr==2 ) { ?>
                    <?php $post_919 = get_post( 253 );
                        $pagebgz919 = $post_919->post_content;

                            $pagebgz919 = apply_filters('the_content', $pagebgz919);
                            $pagebgz919 = str_replace(']]>', ']]&gt;', $pagebgz919);
                            echo $pagebgz919;
                    ?>
        <?php } if ( $swisschkr==3 ) { ?>
                    <?php $post_919 = get_post( 270 );
                        $pagebgz919 = $post_919->post_content;

                            $pagebgz919 = apply_filters('the_content', $pagebgz919);
                            $pagebgz919 = str_replace(']]>', ']]&gt;', $pagebgz919);
                            echo $pagebgz919;
                    ?>
        <?php } if ( $swisschkr==4 ) { ?>
                    <?php $post_919 = get_post( 176 );
                        $pagebgz919 = $post_919->post_content;

                            $pagebgz919 = apply_filters('the_content', $pagebgz919);
                            $pagebgz919 = str_replace(']]>', ']]&gt;', $pagebgz919);
                            echo $pagebgz919;
                    ?>
        <?php } if ( $swisschkr==5 ) { ?>
                    <?php $post_919 = get_post( 178 );
                        $pagebgz919 = $post_919->post_content;

                            $pagebgz919 = apply_filters('the_content', $pagebgz919);
                            $pagebgz919 = str_replace(']]>', ']]&gt;', $pagebgz919);
                            echo $pagebgz919;
                    ?>
        <?php } ?>
                    </div>

        <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>