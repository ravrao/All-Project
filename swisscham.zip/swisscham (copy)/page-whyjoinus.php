<?php 
/*
Template Name: Why Join Us
*/
	get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
<li>
     <span class="show-for-sr">Current: </span> Membership
</li>
                        <li>
        <?php if ( $swisschkr==1 ) { ?>
                            <span class="show-for-sr">Current: </span> Why Join Us
        <?php } if ( $swisschkr==2 ) { ?>
                            <span class="show-for-sr">Current: </span> Why Join Us - Beijing
        <?php } if ( $swisschkr==3 ) { ?>
                            <span class="show-for-sr">Current: </span> Why Join Us - Shanghai
        <?php } if ( $swisschkr==4 ) { ?>
                            <span class="show-for-sr">Current: </span> Why Join Us - Guangzhou
        <?php } if ( $swisschkr==5 ) { ?>
                            <span class="show-for-sr">Current: </span> Why Join Us - Hong Kong
        <?php } ?>
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
        <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 491 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 491); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('member_benifites_title', 491); ?></h3>
                        <?php echo get_field('member_benefits', 491); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('meet,_learn,_exchange_and_celebrate_title', 491); ?></h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 491); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading"><?php echo get_field('make_your_voice_heard_title!', 491); ?></h3>
                        <?php echo get_field('make_your_voice_heard!', 491); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 491); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('be_visible_title', 491); ?></h3>
                        <?php echo get_field('be_visible!', 491); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading"><?php echo get_field('fees_title', 491); ?></h3>
                        <?php echo get_field('fees', 491); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 491); ?>">APPLY ONLINE</a>
                        </p>
                    </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>


                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 206 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 206); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Member Benefits</h3>
                        <?php echo get_field('member_benefits', 206); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Meet, learn, exchange and celebrate!</h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 206); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading">Make your voice heard!</h3>
                        <?php echo get_field('make_your_voice_heard!', 206); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 206); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Be visible!</h3>
                        <?php echo get_field('be_visible!', 206); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Fees</h3>
                        <?php echo get_field('fees', 206); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 206); ?>">APPLY ONLINE</a>
                        </p>
                    </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>


                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 165 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 165); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Member Benefits</h3>
                        <?php echo get_field('member_benefits', 165); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Meet, learn, exchange and celebrate!</h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 165); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading">Make your voice heard!</h3>
                        <?php echo get_field('make_your_voice_heard!', 165); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 165); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Be visible!</h3>
                        <?php echo get_field('be_visible!', 165); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Fees</h3>
                        <?php echo get_field('fees', 165); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 165); ?>">APPLY ONLINE</a>
                        </p>
                    </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } if ( $swisschkr==4 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 137 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 137); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Member Benefits</h3>
                        <?php echo get_field('member_benefits', 137); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Meet, learn, exchange and celebrate!</h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 137); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading">Make your voice heard!</h3>
                        <?php echo get_field('make_your_voice_heard!', 137); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 137); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Be visible!</h3>
                        <?php echo get_field('be_visible!', 137); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Fees</h3>
                        <?php echo get_field('fees', 137); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 137); ?>">APPLY ONLINE</a>
                        </p>
                    </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } if ( $swisschkr==5 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_swiss_wju = get_post( 146 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_swiss_wju->post_title; ?></h1>
                        
                        <?php 
                                $post_swiss_wju2 = $post_swiss_wju->post_content;

                            $post_swiss_wju2 = apply_filters('the_content', $post_swiss_wju2);
                            $post_swiss_wju2 = str_replace(']]>', ']]&gt;', $post_swiss_wju2);
                            echo $post_swiss_wju2; ?>

                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 146); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Member Benefits</h3>
                        <?php echo get_field('member_benefits', 146); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Meet, learn, exchange and celebrate!</h3>
                        <?php echo get_field('meet,_learn,_exchange_and_celebrate!', 146); ?>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <h3 class="common_subheading">Make your voice heard!</h3>
                        <?php echo get_field('make_your_voice_heard!', 146); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 146); ?>">APPLY ONLINE</a>
                        </p>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Be visible!</h3>
                        <?php echo get_field('be_visible!', 146); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Fees</h3>
                        <?php echo get_field('fees', 146); ?>
                        <p>
                            <a class="hollow button common_hollow" href="<?php echo get_field('apply_online_button', 146); ?>">APPLY ONLINE</a>
                        </p>
                    </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } ?>

                <?php get_sidebar(); ?>

                            </div>
        </section>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>