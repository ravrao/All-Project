<?php
	get_header();
    $swisschkr = multisite_globalizer(); ?>
        <?php if ( $swisschkr==1 ) { ?>
	<?php if (is_single('630')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                        <li>
                           <?php if( have_posts() ); ?>
                                 <?php 
                                       while( have_posts() ) : the_post(); ?>
                                          <span class="show-for-sr">Current: </span><?php echo the_title(); ?>
                                  <?php endwhile; ?>        
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_632 = get_post( 630 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 630); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>

	<?php } if (is_single('632')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_632 = get_post( 632 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Extensive Market</h3>
                            <?php echo get_field('4._extensive_market', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 632); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>
	<?php } if (is_single('635')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_635 = get_post( 635 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_635->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 635); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                    		<?php echo get_field('slide_images', 635); ?>
                    </div>


                </div>


	<?php } if (is_single('626')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_626 = get_post( 626 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_626->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Orientations and Planning</h3>
                            <?php echo get_field('3._orientations_and_planning', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 626); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                        <?php echo get_field('slide_images', 626); ?>
                    </div>

                </div>


	<?php } if (is_single('624')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_624 = get_post( 624 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_624->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives </h3>
                            <?php echo get_field('3._objectives', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 624); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>

	<?php } if (is_single('621')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_621 = get_post( 621 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_621->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>               
                            <?php echo get_field('1._introduction', 621); ?>
                           
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 621); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 621); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities </h3>                            
                            <?php echo get_field('4._opportunities', 621); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 621); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>                            
                            <?php echo get_field('6._contact', 621); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        
                        <?php echo get_field('section_beneath_contact', 621); ?>


                    </div>

                </div>

	<?php } if (is_single('763')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_763 = get_post( 763 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_763->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>                            
                            <?php echo get_field('1._introduction', 763); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>                            
                            <?php echo get_field('2._location', 763); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Matchmaking Platform Introduction</h3>
                            <?php echo get_field('3._matchmaking_platform_introduction', 763); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Key Advantages</h3>
                            <?php echo get_field('4._key_advantages', 763); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 763); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>
                            <?php echo get_field('6._contact', 763); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>

	<?php } ?>
        <?php } if ( $swisschkr==2 ) { ?>
	<?php if (is_single('197')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_632 = get_post( 197 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 197); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>

	<?php } if (is_single('199')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_632 = get_post( 199 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Extensive Market</h3>
                            <?php echo get_field('4._extensive_market', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 199); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>
	<?php } if (is_single('201')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_635 = get_post( 201 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_635->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 201); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                    		<?php echo get_field('slide_images', 201); ?>
                    </div>


                </div>


	<?php } if (is_single('193')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_626 = get_post( 193 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_626->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Orientations and Planning</h3>
                            <?php echo get_field('3._orientations_and_planning', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 193); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                        <?php echo get_field('slide_images', 193); ?>
                    </div>

                </div>


	<?php } if (is_single('191')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_624 = get_post( 191 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_624->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives </h3>
                            <?php echo get_field('3._objectives', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 191); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>

	<?php } if (is_single('189')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_621 = get_post( 189 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_621->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>               
                            <?php echo get_field('1._introduction', 189); ?>
                           
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 189); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities </h3>                            
                            <?php echo get_field('4._opportunities', 189); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>                            
                            <?php echo get_field('6._contact', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        
                        <?php echo get_field('section_beneath_contact', 189); ?>


                    </div>

                </div>

	<?php } if (is_single('232')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_763 = get_post( 232 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_763->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>                            
                            <?php echo get_field('1._introduction', 232); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>                            
                            <?php echo get_field('2._location', 232); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Matchmaking Platform Introduction</h3>
                            <?php echo get_field('3._matchmaking_platform_introduction', 232); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Key Advantages</h3>
                            <?php echo get_field('4._key_advantages', 232); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 232); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>
                            <?php echo get_field('6._contact', 232); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>
	<?php } ?>
        <?php } if ( $swisschkr==3 ) { ?>
	<?php if (is_single('156')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_632 = get_post( 156 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 156); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>

	<?php } if (is_single('158')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_632 = get_post( 158 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Extensive Market</h3>
                            <?php echo get_field('4._extensive_market', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 158); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>
	<?php } if (is_single('160')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_635 = get_post( 160 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_635->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 160); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                    		<?php echo get_field('slide_images', 160); ?>
                    </div>


                </div>


	<?php } if (is_single('152')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_626 = get_post( 152 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_626->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Orientations and Planning</h3>
                            <?php echo get_field('3._orientations_and_planning', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 152); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                        <?php echo get_field('slide_images', 152); ?>
                    </div>

                </div>


	<?php } if (is_single('150')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_624 = get_post( 150 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_624->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives </h3>
                            <?php echo get_field('3._objectives', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 150); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>

	<?php } if (is_single('148')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_621 = get_post( 148 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_621->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>               
                            <?php echo get_field('1._introduction', 148); ?>
                           
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 148); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 148); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities </h3>                            
                            <?php echo get_field('4._opportunities', 148); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 148); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>                            
                            <?php echo get_field('6._contact', 148); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        
                        <?php echo get_field('section_beneath_contact', 148); ?>


                    </div>

                </div>

	<?php } if (is_single('189')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_763 = get_post( 189 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_763->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>                            
                            <?php echo get_field('1._introduction', 189); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>                            
                            <?php echo get_field('2._location', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Matchmaking Platform Introduction</h3>
                            <?php echo get_field('3._matchmaking_platform_introduction', 189); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Key Advantages</h3>
                            <?php echo get_field('4._key_advantages', 189); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>
                            <?php echo get_field('6._contact', 189); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>
	<?php } ?>
        <?php } if ( $swisschkr==4 ) { ?>
	<?php if (is_single('129')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_632 = get_post( 129 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 129); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>

	<?php } if (is_single('131')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_632 = get_post( 131 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_632->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Industries</h3>
                            <?php echo get_field('3._industries', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Extensive Market</h3>
                            <?php echo get_field('4._extensive_market', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 131); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>
	<?php } if (is_single('133')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_635 = get_post( 133 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_635->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 133); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                    		<?php echo get_field('slide_images', 133); ?>
                    </div>


                </div>


	<?php } if (is_single('125')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_626 = get_post( 125 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_626->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Orientations and Planning</h3>
                            <?php echo get_field('3._orientations_and_planning', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 125); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                    <div class="large-12 columns ticker_container">
                        <?php echo get_field('slide_images', 125); ?>
                    </div>

                </div>

	<?php } if (is_single('123')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_624 = get_post( 123 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_624->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>
                            <?php echo get_field('1._introduction', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives </h3>
                            <?php echo get_field('3._objectives', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities</h3>
                            <?php echo get_field('4._opportunities', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contacts</h3>
                            <?php echo get_field('6._contacts', 123); ?>
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>
                </div>

	<?php } if (is_single('121')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_621 = get_post( 121 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_621->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>               
                            <?php echo get_field('1._introduction', 121); ?>
                           
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>
                            <?php echo get_field('2._location', 121); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Objectives</h3>
                            <?php echo get_field('3._objectives', 121); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Opportunities </h3>                            
                            <?php echo get_field('4._opportunities', 121); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 121); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>                            
                            <?php echo get_field('6._contact', 121); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        
                        <?php echo get_field('section_beneath_contact', 121); ?>


                    </div>

                </div>
                
	<?php } if (is_single('156')) { ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_763 = get_post( 156 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_763->post_title; ?></h1>
                    </div>

                    <div class="large-12 columns">

                        <div class="inv_inner_sec">
                            <h3>1. Introduction</h3>                            
                            <?php echo get_field('1._introduction', 156); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>2. Location</h3>                            
                            <?php echo get_field('2._location', 156); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>3. Matchmaking Platform Introduction</h3>
                            <?php echo get_field('3._matchmaking_platform_introduction', 156); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>4. Key Advantages</h3>
                            <?php echo get_field('4._key_advantages', 156); ?>
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>5. Further Links </h3>
                            <?php echo get_field('5._further_links', 156); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                        <div class="inv_inner_sec">
                            <h3>6. Contact</h3>
                            <?php echo get_field('6._contact', 156); ?>

                        </div>
                        <div class="large-12 columns no_padding">
                            <hr class="right_devider">
                        </div>
                    </div>

                </div>
	<?php } ?>
        <?php } ?>

                <?php get_sidebar(); ?>
            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>

        <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.webticker.js"></script>
        <script type="text/javascript">
        $(function() {
            $("#webticker").webTicker({
                duplicate: true,
                speed: 40,
                direction: 'left',
                //rssurl: '',
                rssfrequency: 1,
                startEmpty: false,
                hoverpause: true
            });
        });
    </script>