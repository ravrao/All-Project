<?php
/*
    Template Name: BoardBEI
*/

    get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?> 
                      <li>
                            <span class="show-for-sr">Current: </span> About Us
                        </li>
                       <li>
                            <span class="show-for-sr">Current: </span> Board - Beijing
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">

                        <?php if ( $swisschkr==1 ) {

                        $post_64 = get_post( 64 ); ?>

                        <h1 class="common_heading"><?php echo $post_64->post_title; ?></h1>

                        <?php $pagebb = $post_64->post_content;

                            $pagebb = apply_filters('the_content', $pagebb);
                            $pagebb = str_replace(']]>', ']]&gt;', $pagebb);
                            
                                echo $pagebb; ?>

                        <?php } if ( $swisschkr==2 ) {

                            $post_145 = get_post( 145 ); ?>

                        <h1 class="common_heading"><?php echo $post_145->post_title; ?></h1>

                        <?php $pagebbws = $post_145->post_content;

                            $pagebbws = apply_filters('the_content', $pagebbws);
                            $pagebbws = str_replace(']]>', ']]&gt;', $pagebbws);
                            
                                echo $pagebbws; ?>

                        <?php } ?>


                    </div>
                    <div class="large-12 columns" data-equalizer="boardDetailsAlign">
                        <div class="row" data-equalizer="boardOuter">

<?php if ( $swisschkr==1 ) { ?>

<?php $bbbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'boardmember',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'board_cat',
                     'field' => 'slug',
                     'terms' => 'board-beijing'
                  )
               )
            );

            $bbb_array = get_posts( $bbbarg );
           
            foreach ($bbb_array as $bbb_arr) {

            $bbbmimg = wp_get_attachment_image_src( get_post_thumbnail_id( $bbb_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-3 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">
                                    <div class="board_img">
                                        <p class="text-center"><img src="<?php echo $bbbmimg[0]; ?>" /></p>
                                    </div>
                                    <div class="board_details" data-equalizer-watch="boardDetailsAlign">
                                        <h2><?php echo $bbb_arr->post_title; ?></h2>
                                        <h3><?php echo get_field( "functional_role", $bbb_arr->ID ); ?></h3>
                                <?php $bbbmpstn = get_field( "position", $bbb_arr->ID );
                                        if (!($bbbmpstn=='')) { ?>
                                <h5><?php echo $bbbmpstn; ?></h5>
                                        <?php } ?>
                                    </div>
                                <?php $bbbbl = get_field( "organization", $bbb_arr->ID );
                                        if (!($bbbbl=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="<?php echo get_field( "organization_link", $bbb_arr->ID ); ?>"><?php echo $bbbbl; ?></a></p>
                                    </div>
                                <?php } ?>
                                </div>
                            </div>

                <?php } ?>

                <?php } if ( $swisschkr==2 ) { ?>

<?php $bbbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'boardmember',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $bbb_array = get_posts( $bbbarg );
           
            foreach ($bbb_array as $bbb_arr) {

            $bbbmimg = wp_get_attachment_image_src( get_post_thumbnail_id( $bbb_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-3 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">
                                    <div class="board_img">
                                        <p class="text-center"><img src="<?php echo $bbbmimg[0]; ?>" /></p>
                                    </div>
                                    <div class="board_details" data-equalizer-watch="boardDetailsAlign">
                                        <h2><?php echo $bbb_arr->post_title; ?></h2>
                                        <h3><?php echo get_field( "functional_role", $bbb_arr->ID ); ?></h3>
                                <?php $bbbmpstn = get_field( "position", $bbb_arr->ID );
                                        if (!($bbbmpstn=='')) { ?>
                                <h5><?php echo $bbbmpstn; ?></h5>
                                        <?php } ?>
                                    </div>
                                <?php $bbbbl = get_field( "organization", $bbb_arr->ID );
                                        if (!($bbbbl=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="<?php echo get_field( "organization_link", $bbb_arr->ID ); ?>"><?php echo $bbbbl; ?></a></p>
                                    </div>
                                <?php } ?>
                                </div>
                            </div>

                <?php } ?>

                <?php } ?>

                        </div>
                    </div>
                </div>


             <?php get_sidebar(); ?>

                <!--<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="images/inner_sponser1.jpg" /></li>
                                <li><img src="images/inner_sponser2.jpg" /></li>
                                <li><img src="images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>-->


            </div>
        </section>

    <?php //get_footer(); ?>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>
