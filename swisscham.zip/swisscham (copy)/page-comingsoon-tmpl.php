<?php
/*
	Template Name: Coming Soon
*/

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Example of Bootstrap 3 Accordion with Plus/Minus Icon</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

<style type="text/css">
    
body,html{ height: 100%;}
#comingsoon-wrapper {position: relative;height:100%;background: url('<?php bloginfo('template_url')?>/comimgsoon.jpg') no-repeat; background-size:cover;font-family: 'Roboto', sans-serif;}
#main {position: relative;}
.countdown{text-align:center;margin:70px 0 0 0;}
.container_count {width:auto;display:inline-block;margin: 10px 60px;text-align:center;text-transform: uppercase;font-size: 12px;}
.creative{background-color: #fff;width: 300px;padding: 20px;margin: 30px auto 40px auto;}
.creative img{ width: 100%;}
#comingsoon-wrapper h1{font-size: 70px;line-height: 76px;font-family: "Helvetica Neue", Arial, sans-serif;font-weight: 400; color: #fff; text-transform: capitalize;margin: 90px 0 50px 0;}
#comingsoon-wrapper h4{color: #fff;font-size: 16px;font-weight: 500;text-transform: uppercase;}
.coming-social{width: 100%;color: #fff;font-size: 24px;margin-top: 50px;text-align: center; margin-bottom: 70px;}
.coming-social a{color: #fff; margin: 0 10px;}
.coming-social a:last-child{ margin-right: 0;}
.copyright{text-align: center;color: #fff;font-size: 14px;}



</style>





</head>
<body>
    <div id="comingsoon-wrapper">
	<div id="main">
		<div class="container">			
			<div class="row countdown">
                            <div class="col-md-12"> 
                                <h4>Get ready! Something really cool is coming!</h4>
                                <div class="creative">
                                    <img src="<?php bloginfo('template_url')?>/logo.png" alt="">
                                </div>
                                <h1>coming soon page</h1>
                            </div> 
			</div>           
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="coming-social">
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                            <p class="copyright">Copyright © 2016 Swiss Chinese Chamber of Commerce</p>
                        </div>
                    </div>       
                          
              
                </div><!-- End container -->
         </div><!-- End main --> 

    </div>
</body>
</html>                                		                                		                                		


