<?php
/*
	Template Name: Magazine
*/

	get_header(); ?>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                         <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> The Bridge
                        </li>
                    </ul>
                </nav>
            </div>-->
        <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <h1 class="common_heading"><?php the_title(); ?></h1>
                       <?php the_content(); ?>
                   <?php endwhile; ?>
                    <?php
 $args=array(
'posts_per_page'=>-1,
'order'=>DES,
'post_type' =>'bridge_magazine'
);
 
  $data_display = new WP_query($args);
 // echo '<pre>';print_r($data_display);
?>
             
<?php while ($data_display->have_posts()) :$data_display->the_post(); 
	 $newsdetail= get_post_meta($post->ID, 'pm_bridgecontent'); 

$image_url = get_post_meta( $newsdetail[0][0]['upload-bridge-magazine'], '_wp_attached_file' );
$Qrcode_url = get_post_meta( $newsdetail[0][0]['upload-qr-code'], '_wp_attached_file' );
$advspon_url = get_post_meta( $newsdetail[0][0]['our-advertisers-and-sponsors-for-this-issue'], '_wp_attached_file' );
 $upload_path=wp_upload_dir();
//print_r ($advspon_url);
	 //print_r($newsdetail); ?>
	 <?php $image1 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' ); ?>
                        <p class="float_img">
                            <span><img src="<?php echo $image1[0] ?>" /></span><?php the_content(); ?></p>
                        <h5>Price : <span>FREE</span></h5>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <p>Here’s how to access The Bridge:</p>

                        <ul class="fa-ul custom_plus_list margin_left0">
                            <li>To read it <strong>online</strong> or on your <strong>mobile phone</strong> or <strong>tablet</strong>, <a target="_blank" href="<?php echo $newsdetail[0][0]['link-to-read-online-or-on-your-mobile-phone'];?>">click here</a>.</li>
                            <li>To download the magazine, <a target="_blank" href="<?php  echo $upload_path['baseurl']."/".$image_url[0];?>">click here</a>.</li>
                            <li>To access The Bridge Archives, <a href="<?php echo site_url('/the-bridge-magazine-archives/', 'http' ); ?>">click here</a>.</li>
                            <li>To participate in the Bridge Survey, <a target="_blank" href="<?php echo $newsdetail[0][0]['link-to-participate-in-the-bridge-survey'];?>">click here</a>.</li>
                            <li>Scan this <strong>QR Code</strong> and you will be able to read The Bridge magazine on your mobile phone</li>
                        </ul>
                        <p><img src="<?php  echo $upload_path['baseurl']."/".$Qrcode_url[0];?>" /></p>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_devider">
                    </div>
                    <?php endwhile; ?>
                    <?php  wp_reset_postdata(); ?>
                    <div class="large-12 columns dowedo_top margin_top10">
                    <?php
 $args2=array(
'posts_per_page'=> -1,
'order'=>DES,
'post_type' =>'bmsponsor'
);
 
  $latstsponsors = new WP_query($args2);
 // echo '<pre>';print_r($data_display);
?>
                        <h3 class="common_subheading">Our advertisers and sponsors for this issue are:</h3>
                        <!--                        <p>Our advertisers and sponsors for this issue are: </p>-->
                        <ul class="fa-ul mbp_spons">
<?php while ($latstsponsors->have_posts()) :$latstsponsors->the_post(); 

                $imagenew = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' ); 
                 $imagelink= get_post_meta($post->ID, 'pmbmsponsor'); ?>
                            <li>
                             <a href="<?php echo $imagelink[0][0]['enter-the-sponsor-link'];?>"> <img src="<?php echo $imagenew[0];?>" /> </a>
                            </li>
                     <?php endwhile; ?>  
                        </ul>
                    </div>
                </div>

                <?php get_sidebar(); ?>
            </div>
        </section>

	<?php get_footer(); ?>