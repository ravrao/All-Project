<?php
/*
    Template Name: Sino News
*/

    get_header(); ?>

<style>
    
    span.highlight{
  background: #f1c40f;
}

</style>


        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> News
                        </li>
                    </ul>
                </nav>
            </div>-->
           <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">News</h1>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns margin_bottom15">
                            <div class="large-12 columns pattern_bg">
                                <!-- /* commented as per the poin #20 from SwissCham user acceptance test version */ <div class="large-3 columns news_dropmenu">
                                    <label>CATAGORY
                                        <select id="snb">
                                        <option value="select">-Select-</option>
                        <?php /*$nwtrmswisss = get_terms( array(
                                    'taxonomy' => 'news_cat',
                                    'hide_empty' => true,
                                ) );
                            
                            foreach ($nwtrmswisss as $nwtrmswiss) {*/ ?>
                                <option value="<?php //echo $nwtrmswiss->slug; ?>"><?php //echo $nwtrmswiss->name; ?></option>
                        <?php //} ?>
                                        </select>
                                    </label>
                                </div> -->
                                <div class="large-3 columns news_dropmenu">
                                    <label>DATE
                                        <select id="swny">
                                            <option value="year">-Year-</option>
                                            <option value="2012">2012</option>
                                            <option value="2013">2013</option>
                                            <option value="2014">2014</option>
                                            <option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                            <option value="2019">2019</option>
                                            <option value="2020">2020</option>
                                            <option value="2021">2021</option>
                                            <option value="2022">2022</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="large-9 columns news_dropmenu">
                                    <label>KEYWORD
                                        <form>
                                        <div class="input-group">
                                           
                                            <input type="text" id ="myData" class="input-group-field news_search_field"  name="keyword" placeholder="Type any keywords" >
                                            <div class="input-group-button">
<!--                                                <a href="#" id="nwkbut" class="button news_search_button"><i class="fa fa-search" aria-hidden="true"></i></a>-->
                                                <button type="button" class="button news_search_button" id="myButton"  name="perform"><i class="fa fa-search" aria-hidden="true"></i></button>
                                            </div>
                                        </div>
                                        
                                        </form>
                                
                                    </label>
                                </div>
                                
                                 
                            </div>
                        </div>
                    </div>
                    <div class="newsfilter" style="position:relative; float: left; width: 100%;">

         <?php $paged1 = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
       //echo $paged1;
        ?>


       <?php 
$argsevents = array('post_type' => 'news',
                 'posts_per_page' => 10,
                 'paged' => $paged1
                 );
                 ?>  

                  



            <?php $eventspost = new wp_Query($argsevents); ?>

        <?php while ($eventspost->have_posts()) :  $eventspost->the_post();

            $newsimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );  
                   $newsid = get_the_id(); 
                    //print_r($newsid);?>

                    <div class="large-12 columns no_padding panel-body context">
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">
                                <img src="<?php echo $newsimg[0]; ?>" />
                                <!-- <a class="text-center" href="<?php //echo get_field('news_title_link', $newsid); ?>"><img src="<?php //echo $newsimg[0]; ?>" /></a> -->
                            </div>
                            <div class="large-10 columns dowedo_top">
                                <h3 class="common_subheading"><?php echo the_title(); ?></h3>
                                <!-- <a target="_blank" href="<?php //echo get_field('news_title_link', $newsid); ?>">
                                <h3 class="common_subheading"><?php //echo the_title(); ?></h3></a> -->
                                <h5 class="light_text">Published by <?php echo get_field('published_by', $newsid); ?> |  <?php echo get_the_date('d F Y', $newsid); ?>  <!--|  n category of SwissCham Publications. English, Chinese?--> </h5>
                            </div>
                            
                            
                        </div>
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">

                            </div>
                            
                            <div class="large-10 columns dowedo_top">
                            <?php $pagenw = get_the_content();

                            $pagenw = apply_filters('the_content', $pagenw);
                            $pagenw = str_replace(']]>', ']]&gt;', $pagenw);

                            echo mb_strimwidth($pagenw, 0, 400, '...'); ?>

                                <p><a href="<?php echo get_the_permalink( $newsid ); ?>">Read more</a></p>
                            </div>
                           
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>
            <?php endwhile; ?>

            <div class="large-12 columns no_padding">
                <div class="expert-pagn">
                    <ul class="pagination" role="navigation" aria-label="Pagination">
                    
    <?php if ($eventspost->max_num_pages > 1) { // check if the max number of pages is greater than 1  ?>
                
                  
   <?php
$vbig = 999999999; // need an unlikely integer
echo paginate_links( array(
    'base' => str_replace( $vbig, '%#%', esc_url( get_pagenum_link( $vbig ) ) ),
    'format' => '?paged=%#%',

    'current' => max( 1, get_query_var('paged') ),
    'total' => $eventspost->max_num_pages,
    'type' => 'list'
) );

?>
<?php } ?>




                    </ul>
                </div>
            </div>
                    </div>
                    
                    

                </div>
                <?php get_sidebar(); ?>
            </div>
        </section>

      <script type="text/javascript">
      var base_url = "<?php echo get_bloginfo('url'); ?>"
      var templ_url= "<?php echo web_url(); ?>wp-content/uploads/2016/11/";
      </script>
 <script type="text/javascript" src='<?php echo get_bloginfo('template_directory'); ?>/js/swiss.js'></script>
 

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.highlight-5.js"></script>


<script>
   var $jqr = jQuery.noConflict();
    $jqr(function() {
  var $context = $jqr(".context");
  var $form = $jqr("form");
  var $button = $form.find("button[name='perform']");
  var $input = $form.find("input[name='keyword']");

  $button.on("click.perform", function() {

    // Determine search term
    var searchTerm = $input.val();

    // Remove old highlights and highlight
    // new search term afterwards
    $context.removeHighlight();
    $context.highlight(searchTerm);

  });
  $button.trigger("click.perform");
});
</script>
<!--<script>
$jqr(function () {

    $("#myButton").click(function () {
        var name = $jqr("#myData").val();
        alert(name);
        localStorage.setItem('username',name);
    });
});

//alert(localStorage.getItem("username"));

</script>-->
    <?php get_footer(); ?>