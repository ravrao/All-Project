<?php
/*
  Template Name: set baidu HongKong
*/
?>

<html class="no-js" lang="en">

<head>
    <!--added on 10th nov for seo plugin-->
    <meta name="google-site-verification" content="EoHiBQ3VqXUuo-kpSFaLnz2Z9Etb2tZrypls-rd9RuE" />

 
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<div class="medium-12 columns margin_top10 membership_from no_padding">
<div class="large-12 columns margin_top10">
<?php
$EID=$_GET['contentval'];
query_posts('post_id=$EID&post_type=event');
while (have_posts()): the_post();

  //$EID=$_GET['contentval'];
 //$cpost = get_post($fetchingid);
query_posts( array('p' => $EID) );
$fetchingid = $EID;

 $fetchingtitle= get_the_title($EID);
 
 $fetcingvaluechinese = get_post_meta($EID,'pm_chinese');
//echo get_post_meta(323, 'enter-chinese-location', true);
 //print_r($fetcingvaluechinese);
 $locationinchinese= $fetcingvaluechinese[0][0]['enter-english-location-for-hongkong']; 
//echo 'gdgdgddgdgdgdgd'.$locationinchinese;
 //echo  "<h1 class='common_heading'><span class='taxi-dir-icon'><i class='fa fa-taxi' aria-hidden='true'></i></span> ".$fetchingtitle."</h1>";
 ?>
 <h1 class='common_heading'>
     <span class='taxi-dir-icon'><i class='fa fa-taxi' aria-hidden='true'></i></span>
         <?php echo do_shortcode('[event post_id="'.$fetchingid.'"]#_LOCATIONNAME[/event]'); ?>
         <?php //echo $fetchingtitle; ?></h1>
     <p class="taxi-address">请带我去 <?php echo $locationinchinese; ?></p>
<?php endwhile; ?>
</div>

<input type="hidden" name="address" id="address1" value="<?php echo $locationinchinese; ?>" />
<input type="hidden" name="city" id="city" value="<?php echo do_shortcode('[event post_id="'.$fetchingid.'"]#_LOCATIONTOWN[/event]'); ?>" />



<input type="hidden" name="address" id="address1" value="<?=$locationinchinese?>"/>
<div class="large-12 columns margin_top10">
<div style="width:100%;height:300px;border:#ccc solid 1px;float:left;" id="map_canvas"></div><br/>
</div>
<input type="hidden" name="locat_ID" id="locat_ID" value="<?php echo $locationinchinese?>"/>
 <!------------------------------------- Googel Map Integration------------------------------------!-->
 <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCweO2okyDMj7-asSAs1u4x2Irui0syrlI"></script> 
<script>
$(document).ready(function(){ 

    //var zip_in='700104'; 
    
         var zip_in= $('#locat_ID').val();                                           
        
    if ((zip_in.length >= 6)){ 
            $.ajax({
                 
                 url: "http://maps.googleapis.com/maps/api/geocode/json?address="+ zip_in +"&sensor=false",
                 cache: false,
                 dataType: "json",
                 type: "GET",
                 success: function(result, success) {
                    
                    lattitude = result.results[0].geometry.location.lat; 
                    longitude = result.results[0].geometry.location.lng; 
                    //console.log(lattitude); console.log(longitude);
                                        
                    var myLatlng = new google.maps.LatLng(lattitude, longitude); 
                    var myOptions = { zoom: 16, center: myLatlng, mapTypeId: google.maps.MapTypeId.ROADMAP };
                    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions); 
                    var marker = new google.maps.Marker({ position: myLatlng, map: map }); 
                                       
                 },
                 error: function(result, error) {
                        //console.log(result);
                        console.log(error);
                 },
                 complete: function(result, success) {
                        //console.log(result);
                        console.log(success);					
                 }
           });

     }
     
     
     
  });
</script>

<link rel="stylesheet" href="<?php echo web_url();?>wp-content/themes/swisscham/css/app.css">
    <link rel="stylesheet" href="<?php echo web_url();?>wp-content/themes/swisscham/css/swiss.css">
   <div class="large-12 columns margin_bottom15 margin_top10">
   <div class="pattern_bg">
        <ul class="fa-ul no-bullet event_list_details taxi_baidu_icon">
           
                    
                    
                    <li>
                    <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <span class="event_list_name">TIME</span></p>
                        <p class="second_singel_eventdesc"><?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME[/event]'); 



                            ?>
                            <?php $dt=do_shortcode('[event post_id="' . $fetchingid . '"]#d #F #Y[/event]');

                            $ctadte=date('d F Y');
                            ?>
                    </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span> <span class="event_list_name">Venue</span></p>
                           <p class="second_singel_eventdesc"> <?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#_LOCATIONNAME[/event]'); ?>
                        </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span></p>
                          <p class="second_singel_eventdesc">  <?php echo do_shortcode('[event post_id="' . $fetchingid . '"]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>
                        </p>
                    </li>
                    <li>
                        <p class="first_singel_eventdesc"><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">PRICE</span></p>
                        <?php

                        $rs_eventID=$wpdb->get_row("SELECT  * FROM  `sc_em_events` where `post_id`='".$fetchingid."'");

                        $rs_eventID=$wpdb->get_results("SELECT  * FROM  `sc_em_tickets` where `event_id`='". $rs_eventID->event_id."'");

                        ?>

                        <p class="second_singel_eventdesc">

                        <?php
                        $i=1;
                        foreach($rs_eventID as $EventTicket)
                        {
                            echo $EventTicket->ticket_name.'&nbsp;'.(HKD).'&nbsp;'; 
                            echo number_format("$EventTicket->ticket_price");
                            if($i==1) { echo '&nbsp; |'; }
                             //Member HKD 500 | Non Members HKD 200 
                        ?> 

                        <?php $i=$i+1; } ?>    
                        </p>
                    </li>
                    
                    
                </ul>
                            </div>
							</div>
</div>

 <style>
 .taxi-dir-icon
 {
	 padding: 4px 8px;
	 border-radius: 5px;
	 border: #ccc 1px solid;
	 background-color:#aa0008;
	 color: #fff;
 }
 </style>
 </html>