<?php
/**
 * SwissCham functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package SwissCham
 */

if ( ! function_exists( 'swisscham_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function swisscham_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on SwissCham, use a find and replace
	 * to change 'swisscham' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'swisscham', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'swisscham' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'swisscham_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif;
add_action( 'after_setup_theme', 'swisscham_setup' );

require_once('inc/wp_pmcustom_navwalker.php');


/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function swisscham_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'swisscham_content_width', 640 );
}
add_action( 'after_setup_theme', 'swisscham_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function swisscham_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'swisscham' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'swisscham' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

}
add_action( 'widgets_init', 'swisscham_widgets_init' );
add_action('admin_enqueue_scripts', 'swisscham_widget');
function swisscham_widget() {
    wp_enqueue_media();
    wp_enqueue_script('ads_script', get_template_directory_uri() . '/js/widget.js', false, '1.0', true);
}
/**
 * Enqueue scripts and styles.
 */
function swisscham_scripts() {
	wp_enqueue_style( 'swisscham-style', get_stylesheet_uri() );

	wp_enqueue_script( 'swisscham-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'swisscham-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'swisscham_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/*Start of Customization*/

/**/
add_filter( 'auto_update_plugin', '__return_false' );
/**/
add_filter( 'auto_update_theme', '__return_false' );
/**/

function register_swiss_menus() {
  register_nav_menus(
    array(
      'main-menu' => __( 'Main Menu' ),
      'extra-menu' => __( 'Extra Menu' )
    )
  );
}
add_action( 'init', 'register_swiss_menus' );

/**/

function multisite_globalizer() {
	$indswiss = get_current_blog_id();
	return $indswiss;
}

function web_url() {
	$wurl = 'http://www.swisschamofcommerce.com/';
	return $wurl;
}

//

require_once('inc/swiss.php');

//

function mylogo() { ?>
    <style type="text/css">
        .login h1 a {
            background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/logo.png) !important;
            padding-bottom: 30px !important;
      background-size: 100% auto !important;
      height: 47px !important;
      padding: 0 !important;
      width: 270px !important;
      line-height: normal !important;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'mylogo' );

function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'Welcome To SwissCham';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );



function my_login_stylesheet() {
    wp_enqueue_style( 'custom-login', get_template_directory_uri() . '/style-login.css' );
    wp_enqueue_script( 'custom-login', get_template_directory_uri() . '/style-login.js' );
}
add_action( 'login_enqueue_scripts', 'my_login_stylesheet' );

/***/

// Creating the widget 
class swiss_v extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_v', 

__('SwissCham Video Widget', 'swiss_v_domain'), 

array( 'description' => __( 'SwissCham-Video-Widget is created for exclusive use in SwissCham', 'swiss_v_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$vurl = apply_filters( 'widget_title', $instance['vurl'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="<?php if ( ! empty( $vurl ) ) echo $vurl; ?>" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'vurl' ] ) ) {
$vurl = $instance[ 'vurl' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'vurl' ); ?>"><?php _e( 'Paste YouTube Embed URL ( For Ex. <u>Go to YouTube video page > Share > Embed > Copy YouTube URL source from the iframe</u> ):' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'vurl' ); ?>" name="<?php echo $this->get_field_name( 'vurl' ); ?>" type="text" value="<?php echo esc_attr( $vurl ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['vurl'] = ( ! empty( $new_instance['vurl'] ) ) ? strip_tags( $new_instance['vurl'] ) : '';
return $instance;
}
}

function swiss_v_widget() {
	register_widget( 'swiss_v' );
}
add_action( 'widgets_init', 'swiss_v_widget' );

/**/

class swiss_chin extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_chin', 

__('Swiss Business Platform In China', 'swiss_chin_domain'), 

array( 'description' => __( 'Your Swiss Business Platform In China', 'swiss_chin_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$wju = apply_filters( 'widget_title', $instance['wju'] );
$bam = apply_filters( 'widget_title', $instance['bam'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="<?php if ( ! empty( $wju ) ) echo $wju; ?>" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="<?php if ( ! empty( $bam ) ) echo $bam; ?>" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'wju' ] ) ) {
$wju = $instance[ 'wju' ];
}

if ( isset( $instance[ 'bam' ] ) ) {
$bam = $instance[ 'bam' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'wju' ); ?>"><?php _e( 'Paste Why-Join-Us page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wju' ); ?>" name="<?php echo $this->get_field_name( 'wju' ); ?>" type="text" value="<?php echo esc_attr( $wju ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'bam' ); ?>"><?php _e( 'Paste Become-A-Member page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'bam' ); ?>" name="<?php echo $this->get_field_name( 'bam' ); ?>" type="text" value="<?php echo esc_attr( $bam ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['wju'] = ( ! empty( $new_instance['wju'] ) ) ? strip_tags( $new_instance['wju'] ) : '';
$instance['bam'] = ( ! empty( $new_instance['bam'] ) ) ? strip_tags( $new_instance['bam'] ) : '';
return $instance;
}
}

function swiss_chin_widget() {
	register_widget( 'swiss_chin' );
}
add_action( 'widgets_init', 'swiss_chin_widget' );

/**/

/* Swis Bejing start frim Here Widget */

class swiss_chin_beji extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_chin_beji', 

__('Swiss Business Platform In Beijing', 'swiss_chin_domain'), 

array( 'description' => __( 'Your Swiss Business Platform In Beijing', 'swiss_chin_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$wju = apply_filters( 'widget_title', $instance['wju'] );
$bam = apply_filters( 'widget_title', $instance['bam'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN BEJING </h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="<?php if ( ! empty( $wju ) ) echo $wju; ?>" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="<?php if ( ! empty( $bam ) ) echo $bam; ?>" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'wju' ] ) ) {
$wju = $instance[ 'wju' ];
}

if ( isset( $instance[ 'bam' ] ) ) {
$bam = $instance[ 'bam' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'wju' ); ?>"><?php _e( 'Paste Why-Join-Us page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wju' ); ?>" name="<?php echo $this->get_field_name( 'wju' ); ?>" type="text" value="<?php echo esc_attr( $wju ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'bam' ); ?>"><?php _e( 'Paste Become-A-Member page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'bam' ); ?>" name="<?php echo $this->get_field_name( 'bam' ); ?>" type="text" value="<?php echo esc_attr( $bam ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['wju'] = ( ! empty( $new_instance['wju'] ) ) ? strip_tags( $new_instance['wju'] ) : '';
$instance['bam'] = ( ! empty( $new_instance['bam'] ) ) ? strip_tags( $new_instance['bam'] ) : '';
return $instance;
}
}

function swiss_chin_beji_widget() {
	register_widget( 'swiss_chin_beji' );
}
add_action( 'widgets_init', 'swiss_chin_beji_widget' );

/*End Swis Bejing Widget */

/* ////////////////////////////////// Swis Shanghai start from Here Widget ////////////////// */

class swiss_chin_shag extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_chin_shag', 

__('Swiss Business Platform In Shanghai', 'swiss_chin_domain'), 

array( 'description' => __( 'Your Swiss Business Platform In Shanghai', 'swiss_chin_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$wju = apply_filters( 'widget_title', $instance['wju'] );
$bam = apply_filters( 'widget_title', $instance['bam'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN SHANGHAI </h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="<?php if ( ! empty( $wju ) ) echo $wju; ?>" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="<?php if ( ! empty( $bam ) ) echo $bam; ?>" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'wju' ] ) ) {
$wju = $instance[ 'wju' ];
}

if ( isset( $instance[ 'bam' ] ) ) {
$bam = $instance[ 'bam' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'wju' ); ?>"><?php _e( 'Paste Why-Join-Us page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wju' ); ?>" name="<?php echo $this->get_field_name( 'wju' ); ?>" type="text" value="<?php echo esc_attr( $wju ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'bam' ); ?>"><?php _e( 'Paste Become-A-Member page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'bam' ); ?>" name="<?php echo $this->get_field_name( 'bam' ); ?>" type="text" value="<?php echo esc_attr( $bam ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['wju'] = ( ! empty( $new_instance['wju'] ) ) ? strip_tags( $new_instance['wju'] ) : '';
$instance['bam'] = ( ! empty( $new_instance['bam'] ) ) ? strip_tags( $new_instance['bam'] ) : '';
return $instance;
}
}

function swiss_chin_shag_widget() {
	register_widget( 'swiss_chin_shag' );
}
add_action( 'widgets_init', 'swiss_chin_shag_widget' );


/* ////////////////////////////////// Swis Shanghai End from Here Widget ////////////////// */



/* ////////////////////////////////// Swis Guangzhou start from Here Widget ////////////////// */

class swiss_chin_guan extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_chin_guan', 

__('Swiss Business Platform In Guangzhou', 'swiss_chin_domain'), 

array( 'description' => __( 'Your Swiss Business Platform In Guangzhou', 'swiss_chin_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$wju = apply_filters( 'widget_title', $instance['wju'] );
$bam = apply_filters( 'widget_title', $instance['bam'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN  GUANGZHOU </h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="<?php if ( ! empty( $wju ) ) echo $wju; ?>" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="<?php if ( ! empty( $bam ) ) echo $bam; ?>" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'wju' ] ) ) {
$wju = $instance[ 'wju' ];
}

if ( isset( $instance[ 'bam' ] ) ) {
$bam = $instance[ 'bam' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'wju' ); ?>"><?php _e( 'Paste Why-Join-Us page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wju' ); ?>" name="<?php echo $this->get_field_name( 'wju' ); ?>" type="text" value="<?php echo esc_attr( $wju ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'bam' ); ?>"><?php _e( 'Paste Become-A-Member page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'bam' ); ?>" name="<?php echo $this->get_field_name( 'bam' ); ?>" type="text" value="<?php echo esc_attr( $bam ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['wju'] = ( ! empty( $new_instance['wju'] ) ) ? strip_tags( $new_instance['wju'] ) : '';
$instance['bam'] = ( ! empty( $new_instance['bam'] ) ) ? strip_tags( $new_instance['bam'] ) : '';
return $instance;
}
}

function swiss_chin_guan_widget() {
	register_widget( 'swiss_chin_guan' );
}
add_action( 'widgets_init', 'swiss_chin_guan_widget' );

/* ////////////////////////////////// Swis Guangzhou End from Here Widget ////////////////// */

/* ////////////////////////////////// Swis HongKong start from Here Widget ////////////////// */

class swiss_chin_hong extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_chin_hong', 

__('Swiss Business Platform In HongKong', 'swiss_chin_domain'), 

array( 'description' => __( 'Your Swiss Business Platform In HongKong', 'swiss_chin_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$wju = apply_filters( 'widget_title', $instance['wju'] );
$bam = apply_filters( 'widget_title', $instance['bam'] );

?>
						<div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN HONGKONG</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="<?php if ( ! empty( $wju ) ) echo $wju; ?>" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="<?php if ( ! empty( $bam ) ) echo $bam; ?>" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'wju' ] ) ) {
$wju = $instance[ 'wju' ];
}

if ( isset( $instance[ 'bam' ] ) ) {
$bam = $instance[ 'bam' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'wju' ); ?>"><?php _e( 'Paste Why-Join-Us page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wju' ); ?>" name="<?php echo $this->get_field_name( 'wju' ); ?>" type="text" value="<?php echo esc_attr( $wju ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'bam' ); ?>"><?php _e( 'Paste Become-A-Member page URL here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'bam' ); ?>" name="<?php echo $this->get_field_name( 'bam' ); ?>" type="text" value="<?php echo esc_attr( $bam ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['wju'] = ( ! empty( $new_instance['wju'] ) ) ? strip_tags( $new_instance['wju'] ) : '';
$instance['bam'] = ( ! empty( $new_instance['bam'] ) ) ? strip_tags( $new_instance['bam'] ) : '';
return $instance;
}
}

function swiss_chin_hong_widget() {
	register_widget( 'swiss_chin_hong' );
}
add_action( 'widgets_init', 'swiss_chin_hong_widget' );

/* ////////////////////////////////// Swis HongKong End from Here Widget ////////////////// */





class swiss_image extends WP_Widget {

function __construct() {
parent::__construct(

'swiss_image', 

__('SwissCham Image Widget', 'swiss_image_domain'), 

array( 'description' => __( 'SwissCham-Image-Widget is created for exclusive use in SwissCham ', 'swiss_image_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$imguf = apply_filters( 'widget_title', $instance['imguf'] );
$imgf = apply_filters( 'widget_title', $instance['imgf'] );

$imgus = apply_filters( 'widget_title', $instance['imgus'] );
$imgs = apply_filters( 'widget_title', $instance['imgs'] );

$imgut = apply_filters( 'widget_title', $instance['imgut'] );
$imgt = apply_filters( 'widget_title', $instance['imgt'] );

?>
                        <div class="large-12 columns right_y_join margin_top10">
                            <!--<h3 class="common_subheading">Strategic Partner </h3>-->
                            <ul class="fa-ul inner_sponser_img">
                                <li><a target="_blank" href="<?php if ( ! empty( $imguf ) ) echo $imguf;
                                else echo 'javascript:void(0)';
                                 ?>"><img src="<?php if ( ! empty( $imgf ) ) echo $imgf; ?>" /></a></li>
                                <li><a target="_blank" href="<?php if ( ! empty( $imgus ) ) echo $imgus;
                                else echo 'javascript:void(0)';
                                 ?>"><img src="<?php if ( ! empty( $imgs ) ) echo $imgs; ?>" /></a></li>
                                <li><a href="<?php if ( ! empty( $imgut ) ) echo $imgut;
                                else echo 'javascript:void(0)';
                                 ?>"><img src="<?php if ( ! empty( $imgt ) ) echo $imgt; ?>" /></a></li>
                            </ul>
                        </div>
<?php

}
		
public function form( $instance ) {

if ( isset( $instance[ 'imguf' ] ) ) {
$imguf = $instance[ 'imguf' ];
}
if ( isset( $instance[ 'imgf' ] ) ) {
$imgf = $instance[ 'imgf' ];
}

if ( isset( $instance[ 'imgus' ] ) ) {
$imgus = $instance[ 'imgus' ];
}
if ( isset( $instance[ 'imgs' ] ) ) {
$imgs = $instance[ 'imgs' ];
}

if ( isset( $instance[ 'imgut' ] ) ) {
$imgut = $instance[ 'imgut' ];
}
if ( isset( $instance[ 'imgt' ] ) ) {
$imgt = $instance[ 'imgt' ];
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'imguf' ); ?>"><?php _e( 'Paste Image-1 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imguf' ); ?>" name="<?php echo $this->get_field_name( 'imguf' ); ?>" type="text" value="<?php echo esc_attr( $imguf ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'imgf' ); ?>"><?php _e( 'Paste Image-1 URL:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imgf' ); ?>" name="<?php echo $this->get_field_name( 'imgf' ); ?>" type="text" value="<?php echo esc_attr( $imgf ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'imgus' ); ?>"><?php _e( 'Paste Image-2 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imgus' ); ?>" name="<?php echo $this->get_field_name( 'imgus' ); ?>" type="text" value="<?php echo esc_attr( $imgus ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'imgs' ); ?>"><?php _e( 'Paste Image-2 URL:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imgs' ); ?>" name="<?php echo $this->get_field_name( 'imgs' ); ?>" type="text" value="<?php echo esc_attr( $imgs ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'imgut' ); ?>"><?php _e( 'Paste Image-3 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imgut' ); ?>" name="<?php echo $this->get_field_name( 'imgut' ); ?>" type="text" value="<?php echo esc_attr( $imgut ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'imgt' ); ?>"><?php _e( 'Paste Image-3 URL:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'imgt' ); ?>" name="<?php echo $this->get_field_name( 'imgt' ); ?>" type="text" value="<?php echo esc_attr( $imgt ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['imguf'] = ( ! empty( $new_instance['imguf'] ) ) ? strip_tags( $new_instance['imguf'] ) : '';
$instance['imgf'] = ( ! empty( $new_instance['imgf'] ) ) ? strip_tags( $new_instance['imgf'] ) : '';

$instance['imgus'] = ( ! empty( $new_instance['imgus'] ) ) ? strip_tags( $new_instance['imgus'] ) : '';
$instance['imgs'] = ( ! empty( $new_instance['imgs'] ) ) ? strip_tags( $new_instance['imgs'] ) : '';

$instance['imgut'] = ( ! empty( $new_instance['imgut'] ) ) ? strip_tags( $new_instance['imgut'] ) : '';
$instance['imgt'] = ( ! empty( $new_instance['imgt'] ) ) ? strip_tags( $new_instance['imgt'] ) : '';

return $instance;
}
}

function swiss_image_widget() {
	register_widget( 'swiss_image' );
}
add_action( 'widgets_init', 'swiss_image_widget' );

/***/

function get_post_breadcrumbs(){
 $bcrumbs = array(); $html = ''; 
 $swisssitechkr = multisite_globalizer();
 $cpid = $_GET['id'];  
 if( isset( $cpid ) && ($cpid != '')){ $cpost = get_post( $cpid ); 
 } else{ $cpost = get_post(get_the_ID()); } 

 if($swisssitechkr==1){
 //create crumbs based on current post 
 for($id=$cpost->ID; $id != 0; ){ 
   $ppost = get_post($id);
   if($ppost->post_type == "page" || $ppost->post_type == "nav_menu_item"){ 
     $menuItem = wp_get_nav_menu_items('main-menu', 
                 array('posts_per_page' => -1,'meta_key' => '_menu_item_object_id','meta_value' => $ppost->ID ));
     if(!empty($menuItem)){
       array_unshift($bcrumbs, $menuItem); $id = $menuItem[0]->menu_item_parent; 
     } else { 
       array_unshift($bcrumbs, array(0=>$ppost)); $id = $ppost->post_parent;
     }
   }
   else{
     array_unshift($bcrumbs, array(0=>$ppost));
     //get page for the posts for breadcrumbs
     if($ppost->post_type == 'job_listing'){ $id = get_option('job_manager_jobs_page_id'); } 
     if($ppost->post_type == 'event' || $ppost->post_type == 'upcomingevent'){ 
       $pg = get_page_by_path('upcoming-events'); $id = $pg->ID; } 
     if($ppost->post_type == 'news'){ $pg = get_page_by_path('news'); $id = $pg->ID; }
     if($ppost->post_type == 'investmentzone'){ $pg = get_page_by_path('investment-zone'); $id = $pg->ID; } 
   }
 }
 }

 if($swisssitechkr==2){
 //create crumbs based on current post 
 for($id=$cpost->ID; $id != 0; ){ 
   $ppost = get_post($id);
   if($ppost->post_type == "page" || $ppost->post_type == "nav_menu_item"){ 
     $menuItem = wp_get_nav_menu_items('main-menu', 
                 array('posts_per_page' => -1,'meta_key' => '_menu_item_object_id','meta_value' => $ppost->ID ));
     if(!empty($menuItem)){
       array_unshift($bcrumbs, $menuItem); $id = $menuItem[0]->menu_item_parent; 
     } else { 
       array_unshift($bcrumbs, array(0=>$ppost)); $id = $ppost->post_parent;
     }
   }
   else{
     array_unshift($bcrumbs, array(0=>$ppost));
     //get page for the posts for breadcrumbs
     if($ppost->post_type == 'job_listing'){ $id = get_option('job_manager_jobs_page_id'); } 
     if($ppost->post_type == 'event' || $ppost->post_type == 'upcomingevent'){ 
       $pg = get_page_by_path('upcoming-events'); $id = $pg->ID; } 
     if($ppost->post_type == 'news'){ $pg = get_page_by_path('news'); $id = $pg->ID; }
     if($ppost->post_type == 'investmentzone'){ $pg = get_page_by_path('investment-zone'); $id = $pg->ID; } 
   }
 }
 }

 if($swisssitechkr==3){
 //create crumbs based on current post 
 for($id=$cpost->ID; $id != 0; ){ 
   $ppost = get_post($id);
   if($ppost->post_type == "page" || $ppost->post_type == "nav_menu_item"){ 
     $menuItem = wp_get_nav_menu_items('main-menu', 
                 array('posts_per_page' => -1,'meta_key' => '_menu_item_object_id','meta_value' => $ppost->ID ));
     if(!empty($menuItem)){
       array_unshift($bcrumbs, $menuItem); $id = $menuItem[0]->menu_item_parent; 
     } else { 
       array_unshift($bcrumbs, array(0=>$ppost)); $id = $ppost->post_parent;
     }
   }
   else{
     array_unshift($bcrumbs, array(0=>$ppost));
     //get page for the posts for breadcrumbs
     if($ppost->post_type == 'job_listing'){ $id = get_option('job_manager_jobs_page_id'); } 
     if($ppost->post_type == 'event' || $ppost->post_type == 'upcomingevent'){ 
       $pg = get_page_by_path('upcoming-events'); $id = $pg->ID; } 
     if($ppost->post_type == 'news'){ $pg = get_page_by_path('news'); $id = $pg->ID; }
     if($ppost->post_type == 'investmentzone'){ $pg = get_page_by_path('investment-zone'); $id = $pg->ID; } 
   }
 }
 }

 if($swisssitechkr==4){
 //create crumbs based on current post 
 for($id=$cpost->ID; $id != 0; ){ 
   $ppost = get_post($id);
   if($ppost->post_type == "page" || $ppost->post_type == "nav_menu_item"){ 
     $menuItem = wp_get_nav_menu_items('main-menu', 
                 array('posts_per_page' => -1,'meta_key' => '_menu_item_object_id','meta_value' => $ppost->ID ));
     if(!empty($menuItem)){
       array_unshift($bcrumbs, $menuItem); $id = $menuItem[0]->menu_item_parent; 
     } else { 
       array_unshift($bcrumbs, array(0=>$ppost)); $id = $ppost->post_parent;
     }
   }
   else{
     array_unshift($bcrumbs, array(0=>$ppost));
     //get page for the posts for breadcrumbs
     if($ppost->post_type == 'job_listing'){ $id = get_option('job_manager_jobs_page_id'); } 
     if($ppost->post_type == 'event' || $ppost->post_type == 'upcomingevent'){ 
       $pg = get_page_by_path('upcoming-events'); $id = $pg->ID; } 
     if($ppost->post_type == 'news'){ $pg = get_page_by_path('news'); $id = $pg->ID; }
     if($ppost->post_type == 'investmentzone'){ $pg = get_page_by_path('investment-zone'); $id = $pg->ID; } 
   }
 }
 }

 if($swisssitechkr==5){
 //create crumbs based on current post 
 for($id=$cpost->ID; $id != 0; ){ 
   $ppost = get_post($id);
   if($ppost->post_type == "page" || $ppost->post_type == "nav_menu_item"){ 
     $menuItem = wp_get_nav_menu_items('main-menu', 
                 array('posts_per_page' => -1,'meta_key' => '_menu_item_object_id','meta_value' => $ppost->ID ));
     if(!empty($menuItem)){
       array_unshift($bcrumbs, $menuItem); $id = $menuItem[0]->menu_item_parent; 
     } else { 
       array_unshift($bcrumbs, array(0=>$ppost)); $id = $ppost->post_parent;
     }
   }
   else{
     array_unshift($bcrumbs, array(0=>$ppost));
     //get page for the posts for breadcrumbs
     if($ppost->post_type == 'job_listing'){ $id = get_option('job_manager_jobs_page_id'); } 
     if($ppost->post_type == 'event' || $ppost->post_type == 'upcomingevent'){ 
       $pg = get_page_by_path('upcoming-events'); $id = $pg->ID; } 
     if($ppost->post_type == 'news'){ $pg = get_page_by_path('news'); $id = $pg->ID; }
     if($ppost->post_type == 'investmentzone'){ $pg = get_page_by_path('investment-zone'); $id = $pg->ID; } 
   }
 }
 }

 //return html form of the breadcrumbs
 if(!empty($bcrumbs)){ 
  $html .= '<div class="inner_bredcrumb"><nav aria-label="You are here:" role="navigation"><ul class="breadcrumbs page_bredcrunb">';
  if ( $swisssitechkr==1 ) { $html .= '<li><a href="'.home_url().'">Home</a></li>'; }
  if ( $swisssitechkr==2 ) { $html .= '<li><a href="'.home_url().'">Beijing</a></li>'; }
  if ( $swisssitechkr==3 ) { $html .= '<li><a href="'.home_url().'">Shanghai</a></li>'; }
  if ( $swisssitechkr==4 ) { $html .= '<li><a href="'.home_url().'">Guangzhou</a></li>'; }
  if ( $swisssitechkr==5 ) { $html .= '<li><a href="'.home_url().'">Hong Kong</a></li>'; } 
  
  foreach($bcrumbs as $crumb){ 
   $title = $crumb[0]->post_title; 
   if(empty($title)){ $title = $crumb[0]->title; }
   $html .= '<li><a href="'.$crumb[0]->url.'">'.$title.'</a></li>';
  }
                     
  $html .= '</ul></nav></div>'; 
 }
 return $html;
}
/***/

/************************Add Sur Name For Booking Form ******************************/




 /* For Extra field in event booking registration Company Name */

function bweb_add_custom_event_fields_surname(){
    ?>
        <div class="medium-6 columns no_padding surput">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='sur_name'><?php esc_html_e('Surname', 'textdomain'); ?> <span class="requirered">*</span>
                <input type="text" required="true" name="sur_name" id="sur_name"  class="input" value="<?php if (!empty($_REQUEST['sur_name'])) echo esc_attr($_REQUEST['sur_name']); ?>" />
            </label>
        </div>
    </div>
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_fields_surname');
 
 
function  bweb_save_custom_event_fields_surname (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['sur_name'] ) ){
            $EM_Booking->booking_meta['registration']['sur_name'] = wp_kses( $_REQUEST['sur_name'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_fields_surname');    
 
 
function bweb_table_custom_event_fields_surname($template, $EM_Bookings_Table){
        $template['sur_name'] = __('Surname', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_fields_surname',10,2);
 
 
function bweb_display_col_custom_event_fields_surname($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'sur_name' ){
                $val = $EM_Booking->get_person()->sur_name;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_fields_surname', 10, 5);




/************************ End Sur Name Booking Filed ***********************************/

 /* For Extra field in event booking registration Company Name */

function bweb_add_custom_event_fields(){
    ?>
        <div class="medium-12 columns no_padding">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='user_company'><?php esc_html_e('Company Name', 'textdomain'); ?> <span class="requirered">*</span>
                <input type="text" name="user_company" id="user-company"  class="input" value="<?php if (!empty($_REQUEST['user_company'])) echo esc_attr($_REQUEST['user_company']); ?>" />
            </label>
        </div>
    </div>
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_fields');
 
 
function  bweb_save_custom_event_fields (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['user_company'] ) ){
            $EM_Booking->booking_meta['registration']['user_company'] = wp_kses( $_REQUEST['user_company'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_fields');    
 
 
function bweb_table_custom_event_fields($template, $EM_Bookings_Table){
        $template['user_company'] = __('Company', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_fields',10,2);
 
 
function bweb_display_col_custom_event_fields($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'user_company' ){
                $val = $EM_Booking->get_person()->user_company;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_fields', 10, 5);


////////////////////////////////// Gender //////////////////////////


 /* For Extra field in event booking registration Company Name */

function bweb_add_custom_event_gender_fields(){
    ?>
        <div class="medium-12 columns no_padding">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='user_gender'><?php esc_html_e('Gender', 'textdomain'); ?>

                <select name="user_gender" id="user-gender" >
                    <option value="">- None -</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </label>
        </div>
    </div>
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_gender_fields');
 
 
function  bweb_save_custom_event_gender_fields (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['user_gender'] ) ){
            $EM_Booking->booking_meta['registration']['user_gender'] = wp_kses( $_REQUEST['user_gender'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_gender_fields');    
 
 
function bweb_table_custom_event_gender_fields($template, $EM_Bookings_Table){
        $template['user_gender'] = __('Gender', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_gender_fields',10,2);
 
 
function bweb_display_col_custom_event_gender_fields($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'user_gender' ){
                $val = $EM_Booking->get_person()->user_gender;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_gender_fields', 10, 5);


////////////////////////////////// Job Title //////////////////////////


 /* For Extra field in event booking registration Job Title */

function bweb_add_custom_event_jobtitle_fields(){
    ?>
        <div class="medium-12 columns no_padding">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='user_jobtitle'><?php esc_html_e('Job Title', 'textdomain'); ?>
            
             <input type="text" name="user_jobtitle" id="user-jobtitle"  class="input" value="<?php if(!empty($_REQUEST['user_jobtitle'])) echo esc_attr($_REQUEST['user_jobtitle']); ?>" />
        </label>
        </div>
             </div>
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_jobtitle_fields');
 
 
function  bweb_save_custom_event_jobtitle_fields (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['user_jobtitle'] ) ){
            $EM_Booking->booking_meta['registration']['user_jobtitle'] = wp_kses( $_REQUEST['user_jobtitle'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_jobtitle_fields');    
 
 
function bweb_table_custom_event_jobtitle_fields($template, $EM_Bookings_Table){
        $template['user_jobtitle'] = __('Job Title', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_jobtitle_fields',10,2);
 
 
function bweb_display_col_custom_event_jobtitle_fields($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'user_jobtitle' ){
                $val = $EM_Booking->get_person()->user_jobtitle;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_jobtitle_fields', 10, 5);



////////////////////////////////// Year Of Birth  //////////////////////////


 /* For Extra field in event booking year of birth */

function bweb_add_custom_event_yearofbirth_fields(){
    ?>
        <div class="medium-12 columns no_padding">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='user_yearofbirth'><?php esc_html_e('Year Of Birth', 'textdomain'); ?>
           
        
        <input type="text" name="user_yearofbirth" id="user-yearofbirth"  class="input" value="<?php if(!empty($_REQUEST['user_yearofbirth'])) echo esc_attr($_REQUEST['user_yearofbirth']); ?>" />
        </label>
        </div>
            </div>
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_yearofbirth_fields');
 
 
function  bweb_save_custom_event_yearofbirth_fields (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['user_yearofbirth'] ) ){
            $EM_Booking->booking_meta['registration']['user_yearofbirth'] = wp_kses( $_REQUEST['user_yearofbirth'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_yearofbirth_fields');    
 
 
function bweb_table_custom_event_yearofbirth_fields($template, $EM_Bookings_Table){
        $template['user_yearofbirth'] = __('Year Of Birth', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_yearofbirth_fields',10,2);
 
 
function bweb_display_col_custom_event_yearofbirth_fields($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'user_yearofbirth' ){
                $val = $EM_Booking->get_person()->user_yearofbirth;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_yearofbirth_fields', 10, 5);




////////////////////////////////// Address  //////////////////////////


 /* For Extra field in event booking registration Address */

function bweb_add_custom_event_address_fields(){
    ?>
        <div class="medium-12 columns no_padding">
        <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
            <label for='user_address'><?php esc_html_e('Address', 'textdomain'); ?>
           
         <textarea rows="2" placeholder="None" name="user_address" id="user-address" ><?php if(!empty($_REQUEST['user_address'])) echo esc_attr($_REQUEST['user_address']); ?></textarea>
        </label>
        </div>
            </div>

<div class="medium-12 columns no_padding">
                    <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                        <fieldset class="large-12 columns no_padding margin_bottom5">
                            
                            <label class="event_reg_term" for="checkbox1">
                            <input type="checkbox" value="yes" name="add_mailing_list" id="checkbox1">
                            Add me to your mailing list.</label>
                        </fieldset>
                        <fieldset class="large-12 columns no_padding margin_bottom5">
                            
                            <label class="event_reg_term agree" for="checkbox2">
                                <input type="checkbox" required="true" class="agree" value="yes" name="agree" id="checkbox2"> I agree to the terms and conditions, and understand there might be a fee involved.</label>
                        </fieldset>
                        <small>In case you want to cancel your registration please contact us at least 24 hours (or otherwise stated in the invitation) before the event. Failure to cancel or attend the event will require the payment of a no show bill of the full amount of the event.</small>
                    </div>
                </div>
       
 
    <?php
}
add_action('em_register_form','bweb_add_custom_event_address_fields');
 
 
function  bweb_save_custom_event_address_fields (){
    global $EM_Booking ;
    if( ! empty( $_REQUEST['user_address'] ) ){
            $EM_Booking->booking_meta['registration']['user_address'] = wp_kses( $_REQUEST['user_address'], array() );
    }
}
add_filter('em_booking_add','bweb_save_custom_event_address_fields');    
 
 
function bweb_table_custom_event_address_fields($template, $EM_Bookings_Table){
        $template['user_address'] = __('Address', 'textdomain');
        return $template;
}
add_action('em_bookings_table_cols_template', 'bweb_table_custom_event_address_fields',10,2);
 
 
function bweb_display_col_custom_event_address_fields($val, $col, $EM_Booking, $EM_Bookings_Table, $csv){
        if( $col == 'user_address' ){
                $val = $EM_Booking->get_person()->user_address;               
        }
        return $val;
}
add_filter('em_bookings_table_rows_col','bweb_display_col_custom_event_address_fields', 10, 5);




//*********** create a function that will attach our new 'Sponsers Image' taxonomy to the 'post' post type
function add_member_taxonomy_to_post(){

    //set the name of the taxonomy
    $taxonomy = 'headerbranchname';
    //set the post types for the taxonomy
    $object_type = 'sponsor';
    //populate our array of names for our taxonomy
    $labels = array(
        'name'               => 'Header Branch Name',
        'singular_name'      => 'Header Branch Name',
        'search_items'       => 'Search Header Branch Name',
        'all_items'          => 'All Header Branch Name',
        'parent_item'        => 'Parent Header Branch Name',
        'parent_item_colon'  => 'Parent Header Branch Name:',
        'update_item'        => 'Update Header Branch Name',
        'edit_item'          => 'Edit Header Branch Name',
        'add_new_item'       => 'Add New Header Branch Name', 
        'new_item_name'      => 'New Header Branch Name',
        'menu_name'          => 'Header Branch Name'
    );
    
    //define arguments to be used 
    $args = array(
        'labels'            => $labels,
        'hierarchical'      => true,
        'show_ui'           => true,
        'how_in_nav_menus'  => true,
        'public'            => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'headerbranchname')
    );
    
    //call the register_taxonomy function
    register_taxonomy($taxonomy, $object_type, $args); 
}
add_action('init','add_member_taxonomy_to_post');

//*********** create a function that will attach our new 'Sponsers Image' taxonomy to the 'post' post type
function add_sponsor_taxonomy_to_post(){

    //set the name of the taxonomy
    $taxonomy = 'footerbranchname';
    //set the post types for the taxonomy
    $object_type = 'sponsorbottom';
    //populate our array of names for our taxonomy
    $labels = array(
        'name'               => 'Footer Branch Name',
        'singular_name'      => 'Footer Branch Name',
        'search_items'       => 'Search Footer Branch Name',
        'all_items'          => 'All Footer Branch Name',
        'parent_item'        => 'Parent Footer Branch Name',
        'parent_item_colon'  => 'Parent Footer Branch Name:',
        'update_item'        => 'Update Footer Branch Name',
        'edit_item'          => 'Edit Footer Branch Name',
        'add_new_item'       => 'Add New Footer Branch Name', 
        'new_item_name'      => 'New Footer Branch Name',
        'menu_name'          => 'Footer Branch Name'
    );
    
    //define arguments to be used 
    $args = array(
        'labels'            => $labels,
        'hierarchical'      => true,
        'show_ui'           => true,
        'how_in_nav_menus'  => true,
        'public'            => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'footerbranchname')
    );
    
    //call the register_taxonomy function
    register_taxonomy($taxonomy, $object_type, $args); 
}
add_action('init','add_sponsor_taxonomy_to_post');


/* * *********  Shortcode Creator HongKong Site Upcomming Event Right Side Bar ******************** */

function hongkong_upcoming_function() {
    //return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec nulla vitae lacus mattis volutpat eu at sapien. Nunc interdum congue libero, quis laoreet elit sagittis ut. Pellentesque lacus erat, dictum condimentum pharetra vel, malesuada volutpat risus. Nunc sit amet risus dolor. Etiam posuere tellus nisl. Integer lorem ligula, tempor eu laoreet ac, eleifend quis diam. Proin cursus, nibh eu vehicula varius, lacus elit eleifend elit, eget commodo ante felis at neque. Integer sit amet justo sed elit porta convallis a at metus. Suspendisse molestie turpis pulvinar nisl tincidunt quis fringilla enim lobortis. Curabitur placerat quam ac sem venenatis blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam sed ligula nisl. Nam ullamcorper elit id magna hendrerit sit amet dignissim elit sodales. Aenean accumsan consectetur rutrum.';
   ?>
<div class="large-12 columns right_y_join margin_top10">
<h3 class="common_subheading">Upcoming Events</h3>
<div class="tab_list_item"> <?php

$events_all_count_HongKong = EM_Events::get(array('scope'=>'future','category'=>54,'blog'=>'1'));
 $hongcount=count($events_all_count_HongKong);
    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>'54',
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/hk/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); ?>
</div>
<?php
if($hongcount>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>hk/upcoming-events/">See Upcoming Events</a>
    <?php }  ?>
    </div>
<?php
     
}
add_shortcode('HongKong-Upcoming-Event', 'hongkong_upcoming_function');


/* * *********  Shortcode Creator Beijing Site Upcomming Event Right Side Bar ******************** */

function beijing_upcoming_function() {
    //return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec nulla vitae lacus mattis volutpat eu at sapien. Nunc interdum congue libero, quis laoreet elit sagittis ut. Pellentesque lacus erat, dictum condimentum pharetra vel, malesuada volutpat risus. Nunc sit amet risus dolor. Etiam posuere tellus nisl. Integer lorem ligula, tempor eu laoreet ac, eleifend quis diam. Proin cursus, nibh eu vehicula varius, lacus elit eleifend elit, eget commodo ante felis at neque. Integer sit amet justo sed elit porta convallis a at metus. Suspendisse molestie turpis pulvinar nisl tincidunt quis fringilla enim lobortis. Curabitur placerat quam ac sem venenatis blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam sed ligula nisl. Nam ullamcorper elit id magna hendrerit sit amet dignissim elit sodales. Aenean accumsan consectetur rutrum.';
   ?>
<div class="large-12 columns right_y_join margin_top10">
<h3 class="common_subheading">Upcoming Events</h3>
<div class="tab_list_item"> <?php

 $events_all_count_Beijing = EM_Events::get(array('scope'=>'future','category'=>51,'blog'=>'1'));
 $beicount=count($events_all_count_Beijing);
    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>'51',
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/bei/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); 
      

     ?>

</div>
<?php
if($beicount>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>bei/upcoming-events/">See Upcoming Events</a>
    <?php }  ?>
    </div>
<?php
     
}

add_shortcode('Beijing-Upcoming-Event', 'beijing_upcoming_function');


/* * *********  Shortcode Creator Shanghai Site Upcomming Event Right Side Bar ******************** */

function shanghai_upcoming_function() {
    //return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec nulla vitae lacus mattis volutpat eu at sapien. Nunc interdum congue libero, quis laoreet elit sagittis ut. Pellentesque lacus erat, dictum condimentum pharetra vel, malesuada volutpat risus. Nunc sit amet risus dolor. Etiam posuere tellus nisl. Integer lorem ligula, tempor eu laoreet ac, eleifend quis diam. Proin cursus, nibh eu vehicula varius, lacus elit eleifend elit, eget commodo ante felis at neque. Integer sit amet justo sed elit porta convallis a at metus. Suspendisse molestie turpis pulvinar nisl tincidunt quis fringilla enim lobortis. Curabitur placerat quam ac sem venenatis blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam sed ligula nisl. Nam ullamcorper elit id magna hendrerit sit amet dignissim elit sodales. Aenean accumsan consectetur rutrum.';
   ?>
<div class="large-12 columns right_y_join margin_top10">
<h3 class="common_subheading">Upcoming Events</h3>
<div class="tab_list_item"> <?php

    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>'52',
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/sha/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); 
      
$events_all_count_Shang = EM_Events::get(array('scope'=>'future','category'=>52,'blog'=>'1'));
$shacount=count($events_all_count_Shang);
     ?>

</div>
<?php
if($shacount>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>sha/upcoming-events/">See Upcoming Events</a>
    <?php }  ?>
    </div>
<?php
     
}

add_shortcode('Shanghai-Upcoming-Event', 'shanghai_upcoming_function');

/* * *********  Shortcode Creator Guangzhou Site Upcomming Event Right Side Bar ******************** */

function Guangzhou_upcoming_function() {
    //return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec nulla vitae lacus mattis volutpat eu at sapien. Nunc interdum congue libero, quis laoreet elit sagittis ut. Pellentesque lacus erat, dictum condimentum pharetra vel, malesuada volutpat risus. Nunc sit amet risus dolor. Etiam posuere tellus nisl. Integer lorem ligula, tempor eu laoreet ac, eleifend quis diam. Proin cursus, nibh eu vehicula varius, lacus elit eleifend elit, eget commodo ante felis at neque. Integer sit amet justo sed elit porta convallis a at metus. Suspendisse molestie turpis pulvinar nisl tincidunt quis fringilla enim lobortis. Curabitur placerat quam ac sem venenatis blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam sed ligula nisl. Nam ullamcorper elit id magna hendrerit sit amet dignissim elit sodales. Aenean accumsan consectetur rutrum.';
   ?>
<div class="large-12 columns right_y_join margin_top10">
<h3 class="common_subheading">Upcoming Events</h3>
<div class="tab_list_item"> <?php

 $events_all_count_Guan = EM_Events::get(array('scope'=>'future','category'=>53,'blog'=>'1'));
 $guancount=count($events_all_count_Guan);
    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>'53',
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/gz/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); 
      

     ?>

</div>
<?php
if($guancount>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>gz/upcoming-events/">See Upcoming Events</a>
    <?php }  ?>
    </div>
<?php
     
}

add_shortcode('Guangzhou-Upcoming-Event', 'Guangzhou_upcoming_function');

/* * *********  Shortcode Creator For Home Site Upcomming Event Right Side Bar ******************** */

function Home_upcoming_function() {
    //return 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec nulla vitae lacus mattis volutpat eu at sapien. Nunc interdum congue libero, quis laoreet elit sagittis ut. Pellentesque lacus erat, dictum condimentum pharetra vel, malesuada volutpat risus. Nunc sit amet risus dolor. Etiam posuere tellus nisl. Integer lorem ligula, tempor eu laoreet ac, eleifend quis diam. Proin cursus, nibh eu vehicula varius, lacus elit eleifend elit, eget commodo ante felis at neque. Integer sit amet justo sed elit porta convallis a at metus. Suspendisse molestie turpis pulvinar nisl tincidunt quis fringilla enim lobortis. Curabitur placerat quam ac sem venenatis blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam sed ligula nisl. Nam ullamcorper elit id magna hendrerit sit amet dignissim elit sodales. Aenean accumsan consectetur rutrum.';
   ?>
<div class="large-12 columns right_y_join margin_top10">
<h3 class="common_subheading">Upcoming Events</h3>
<div class="tab_list_item"> <?php

 $events_all_count_home = EM_Events::get(array('scope'=>'future'));
 $home_count=count($events_all_count_home);
    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>"51,52,53,54",
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/#_CATEGORYSLUG/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); 
      

     ?>

</div>
<?php
if($home_count>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>upcoming-events/">See Upcoming Events</a>
    <?php }  ?>
    </div>
<?php
     
}

add_shortcode('Home-Upcoming-Event', 'Home_upcoming_function');

/////////////////// Create username with Special symbols like ///////////////////

add_filter( 'sanitize_user', 'tubs_sanitize_user', 10, 3);
function tubs_sanitize_user($username, $raw_username, $strict) {
    $new_username = strip_tags($raw_username);
    // Kill octets
    //$new_username = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '', $new_username);
    //$new_username = preg_replace('/.?;/', '', $new_username); // Kill entities

   // If strict, reduce to ASCII for max portability.
   //if ( $strict )
       // $new_username = preg_replace('|[^a-z0-9 _.\-@+]|i', '', $new_username);

    return trim($new_username);
}

add_action('set_current_user', 'cc_hide_admin_bar');
function cc_hide_admin_bar() {
  if (!current_user_can('edit_posts')) {
    show_admin_bar(false);
  }
}