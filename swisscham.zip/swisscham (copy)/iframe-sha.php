<?php
//get_header();
$eventsssssssssssss = EM_Events::get(array('post_type' => 'event','scope'=>'future','category'=>52));
echo count($eventsssssssssssss);
?>
  <?php get_footer(); ?>