<?php
/*
	Template Name: Investment Zone
*/
	get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>        
<?php } ?>             
                        <li>
                            <span class="show-for-sr">Current: </span> Membership
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Investment Zone
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
        <?php if ( $swisschkr==1 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $post_613 = get_post( 613 ); ?>
                        <h1 class="common_heading"><?php echo $post_613->post_title; ?></h1>
                        <?php $pagebgz70 = $post_613->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>
                    </div>
        <?php } if ( $swisschkr==2 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $post_613 = get_post( 187 ); ?>
                        <h1 class="common_heading"><?php echo $post_613->post_title; ?></h1>
                        <?php $pagebgz70 = $post_613->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>
                    </div>
        <?php } if ( $swisschkr==3 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $post_613 = get_post( 146 ); ?>
                        <h1 class="common_heading"><?php echo $post_613->post_title; ?></h1>
                        <?php $pagebgz70 = $post_613->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>
                    </div>
        <?php } if ( $swisschkr==4 ) { ?>
                    <div class="large-12 columns dowedo_top">
                    <?php $post_613 = get_post( 118 ); ?>
                        <h1 class="common_heading"><?php echo $post_613->post_title; ?></h1>
                        <?php $pagebgz70 = $post_613->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>
                    </div>
        <?php } ?>

                    <div class="large-12 columns">
                        <hr class="common_devider">
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul inv_zone">
    <?php $gzbarg = array(
                    'posts_per_page'   => -1,
                    'orderby'          => 'date',
                    'order'            => 'DESC',
                    'post_type'        => 'investmentzone',
                    'post_status'      => 'publish',
                    'suppress_filters' => 0
                );

                $gzb_array = get_posts( $gzbarg );
               
                foreach ($gzb_array as $gzb_arr) {

                $gzbmimg = wp_get_attachment_image_src( get_post_thumbnail_id( $gzb_arr->ID ), 'single-post-thumbnail' ); ?>
                            <li>
                                <div class="inv_images">
                                    <p class="inv_logo">
                                        <img src="<?php echo $gzbmimg[0]; ?>" />
                                    </p>
                                </div>
                                <div class="inv_details">
                                    <h3><a href="<?php echo get_permalink( $gzb_arr->ID ); //echo get_field( "link", $gzb_arr->ID ); ?>" target="_blank"><?php echo $gzb_arr->post_title; ?></a></h3>
                                    <p><?php echo get_field( "sub_text", $gzb_arr->ID ); ?></p>
                                </div>
                            </li>
                <?php } ?>

                        </ul>
                    </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>