

<?php
/*
    Template Name: ReaderDigest
*/

    get_header(); 
$swisschkr = multisite_globalizer(); ?>
<link href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.css" rel="stylesheet">
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
  
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Reader’s Digest
                        </li>
                    </ul>
                </nav>
            </div>-->
        <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                     <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php the_title(); ?></h1>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns dowedo_top">
                            <?php
                            $my_id = 76;
                            $post_id_76 = get_post($my_id);
                            $content = $post_id_76->post_content;
                            $content = apply_filters('the_content', $content);
                            $content = str_replace(']]>', ']]>', $content);
                            echo $content;
                            ?>
                        </div>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns margin_bottom15">
                            <div class="large-12 columns pattern_bg">
                                <div class="large-4 columns news_dropmenu">
                                    <label>DATE
                                        <select>
                                            <option value="husker">-Search by Year-</option>
                                            <option value="starbuck">2016</option>
                                            <option value="hotdog">2015</option>
                                            <option value="apollo">2014</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="large-8 columns news_dropmenu">
                                    <label>KEYWORDS
                                        <div class="input-group">
                                            <input class="input-group-field news_search_field" type="text" placeholder="Type any keywords">
                                            <div class="input-group-button">
                                                <a href="#" class="button news_search_button"><i class="fa fa-search" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
<div class="large-12 columns no_padding">
    <div class="large-12 columns dowedo_top">
        <div class="radius_table_container">
            <div id="owl-demo-3" class="owl-carousel owl-theme">

                <?php  $args = array(
                'post_status' => 'any',
                'post_type'   => 'readerdigest'
                   );

             $query = new WP_Query( $args ); ?>
             <?php $prev_yr= null; ?>

             <?php $array = array(); ?>

             <?php while ( $query->have_posts() ) : $query->the_post(); ?>

            <?php $array[] = get_the_date('Y');

             ?>  
                  <?php endwhile; ?>
                 <?php $arrlength = count($array); 

          //echo $arrlength; 
                //for($m=0;$m<$arrlength;$m++) {  
                       //echo $array[$m]; }
                          ?>

                          <?php $arr= array_unique($array); ?>
                     <?php $a = array(); $j=0;?>

                     <?php for($i=0; $i<$arrlength; $i++){
                       if($arr[$i] != null){
                       $a[$j]=$arr[$i];
                       $j=$j+1;
                       }

                     } ?>
                     <?php $arrlen = count($a); 
                        //echo $arrlen; ?>


                    <?php for($m=0; $m < $arrlen; $m++) { ?>
                    <?php $count=0; ?>
                    <?php while ( $query->have_posts() ) : $query->the_post();

                    

                    $this_yr = get_the_date('Y'); ?>
                    <?php if($this_yr == $a[$m] && $count == 0) { ?> 

                    <div class="item">
                            <table class="reader_list" border="1">
                                <thead>
                                    <tr>
                                        <?php if($count%3==0) {?>
                                        <th width=""><?php echo get_the_date('Y'); ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                
                                    <?php  $args3 = array(
                                    'post_status' => 'any',
                                    'post_type'   => 'readerdigest'
                                       );

                                     $query3 = new WP_Query( $args3 ); ?>

                                     <?php while ( $query3->have_posts() ) : $query3->the_post();  
                                     $date = get_the_date('Y'); ?> 
                                     <?php if($date == $a[$m]) { $count++; ?>
                                <?php
                                $uploadpdfid3 =  get_the_ID(); 
                                //echo $uploadpdfid3; 
                               

                                $var3 = get_post_meta($uploadpdfid3,'pm_readerdigest');  
                                //print_r($var); 

                                $pdfup3 = get_post_meta($var3[0][0]['pdf'],'_wp_attached_file'); 
                                //print_r($pdfup); 
                                $value3 = $upload_dir['baseurl'].'/'.$pdfup3[0]; 
                               //echo $value;
                                ?>
                                <tbody>
                                    <tr>
                                        <td><a href="<?php echo  $value3;?>" target="_blank"> <?php echo the_title(); ?> 
                                                <!--<span class="badge reader_new_badge">NEW</span>--> </a></td>
                                        
                                                 
                                    </tr>

                                </tbody>
                                 <?php } ?>      
                                   <?php endwhile; ?> 
                            </table>
                 </div>
                 <?php } ?>
                 <?php endwhile; ?>
                <?php }?>   


            </div>

        </div>
    </div>
</div>
</div>
                
<?php get_sidebar(); ?>

               

            </div>
        </section>
 
    
    <!-- Script to Activate the Carousel -->
    <script>
        var $jqr = jQuery.noConflict();
   // $jqr('.carousel').carousel({
        //interval: 5000 //changes the speed
    //})
    </script>
  

<script>
    $jqr(document).ready(function() {
 
  $jqr("#owl-demo-3").owlCarousel({
     autoplay:false,
     loop:true,
     autoplayTimeout:5000,
     smartSpeed:450,
    items : 3,
    margin : 10,
    lazyLoad : true,
    navigation : true
    
  }); 
 
});
</script>
    <?php get_footer(); ?>
