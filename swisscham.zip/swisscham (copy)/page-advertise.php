<?php
/*
	Template Name: Advertise
*/
	get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                            <?php if ( $swisschkr==1 ) { ?>
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                            <?php } if ( $swisschkr==2 ) { ?>
                        <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
                            <?php } if ( $swisschkr==3 ) { ?>
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                            <?php } if ( $swisschkr==4 ) { ?>
                        <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
                            <?php } if ( $swisschkr==5 ) { ?>
                        <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
                            <?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> Services
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Advertise with Us
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">

        <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_826 = get_post( 826 );
                     $pagea = $post_826->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_826 = get_post( 236 );
                     $pagea = $post_826->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_826 = get_post( 203 );
                     $pagea = $post_826->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
                </div>
        <?php } if ( $swisschkr==4 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_826 = get_post( 162 );
                     $pagea = $post_826->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
                </div>
        <?php } if ( $swisschkr==5 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <?php $post_826 = get_post( 164 );
                     $pagea = $post_826->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
                </div>
        <?php } ?>

                <?php get_sidebar(); ?>
            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>