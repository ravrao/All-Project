<?php
/*
    Template Name: ReaderDigest
*/

    get_header(); 
$swisschkr = multisite_globalizer(); ?>
<link href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.css" rel="stylesheet">
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
 <style>
        .customNavigation{display: none;}
        .owl-pagination{display: none;}
        .owl-theme .owl-controls {
    margin-top: -35px;
    /* text-align: right; */
    position: absolute;
    top: 0;
    right: 0;
}
.owl-theme .owl-controls .owl-buttons div{background:#aa0008 }
    </style>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Reader’s Digest
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">Reader's Digest</h1>
                    </div>
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns dowedo_top">
                            <p>SwissCham China publishes a Reader's Digest every second week. It provides Swiss and Chinese Business Related News in Switzerland and China, as well as a summary of all SwissCham Chapters' activities for the following fortnight. In short:</p>
                            <ul class="fa-ul no-bullet">
                                <li>Compilation of Sino-Swiss Business related news sent every other Fridays.</li>
                                <li>Distributed to all SwissCham China Members, Associates and Employees in Members Companies, as well as to the members of Swiss Chinese Chamber of Commerce in Switzerland (SCCC) and the Swiss Chamber of Commerce in Hong Kong (more than 4’000 contacts in total)</li>
                                <li>Only one exclusive banner (600 x 125 pixels) per issue.</li>
                                <li>Advertisement Options and Rates:</li>
                                <li>Members & Associates: 2’500 RMB, Non-Members: 3’000 RMB</li>
                                <li>An incrementing discount is proposed for multiple orders.</li>
                            </ul>
                        </div>
                    </div>
                    <!--<div class="large-12 columns no_padding">
                        <div class="large-12 columns margin_bottom15">
                            <div class="large-12 columns pattern_bg">
                                <div class="large-4 columns news_dropmenu">
                                    <label>DATE
                                        <select>
                                            <option value="husker">-Search by Year-</option>
                                            <option value="starbuck">2016</option>
                                            <option value="hotdog">2015</option>
                                            <option value="apollo">2014</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="large-8 columns news_dropmenu">
                                    <label>KEYWORDS
                                        <div class="input-group">
                                            <input class="input-group-field news_search_field" type="text" placeholder="Type any keywords">
                                            <div class="input-group-button">
                                                <a href="#" class="button news_search_button"><i class="fa fa-search" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>-->
                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns dowedo_top">
                            <div class="radius_table_container">
                                <div id="owl-demo-3" class="owl-carousel owl-theme">
                                <div class="item">
                                <table class="reader_list" border="1">
                                    <thead>
                                        <tr>
                                            <th width="">2016</th>
                                            <th width="">2015</th>
                                            <th width="">2014</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July <span class="badge reader_new_badge">NEW</span> </a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                                    
                                </div>   
                                    
                                <div class="item">
                                <table class="reader_list" border="1">
                                    <thead>
                                        <tr>
                                            <th width="">2016</th>
                                            <th width="">2015</th>
                                            <th width="">2014</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July <span class="badge reader_new_badge">NEW</span> </a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                        <tr>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                            <td><a href="#"> 16 July - 29 July</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                                    
                                </div>      
                            </div>
                                
                                <div class="customNavigation">
                                <a class="btn prev">Previous</a>
                                <a class="btn next">Next</a>
                                <a class="btn play">Autoplay</a>
                                <a class="btn stop">Stop</a>
                              </div>
                        </div>
                    </div>
                </div>
                <?php get_sidebar(); ?>

                <!--<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="images/inner_sponser1.jpg" /></li>
                                <li><img src="images/inner_sponser2.jpg" /></li>
                                <li><img src="images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>-->


            </div>
        </section>
 <!-- jQuery -->
    

   
    
    <!-- Script to Activate the Carousel -->
    <script>
        var $jqr = jQuery.noConflict();
   // $jqr('.carousel').carousel({
        //interval: 5000 //changes the speed
    //})
    </script>
  

<script>
    $jqr(document).ready(function() {
 
  $jqr("#owl-demo-3").owlCarousel({
     autoPlay: 3000,
    items : 1,
    lazyLoad : true,
    navigation : true
    
  }); 
 
});
</script>
    <?php get_footer(); ?>




