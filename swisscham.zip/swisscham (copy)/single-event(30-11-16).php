<?php
get_header();
    $swisschkr = multisite_globalizer(); 
$fetchtid = get_the_ID();
//echo $fetchtid;
    ?>

    <?php $getrecipedetail = get_post_meta($fetchtid,'pm_enterroute'); 
 //print_r($getrecipedetail);

 $uploadedimage =  get_post_meta($getrecipedetail[0][0]['map-image'],'_wp_attached_file');
 // print_r($uploadedimage);
 $upload_dir = wp_upload_dir();
 ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <?php if(is_singular( 'news' )) { ?>
                            <li><a href="<?php echo home_url(); ?>/news/">Events</a></li>
                            <!-- <li>
                                <span class="show-for-sr">Current: </span>News
                        </li> -->
                            <?php } else { ?>
                                <li>
                                    <?php if( have_posts() ); ?>
                                        <?php 
                                       while( have_posts() ) : the_post(); ?>
                                            <span class="show-for-sr">Current: </span>
                                            <?php echo "Events"; ?>
                                                <?php endwhile; ?>
                                </li>
                                <?php }
                         ?>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo get_the_title($fetchid);?></h1>
                    </div>
                    <div class="large-12 columns no_padding" data-equalizer="event_box_align">
                        <div class="large-8 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">
                                <ul class="fa-ul no-bullet event_list_details">
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <span class="event_list_name">TIME</span>
                                            <?php echo do_shortcode('[event]#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME[/event]'); ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span> <span class="event_list_name">Venue</span>
                                            <?php echo do_shortcode('[event]#_LOCATIONNAME[/event]'); ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span>
                                            <?php echo do_shortcode('[event]#_LOCATIONADDRESS,#_LOCATIONTOWN,#_LOCATIONCOUNTRY[/event]'); ?>
                                        </p>
                                    </li>
                                    <li>
                                        <p><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">PRICE</span> Member
                                            <?php $minprice= do_shortcode('[event]#_EVENTPRICEMIN[/event]'); 
 $minexploded=explode(".",$minprice); echo $minexploded[0];
                                             ?> | Non Members
                                                <?php $maxprice= do_shortcode('[event]#_EVENTPRICEMAX[/event]');
 $maxexploded=explode(".",$maxprice); echo $maxexploded[0];
                                                 ?>
                                        </p>
                                    </li>

                                </ul>
                            </div>

                        </div>

<?php $createstartdate= do_shortcode('[event]#Y#m#d T #H#i#s[/event]'); $withoutspacestart=str_replace(' ', '', $createstartdate); ?>
<?php $createenddatedate= do_shortcode('[event]#@Y#@m#@d T #@H#@i#@s[/event]'); $withoutspaceend=str_replace(' ', '', $createenddatedate); 

$sendtitle=get_the_title($fetchid);
    

?>

                        <div class="large-4 columns margin_bottom15">
                            <div class="pattern_bg" data-equalizer-watch="event_box_align">
                                <p class="register_button"><a href="#" class="button expanded common_button">Register Now</a></p>
                                <ul class="fa-ul no-bullet register_sublist">
                                    <li><a href="http://54.152.108.131/SwissCham/calendercreator/?withoutspacestart=<?php echo $withoutspacestart; ?>&withoutspaceend=<?php echo $withoutspaceend ;?>&sendtitle=<?php echo $sendtitle ;?>" class="">add to calendar</a></li>
                                    <li><a href="http://54.152.108.131/SwissCham/baidu-test/?lat=23.142106886029&lang=113.52897592105" class="">taxi directions</a></li>
                                </ul>
 
                             
                            </div>

                        </div>
                    </div>
                    <div class="large-12 columns">
                        <div id="eventListTab">
                            <ul class="resp-tabs-list hor_1 innerpage_tab">
                                <li class="tab_active">Event Info</li>
                                <li class="">location</li>
                                <li>contact</li>
                                <li>related</li>
                            </ul>
                            <div class="resp-tabs-container hor_1 eventtab_list_details">
                                <div>
                                    <div class="eventtab_list_item">
                                        <?php if( have_posts() ); ?>

                                            <?php 
                               while( have_posts() ) : the_post(); ?>

                                                <?php the_content(); ?>
                                                    <?php endwhile; ?>
                                    </div>
                                </div>
                                <div>
                                    <div class="eventtab_list_item">
                                        <?php echo do_shortcode('[event]#_LOCATIONFULLBR[/event]'); ?>
                                            <p>
                                                <?php echo $getrecipedetail[0][0]['enter-route-description'];?>
                                            </p>
                                            <img src="<?php echo $upload_dir['baseurl'].'/'.$uploadedimage[0];?>" alt="" class="img-responsive" />
                                    </div>
                                </div>
                                <div>
                                    <div class="eventtab_list_item">
                                        Contact Us:
                                        <p>
                                            <?php echo $getrecipedetail[0][0]['add-contact-details'];?>
                                        </p>
                                    </div>

                                </div>
                                <div>
                                    <div class="eventtab_list_item">
                                        <?php echo do_shortcode('[event]#_CATEGORYALLEVENTS[/event]'); ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <?php get_sidebar(); ?>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">

                    </div>

                </div>



            </div>
        </section>

        <?php 
          get_footer('event');
         ?>
