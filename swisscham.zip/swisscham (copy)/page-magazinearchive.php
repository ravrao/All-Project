<?php
/*
	Template Name: Magazine Archives
*/

get_header(); ?>
     <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> bridge archives
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                      <div class="large-12 columns dowedo_top">
                        <?php while ( have_posts() ) : the_post(); ?>
                        <h1 class="common_heading"><?php the_title(); ?></h1>
                        <?php the_content(); ?>
                   <?php endwhile; ?>
                    </div>
 <?php
 $args2=array(
'posts_per_page'=> -1,
'orderby' =>'date',
'order'=>DESC,
'post_type' =>'bridge_magazine'
);
 $items = array();$count=1;
  $latstsponsors = new WP_query($args2);
   $prev_year = null;
    $upload_path=wp_upload_dir();
 if ($latstsponsors-> have_posts() ) :  while ($latstsponsors->have_posts()) :$latstsponsors->the_post(); 
  $newsdetail= get_post_meta($post->ID, 'pm_bridgecontent'); 
  $image_url = get_post_meta( $newsdetail[0][0]['upload-bridge-magazine'], '_wp_attached_file' );
      $this_year = get_the_date('Y');
     $image2 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' ); 
      if ($prev_year != $this_year) {
        // echo $count;
         if($flag == '1'){
          echo '</ul>'; ?>
         <div class="large-12 columns dowedo_top">
<ul class="fa-ul mag_archive_img">
<?php 
foreach($items as $value) { ?>
  <li>
 <p><img src="<?php echo $value; ?>"></p>
  </li>
<?php }
?>
   </ul>
   </div>

  <?php 
unset($items);
$flag=0;

   }
          // Year boundary
        if($count != '1'){
        echo '<div class="large-12 columns"><hr class="right_devider"></div>';
    }
          if (!is_null($prev_year)) {
             // A list is already open, close it first
             echo '</ul></div>';
          }
          echo '<div class="large-12 columns dowedo_top margin_top10"><h3 class="common_subheading">' . $this_year . '</h3>'; $count++; if($count > 1){$flag=1;}
          //print_r($items);
          echo '<ul class="fa-ul mag_archive_list">';
      }
      echo '<li>'; ?>
 <a target="_blank" href="<?php  echo $upload_path['baseurl']."/".$image_url[0];?>"><?php the_title(); ?></a>
  <?php   echo '</li>';
      $prev_year = $this_year;
 $items[] = $image2[0];
 //print_r($items);

 endwhile;?>
 <?php  echo '</ul>';?>
  <div class="large-12 columns dowedo_top">
<ul class="fa-ul mag_archive_img">
<?php 
foreach($items as $value) { ?>
  <li>
 <p><img src="<?php echo $value; ?>"></p>
  </li>
<?php }
?>
   </ul>
   </div>
   <?php
   echo '</ul></div>';
 endif;
wp_reset_postdata();

//echo $find_date."-----------";

//echo $newdate;
?>             
               


                </div>

         <?php get_sidebar(); ?>
            </div>
        </section>

		<?php get_footer(); ?>