<?php
/*
  template name: Calender creator

 */

global $wpdb;
date_default_timezone_set("Asia/Shanghai");
$statingdate=$_GET['withoutspacestart'];
$endingdate=$_GET['withoutspaceend'];
$title= $_GET['sendtitle'];
$location= $_GET['sendlocation'];
$description= $_GET['senddescription'];
//require_once( ABSPATH .'wp-load.php' );
//$rs=$wpdb->get_row("SELECT  * FROM  `sc_posts` where `ID`='".$description."' AND `post_status`='publish'");
//$content = str_replace(']]>', ']]>', $rs->post_content);
//$subconent_ics=substr($content, 0, 400);

$strDate = date('Ymd');
$strtime = date('his');
$mergeddate= $strDate.'T'.$strtime;


header("Content-Type: text/Calendar");
header("Content-Disposition: inline; filename=Swisscham_$mergeddate.ics");

echo "BEGIN:VCALENDAR\n";
echo "PRODID:-//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN\n";
echo "VERSION:2.0\n";
echo "METHOD:PUBLISH\n";
echo "X-MS-OLK-FORCEINSPECTOROPEN:TRUE\n";
echo "BEGIN:VEVENT\n";
echo "CLASS:PUBLIC\n";
//echo "CREATED:20091109T101015Z\n";
echo "LOCATION:".$location."\n";

echo "DESCRIPTION:".$description."\n";
echo "DTEND:".$_GET['withoutspaceend']."Z\n";
//echo "DTSTAMP:".$mergeddate."Z\n";
//echo "DTSTART:".$statingdate."Z\n";
echo "PRIORITY:5\n";
echo "SEQUENCE:0\n";
echo "SUMMARY;LANGUAGE=en-us:".$title."\n";
echo "TRANSP:OPAQUE\n";
echo "UID:040000008200E00074C5B7101A82E008000000008062306C6261CA01000000000000000\n";
echo "X-MICROSOFT-CDO-BUSYSTATUS:BUSY\n";
echo "X-MICROSOFT-CDO-IMPORTANCE:1\n";
echo "X-MICROSOFT-DISALLOW-COUNTER:FALSE\n";
echo "X-MS-OLK-ALLOWEXTERNCHECK:TRUE\n";
echo "X-MS-OLK-AUTOFILLLOCATION:FALSE\n";
echo "X-MS-OLK-CONFTYPE:0\n";
//Here is to set the reminder for the event.
echo "BEGIN:VALARM\n";
echo "TRIGGER:-PT1440M\n";
echo "ACTION:DISPLAY\n";
echo "DESCRIPTION:Reminder\n";
echo "END:VALARM\n";
echo "END:VEVENT\n";
echo "END:VCALENDAR\n"; 

/*date_default_timezone_set('Asia/Calcutta');
$startdate=20170922;
$enddate=20170924;
$startminutes=1300;
$endminutes=1400;

//echo date("y/m/d H i s");

  // DISPLAY CALENDER EVENT
$startdate = date('Ymd',strtotime($startdate)); //needs the YYYYMMDD  format
$enddate = date('Ymd',strtotime($enddate)); //ends the day before the set date. So the date range is startdate(inclusive) -> enddate(exclusive)
//$startTime = gmdate('Hi',mktime($startminutes)); // This is in greenwhich mean time. Have the users input time normally and simply  
 $startTime = $startminutes;                                                             //explode on :
$endTime   = gmdate('Hi',mktime($endminutes));
$subject   = 'yeah';
$desc      = 'come to this meeting';
$location = 'wherever';

$ical = "BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//hacksw/handcal//NONSGML v1.0//EN
BEGIN:VEVENT
UID:" . md5(uniqid(mt_rand(), true))."
DTSTAMP:" . gmdate('Ymd').'T'. gmdate('His') . "Z
DTSTART:".$startdate."T".$startTime."
DTEND:".$enddate."T".$endTime."00Z
LOCATION:$location
SUMMARY:".$subject."
DESCRIPTION:".$desc."
END:VEVENT
END:VCALENDAR";

//set correct content-type-header
header('Content-type: text/calendar; charset=utf-8');
header('Content-Disposition: inline; filename=calendar.ics');
echo $ical; */







 
?>

