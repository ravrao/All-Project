<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package SwissCham
 */

get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
 <?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> This url is not present in our server
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">404 Error</h1>
                        <p>Sorry for the inconvenience. This page is currently unavailable.</p>
                    </div>
                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
          get_footer();
         } if ( $swisschkr==2 ) {
          get_footer('bei');
         } if ( $swisschkr==3 ) {
          get_footer('sha');
         } if ( $swisschkr==4 ) {
          get_footer('gz');
         } if ( $swisschkr==5 ) {
          get_footer('hk');
         } ?>