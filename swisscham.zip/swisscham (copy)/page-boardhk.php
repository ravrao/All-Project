<?php
/*
    Template Name: BoardHK
*/

    get_header();
    $swisschkr = multisite_globalizer(); ?>

            <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <li>
                            <span class="show-for-sr">Current: </span> About Us
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Board - Hong Kong
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>

        <?php if ( $swisschkr==1 ) {

        	$post_72 = get_post( 72 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_72->post_title; ?></h1>

                        <?php $pagebgz72 = $post_72->post_content;

                            $pagebgz72 = apply_filters('the_content', $pagebgz72);
                            $pagebgz72 = str_replace(']]>', ']]&gt;', $pagebgz72);
                            echo $pagebgz72;  
                        ?>

                    </div>
        <?php } if ( $swisschkr==5 ) {

        	$post_114 = get_post( 114 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_114->post_title; ?></h1>

                        <?php $pagebgz70 = $post_114->post_content;

                            $pagebgz70 = apply_filters('the_content', $pagebgz70);
                            $pagebgz70 = str_replace(']]>', ']]&gt;', $pagebgz70);
                            echo $pagebgz70;  
                        ?>

                    </div>
        <?php } ?>

                    <div class="large-12 columns" data-equalizer="boardDetailsAlign">
                        <div class="row" data-equalizer="boardOuter">

            <?php if ( $swisschkr==1 ) { ?>

<?php $hkbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'boardmember',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'board_cat',
                     'field' => 'slug',
                     'terms' => 'board-hongkong'
                  )
               )
            );

            $hkb_array = get_posts( $hkbarg );
           
            foreach ($hkb_array as $hkb_arr) {

            $hkbmimg = wp_get_attachment_image_src( get_post_thumbnail_id( $hkb_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-3 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">
                                    <div class="board_img">
                                        <p class="text-center"><img src="<?php echo $hkbmimg[0]; ?>" /></p>
                                    </div>
                                    <div class="board_details" data-equalizer-watch="boardDetailsAlign">
                                <h2><?php echo $hkb_arr->post_title; ?></h2>
                                <h3><?php echo get_field( "functional_role", $hkb_arr->ID ); ?></h3>
                                <?php $hkbmpstn = get_field( "position", $hkb_arr->ID );
                                        if (!($hkbmpstn=='')) { ?>
                                <h5><?php echo $hkbmpstn; ?></h5>
                                        <?php } ?>
                                    </div>
                                    
                                <?php $hkbbl = get_field( "organization", $hkb_arr->ID );
                                        if (!($hkbbl=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="<?php echo get_field( "organization_link", $gzb_arr->ID ); ?>"><?php echo $hkbbl; ?></a></p>
                                    </div>
                                <?php } ?>




                                </div>
                            </div>

                    <?php } ?>

                    <?php } if ( $swisschkr==5 ) { ?>

<?php $hkbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'boardmember',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $hkb_array = get_posts( $hkbarg );
           
            foreach ($hkb_array as $hkb_arr) {

            $hkbmimg = wp_get_attachment_image_src( get_post_thumbnail_id( $hkb_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-3 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">
                                    <div class="board_img">
                                        <p class="text-center"><img src="<?php echo $hkbmimg[0]; ?>" /></p>
                                    </div>
                                    <div class="board_details" data-equalizer-watch="boardDetailsAlign">
                                <h2><?php echo $hkb_arr->post_title; ?></h2>
                                <h3><?php echo get_field( "functional_role", $hkb_arr->ID ); ?></h3>
                                <?php $hkbmpstn = get_field( "position", $hkb_arr->ID );
                                        if (!($hkbmpstn=='')) { ?>
                                <h5><?php echo $hkbmpstn; ?></h5>
                                        <?php } ?>
                                    </div>
                                    
                                <?php $hkbbl = get_field( "organization", $hkb_arr->ID );
                                        if (!($hkbbl=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="<?php echo get_field( "organization_link", $gzb_arr->ID ); ?>"><?php echo $hkbbl; ?></a></p>
                                    </div>
                                <?php } ?>




                                </div>
                            </div>

                    <?php } ?>

                    <?php } ?>

                        </div>
                    </div>
                </div>
                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
            get_footer();
         } if ( $swisschkr==2 ) {
            get_footer('bei');
         } if ( $swisschkr==3 ) {
            get_footer('sha');
         } if ( $swisschkr==4 ) {
            get_footer('gz');
         } if ( $swisschkr==5 ) {
            get_footer('hk');
         } ?>