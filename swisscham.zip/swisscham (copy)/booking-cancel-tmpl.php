<?php
/*
  Template Name: Booking Cancel
 */

get_header();
$swisschkr = multisite_globalizer(); ?>
<?php
$booking_details=$wpdb->get_row("SELECT  * FROM  `sc_em_bookings` where `booking_id`='".$_GET['booking_id']."'");
$userdetails=$booking_details->booking_meta;

$mydata_booking = unserialize($userdetails);
//print_r($mydata_booking);
$ser=  maybe_serialize($mydata_booking);

 //var_dump($ser);

$booking_user=$wpdb->get_row("SELECT  * FROM  `sc_users` where `ID`='".$booking_details->person_id."'");
$booking_event_name=$wpdb->get_row("SELECT  * FROM  `sc_em_events` where `event_id`='".$booking_details->event_id."'");

if (isset($_REQUEST['cancel'])){
$update = "UPDATE `sc_em_bookings`
SET `booking_status`=3
WHERE `booking_id` = '".$_GET['booking_id']."'";	 
$wpdb->query($update); 
?>
<script language="javascript" type="text/javascript">
window.location.href="<?php bloginfo('url') ?>/event-booking-cancel/?booking_id=<?php echo $_GET['booking_id'];?>";
</script>
<?php 
$booking_details=$wpdb->get_row("SELECT  * FROM  `sc_em_bookings` where `booking_id`='".$_GET['booking_id']."'");
$booking_user=$wpdb->get_row("SELECT  * FROM  `sc_users` where `ID`='".$booking_details->person_id."'");
$uname=get_user_meta($booking_user->ID, 'first_name', true);




$to  = 'ravi@sketchwebsolutions.com';
$subject = 'Booking Cancelled';

$message = '<p>This is to notify that a cancelled has occurred.</p>
    <p>User Name:  '.$uname.'</p>
    <p>User Email: '.$booking_user->user_email.'</p>    
    <p>Requested Sapces for '.$booking_event_name->event_name.' which has now been cancled by '.$uname.'</p>

    <p>With best regards,</p> 

    <p>Your SwissCham team</p>';

 			
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: swischam.com';
@mail($to, $subject, $message, $headers);
}
?>
<div class="abc"></div>
<section class="inner_banner bg-beijing hide-for-small-only">

    <?php echo get_post_breadcrumbs(); ?> 
</section>
    <section>
        
        
        <div class="row" data-equalizer data-equalize-on="medium">
            <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <div class="large-12 columns dowedo_top">
                <div class="table-scroll">
                    <?php 
                    $booking_details_condition=$wpdb->get_row("SELECT  * FROM  `sc_em_bookings` where `booking_id`='".$_GET['booking_id']."'");
                    if($booking_details_condition->booking_status!=3) {  ?>
                    <h3><center>Are you sure you want to cancel event registration ?</center></h3>
                    <div class="em-booking css-booking" id="em-booking">
    <form action="" method="post" name="booking-form" class="em-booking-form">
        <input type="hidden" value="booking_add" name="action">
        <input type="hidden" value="74" name="event_id">
        <input type="hidden" value="7903404bf6" name="_wpnonce">
        <div class="em-booking-form-details">
            			
            <input type="hidden" class="em-ticket-select" value="1" name="em_tickets[66][spaces]">
            <style>
                .em-booking-form-details{ width:100%; }
                .em-booking-form label{ width:100%; }
                .em-booking-form-details input.input, .em-booking-form-details textarea{ width:100%; }
                #em-booking-submit {
                    background-color: #aa0008;
                    border: 1px solid transparent;
                    border-radius: 0;
                    color: #fff;
                    cursor: pointer;
                    display: inline-block;
                    font-size: 0.9rem;
                    line-height: 1;
                    margin: 0 0 1rem;
                    padding: 0.85em 1em;
                    text-align: center;
                    transition: background-color 0.25s ease-out 0s, color 0.25s ease-out 0s;
                    vertical-align: middle;
                    float:right;
                }
                body {

                    color: #000;
                    font-family: "robotomedium",Helvetica,Roboto,Arial,sans-serif;

                }
                .em-tickets-spaces label{ font-weight:700; }
                label {
                    color: #000;
                    display: block;
                    font-size: 0.875rem;

                    line-height: 18px;
                    margin: 0;
                }
                .ticket-price label{ float: left; width: 60px; margin-bottom: 15px; }
                .ticket-price strong{ float: left; }
            </style>

       <div class="medium-12 columns no_padding">
                <div class="medium-6 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_name">Name
                    <input readonly="true" type="text" value="<?php echo get_user_meta($booking_user->ID, 'first_name', true); ?>" class="input">

                </div>


                <div class="clearfix"></div>

                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="dbem_phone">Phone                        
                        <input readonly="true" type="text" value="<?php echo get_user_meta($booking_user->ID, 'dbem_phone', true); ?>" class="input" >
                    </label>
                </div>
            </div>
            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_email">E-mail 
                    <input type="text" value="<?php echo $booking_user->user_email; ?>" readonly="true" class="input" >

                    <small>The email to associate with this registration.</small>
                </div>
            </div>

            <div class="medium-6 columns no_padding surput">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="sur_name">Surname 
                        <input readonly="true" type="text" value="<?php echo $mydata_booking['registration']['sur_name']; ?>" class="input">
                    </label>
                </div>
            </div>
            
            <div class="medium-12 columns no_padding">
                <div class="medium-12 columns margin_top10 membership_from event_reg_field small_padding">
                    <label for="user_email">Event Name 
                    <input  type="text" value="<?php echo $booking_event_name->event_name; ?>" readonly="true" class="input" >

                    
                </div>
            </div>
       <div class="clearfix"></div>
            <div class="em-booking-buttons">
               
                <input type="submit" name="cancel" value="Cancel" id="em-booking-submit" class="em-booking-submit">
                 <small>This action cannot be undone.</small>
            </div>
        </div>
    </form>		
    <br style="clear:left;" class="clear">  
</div>
                    <?php } else {?> 
                    <h3><center>You booking has been cancelled. </center></h3>
                    <?php } ?>
                    </div>
                </div>

            </div>
             <?php get_sidebar(); ?>
        </div>
    </section>


 <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>