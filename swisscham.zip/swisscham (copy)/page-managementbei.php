<?php
/*
    Template Name: Management BEI
*/

    get_header();
    $swisschkr = multisite_globalizer(); ?>

     <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>        
<?php } ?>              
                        <li>
                            <span class="show-for-sr">Current: </span> About Us
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Managment - Beijing
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">

        <?php if ( $swisschkr==1 ) {

            $post_431 = get_post( 431 ); ?>

                        <h1 class="common_heading"><?php echo $post_431->post_title; ?></h1>
                        <?php $pagemsha431 = $post_431->post_content;

                            $pagemsha431 = apply_filters('the_content', $pagemsha431);
                            $pagemsha431 = str_replace(']]>', ']]&gt;', $pagemsha431);
                            echo $pagemsha431;  
                        ?>

        <?php } if ( $swisschkr==2 ) {

            $post_180 = get_post( 180 ); ?>

                        <h1 class="common_heading"><?php echo $post_180->post_title; ?></h1>
                        <?php $pagemsha180 = $post_180->post_content;

                            $pagemsha180 = apply_filters('the_content', $pagemsha180);
                            $pagemsha180 = str_replace(']]>', ']]&gt;', $pagemsha180);
                            echo $pagemsha180;  
                        ?>

        <?php } ?>

                    </div>
                    <div class="large-12 columns" data-equalizer="managementDetailsAlign">
                        <div class="row" data-equalizer="managementOuter">

<?php if ( $swisschkr==1 ) { ?>

<?php $beimarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'management',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'management_cat',
                     'field' => 'slug',
                     'terms' => 'management-beijing'
                  )
               )
            );

            $beim_array = get_posts( $beimarg );
           
            foreach ($beim_array as $beim_arr) {

            $beimimg = wp_get_attachment_image_src( get_post_thumbnail_id( $beim_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-4 medium-6 columns small_padding management_container_sec" data-equalizer-watch="managementOuter">
                                <div class="management_container">
                                    <div class="managemnet_img">
                                        <p class=""><img src="<?php echo $beimimg[0]; ?>" /></p>
                                    </div>
                                    <div class="management_details" data-equalizer-watch="managementDetailsAlign">
                                        <h2><?php echo $beim_arr->post_title; ?></h2>
                                        <h2><?php echo get_field( "subtitle", $beim_arr->ID ); ?></h2>
                                        <h3><?php echo get_field( "functional_role", $beim_arr->ID ); ?></h3>
                                        <h5><?php echo get_field( "languages", $beim_arr->ID ); ?></h5>
                                    </div>
                                    <?php $beimmail = get_field( "email_address", $beim_arr->ID );
                                        if (!($beimmail=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="mailto:<?php echo $beimmail; ?>"><?php echo $beimmail; ?></a></p>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
            <?php } ?>

            <?php } if ( $swisschkr==2 ) { ?>

<?php $beimarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'management',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $beim_array = get_posts( $beimarg );
           
            foreach ($beim_array as $beim_arr) {

            $beimimg = wp_get_attachment_image_src( get_post_thumbnail_id( $beim_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-4 medium-6 columns small_padding management_container_sec" data-equalizer-watch="managementOuter">
                                <div class="management_container">
                                    <div class="managemnet_img">
                                        <p class=""><img src="<?php echo $beimimg[0]; ?>" /></p>
                                    </div>
                                    <div class="management_details" data-equalizer-watch="managementDetailsAlign">
                                        <h2><?php echo $beim_arr->post_title; ?></h2>
                                        <h2><?php echo get_field( "subtitle", $beim_arr->ID ); ?></h2>
                                        <h3><?php echo get_field( "functional_role", $beim_arr->ID ); ?></h3>
                                        <h5><?php echo get_field( "languages", $beim_arr->ID ); ?></h5>
                                    </div>
                                    <?php $beimmail = get_field( "email_address", $beim_arr->ID );
                                        if (!($beimmail=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="mailto:<?php echo $beimmail; ?>"><?php echo $beimmail; ?></a></p>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
            <?php } ?>

            <?php } ?>
                        </div>
                    </div>
                </div>

              <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
            get_footer();
         } if ( $swisschkr==2 ) {
            get_footer('bei');
         } if ( $swisschkr==3 ) {
            get_footer('sha');
         } if ( $swisschkr==4 ) {
            get_footer('gz');
         } if ( $swisschkr==5 ) {
            get_footer('hk');
         } ?>