<?php
/*
	Template Name: Other Events HK
*/
	get_header(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
           
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15">
                    <div class="large-12 columns dowedo_top">
                    <div class="table-scroll">
                    <table class="upcom_list">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Place</th>
                            </tr>
                        </thead>
                        <tbody>

<?php

global $switched;
    switch_to_blog(1);

 $bbbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $bbb_array = get_posts( $bbbarg );
           
            foreach ($bbb_array as $bbb_arr) {

             ?>
<?php $colors = get_field('is_this_other_events_in_hk', $bbb_arr->ID);

    if( $colors ): 

         foreach( $colors as $color ):

                    if ($color=='yes') { 
    
    echo do_shortcode('[event post_id="'.$bbb_arr->ID.'"]<tr><td><a href="/hk/event-details/?id=#_EVENTPOSTID">#_EVENTNAME</td><td><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/event]');

 }  endforeach;  endif; } ?>

                        </tbody>
                    </table>
                    </div>
                    </div>
                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php get_footer('hk'); ?>