<?php
/*
	Template name: MBP Bei
*/
	get_header();
	$swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
<?php } ?>             
                        <li>
                            <span class="show-for-sr">Current: </span> Membership
                        </li> 
                        <li>
                            <span class="show-for-sr">Current: </span> MBP - Beijing
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
        <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_684 = get_post( 684 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_684->post_title; ?></h1>
                        <?php $pagebgz684 = $post_684->post_content;

                            $pagebgz684 = apply_filters('the_content', $pagebgz684);
                            $pagebgz684 = str_replace(']]>', ']]&gt;', $pagebgz684);
                            echo $pagebgz684;  
                        ?>
                    </div>
                    <?php echo get_field('content', 684); ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_216 = get_post( 216 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_216->post_title; ?></h1>
                        <?php $pagebgz216 = $post_216->post_content;

                            $pagebgz216 = apply_filters('the_content', $pagebgz216);
                            $pagebgz216 = str_replace(']]>', ']]&gt;', $pagebgz216);
                            echo $pagebgz216;  
                        ?>
                    </div>
                    <?php echo get_field('content', 216); ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       <div class="wechat_pop" style="display: none">
         <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
        </div>
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } ?>

                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } ?>