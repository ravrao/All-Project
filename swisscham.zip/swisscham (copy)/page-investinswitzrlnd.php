<?php
/*
	Template Name: Invest in Switzerland
*/
	get_header();
	$swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>              
                        <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li> 
                        <li>
                            <span class="show-for-sr">Current: </span> Invest in Switzerland
                        </li>
                    </ul>
                </nav>
            </div>-->
        <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php if($swisschkr==1) { ?>
                <?php $post_743 = get_post( 743 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_743->post_title; ?></h1>
                        <?php $pagebgz743 = $post_743->post_content;

                            $pagebgz743 = apply_filters('the_content', $pagebgz743);
                            $pagebgz743 = str_replace(']]>', ']]&gt;', $pagebgz743);
                            echo $pagebgz743;
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10"> 
                    <?php echo get_field('handbook', 743); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                    	<?php echo get_field('switzerland_-_business_environment', 743); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                       <?php echo get_field('success_stories_booklet', 743); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('sino-swiss', 743); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('contact_details', 743); ?>
                    </div>
                    <?php } if($swisschkr==2) { ?>
                    <?php $post_743 = get_post( 225 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_743->post_title; ?></h1>
                        <?php $pagebgz743 = $post_743->post_content;

                            $pagebgz743 = apply_filters('the_content', $pagebgz743);
                            $pagebgz743 = str_replace(']]>', ']]&gt;', $pagebgz743);
                            echo $pagebgz743;
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10"> 
                    <?php echo get_field('handbook', 225); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                    	<?php echo get_field('switzerland_-_business_environment', 225); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                       <?php echo get_field('success_stories_booklet', 225); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('sino-swiss', 225); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('contact_details', 225); ?>
                    </div>
                    <?php } if($swisschkr==3) { ?>
                    <?php $post_743 = get_post( 185 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_743->post_title; ?></h1>
                        <?php $pagebgz743 = $post_743->post_content;

                            $pagebgz743 = apply_filters('the_content', $pagebgz743);
                            $pagebgz743 = str_replace(']]>', ']]&gt;', $pagebgz743);
                            echo $pagebgz743;
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10"> 
                    <?php echo get_field('handbook', 185); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                    	<?php echo get_field('switzerland_-_business_environment', 185); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                       <?php echo get_field('success_stories_booklet', 185); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('sino-swiss', 185); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('contact_details', 185); ?>
                    </div>
                    <?php } if($swisschkr==4) { ?>
                    <?php $post_743 = get_post( 152 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_743->post_title; ?></h1>
                        <?php $pagebgz743 = $post_743->post_content;

                            $pagebgz743 = apply_filters('the_content', $pagebgz743);
                            $pagebgz743 = str_replace(']]>', ']]&gt;', $pagebgz743);
                            echo $pagebgz743;
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10"> 
                    <?php echo get_field('handbook', 152); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                    	<?php echo get_field('switzerland_-_business_environment', 152); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                       <?php echo get_field('success_stories_booklet', 152); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('sino-swiss', 152); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('contact_details', 152); ?>
                    </div>
                    <?php } if($swisschkr==5) { ?>
                    <?php $post_743 = get_post( 158 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_743->post_title; ?></h1>
                        <?php $pagebgz743 = $post_743->post_content;

                            $pagebgz743 = apply_filters('the_content', $pagebgz743);
                            $pagebgz743 = str_replace(']]>', ']]&gt;', $pagebgz743);
                            echo $pagebgz743;
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10"> 
                    <?php echo get_field('handbook', 158); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                    	<?php echo get_field('switzerland_-_business_environment', 158); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                       <?php echo get_field('success_stories_booklet', 158); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('sino-swiss', 158); ?>
                    </div>

                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php echo get_field('contact_details', 158); ?>
                    </div>
                    <?php } ?>
                </div>

                <?php echo get_sidebar(); ?>

                </div>
                </section>
        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>