<?php
/*
    Template Name: Whatwedo
*/

    get_header(); ?>

            <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="beijing.html">Beijing</a></li>
                        <li><a href="javascript:void(0);">About Us</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> What do we do ?
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">SWISSCHAM Bejing - WHAT DO WE DO?</h1>
                        <p>The Swiss Chamber of Commerce is a networking and information platform for Swiss companies in China and Chinese companies interested in Switzerland. Our main goal is to gather on a common platform all actors of the Sino-Swiss business community, in order to strengthen the political and economic bonds between the two countries, stimulate interaction and develop business opportunities. In a nutshell:</p>
                        <ul class="fa-ul custom_plus_list">
                            <li>We CONNECT the companies, institutions and organizations together.</li>
                            <li>We enable EXCHANGE and PROMOTION through our communication channels which encompass events, website, online directory and printed publications,
                                <br /> providing exposure and privileged space to discuss business, find solutions and share your know-how.</li>
                            <li>In Shanghai, we BRING YOU CLOSER through our 4 committees: Finance & Tax, Legal & HR, SME & Industrial and Hospitality, to discuss related topics in more detail. For more information, contact events@sha.swisscham.org</li>
                            <li>We provide a wide range of SERVICES such as access to trainings, event consulting, discounts to members on services/products, and general consulting on business in China.</li>
                        </ul>
                        <div class="inner_middle_img">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/beijing-inner-body.jpg" />
                        </div>
                    </div>
                    <div class="large-12 columns no_padding" data-equalizer="about_inner_height">
                        <div class="large-6 columns dowedo_top" data-equalizer-watch="about_inner_height">
                            <h3 class="common_subheading">Internal organization</h3>
                            <p>SwissCham China is a non-profit, umbrella organization coordinating the Chinese branches. The local branches include SwissCham Beijing, SwissCham Shanghai and SwissCham Guangzhou, which are represented by a Board of Directors (BOD). The BOD may delegate the Chamber's management to an Executive Director (or General Manager) in charge of managing the Chamber's office.</p>
                            <p><a href="#">Read more</a></p>
                        </div>
                        <div class="large-6 columns dowedo_top" data-equalizer-watch="about_inner_height">
                            <h3 class="common_subheading">Internal organization</h3>
                            <p>SwissCham China is a non-profit, umbrella organization coordinating the Chinese branches. The local branches include SwissCham Beijing, SwissCham Shanghai and SwissCham Guangzhou, which are represented by a Board of Directors (BOD). The BOD may delegate the Chamber's management to an Executive Director (or General Manager) in charge of managing the Chamber's office.</p>
                            <p><a href="#">Read more</a></p>
                        </div>
                    </div>
                    <div class="large-12 columns no_padding" data-equalizer="about_inner_height2">
                        <div class="large-6 columns dowedo_top" data-equalizer-watch="about_inner_height2">
                            <h3 class="common_subheading">Network partners</h3>
                            <p>SwissCham China collaborates with other independent Swiss Chinese Chambers of Commerce which include Swiss Chamber of Commerce in Hong Kong (SCCHK) and the Swiss-Chinese Chamber of Commerce (SCCC) in Switzerland (Zurich, Geneva and Lugano). Swiss interests in Taipei are further represented by a private organization called, the Trade Office of Swiss Industries (TOSI).</p>
                            <p><a href="#">Read more</a></p>
                        </div>
                        <div class="large-6 columns dowedo_top" data-equalizer-watch="about_inner_height2">
                            <h3 class="common_subheading">Network partners</h3>
                            <p>SwissCham China collaborates with other independent Swiss Chinese Chambers of Commerce which include Swiss Chamber of Commerce in Hong Kong (SCCHK) and the Swiss-Chinese Chamber of Commerce (SCCC) in Switzerland (Zurich, Geneva and Lugano). Swiss interests in Taipei are further represented by` a private organization called, the Trade Office of Swiss Industries (TOSI).</p>
                            <p><a href="#">Read more</a></p>
                        </div>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top20">
                        <h3 class="common_subheading">External partners</h3>
                        <p>SwissCham Beijing further collaborates with external partners:</p>
                        <ul class="fa-ul custom_plus_list">
                            <li>Suspendisse lacinia semper fermentum. Integer dui lectus, fermentum et risus eu; luctus sodales nisl Sed sed magna pretium, pellentesque arcu vitae.</li>
                            <li>Consulates General in Shanghai, Guangzhou and Hong Kong;</li>
                            <li>Swiss external trade promotion agency OSEC and its Swiss Business Hubs (SBH) in Greater China area;</li>
                            <li>China Council for the Promotion of International Trade (CCPIT);</li>
                            <li>Swiss Center Shanghai (SCS);</li>
                            <li>Other Foreign Chambers of Commerce.</li>
                            <li>and numerous other Swiss, Chinese and foreign organizations.</li>
                        </ul>
                    </div>
                </div>
                <?php get_sidebar(); ?>

                <!--<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="images/inner_sponser1.jpg" /></li>
                                <li><img src="images/inner_sponser2.jpg" /></li>
                                <li><img src="images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>-->

            </div>
        </section>
    <?php get_footer(); ?>