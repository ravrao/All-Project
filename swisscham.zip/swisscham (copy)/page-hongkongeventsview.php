<?php 
/*
template name: Hongkong Events Overview

*/

get_header();
    $swisschkr = multisite_globalizer();
    global $post; ?>

    <div class="abc"></div>
    <section class="inner_banner bg-beijing hide-for-small-only">
        
        <?php echo get_post_breadcrumbs(); ?>
    </section>
    <section>
        <div class="row" data-equalizer data-equalize-on="medium">
            <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <div class="large-12 columns dowedo_top">
                    <h1 class="common_heading"><?php echo $post->post_title; ?></h1>
                </div>
                <div class="large-12 columns dowedo_top margin_top10">

                    <?php $pagebgz684 = $post->post_content;

                    $pagebgz684 = apply_filters('the_content', $pagebgz684);
                    $pagebgz684 = str_replace(']]>', ']]&gt;', $pagebgz684);
                    echo $pagebgz684;  
                ?>

                </div>

                <!--<div class="large-12 columns dowedo_top">
                    <div class="table-scroll">
                        <table class="upcom_list">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="" class="">Date</th>
                                    <th width="" class="">Time</th>
                                    <th width="" class="">Place</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php //echo do_shortcode('[events_list scope="past" limit=5 pagination=1 category="54"  orderby="event_start_date" order="desc"]<tr><td>#_EVENTLINK</td><td class=""><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td class=""><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td class=""><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/events_list]'); ?>
<?php echo do_shortcode('[events_list blog=1 scope="past" limit=5 pagination=1 category="54"  orderby="event_start_date" order="desc"]<tr><td><a href="/hk/event-details/?id=#_EVENTPOSTID">#_EVENTNAME</td><td class=""><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td class=""><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td class=""><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/events_list]'); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>-->

            </div>

            <?php get_sidebar(); ?>

        </div>
    </section>
    <?php 
          get_footer('event');
         ?>
