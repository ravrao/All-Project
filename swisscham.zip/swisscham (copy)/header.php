<!doctype html>
<html class="no-js" lang="en">

<head>
    <!--added on 10th nov for seo plugin-->
    <meta name="google-site-verification" content="EoHiBQ3VqXUuo-kpSFaLnz2Z9Etb2tZrypls-rd9RuE" />

    <?php $swisschkr = multisite_globalizer(); ?>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if ( $swisschkr==1 ) { ?>
    <title>SwissCham >> <?php wp_title(''); ?></title>
    <?php } if ( $swisschkr==2 ) { ?>
    <title>Swisscham | Beijing >> <?php wp_title(''); ?></title>
    <?php } if ( $swisschkr==3 ) { ?>
    <title>Swisscham | Shanghai >> <?php wp_title(''); ?></title>
    <?php } if ( $swisschkr==4 ) { ?>
    <title>Swisscham | Guangzhou >> <?php wp_title(''); ?></title>
    <?php } if ( $swisschkr==5 ) { ?>
    <title>Swisscham | Hong Kong >> <?php wp_title(''); ?></title>
    <?php } ?>    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/app.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/swiss.css">
    <!-- Popup CSS Start Here-->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/chatpoup.css">
    <!-- Popup End CSS-->
    <!-- Favicon -->
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="57x57">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="72x72">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="114x114">
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png" sizes="144x144">
    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
    <div id="page">

        <section class="top_strip">
            <div class="row">
                <div class="large-7 medium-7 columns">
                    <a class="medBt show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <ul class="menu simple top_site_buttom">
                    <?php
                    
                    $current_site = get_current_site(); 
                   
                    if ( $swisschkr==1 ) { 
                        $domain=$current_site->domain;
                        ?>
                    <li class="active"><a href="<?php echo web_url(); ?>">Home</a></li>
                    <li><a href="<?php echo web_url(); ?>bei/">Beijing</a></li>
                    <li><a href="<?php echo web_url(); ?>sha/">Shanghai</a></li>
                    <li><a href="<?php echo web_url(); ?>gz/">Guangzhou</a></li>
                    <li><a href="<?php echo web_url(); ?>hk/">Hong Kong</a></li>
                    <li><a href="https://www.sccc.ch/geneva/" target="blank">Switzerland</a></li>
                    <?php }
                    if ( $swisschkr==2 ) { 
                        $domain=$current_site->domain;
                        ?>
                    <li><a href="<?php echo web_url(); ?>">Home</a></li>
                    <li class="active"><a href="<?php echo web_url(); ?>bei/">Beijing</a></li>
                    <li><a href="<?php echo web_url(); ?>sha/">Shanghai</a></li>
                    <li><a href="<?php echo web_url(); ?>gz/">Guangzhou</a></li>
                    <li><a href="<?php echo web_url(); ?>hk/">Hong Kong</a></li>
                    <li><a href="https://www.sccc.ch/geneva/" target="blank">Switzerland</a></li>
                    <?php }
                    if ( $swisschkr==3 ) { 
                        $domain=$current_site->domain;
                        ?>
                    <li><a href="<?php echo web_url(); ?>">Home</a></li>
                    <li><a href="<?php echo web_url(); ?>bei/">Beijing</a></li>
                    <li class="active"><a href="<?php echo web_url(); ?>sha/">Shanghai</a></li>
                    <li><a href="<?php echo web_url(); ?>gz/">Guangzhou</a></li>
                    <li><a href="<?php echo web_url(); ?>hk/">Hong Kong</a></li>
                    <li><a href="https://www.sccc.ch/geneva/" target="blank">Switzerland</a></li>
                    <?php }
                    if ( $swisschkr==4 ) {
                        $domain=$current_site->domain;
                        ?>
                    <li><a href="<?php echo web_url(); ?>">Home</a></li>
                    <li><a href="<?php echo web_url(); ?>bei/">Beijing</a></li>
                    <li><a href="<?php echo web_url(); ?>sha/">Shanghai</a></li>
                    <li class="active"><a href="<?php echo web_url(); ?>gz/">Guangzhou</a></li>
                    <li><a href="<?php echo web_url(); ?>hk/">Hong Kong</a></li>
                    <li><a href="https://www.sccc.ch/geneva/" target="blank">Switzerland</a></li>
                    <?php }
                    if ( $swisschkr==5 ) { 
                        $domain=$current_site->domain;
                        ?>
                    <li><a href="<?php echo web_url(); ?>">Home</a></li>
                    <li><a href="<?php echo web_url(); ?>bei/">Beijing</a></li>
                    <li><a href="<?php echo web_url(); ?>sha/">Shanghai</a></li>
                    <li><a href="<?php echo web_url(); ?>gz/">Guangzhou</a></li>
                    <li class="active"><a href="<?php echo web_url(); ?>hk/">Hong Kong</a></li>
                    <li><a href="https://www.sccc.ch/geneva/" target="blank">Switzerland</a></li>
                    <?php } ?>
                        
                    </ul>
                </div>
  <!-- Login Modal Start -->
        <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
            <h1>Please enter the details to login</h1>
            <?php if($_GET['loginerror']==1) {?>
            <div style="font-weight: bold; color: red; text-align: center;"> Wrong User ID And Password</div> 
            <?php } ?>
            <!-- <p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p> -->
            <form name="logInForm" id="logInForm" action="<?php echo web_url(); ?>swisschamlogin/login_process.php" method="POST">
                <div class="row">
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>User ID <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                        </label>
                    </div>
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>Password <span class="mandatory_tag">*</span>
                            <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from no_padding">
                        <p class="text-right"><button class="button regnext_btn" data-close aria-label="Close reveal" type="submit">Login</button></p>
                    </div>
                </div>
            </form>
            <button class="close-button" data-close aria-label="Close reveal" type="button">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <!-- Login Modal End -->

                
                <div class="large-5 medium-5 columns top_log_sec">
                    <ul class="menu simple top_log_buttom ">
                      <?php if ( $swisschkr==1 ) { ?>
                       <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                           foreach ($swisssocial as $sss) {
                            if ($sss=='linkedin') { ?>
                            <li class="top_social_link">
                             <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                            </li>
                            <?php } if ($sss=='wechat') { ?>
                            <li class="top_social_link">
                              <a class="top_weix" href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                              <div class="wechat_pop" style="display: none">
                                <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
                              </div>
                            </li>
                        <?php } } } ?>
                        <?php } if ( $swisschkr==2 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4);
                         if(!empty($swisssocial)){ 
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                         <li class="top_social_link">
                           <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                         </li>
                        <?php } if ($sss=='wechat') { ?>
                         <li class="top_social_link">
                           <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                           
                         </li>
                        <?php } } } ?>
                        <?php } if ( $swisschkr==3 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                           <li class="top_social_link">
                            <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                           </li>
                         <?php } if ($sss=='wechat') { ?>
                          <li class="top_social_link">
                           <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                           
                         </li>
                        <?php } } } ?>
                         <?php } if ( $swisschkr==4 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                            <li class="top_social_link">
                            <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                            </li>
                            <?php } if ($sss=='wechat') { ?>
                            <li class="top_social_link">
                            <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                             
                            </li>
                        <?php } } } ?>
                         <?php } if ( $swisschkr==5 ) { ?>
                         <?php $swisssocial = get_field('socialicons', 5);
                         if(!empty($swisssocial)){ 
                         foreach ($swisssocial as $sss) {
                             
                                if ($sss=='linkedin') { ?>
                               <li class="top_social_link">
                                 <a target="_blank" href="<?php echo get_field('linkedin_link', 5); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                               </li>
                               <?php }
                               
                                if ($sss=='facebook') { ?>
                               <li class="top_social_link">
                                 <a target="_blank" href="<?php echo get_field('facebook_link', 5); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook.png" /></a>
                               </li>
                               <?php }
                               
                               if ($sss=='wechat') { ?>
                               <li class="top_social_link">
                                 <a class="top_weix" href="javascript:void(0)"onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                                 
                               </li>
                          <?php } } } ?>
                          <?php } ?> 

                  <?php
                  if (! is_user_logged_in() ) {
                  ?>
                               <li><a href="#" data-toggle="loginModal" class="join_active" aria-controls="loginModal" aria-haspopup="true" tabindex="0">Login</a></li>
                  <?php } ?>
                  <?php if (! is_user_logged_in() ) { ?>
                        <li class="top_fix_btn"><a href="<?php echo web_url(); ?>swisschamlogin/online_application.php" class="join_active">Join Us</a></li>
                  <?php } else { ?>
                        <li class="top_fix_btn"><a class="join_active" href="<?php bloginfo('url')?>/swisschamlogin/logout.php"  aria-haspopup="true" tabindex="0">Logout</a></li>
                        <li class="top_fix_btn"><a class="join_active" href="<?php bloginfo('url')?>/swisschamlogin/membership.php">My Account</a></li>
                       
                  <?php } ?>
                        <!--<li class="language_selector top_fix_btn"><a href="#">EN</a> | <a href="#">中文</a></li>-->
                    </ul>
                </div>
            </div>
        </section>
        
                 <!-- Login Modal Start -->
        <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
            <h1>Please enter the details to login</h1>
            <?php if($_GET['loginerror']==1) {?>
            <div style="font-weight: bold; color: red; text-align: center;"> Wrong User ID And Password</div> 
            <?php } ?>
            <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
            <form name="logInForm" id="logInForm" action="<?php echo web_url(); ?>swisschamlogin/login_process.php" method="POST">
                <div class="row">
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>User ID <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                        </label>
                    </div>
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>Password <span class="mandatory_tag">*</span>
                            <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from no_padding">
                        <p class="text-right">
                        	<button class="button regnext_btn" data-close aria-label="Close reveal" type="submit">Login</button>
                        	</p>
                    </div>
                </div>
            </form>
            <button class="close-button" data-close aria-label="Close reveal" type="button">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <!-- Login Modal End -->
        
        <section class="small_top_strip">
            <div class="row show-for-small-only">
                <div class="large-12 columns text-right no_padding">
                    <ul class="menu simple small_login_field">
                        
                        <?php if ( $swisschkr==1 ) { ?>
                       <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                           foreach ($swisssocial as $sss) {
                            if ($sss=='linkedin') { ?>
                            <li class="top_social_link">
                             <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                            </li>
                            <?php } if ($sss=='wechat') { ?>
                            <li class="top_social_link">
                              <a class="top_weix" href="javascript:void(0)" onclick="$('.wechat_pop').fadeToggle(300)"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                              <div class="wechat_pop" style="display: none">
                                <img src="<?php  echo get_template_directory_uri();?>/images/swisscham-qr.jpg">
                              </div>
                            </li>
                        <?php } } } ?>
                        <?php } if ( $swisschkr==2 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4);
                         if(!empty($swisssocial)){ 
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                         <li class="top_social_link">
                           <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                         </li>
                        <?php } if ($sss=='wechat') { ?>
                         <li class="top_social_link">
                           <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                           
                         </li>
                        <?php } } } ?>
                        <?php } if ( $swisschkr==3 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                           <li class="top_social_link">
                            <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                           </li>
                         <?php } if ($sss=='wechat') { ?>
                          <li class="top_social_link">
                           <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                           
                         </li>
                        <?php } } } ?>
                         <?php } if ( $swisschkr==4 ) { ?>
                        <?php $swisssocial = get_field('socialicons', 4); 
                         if(!empty($swisssocial)){
                         foreach ($swisssocial as $sss) {
                                if ($sss=='linkedin') { ?>
                            <li class="top_social_link">
                            <a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                            </li>
                            <?php } if ($sss=='wechat') { ?>
                            <li class="top_social_link">
                            <a class="top_weix" href="javascript:void(0)" onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                             
                            </li>
                        <?php } } } ?>
                         <?php } if ( $swisschkr==5 ) { ?>
                         <?php $swisssocial = get_field('socialicons', 5);
                         if(!empty($swisssocial)){ 
                         foreach ($swisssocial as $sss) {
                             
                                if ($sss=='linkedin') { ?>
                               <li class="top_social_link">
                                 <a target="_blank" href="<?php echo get_field('linkedin_link', 5); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/linkdin.png" /></a>
                               </li>
                               <?php }
                               
                                if ($sss=='facebook') { ?>
                               <li class="top_social_link">
                                 <a target="_blank" href="<?php echo get_field('facebook_link', 5); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook.png" /></a>
                               </li>
                               <?php }
                               
                               if ($sss=='wechat') { ?>
                               <li class="top_social_link">
                                 <a class="top_weix" href="javascript:void(0)"onclick="nCol()"><img src="<?php echo get_template_directory_uri(); ?>/images/wechat.png" /></a>
                                 
                               </li>
                          <?php } } } ?>
                          <?php } ?> 

                        
                        
                        
                        
                        
                        <li><a href="#" data-toggle="loginModal" aria-controls="loginModal" aria-haspopup="true" tabindex="0">Login </a></li>
                        <li class="small_join_btn"><a href="<?php echo web_url(); ?>swisschamlogin/online_application.php" class="button">Join Us</a></li>
                       
                       
                        
                        
                        <!--
                            <li class="small_social_button">
    <a class=""><img src="images/wechat.png" /></a>
</li>
<li class="small_social_button">
    <a class=""><img src="images/linkdin.png" /></a>
</li>
-->
                    </ul>
                </div>
            </div>
        </section>
        
        <section class="top_fixed_strip">
            <header>
                <a class="menu_toogler " href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
                <div class="row">
                 
                    <div class="large-7 medium-6 columns">
                        <p class="main_logo">
                            <a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" /></a>
                        </p>
                    </div>

                  <div class="large-5 medium-6 columns no_padding">
                      <div class="large-6 medium-6 columns">
                            
                        <?php get_search_form(); ?>
                            
                    </div>
                    <div class="large-6 medium-6 columns">
                            <!--
                            <ul class="menu simple ad_sponsor_item">
                                <li class=""><img src="images/sponser1.jpg" /></li>
                                <li class=""><img src="images/sponser2.png" /></li>
                            </ul>
-->
                            <div class="large-12 medium-12 small-6 columns small_support_text show-for-small-only">
                                <h3 class="text-right"><?php _e( 'supported by', 'swisscham' ); ?></h3>
                            </div>
                            <div class="large-12 medium-12 small-6 columns no_padding">
                                <div class="adSponsorItem">
                                <?php global $switched;
                                        switch_to_blog(1); ?>
                                <?php 
                                if($swisschkr==1)
                                {
                                
                                $spntarg = array(
                                'posts_per_page'   => -1,
                                'orderby'          => 'date',
                                'order'            => 'DESC',
                                'post_mime_type'   => '',
                                'post_parent'      => '',
                                'post_type'        => 'sponsor',
                                'meta_key'          => 'image_status',
                                'meta_value'        => 'active',    
                                'post_status'      => 'publish',
                                'suppress_filters' => 0,
                                    
                                'tax_query' => array(
                      array(
                         'taxonomy' => 'headerbranchname',
                         'field' => 'slug',
                         'terms' => 'home'
                      )
                   )    
                            );
                                }
                     
                    if($swisschkr==2)
                                {
                                
                                $spntarg = array(
                                'posts_per_page'   => -1,
                                'orderby'          => 'date',
                                'order'            => 'DESC',
                                'post_mime_type'   => '',
                                'post_parent'      => '',
                                'post_type'        => 'sponsor',
                                'meta_key'          => 'image_status',
                                'meta_value'        => 'active',    
                                'post_status'      => 'publish',
                                'suppress_filters' => 0,
                                    
                                'tax_query' => array(
                      array(
                         'taxonomy' => 'headerbranchname',
                         'field' => 'slug',
                         'terms' => 'beijing'
                      )
                   )    
                            );
                                }
                                
                if($swisschkr==3)
                                {
                                
                                $spntarg = array(
                                'posts_per_page'   => -1,
                                'orderby'          => 'date',
                                'order'            => 'DESC',
                                'post_mime_type'   => '',
                                'post_parent'      => '',
                                'post_type'        => 'sponsor',
                                'meta_key'          => 'image_status',
                                'meta_value'        => 'active',    
                                'post_status'      => 'publish',
                                'suppress_filters' => 0,
                                    
                                'tax_query' => array(
                      array(
                         'taxonomy' => 'headerbranchname',
                         'field' => 'slug',
                         'terms' => 'shanghai'
                      )
                   )    
                            );
                                }
                                
                 if($swisschkr==4)
                                {
                                
                                $spntarg = array(
                                'posts_per_page'   => -1,
                                'orderby'          => 'date',
                                'order'            => 'DESC',
                                'post_mime_type'   => '',
                                'post_parent'      => '',
                                'post_type'        => 'sponsor',
                                'meta_key'          => 'image_status',
                                'meta_value'        => 'active',    
                                'post_status'      => 'publish',
                                'suppress_filters' => 0,
                                    
                                'tax_query' => array(
                      array(
                         'taxonomy' => 'headerbranchname',
                         'field' => 'slug',
                         'terms' => 'guangzhou'
                      )
                   )    
                            );
                                }
                                
                if($swisschkr==5)
                                {
                                
                                $spntarg = array(
                                'posts_per_page'   => -1,
                                'orderby'          => 'date',
                                'order'            => 'DESC',
                                'post_mime_type'   => '',
                                'post_parent'      => '',
                                'post_type'        => 'sponsor',
                                'meta_key'          => 'image_status',
                                'meta_value'        => 'active',    
                                'post_status'      => 'publish',
                                'suppress_filters' => 0,
                                    
                                'tax_query' => array(
                      array(
                         'taxonomy' => 'headerbranchname',
                         'field' => 'slug',
                         'terms' => 'hong-kong'
                      )
                   )    
                            );
                                }                
           
            $spnt_array = get_posts( $spntarg );
            

            foreach ($spnt_array as $spnt_arr) {
            

            $spntimg = wp_get_attachment_image_src( get_post_thumbnail_id( $spnt_arr->ID ), 'single-post-thumbnail' );  ?>

                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="<?php echo get_post_meta($spnt_arr->ID, 'url', true); ?>" target="_blank"><img src="<?php echo $spntimg[0]; ?>" /></a>
                                        </p>
                                    </div>
            <?php } ?>
            <?php restore_current_blog(); ?>
<!-- 
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.vischer.com/en/home/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/slider_sponsor2.jpg" /></a>
                                        </p>
                                    </div>
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.swiss.com/web/EN/Pages/index.aspx?WT.mc_id=SwissCham" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/slider_sponsor3.jpg" /></a>
                                        </p>
                                    </div> -->
                                </div>
                            </div>
                        </div>

                </div>
                                            </div>
                </div>
            </header>

            <section class="relative_sec">
                <div class="row">
                    <div class="large-12 columns main_navbar">
                        <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
                            <button class="menu-icon" type="button" data-toggle></button>
                            <div class="title-bar-title"><?php _e( 'Menu', 'swisscham' ); ?></div>
                        </div>

                        <div class="top-bar main_nav" id="main-menu">
                            <div class="top-bar-left">
                                <!--
                        <ul class="dropdown menu" data-dropdown-menu>
    <li class="menu-text">Site Title</li>
</ul>
-->
                            </div>





                            <div class="top-bar-left main_nav_list">
                        <?php wp_nav_menu( array( 'menu' =>'Main Menu','container'=> 'li','container_class' => '','container_id' => '','items_wrap' =>'<ul class="menu main_nav_list_item dropdown" data-responsive-menu="drilldown medium-dropdown">%3$s</ul>','walker' => new wp_pmcustom_navwalker(array( 'in_top_bar' => true, 'item_type' => 'li', 'menu_type' => 'top-menu' )) ) ); ?>
                        </div>





                        </div>

                    </div>
                </div>
            </section>
        </section>
