<?php 
/*
template name: Upcoming Shanghai Events General

*/

get_header();
    $swisschkr = multisite_globalizer(); ?>

    <div class="abc"></div>
    <section class="inner_banner bg-beijing hide-for-small-only">
       
        <?php echo get_post_breadcrumbs(); ?> 
    </section>
    <section>
        <div class="row" data-equalizer data-equalize-on="medium">
            <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <div class="large-12 columns dowedo_top">
                <div class="table-scroll">
                    <table class="upcom_list">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="" class="">Date</th>
                                    <th width="" class="">Time</th>
                                    <th width="" class="">Place</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                               
                                $args=array(
                                    'blog'=>'1',
                                    'bookings'=>'0',
                                    'category'=>'52',
                                    'scope'=>'future',
                                    'format'=>'<tr><td><a href="/sha/event-details/?id=#_EVENTPOSTID">#_EVENTNAME </a></td>'. 
                                              '<td><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td>'.
                                              '<td><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td>'.
                                              '<td><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td></tr>',
                                    
                                );
                                 em_events($args);
                                ?>
                                
                                
                          
                                
                              </tbody>
                        </table>
                    </div>
                </div>

            </div>

            <?php get_sidebar(); ?>

        </div>
    </section>
    <?php 
          get_footer('event');
         ?>
