<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package SwissCham
 */

get_header(); ?>

<style type="text/css">
	.darchve h2 {
  color: inherit;
  font-family: "robotomedium",Helvetica,Roboto,Arial,sans-serif;
  font-style: normal;
  font-size: 19px !important;
  font-weight: normal;
  line-height: 1.4;
  margin-bottom: 0.5rem;
  margin-top: 0;
  text-rendering: optimizelegibility;
	}
	.darchve h3 {
  color: #aa0008;
  font-size: 18px;
	}
	.swimg {
		margin-bottom: 10px;
	}
</style>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                        	<span class="show-for-sr">Current: </span> MBP - Shanghai
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top darchve">
                    <?php if( have_posts() ); ?>
                    <h1 class="common_heading"><?php single_cat_title(); ?></h1>
                    <br>
                         <?php
                               while( have_posts() ) : the_post(); 
                               $arcnewsimg = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' ); ?>
                    <img class="swimg" style="height:100px" src="<?php echo $arcnewsimg[0]; ?>">
                        <h3><?php the_title();?></h3>
                       <?php the_content(); ?>
                        <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>
                   <?php endwhile; ?>
                    </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

	<?php get_footer(); ?>