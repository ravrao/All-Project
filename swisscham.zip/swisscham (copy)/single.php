<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package SwissCham
 */

get_header();
    $swisschkr = multisite_globalizer(); ?>
    
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                        <?php if(is_singular( 'news' )) { ?>
                        <li><a href="<?php echo home_url(); ?>/news/">News</a></li>
                        <!-- <li>
                                <span class="show-for-sr">Current: </span>News
                        </li> -->
                        <?php } else { ?>
                        <li>
                           <?php if( have_posts() ); ?>
                                 <?php 
                                       while( have_posts() ) : the_post(); ?>
                                          <span class="show-for-sr">Current: </span><?php the_title(); ?>
                                  <?php endwhile; ?>        
                        </li>
                        <?php }
                         ?>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                    <?php if( have_posts() ); ?>

                         <?php 
                               while( have_posts() ) : the_post(); ?>
                        <h1 class="common_heading"><?php the_title();?></h1>
                       <?php the_content(); ?>
                   <?php endwhile; ?>
                    </div>

                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
          get_footer();
         } if ( $swisschkr==2 ) {
          get_footer('bei');
         } if ( $swisschkr==3 ) {
          get_footer('sha');
         } if ( $swisschkr==4 ) {
          get_footer('gz');
         } if ( $swisschkr==5 ) {
          get_footer('hk');
         } ?>