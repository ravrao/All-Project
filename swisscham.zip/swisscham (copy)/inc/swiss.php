<?php function swissmd(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text = $_POST['slug'];// Search keyword here

 $alphaarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_mime_type'   => '',
                'post_parent'      => '',
                'post_type'        => 'membersdirectory',
                'post_status'      => 'publish',
                'suppress_filters' => 0 
            );

            $alpha_array = get_posts( $alphaarg );


//Geting product
/*$arahile = query_posts( array(
'post_type' => array('membersdirectory'),
's' => $text,
'posts_per_page' => -1,
'post_status'      => 'publish',
));*/ ?>

<div class="large-12 columns dowedo_top">
                        <form>
                            <div class="row">
                                <div class="medium-2 columns filter_drop">
                                    <select>
                                        <option>Filter by</option>
                            <?php
                            $mdpretrm = get_terms( 'memberin', array(
                                'hide_empty' => false,
                            ) ); foreach ($mdpretrm as $mdpretr) { ?>
                                    <option value="<?php echo $mdpretr->slug; ?>"><?php echo $mdpretr->name; ?></option>
                            <?php } ?>
                                    </select>
                                </div>
                                <div class="medium-10 columns filter_drop">
                                <a href="#" style="text-align:right;display:block" id="backtomd">Back to Directory</a>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="large-12 columns">
                        <hr class="inner_separetor" />
                    </div>
                    <div class="large-12 columns">
<?php $lenaf = count($alpha_array); foreach ($alpha_array as $alpha_arr) {
                    $alphchart = $alpha_arr->post_title;
        $alphaimg = wp_get_attachment_image_src( get_post_thumbnail_id( $alpha_arr->ID ), 'single-post-thumbnail' ); 
                    if ($text==$alphchart[0]) {
                ?>
                        <div class="large-12 columns directory_sort">
                            <div class="large-3 columns small_padding">
                                <p class="text-center directory_logo"><img src="<?php echo $alphaimg[0]; ?>" /></p>
                            </div>
                            <div class="large-9 columns directory_item_details small_padding">
                                <h2><?php echo $alphchart; ?></h2>
                                <h4>公司名稱</h4>
                                <h3 class="common_subheading">Industry Name</h3>
                                <h3 class="">公司名稱</h3>
                                
                                <h4>Member in: 
                                <?php $alphami = wp_get_post_terms( $alpha_arr->ID, 'memberin' );
                                                $alp = 0;
                                                $lena = count($alphami);

                                        foreach ($alphami as $alpham) {
                                            
                                        if( !(is_object_in_term( $alpham->ID, 'memberin', 'beijing' )||is_object_in_term( $alpham->ID, 'memberin', 'guangzhou')||is_object_in_term( $alpham->ID, 'memberin', 'hong-kong')||is_object_in_term( $alpham->ID, 'memberin', 'shanghai')) ) { ?>
                                            <span><?php echo $alpham->name; if (!($alp == $lena - 1)) { if (!($lena==1)) { echo ","; }  } else { } ?></span>
                                            <?php } elseif ($alp==0) { ?>
                                            <span>National(China)</span>
                                            <?php       }
                                                    $alp++;
                                                     } // End mini foreach
                                                     echo "</h4>";
                                     ?>
                                
                                <!--                                <h5 class="light_text">Published by SwissCham China 2016 |  01 August, 2016  |  n category of SwissCham Publications. English, Chinese </h5>-->
                            </div>
                            <div class="large-12 columns dowedo_top small_padding">
                                <p class="wordLimit">"Market Mover" – As China’s economy changes from manufacturing for export to one more focused on domestic consumption, its logistics sector is being profoundly impacted. Patrick Scheibli, Managing Director of Fracht (Shanghai), talks with The Bridge on how the Swiss.</p>
                                <p class="wordLimit">公司名稱公司名稱公司名稱公司名稱公司名稱公司名稱 公司名稱公司名稱 </p>
                            </div>
                        </div>

                        <div class="large-12 columns no_padding">
                            <hr class="common_devider" />
                        </div>
                        <?php } //end big if
                                    if ($text=='#') {
                                        if (is_numeric ($alphchart[0])) { ?>
                        <div class="large-12 columns directory_sort">
                            <div class="large-3 columns small_padding">
                                <p class="text-center directory_logo"><img src="<?php echo $alphaimg[0]; ?>" /></p>
                            </div>
                            <div class="large-9 columns directory_item_details small_padding">
                                <h2><?php echo $alphchart; ?></h2>
                                <h4>公司名稱</h4>
                                <h3 class="common_subheading">Industry Name</h3>
                                <h3 class="">公司名稱</h3>
                                
                                <h4>Member in: 
                                <?php $alphami = wp_get_post_terms( $alpha_arr->ID, 'memberin' );
                                                $alp = 0;
                                                $lena = count($alphami);

                                        foreach ($alphami as $alpham) {
                                            
                                        if( !(is_object_in_term( $alpham->ID, 'memberin', 'beijing' )||is_object_in_term( $alpham->ID, 'memberin', 'guangzhou')||is_object_in_term( $alpham->ID, 'memberin', 'hong-kong')||is_object_in_term( $alpham->ID, 'memberin', 'shanghai')) ) { ?>
                                            <span><?php echo $alpham->name; if (!($alp == $lena - 1)) { if (!($lena==1)) { echo ","; }  } else { } ?></span>
                                            <?php } elseif ($alp==0) { ?>
                                            <span>National(China)</span>
                                            <?php       }
                                                    $alp++;
                                                     } // End mini foreach
                                                     echo "</h4>";
                                     ?>
                                
                                <!--                                <h5 class="light_text">Published by SwissCham China 2016 |  01 August, 2016  |  n category of SwissCham Publications. English, Chinese </h5>-->
                            </div>
                            <div class="large-12 columns dowedo_top small_padding">
                                <p class="wordLimit">"Market Mover" – As China’s economy changes from manufacturing for export to one more focused on domestic consumption, its logistics sector is being profoundly impacted. Patrick Scheibli, Managing Director of Fracht (Shanghai), talks with The Bridge on how the Swiss.</p>
                                <p class="wordLimit">公司名稱公司名稱公司名稱公司名稱公司名稱公司名稱 公司名稱公司名稱 </p>
                            </div>
                        </div>

                        <div class="large-12 columns no_padding">
                            <hr class="common_devider" />
                        </div>
                            <?php  }
                                    } if ($lenaf==0) { ?>
                        <div class="large-12 columns directory_sort">
                            <div class="large-9 columns directory_item_details small_padding">
                                <h2>No members found starting with "<?php echo $text; ?>" Alphabet. Please try again later..</h2>
                            </div>

                        </div>
                                   <?php }        
                                        } //end foreach ?>
                    </div>

<?php

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissmd','swissmd' );
add_action('wp_ajax_swissmd','swissmd' );

// search by keyword

function swissmdkeyword(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text2 = $_POST['slug2'];// Search keyword here

$alpha_array2 = query_posts( array(
'post_type' => array('membersdirectory'),
's' => $text2,
'posts_per_page' => -1,
'post_status'      => 'publish',
)); 

$lenadeloy = count($alpha_array2);
if (!($lenadeloy==0)) { ?>

<div class="large-12 columns dowedo_top">
                        <form>
                            <div class="row">
                                <div class="medium-2 columns filter_drop">
                                    <select>
                                        <option>Filter by</option>
                            <?php
                            $mdpretrm2 = get_terms( 'memberin', array(
                                'hide_empty' => false,
                            ) ); foreach ($mdpretrm2 as $mdpretr2) { ?>
                                    <option value="<?php echo $mdpretr->slug; ?>"><?php echo $mdpretr2->name; ?></option>
                            <?php } ?>
                                    </select>
                                </div>
                                <div class="medium-10 columns filter_drop">
                                <a href="#" style="text-align:right;display:block" id="backtomd">Back to Directory</a>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="large-12 columns">
                        <hr class="inner_separetor" />
                    </div>
                    <div class="large-12 columns">
<?php   foreach ($alpha_array2 as $alpha_arr2) {
                    $alphchart2 = $alpha_arr2->post_title;
        $alphaimg2 = wp_get_attachment_image_src( get_post_thumbnail_id( $alpha_arr2->ID ), 'single-post-thumbnail' ); 
                ?>
                        <div class="large-12 columns directory_sort">
                            <div class="large-3 columns small_padding">
                                <p class="text-center directory_logo"><img src="<?php echo $alphaimg2[0]; ?>" /></p>
                            </div>
                            <div class="large-9 columns directory_item_details small_padding">
                                <h2><?php echo $alphchart2; ?></h2>
                                <h4>公司名稱</h4>
                                <h3 class="common_subheading">Industry Name</h3>
                                <h3 class="">公司名稱</h3>
                                
                                <h4>Member in: 
                                <?php $alphami2 = wp_get_post_terms( $alpha_arr2->ID, 'memberin' );
                                                $alp2 = 0;
                                                $lena2 = count($alphami2);

                                        foreach ($alphami2 as $alpham2) {
                                            
                                        if( !(is_object_in_term( $alpham2->ID, 'memberin', 'beijing' )||is_object_in_term( $alpham2->ID, 'memberin', 'guangzhou')||is_object_in_term( $alpham2->ID, 'memberin', 'hong-kong')||is_object_in_term( $alpham2->ID, 'memberin', 'shanghai')) ) { ?>
                                            <span><?php echo $alpham2->name; if (!($alp2 == $lena2 - 1)) { if (!($lena2==1)) { echo ","; }  } else { } ?></span>
                                            <?php } elseif ($alp2==0) { ?>
                                            <span>National(China)</span>
                                            <?php       }
                                                    $alp2++;
                                                     } // End mini foreach
                                                     echo "</h4>";
                                     ?>
                                
                                <!--                                <h5 class="light_text">Published by SwissCham China 2016 |  01 August, 2016  |  n category of SwissCham Publications. English, Chinese </h5>-->
                            </div>
                            <div class="large-12 columns dowedo_top small_padding">
                                <p class="wordLimit">"Market Mover" – As China’s economy changes from manufacturing for export to one more focused on domestic consumption, its logistics sector is being profoundly impacted. Patrick Scheibli, Managing Director of Fracht (Shanghai), talks with The Bridge on how the Swiss.</p>
                                <p class="wordLimit">公司名稱公司名稱公司名稱公司名稱公司名稱公司名稱 公司名稱公司名稱 </p>
                            </div>
                        </div>

                        <div class="large-12 columns no_padding">
                            <hr class="common_devider" />
                        </div>
                       <?php } //end foreach 
                        } else { ?>
<div class="large-12 columns dowedo_top">
                        <form>
                            <div class="row">
                                <div class="medium-2 columns filter_drop">
                                    <select>
                                        <option>Filter by</option>
                            <?php
                            $mdpretrm2 = get_terms( 'memberin', array(
                                'hide_empty' => false,
                            ) ); foreach ($mdpretrm2 as $mdpretr2) { ?>
                                    <option value="<?php echo $mdpretr->slug; ?>"><?php echo $mdpretr2->name; ?></option>
                            <?php } ?>
                                    </select>
                                </div>
                                <div class="medium-10 columns filter_drop">
                                <a href="#" style="text-align:right;display:block" id="backtomd">Back to Directory</a>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="large-12 columns">
                        <hr class="inner_separetor" />
                    </div>
                    <div class="large-12 columns">

                        <div class="large-12 columns directory_sort">

                            <div class="large-9 columns directory_item_details small_padding">
                                <h2>No result found. Try with another keyword..</h2>
                            </div>

                        </div>

                        </div>
                        <?php } ?>
                    </div>

<?php

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissmdkeyword','swissmdkeyword' );
add_action('wp_ajax_swissmdkeyword','swissmdkeyword' );

//members by chapters

function swissmdbychapter(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text2 = $_POST['slug3'];// Search keyword here

$alpha_array3 = query_posts( array(
'post_type' => array('membersdirectory'),
's' => $text3,
'posts_per_page' => -1,
'post_status'      => 'publish',
)); 

$lenadeloy3 = count($alpha_array3);
if (!($lenadeloy3==0)) { ?>

<div class="large-12 columns dowedo_top">
                        <form>
                            <div class="row">
                                <div class="medium-2 columns filter_drop">
                                    <select>
                                        <option>Filter by</option>
                            <?php
                            $mdpretrm3 = get_terms( 'memberin', array(
                                'hide_empty' => false,
                            ) ); foreach ($mdpretrm3 as $mdpretr3) { ?>
                                    <option value="<?php echo $mdpretr3->slug; ?>"><?php echo $mdpretr3->name; ?></option>
                            <?php } ?>
                                    </select>
                                </div>
                                <div class="medium-10 columns filter_drop">
                                <a href="#" style="text-align:right;display:block" id="backtomd">Back to Directory</a>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="large-12 columns">
                        <hr class="inner_separetor" />
                    </div>
                    <div class="large-12 columns">
<?php   foreach ($alpha_array3 as $alpha_arr3) {
                    $alphchart3 = $alpha_arr3->post_title;
        $alphaimg3 = wp_get_attachment_image_src( get_post_thumbnail_id( $alpha_arr3->ID ), 'single-post-thumbnail' ); 
                ?>
                        <div class="large-12 columns directory_sort">
                            <div class="large-3 columns small_padding">
                                <p class="text-center directory_logo"><img src="<?php echo $alphaimg3[0]; ?>" /></p>
                            </div>
                            <div class="large-9 columns directory_item_details small_padding">
                                <h2><?php echo $alphchart3; ?></h2>
                                <h4>公司名稱</h4>
                                <h3 class="common_subheading">Industry Name</h3>
                                <h3 class="">公司名稱</h3>
                                
                                <h4>Member in: 
                                <?php $alphami3 = wp_get_post_terms( $alpha_arr3->ID, 'memberin' );
                                                $alp3 = 0;
                                                $lena3 = count($alphami3);

                                        foreach ($alphami3 as $alpham3) {
                                            
                                        if( !(is_object_in_term( $alpham3->ID, 'memberin', 'beijing' )||is_object_in_term( $alpham3->ID, 'memberin', 'guangzhou')||is_object_in_term( $alpham3->ID, 'memberin', 'hong-kong')||is_object_in_term( $alpham3->ID, 'memberin', 'shanghai')) ) { ?>
                                            <span><?php echo $alpham3->name; if (!($alp3 == $lena3 - 1)) { if (!($lena3==1)) { echo ","; }  } else { } ?></span>
                                            <?php } elseif ($alp3==0) { ?>
                                            <span>National(China)</span>
                                            <?php       }
                                                    $alp3++;
                                                     } // End mini foreach
                                                     echo "</h4>";
                                     ?>
                                
                                <!--                                <h5 class="light_text">Published by SwissCham China 2016 |  01 August, 2016  |  n category of SwissCham Publications. English, Chinese </h5>-->
                            </div>
                            <div class="large-12 columns dowedo_top small_padding">
                                <p class="wordLimit">"Market Mover" – As China’s economy changes from manufacturing for export to one more focused on domestic consumption, its logistics sector is being profoundly impacted. Patrick Scheibli, Managing Director of Fracht (Shanghai), talks with The Bridge on how the Swiss.</p>
                                <p class="wordLimit">公司名稱公司名稱公司名稱公司名稱公司名稱公司名稱 公司名稱公司名稱 </p>
                            </div>
                        </div>

                        <div class="large-12 columns no_padding">
                            <hr class="common_devider" />
                        </div>
                       <?php } //end foreach 
                        } else { ?>
<div class="large-12 columns dowedo_top">
                        <form>
                            <div class="row">
                                <div class="medium-2 columns filter_drop">
                                    <select>
                                        <option>Filter by</option>
                            <?php
                            $mdpretrm3 = get_terms( 'memberin', array(
                                'hide_empty' => false,
                            ) ); foreach ($mdpretrm3 as $mdpretr3) { ?>
                                    <option value="<?php echo $mdpretr->slug; ?>"><?php echo $mdpretr3->name; ?></option>
                            <?php } ?>
                                    </select>
                                </div>
                                <div class="medium-10 columns filter_drop">
                                <a href="#" style="text-align:right;display:block" id="backtomd">Back to Directory</a>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="large-12 columns">
                        <hr class="inner_separetor" />
                    </div>
                    <div class="large-12 columns">

                        <div class="large-12 columns directory_sort">

                            <div class="large-9 columns directory_item_details small_padding">
                                <h2>No result found. Try with another keyword..</h2>
                            </div>

                        </div>

                        </div>
                        <?php } ?>
                    </div>

<?php

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissmdbychapter','swissmdbychapter' );
add_action('wp_ajax_swissmdbychapter','swissmdbychapter' );

//news page by cat

function swissnews(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text5 = $_POST['slug5'];// Search keyword here

 $swfilcatarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'news',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'news_cat',
                     'field' => 'slug',
                     'terms' => $text5
                  )
               )
            );

            $swissfilcat = get_posts( $swfilcatarg );

        foreach ($swissfilcat as $swissf1cat) {

            $newsimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swissf1cat->ID ), 'single-post-thumbnail' );
                        ?>

                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">
                                <p class="text-center"><img src="<?php echo $newsimg[0]; ?>" /></p>
                            </div>
                            <div class="large-10 columns dowedo_top">
                                <a target="_blank" href="<?php echo get_field('news_title_link', $swissf1cat->ID); ?>">
                                <h3 class="common_subheading"><?php echo $swissf1cat->post_title; ?></h3></a>
                                <h5 class="light_text">Published by <?php echo get_field('published_by', $swissf1cat->ID); ?> |  <?php echo get_the_date('F j, Y', $swissf1cat->ID); ?>  <!--|  n category of SwissCham Publications. English, Chinese?--> </h5>
                            </div>
                        </div>
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">

                            </div>
                            <div class="large-10 columns dowedo_top">
                            <?php $pagenw = $swissf1cat->post_content;

                            $pagenw = apply_filters('the_content', $pagenw);
                            $pagenw = str_replace(']]>', ']]&gt;', $pagenw);

                                echo $pagenw; ?>

                                <p><a href="<?php echo get_the_permalink( $swissf1cat->ID ); ?>">Read more</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>
    <?php } 

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissnews','swissnews' );
add_action('wp_ajax_swissnews','swissnews' );

//news page by year

function swissnewsy(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text6 = $_POST['slug6'];// Search keyword here

 $swfilcatargy = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'news',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'date_query' => array(
                        array(
                            'year'  => $text6
                        )
                    )
            );

            $swissfilcaty = get_posts( $swfilcatargy );

        foreach ($swissfilcaty as $swissf1caty) {

            $newsimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swissf1caty->ID ), 'single-post-thumbnail' );
                        ?>

                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">
                                <p class="text-center"><img src="<?php echo $newsimg[0]; ?>" /></p>
                            </div>
                            <div class="large-10 columns dowedo_top">
                                <a target="_blank" href="<?php echo get_field('news_title_link', $swissf1caty->ID); ?>">
                                <h3 class="common_subheading"><?php echo $swissf1caty->post_title; ?></h3></a>
                                <h5 class="light_text">Published by <?php echo get_field('published_by', $swissf1caty->ID); ?> |  <?php echo get_the_date('F j, Y', $swissf1caty->ID); ?>  <!--|  n category of SwissCham Publications. English, Chinese?--> </h5>
                            </div>
                        </div>
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">

                            </div>
                            <div class="large-10 columns dowedo_top">
                            <?php $pagenw = $swissf1caty->post_content;

                            $pagenw = apply_filters('the_content', $pagenw);
                            $pagenw = str_replace(']]>', ']]&gt;', $pagenw);

                                echo $pagenw; ?>

                                <p><a href="<?php echo get_the_permalink( $swissf1caty->ID ); ?>">Read more</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>
    <?php } 

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissnewsy','swissnewsy' );
add_action('wp_ajax_swissnewsy','swissnewsy' );

//news page by keyword

function swissnewsk(){

header('Content-type:text/html'); 

global $wpdb;
global $post;

$text9 = $_POST['slug9'];// Search keyword here

 $swfilcatargk = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                's'                => $text9,
                'post_type'        => 'news',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $swissfilcatk = get_posts( $swfilcatargk );

        foreach ($swissfilcatk as $swissf1catk) {

            $newsimg = wp_get_attachment_image_src( get_post_thumbnail_id( $swissf1catk->ID ), 'single-post-thumbnail' );
                        ?>

                    <div class="large-12 columns no_padding">
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">
                                <p class="text-center"><img src="<?php echo $newsimg[0]; ?>" /></p>
                            </div>
                            <div class="large-10 columns dowedo_top">
                                <a target="_blank" href="<?php echo get_field('news_title_link', $swissf1catk->ID); ?>">
                                <h3 class="common_subheading"><?php echo $swissf1catk->post_title; ?></h3></a>
                                <h5 class="light_text">Published by <?php echo get_field('published_by', $swissf1catk->ID); ?> |  <?php echo get_the_date('F j, Y', $swissf1catk->ID); ?>  <!--|  n category of SwissCham Publications. English, Chinese?--> </h5>
                            </div>
                        </div>
                        <div class="large-12 columns no_padding">
                            <div class="large-2 columns">

                            </div>
                            <div class="large-10 columns dowedo_top">
                            <?php $pagenw = $swissf1catk->post_content;

                            $pagenw = apply_filters('the_content', $pagenw);
                            $pagenw = str_replace(']]>', ']]&gt;', $pagenw);

                                echo $pagenw; ?>

                                <p><a href="<?php echo get_the_permalink( $swissf1catk->ID ); ?>">Read more</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>
    <?php } 

//wp_reset_query();

die();
}
add_action('wp_ajax_nopriv_swissnewsk','swissnewsk' );
add_action('wp_ajax_swissnewsk','swissnewsk' );