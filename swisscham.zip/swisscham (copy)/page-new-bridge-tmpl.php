<?php
/*
    Template Name: New Magazine
*/

    get_header();
    	$swisschkr = multisite_globalizer();
     ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">

       <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 448 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    
                    
                </div>
        <?php } if ( $swisschkr==2 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 102 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 102 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 102 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 102 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 102 ); ?>"><?php echo get_field( "national_articles_of_association", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 102 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 102 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 102 ); ?>"><?php echo get_field( "beijing_bylaws", 102 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 102 ); ?>"><?php echo get_field( "shanghai_bylaws", 102 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 102 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 102 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 102 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 102 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 102 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 75 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 75 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 75 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 75 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 75 ); ?>"><?php echo get_field( "national_articles_of_association", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 75 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 75 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 75 ); ?>"><?php echo get_field( "beijing_bylaws", 75 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 75 ); ?>"><?php echo get_field( "shanghai_bylaws", 75 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 75 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 75 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 75 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 75 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 75 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==4 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 61 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 61 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 61 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 61 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 61 ); ?>"><?php echo get_field( "national_articles_of_association", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 61 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 61 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 61 ); ?>"><?php echo get_field( "beijing_bylaws", 61 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 61 ); ?>"><?php echo get_field( "shanghai_bylaws", 61 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 61 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 61 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 61 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 61 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 61 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } if ( $swisschkr==5 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                     <?php $rule = get_post( 68 ); ?>
                        <h1 class="common_heading"><?php echo $rule->post_title; ?></h1>

                    <?php $pagerule = $rule->post_content;

                            $pagerule = apply_filters('the_content', $pagerule);
                            $pagerule = str_replace(']]>', ']]&gt;', $pagerule);
                            echo $pagerule;  
                     ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <h3 class="common_subheading">Download Rules</h3>
                        <ul class="fa-ul custom_download_list">
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[en]_link", 68 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[en]", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "foreign_chambers_regulations_[cn]_link", 68 ); ?>"><?php echo get_field( "foreign_chambers_regulations_[cn]", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_articles_of_association_(version_14.04.2006)_link", 68 ); ?>"><?php echo get_field( "national_articles_of_association_(version_14.04.2006)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "_national_articles_of_association_(version_27.03.2015)_link", 68 ); ?>"><?php echo get_field( "national_articles_of_association", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_12.04.2006)_link", 68 ); ?>"><?php echo get_field( "national_bylaws_(version_12.04.2006)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "national_bylaws_(version_27.03.2015)_link", 68 ); ?>"><?php echo get_field( "national_bylaws_(version_27.03.2015)", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "beijing_bylaws_link", 68 ); ?>"><?php echo get_field( "beijing_bylaws", 68 ); ?></a></li>
                            <li><a href="<?php echo get_field( "shanghai_bylaws_link", 68 ); ?>"><?php echo get_field( "shanghai_bylaws", 68 ); ?></a></li>
                        </ul>
                        <h3 class="common_subheading">National and Regional Annual General Assembly</h3>
                    <?php echo get_field( "national_and_regional_annual_general_assembly", 68 ); ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <ul class="fa-ul custom_click_list">
                         <li><a href="<?php echo get_field( "click_here_to_access_the_raga/naga_archives_link", 68 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 68 ); ?></a></li>
                         <li><a href="<?php echo get_field( "click_here_to_access_swisscham_beijing_raga_page_link", 68 ); ?>"><?php echo get_field( "click_here_to_access_the_raga/naga_archives", 68 ); ?></a></li>
                        </ul>
                    </div>
                </div>
        <?php } ?>



                <?php get_sidebar(); ?>

               
            </div>
        </section>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>
