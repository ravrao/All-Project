<?php
/*
    Template Name: Our Services
*/
    get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>

                        <li>
<span class="show-for-sr">Current: </span> Services
</li>
                        <li>
                            <span class="show-for-sr">Current: </span> Our Services
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                
                        <?php if ( $swisschkr==1 ) { ?>

                        <?php $serviceforlife = get_post( 40 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $serviceforlife->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <?php echo get_field( "content", 40 ); ?>
                    
                    </div>

                        <?php } if ( $swisschkr==2 ) { ?>

                        <?php $serviceforlife = get_post( 115 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $serviceforlife->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <?php echo get_field( "content", 115 ); ?>
                    
                    </div>

                        <?php } if ( $swisschkr==3 ) { ?>

                        <?php $serviceforlife = get_post( 84 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $serviceforlife->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <?php echo get_field( "content", 84 ); ?>
                    
                    </div>

                        <?php } if ( $swisschkr==4 ) { ?>

                        <?php $serviceforlife = get_post( 70 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $serviceforlife->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <?php echo get_field( "content", 70 ); ?>
                    
                    </div>

                        <?php } if ( $swisschkr==5 ) { ?>

                        <?php $serviceforlife = get_post( 76 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $serviceforlife->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">

                        <?php echo get_field( "content", 76 ); ?>
                    
                    </div>

                        <?php } ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>


                </div>

        <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) { ?>
                <?php get_footer(); ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php get_footer('bei'); ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php get_footer('sha'); ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php get_footer('gz'); ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php get_footer('hk'); ?>
        <?php } ?>