<?php
/*
	Template name: MBP Sha
*/
	get_header();
	$swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
<?php } ?>
                         <li>
                            <span class="show-for-sr">Current: </span> Membership
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> MBP - Shanghai
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
        <?php if ( $swisschkr==1 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_693 = get_post( 693 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_693->post_title; ?></h1>
                        <?php $pagebgz693 = $post_693->post_content;

                            $pagebgz693 = apply_filters('the_content', $pagebgz693);
                            $pagebgz693 = str_replace(']]>', ']]&gt;', $pagebgz693);
                            echo $pagebgz693;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <div class="table-scroll">
                            <table class="mbp_shanghai_logo">
                                <tbody>
                <?php 
                        $sctaxonomy = 'mbp_sha_cat';
                        $scterm_args=array(
                          'hide_empty' => false,
                          'orderby' => 'name',
                          'order' => 'ASC'
                        );
                        $sctax_terms = get_terms($sctaxonomy,$scterm_args);
                        $swte = 1;
                            foreach ($sctax_terms as $sctax_term) {
                                if ($swte==1) { ?>
                                    <tr>
                                        <td width="250"><a target="_blank" href="<?php echo esc_attr(get_term_link($sctax_term, $sctaxonomy)); ?>"><?php echo $sctax_term->name; ?></a></td>
                                        <td rowspan="13" class="text-center">
                                            <p class="mbp_alllogos"><img src="<?php echo web_url(); ?>wp-content/uploads/2016/10/mbp-all_logo-shanghai.jpg" /></p>
                                        </td>
                                    </tr>
                                <?php } else { ?>
                                    <tr>
                                        <td><a target="_blank" href="<?php echo esc_attr(get_term_link($sctax_term, $sctaxonomy)); ?>"><?php echo $sctax_term->name; ?></a></td>
                                    </tr>
                                <?php } ?>
                        <?php $swte++; } ?>
                                </tbody>
                            </table>
                        </div>
                            <?php echo get_field('table', 693); ?>
                    </div>
                            <?php echo get_field('content_beneath_the_table', 693); ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } if ( $swisschkr==3 ) { ?>
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_174 = get_post( 174 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_174->post_title; ?></h1>
                        <?php $pagebgz174 = $post_174->post_content;

                            $pagebgz174 = apply_filters('the_content', $pagebgz174);
                            $pagebgz174 = str_replace(']]>', ']]&gt;', $pagebgz174);
                            echo $pagebgz174;  
                        ?>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <?php
                            //global $switched;
                            //switch_to_blog(1); ?>
                        <div class="table-scroll">
                            <table class="mbp_shanghai_logo">
                                <tbody>
                <?php 
                        $sctaxonomy = 'mbp_sha_cat';
                        $scterm_args=array(
                          'hide_empty' => false,
                          'orderby' => 'name',
                          'order' => 'ASC'
                        );
                        $sctax_terms = get_terms($sctaxonomy,$scterm_args);
                        $swte = 1;
                            foreach ($sctax_terms as $sctax_term) {
                                if ($swte==1) { ?>
                                    <tr>
                                        <td width="250"><a target="_blank" href="<?php echo esc_attr(get_term_link($sctax_term, $sctaxonomy)); ?>"><?php echo $sctax_term->name; ?></a></td>
                                        <td rowspan="13" class="text-center">
                                            <p class="mbp_alllogos"><img src="<?php echo web_url(); ?>wp-content/uploads/2016/10/mbp-all_logo-shanghai.jpg" /></p>
                                        </td>
                                    </tr>
                                <?php } else { ?>
                                    <tr>
                                        <td><a target="_blank" href="<?php echo esc_attr(get_term_link($sctax_term, $sctaxonomy)); ?>"><?php echo $sctax_term->name; ?></a></td>
                                    </tr>
                                <?php } ?>
                        <?php $swte++; } ?>
                                </tbody>
                            </table>
                        </div>
                        <?php //restore_current_blog(); ?>
                            <?php echo get_field('table', 174); ?>
                    </div>

                            <?php echo get_field('content_beneath_the_table', 174); ?>

<div class="large-12 columns dowedo_top">
 <ul class="fa-ul all_social_icons">
   <li><span>Share the event : </span></li>
   <li><a href="#" class="fb_icon"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
   <li><a target="_blank" href="<?php echo get_field('linkedin_link', 4); ?>" class="link_icon"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="gpl_icon"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
   <li><a href="#" class="twit_icon"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
   <li><a href="javascript:void(0)" onclick="nCol()" class="wech_icon"><i class="fa fa-weixin" aria-hidden="true"></i></a>
       
   </li>
   <li><a href="#" class="email_icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
 </ul>
</div>

                </div>
        <?php } ?>
                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } ?>