<?php
/*
	Template Name: Contact Us
*/
	get_header();
    $swisschkr = multisite_globalizer(); ?>
    
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">

    <li><a href="<?php echo home_url(); ?>">Home</a></li>

                        <li>
                            <span class="show-for-sr">Current: </span> About Us
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Contact Us
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                <?php $post_603 = get_post( 603 ); ?>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_603->post_title; ?></h1>
                    </div>
                    <div class="large-12 columns dowedo_top">
                        <div class="container_container">
                            
                         <div class="row">
                            <div class="medium-6 columns contact_form">
                            <label>Who would you like to contact?<br>
                            <span class="wpcf7-form-control-wrap contact">
                                <select aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" name="contact">
                                    <option value="Beijing">Beijing</option>
                                    <option value="Shanghai">Shanghai</option>
                                    <option value="Guangzhou">Guangzhou</option>
                                    <option value="HongKong">Hong Kong</option>
                                </select>
                                
                                
                            </span><br>
                            </label>
                            </div>
                            <div class="medium-6 columns contact_form">
                            </div>
</div>   
                        <?php //echo do_shortcode( '[contact-form-7 id="612" title="Main Contact Us Form"]' ); ?>
                            
                            <div class="Beijing box" id="beijing_sec">   
                                <?php echo do_shortcode( '[contact-form-7 id="1774" title="Beijing"]' ); ?>
                            </div>
                            <div class="Shanghai box" id="shanghai_sec">   
                                <?php echo do_shortcode( '[contact-form-7 id="1775" title="Shanghai"]' ); ?>
                            </div>
                            <div class="Guangzhou box" id="guangzhou_sec">   
                                <?php echo do_shortcode( '[contact-form-7 id="1776" title="Guangzhou"]' ); ?>
                            </div>
                            <div class="HongKong box" id="hongkong_sec">   
                                <?php echo do_shortcode( '[contact-form-7 id="1777" title="Hong Kong"]' ); ?>
                            </div>
                        </div>
                    </div>

                    <div class="large-12 columns" data-equalizer="contactDetailsAlign">
                        <div class="row" data-equalizer="contactOuter">
                            <div class="large-12 columns dowedo_top">
                                <h1 class="common_heading2 text-center">SWISSCHAM - Our All Addresses</h1>
                            </div>
                            <div class="large-12 columns">
                                <div class="large-6 columns small_padding contact_container_sec">
                                    <div class="contact_container" data-equalizer-watch="contactOuter">
                                    <?php echo get_field('beijing', 603); ?>
                                        <div class="contact_add_tag">Beijing</div>
                                    </div>
                                </div>
                                <div class="large-6 columns small_padding contact_container_sec">
                                    <div class="contact_container" data-equalizer-watch="contactOuter">
                                    <?php echo get_field('shanghai', 603); ?>
                                        <div class="contact_add_tag">Shanghai</div>
                                    </div>
                                </div>
                                <div class="large-6 columns small_padding contact_container_sec">
                                    <div class="contact_container" data-equalizer-watch="contactOuter">
                                    <?php echo get_field('guangzhou', 603); ?>
                                        <div class="contact_add_tag">Guangzhou</div>
                                    </div>
                                </div>
                                <div class="large-6 columns small_padding contact_container_sec">
                                    <div class="contact_container" data-equalizer-watch="contactOuter">
                                    <?php echo get_field('hong_kong', 603); ?>
                                        <div class="contact_add_tag">Hong Kong</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $("select").change(function(){
        
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>                
                
                
                
                <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>