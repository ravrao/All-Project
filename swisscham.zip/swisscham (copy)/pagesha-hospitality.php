<?php
/*
    Template Name: Hospitality
*/
    get_header();
    ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> Events 
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Committees 
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> EVENT HOSPITALITY SHANGHAI 
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        
            <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo the_title(); ?></h1>
                        <?php $content_post = get_post(452);

        $contentgroup = $content_post->post_content;
        $contentgroup = apply_filters('the_content', $contentgroup);
        $contentgroup = str_replace(']]>', ']]&gt;', $contentgroup);
                    echo $contentgroup;  
                                  
                                    ?>
                        <p><?php echo the_content(); ?></p>
                    </div>
                    
                    <div class="large-12 columns" data-equalizer="boardDetailsAlign">
                        <div class="row" data-equalizer="boardOuter">
                           

                                <?php
           $args = array(
            'post_type' => 'committee', // it's default, you can skip it
            'posts_per_page' => -1,
            'order_by' => 'date', // it's also default
            'order' => 'DESC', // it's also default
                'tax_query' => array(
                    array(
                        'taxonomy' => 'committee_cat',
                        'field' => 'slug',
                        'terms' => 'hospitality'
                    )
                )
            );
            $query = new WP_Query( $args );
           ?>
           <?php  while( $query->have_posts() ) : $query->the_post(); 
          $hosimage = wp_get_attachment_image_src(get_post_thumbnail_id($query->ID), '' ); 
            $hosdetail = get_post_meta($post->ID, 'pm_committeedetailsha'); 
            //print_r($ftdetail); ?>

 <div class="large-3 medium-6 columns small_padding board_container_sec" data-equalizer-watch="boardOuter">
                                <div class="board_container">

                                    <h3 class="common_subheading text-center">Chair:</h3>
                                    <div class="board_img">
                                        <p class="text-center"><img src="<?php echo $hosimage[0]; ?>" alt= ""></p>
                                    </div>
                                    <div class="board_details" data-equalizer-watch="boardDetailsAlign">
                                        <h2><?php echo the_title(); ?></h2>
                                        <h3><?php echo $hosdetail[0][0]['belongs'];?></h3>
                                        <h5><?php echo $hosdetail[0][0]['designation'];?></h5>
                                    </div>
                                    <div class="board_link">
                                        <p><a href="<?php echo $ftdetail[0][0]['url'];?>"><?php echo $hosdetail[0][0]['url-text']; ?></a></p>
                                    </div>
                              
                                </div>
                            </div>
                            
                          <?php endwhile; ?>  
                            
                        </div>
                    </div>

                    <div class="large-12 columns dowedo_top">
                <div class="table-scroll">
                    <table class="upcom_list">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Place</th>
                            </tr>
                        </thead>
                        <tbody>
<?php

global $switched;
    switch_to_blog(1);

 $bbbarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'post_type'        => 'event',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'event-categories',
                     'field' => 'slug',
                     'terms' => 'shanghai'
                  )
               )
            );

            $bbb_array = get_posts( $bbbarg );
           
            foreach ($bbb_array as $bbb_arr) {

             ?>
<?php $colors = get_field('select_if_you_want_to_display_this_event_to_the_respective_pages_below', $bbb_arr->ID);

    if( $colors ): 

         foreach( $colors as $color ):

                    if ($color=='hospitality') { 
    
    echo do_shortcode('[event scope="future" category="52" post_id="'.$bbb_arr->ID.'"]<tr><td>#_EVENTLINK</td><td><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/event]');

 }  endforeach;  endif; } restore_current_blog(); ?>

                        <?php //echo do_shortcode('[events_list scope="future" category="51,52,53,54" blog="1,2,3,4,5"]<tr><td>#_EVENTLINK</td><td><i class="fa fa-calendar" aria-hidden="true"></i> #_EVENTDATES</td><td><i class="fa fa-clock-o" aria-hidden="true"></i> #_EVENTTIMES</td><td><i class="fa fa-map-marker" aria-hidden="true"></i> #_CATEGORYNAME</td>[/events_list]'); ?>

                        </tbody>
                    </table>
                    </div>
                </div>

                </div>

        <?php get_sidebar(); ?>

            </div>
        </section>

        
                <?php get_footer('sha'); ?>
       