<?php
/*
    Template Name: Management SHA
*/

    get_header();
    $swisschkr = multisite_globalizer(); ?>

        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <!--<div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>        
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
<?php } ?>      
                        <li>
                            <span class="show-for-sr">Current: </span> About Us
                        </li> 
                        <li>
                            <span class="show-for-sr">Current: </span> Managment - Shanghai
                        </li>
                    </ul>
                </nav>
            </div>-->
            <?php echo get_post_breadcrumbs(); ?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
        
        <?php if ( $swisschkr==1 ) {

        	$post_403 = get_post( 403 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_403->post_title; ?></h1>
                        <?php $pagemsha72 = $post_403->post_content;

                            $pagemsha72 = apply_filters('the_content', $pagemsha72);
                            $pagemsha72 = str_replace(']]>', ']]&gt;', $pagemsha72);
                            echo $pagemsha72;  
                        ?>
                    </div>

        <?php } if ( $swisschkr==3 ) {

        	$post_132 = get_post( 132 ); ?>

                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading"><?php echo $post_132->post_title; ?></h1>
                        <?php $pagemsha132 = $post_132->post_content;

                            $pagemsha132 = apply_filters('the_content', $pagemsha132);
                            $pagemsha132 = str_replace(']]>', ']]&gt;', $pagemsha132);
                            echo $pagemsha132;  
                        ?>
                    </div>

        <?php } ?>

                    <div class="large-12 columns" data-equalizer="managementDetailsAlign">
                        <div class="row" data-equalizer="managementOuter">

            <?php if ( $swisschkr==1 ) { ?>

<?php $shamarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'management',
                'post_status'      => 'publish',
                'suppress_filters' => 0,
                'tax_query' => array(
                  array(
                     'taxonomy' => 'management_cat',
                     'field' => 'slug',
                     'terms' => 'management-shanghai'
                  )
               )
            );

            $sham_array = get_posts( $shamarg );
           
            foreach ($sham_array as $sham_arr) {

            $shamimg = wp_get_attachment_image_src( get_post_thumbnail_id( $sham_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-4 medium-6 columns small_padding management_container_sec" data-equalizer-watch="managementOuter">
                                <div class="management_container">
                                    <div class="managemnet_img">
                                        <p class=""><img src="<?php echo $shamimg[0]; ?>" /></p>
                                    </div>
                                    <div class="management_details" data-equalizer-watch="managementDetailsAlign">
                                        <h2><?php echo $sham_arr->post_title; ?></h2>
                                        <h2><?php echo get_field( "subtitle", $sham_arr->ID ); ?></h2>
                                        <h3><?php echo get_field( "functional_role", $sham_arr->ID ); ?></h3>
                                        <h5><?php echo get_field( "languages", $sham_arr->ID ); ?></h5>
                                    </div>
                                    <?php $shammail = get_field( "email_address", $sham_arr->ID );
                                        if (!($shammail=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="mailto:<?php echo $shammail; ?>"><?php echo $shammail; ?></a></p>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>

            <?php } ?>

            <?php } if ( $swisschkr==3 ) { ?>

<?php $shamarg = array(
                'posts_per_page'   => -1,
                'orderby'          => 'date',
                'order'            => 'ASC',
                'post_type'        => 'management',
                'post_status'      => 'publish',
                'suppress_filters' => 0
            );

            $sham_array = get_posts( $shamarg );
           
            foreach ($sham_array as $sham_arr) {

            $shamimg = wp_get_attachment_image_src( get_post_thumbnail_id( $sham_arr->ID ), 'single-post-thumbnail' ); ?>

                            <div class="large-4 medium-6 columns small_padding management_container_sec" data-equalizer-watch="managementOuter">
                                <div class="management_container">
                                    <div class="managemnet_img">
                                        <p class=""><img src="<?php echo $shamimg[0]; ?>" /></p>
                                    </div>
                                    <div class="management_details" data-equalizer-watch="managementDetailsAlign">
                                        <h2><?php echo $sham_arr->post_title; ?></h2>
                                        <h2><?php echo get_field( "subtitle", $sham_arr->ID ); ?></h2>
                                        <h3><?php echo get_field( "functional_role", $sham_arr->ID ); ?></h3>
                                        <h5><?php echo get_field( "languages", $sham_arr->ID ); ?></h5>
                                    </div>
                                    <?php $shammail = get_field( "email_address", $sham_arr->ID );
                                        if (!($shammail=='')) { ?>
                                    <div class="board_link">
                                        <p><a href="mailto:<?php echo $shammail; ?>"><?php echo $shammail; ?></a></p>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>

            <?php } ?>

            <?php } ?>

                        </div>
                    </div>
                </div>


    <?php get_sidebar(); ?>

            </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>