<?php
/*
	Template Name: Business Publications
*/
	get_header();
	$swisschkr = multisite_globalizer(); ?>
	
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
<?php if ( $swisschkr==1 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <?php } if ( $swisschkr==2 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Beijing</a></li>
        <?php } if ( $swisschkr==3 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Shanghai</a></li>
        <?php } if ( $swisschkr==4 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Guangzhou</a></li>
        <?php } if ( $swisschkr==5 ) { ?>
    <li><a href="<?php echo home_url(); ?>">Hong Kong</a></li>
<?php } ?>
                       <li>
                            <span class="show-for-sr">Current: </span> Publications
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> Business Publications
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <style type="text/css">
.accordion-header:after{background:url(<?php echo web_url();?>wp-content/uploads/2016/11/plus.png) !important;}
        </style>
        <section>
            <div class="row" >
        <?php if ( $swisschkr==1 ) { ?>
                <?php $post_846 = get_post( 846 );
                     $pagea = $post_846->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
        <?php } if ( $swisschkr==2 ) { ?>
                <?php $post_846 = get_post( 249 );
                     $pagea = $post_846->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
        <?php } if ( $swisschkr==3 ) { ?>
                <?php $post_846 = get_post( 264 );
                     $pagea = $post_846->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
        <?php } if ( $swisschkr==4 ) { ?>
                <?php $post_846 = get_post( 171 );
                     $pagea = $post_846->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
        <?php } if ( $swisschkr==5 ) { ?>
                <?php $post_846 = get_post( 173 );
                     $pagea = $post_846->post_content;

                            $pagea = apply_filters('the_content', $pagea);
                            $pagea = str_replace(']]>', ']]&gt;', $pagea);
                            
                                echo $pagea; ?>
        <?php } ?>
                   <?php get_sidebar(); ?>
          </div>
        </section>

        <?php if ( $swisschkr==1 ) {
        	get_footer();
         } if ( $swisschkr==2 ) {
         	get_footer('bei');
         } if ( $swisschkr==3 ) {
         	get_footer('sha');
         } if ( $swisschkr==4 ) {
         	get_footer('gz');
         } if ( $swisschkr==5 ) {
         	get_footer('hk');
         } ?>