 <?php get_header(); ?>
    <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> <a href="#">Services</a>
                        </li>
                        <li>
                            <span class="show-for-sr">Current: </span> <a href="<?php echo web_url(); ?>jobs/">Job Opportunities</a>
                        </li>
                    </ul>
                </nav>
            </div>
            
            <?php //echo get_post_breadcrumbs();?>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns margin_top15" data-equalizer-watch>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

  <?php the_content(); ?>
    <?php endwhile; endif; ?>
                </div>

                <?php get_sidebar(); ?>

            </div>
        </section>

    <?php get_footer(); ?>