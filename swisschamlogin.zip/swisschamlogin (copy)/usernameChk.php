<?php 
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 

$admin_generated_userId=addcslashes($_POST['admin_generated_userId']);
$userId=$_POST['userId'];
$sql="SELECT * FROM `sc_c_userdetails` 
			   WHERE `admin_generated_userId`='".$admin_generated_userId."'
			   AND `userId`<>'".$userId."'";
$res = mysql_query($sql);
$rowcount=mysql_num_rows($res);
if($rowcount!=0){
	return 1;
} else{
	return 0;
}




?>