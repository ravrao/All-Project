<?php
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://votecompany.e-ngine.nl/mail/forward/?kid=282&mlid=55&source=partner&campaign=campagne&medium=banner&content=specs&fee=400&analytics=1&soap=s@gmail.com&dest=ssssss");
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
curl_close($curl);
print $result;
?>
