<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swisscham | Registration 2</title>
    <link rel="stylesheet" href="css/app.css">
    <!-- Favicon -->
	<link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
	<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
	<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
	<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
	<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
    <link rel="icon" href="favicon.png">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
    
    <link rel="stylesheet" href="css/dev1.css" />
</head>

<body>
    <div id="page">

        <?php 
			require_once(__ROOT__.'/includes/header.php'); 
		?>
        </section>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="<?=$site_url?>">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span>SUCCESSFUL REGISTRATION
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
               <div class="medium-8 medium-offset-2 columns">
               <div class="registration_msg">
                  <h1><i class="fa fa-check-square" aria-hidden="true"></i></h1>
                   <h3>Your application was successfully submitted</h3>
                   <p>We will review your application and once validated, we will provide you with the username and password.</p>
               </div>             
            
                </div> 
            
            
            
            </div>
        </section>
        <!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please enter the details to login</h1>
                        <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                    </label>
                                </div>
                                <!--<div class="medium-12 columns margin_top10 membership_from no_padding">
								 <h6 class="directory_register_msg">If you are not member yet Please <a href="online_application.php">Register</a></h6>
								 </div>-->
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
       <?php 
		require_once(__ROOT__.'/includes/footer.php'); 
		?>

        


    </div>

    <a href="#0" class="cd-top">Top</a>




    <script src="bower_components/jquery/dist/jquery.js"></script>
    <script src="bower_components/what-input/what-input.js"></script>
    <script src="bower_components/foundation-sites/dist/foundation.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
    <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
    <script type="text/javascript" src="js/pace.js"></script>
    <script type="text/javascript">
        $(function() {
            $('nav#menu').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: true,
                counters: false,
                "offCanvas": {
                    "position": "left"
                },
                navbar: {
                    title: 'SWISSCHAM'
                },
                navbars: [{
                    position: 'top',
                    content: ['searchfield']
                }, {
                    position: 'top',
                    content: [
                        'prev',
                        'title',
                        'close'
                    ]
                }, {
                    position: 'bottom',
                    content: [
                        //                        '<a href="http://mmenu.frebsite.nl/wordpress-plugin.html" target="_blank">WordPress plugin</a>'
                    ]
                }]
            });
            $('nav#log_togg').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: false,
                counters: false,
                navbar: {
                    title: 'Welcome to Swisscham'
                },

            });

        });

    </script>
    <script src="js/app.js"></script>

</body>

</html>
