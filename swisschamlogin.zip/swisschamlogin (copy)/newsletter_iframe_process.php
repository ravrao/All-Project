<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 

$USER_ID = $_REQUEST['guan_id'];

$newsval = $_REQUEST['gz_Value'];


if($newsval=='gz_news')
{
 $sql = "UPDATE `sc_c_userdetails`
                SET `news_gua`='".$newsval."'
              WHERE `userId` = '".$USER_ID."'";
}

if($newsval=='bj_news')
{
 $sql = "UPDATE `sc_c_userdetails`
                SET `news_bei`='".$newsval."'
              WHERE `userId` = '".$USER_ID."'";
}

if($newsval=='sha_news')
{
 $sql = "UPDATE `sc_c_userdetails`
                SET `news_sha`='".$newsval."'
              WHERE `userId` = '".$USER_ID."'";
}
 $rs=mysql_query($sql);
 
 if(!$rs)
 {
    die('Invalid query: ' . mysql_error());
 }
 
 //echo "OK";
