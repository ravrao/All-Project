<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 
if($_POST){

$info=trim($_GET['info']);

$userId=$_REQUEST['userId'];
$adminId = $_SESSION["userId"];

switch ($info) {
case "basic":
	$company_id = isset($_REQUEST['company_id'])?addslashes($_REQUEST['company_id']):"";
	$business_scope = isset($_REQUEST['business_scope'])?addslashes($_REQUEST['business_scope']):"";
	if($business_scope=='Other'){
		$other_business_scope = isset($_REQUEST['other_business_scope'])?addslashes($_REQUEST['other_business_scope']):"";	
	} else{
		$other_business_scope='';
	}
	
	$business_description_english = isset($_REQUEST['business_description_english'])?addslashes($_REQUEST['business_description_english']):"";
	$business_description_chinese = isset($_REQUEST['business_description_chinese'])?addslashes($_REQUEST['business_description_chinese']):"";
	$company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
	$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
	$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
	$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
	$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
	$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
	$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
	$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
	$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
	$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
	$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
	$legal_entity = isset($_REQUEST['legal_entity'])?addslashes($_REQUEST['legal_entity']):"";
	$no_of_employees = isset($_REQUEST['no_of_employees'])?addslashes($_REQUEST['no_of_employees']):"";
	$is_company_swiss_registered = isset($_REQUEST['is_company_swiss_registered'])?addslashes($_REQUEST['is_company_swiss_registered']):"";
	$is_company_registered_PRC = isset($_REQUEST['is_company_registered_PRC'])?addslashes($_REQUEST['is_company_registered_PRC']):"";
	$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
	$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";
	if($is_company_registered_PRC==''){
		$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
		$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";
	}
	if((isset($_FILES['logo_name']['name'])) && (!empty($_FILES['logo_name']['name']))){
      $errors= array();
      $file_name = $_FILES['logo_name']['name'];
      $file_size =$_FILES['logo_name']['size'];
      $file_tmp =$_FILES['logo_name']['tmp_name'];
      $file_type=$_FILES['logo_name']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['logo_name']['name'])));
      $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $file_name="logo_name".time().$file_ext;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $logo_name="uploads/".$file_name; 
         $logo_name1=$file_name; 
      }else{
		 header('Location: admin_edit_membership.php');
      }
	} else{
	   $logo_name="";
	   $logo_name1="";
	}
	if($logo_name1!=''){
	   $basicSql = "UPDATE `sc_c_company_details`
		                 SET `business_scope`='".$business_scope."',
		                     `other_business_scope`='".$other_business_scope."',
		                     `business_description_english`='".$business_description_english."',
		                     `business_description_chinese`='".$business_description_chinese."',
		                     `company_name_english`='".$company_name_english."',
		                     `company_name_chinese`='".$company_name_chinese."',
		                     `company_address`='".$company_address."',
		                     `company_city`='".$company_city."',
		                     `province_area_english`='".$province_area_english."',
		                     `china_office_address`='".$china_office_address."',
		                     `china_office_city`='".$china_office_city."',
		                     `company_zipCode`='".$company_zipCode."',
		                     `company_generalPhone`='".$company_generalPhone."',
		                     `company_email`='".$company_email."',
		                     `company_website`='".$company_website."',
		                     `legal_entity`='".$legal_entity."',
		                     `no_of_employees`='".$no_of_employees."',
		                     `is_company_swiss_registered`='".$is_company_swiss_registered."',
		                     `is_company_registered_PRC`='".$is_company_registered_PRC."',
		                     `establishment_hongkong`='".$establishment_hongkong."',
		                     `geographical_responsibility_hongkong`='".$geographical_responsibility_hongkong."',
		                     `logo_name`='".$logo_name."'
		               WHERE `company_id` = '".$company_id."'";
					   
	} else{
	   $basicSql = "UPDATE `sc_c_company_details`
		                 SET `business_scope`='".$business_scope."',
		                     `other_business_scope`='".$other_business_scope."',
		                     `business_description_english`='".$business_description_english."',
		                     `business_description_chinese`='".$business_description_chinese."',
		                     `company_name_english`='".$company_name_english."',
		                     `company_name_chinese`='".$company_name_chinese."',
		                     `company_address`='".$company_address."',
		                     `company_city`='".$company_city."',
		                     `province_area_english`='".$province_area_english."',
		                     `china_office_address`='".$china_office_address."',
		                     `china_office_city`='".$china_office_city."',
		                     `company_zipCode`='".$company_zipCode."',
		                     `company_generalPhone`='".$company_generalPhone."',
		                     `company_email`='".$company_email."',
		                     `company_website`='".$company_website."',
		                     `legal_entity`='".$legal_entity."',
		                     `no_of_employees`='".$no_of_employees."',
		                     `is_company_swiss_registered`='".$is_company_swiss_registered."',
		                     `is_company_registered_PRC`='".$is_company_registered_PRC."',
		                     `establishment_hongkong`='".$establishment_hongkong."',
		                     `geographical_responsibility_hongkong`='".$geographical_responsibility_hongkong."'
		               WHERE `company_id` = '".$company_id."'"; 
	}
	
	$res = mysql_query($basicSql);
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab3|ChildVerticalTab_13|companyInfoTab1');
	break;
case "headquarter":
	$company_id = isset($_REQUEST['company_id'])?addslashes($_REQUEST['company_id']):"";
	$headquarter_name = isset($_REQUEST['headquarter_name'])?addslashes($_REQUEST['headquarter_name']):"";
	$headquarter_address = isset($_REQUEST['headquarter_address'])?addslashes($_REQUEST['headquarter_address']):"";
	$headquarter_city = isset($_REQUEST['headquarter_city'])?addslashes($_REQUEST['headquarter_city']):"";
	$headquarter_zipCode = isset($_REQUEST['headquarter_zipCode'])?addslashes($_REQUEST['headquarter_zipCode']):"";
	$headquarter_phone = isset($_REQUEST['headquarter_phone'])?addslashes($_REQUEST['headquarter_phone']):"";
	$headquarter_province_area_english = isset($_REQUEST['headquarter_province_area_english'])?addslashes($_REQUEST['headquarter_province_area_english']):"";
	
	 $headquarterSql = "UPDATE `sc_c_company_details`
		                 SET `headquarter_name`='".$headquarter_name."',
		                     `headquarter_address`='".$headquarter_address."',
		                     `headquarter_city`='".$headquarter_city."',
		                     `headquarter_zipCode`='".$headquarter_zipCode."',
		                     `headquarter_phone`='".$headquarter_phone."',
		                     `headquarter_province_area_english`='".$headquarter_province_area_english."'
		                     
		               WHERE `company_id` = '".$company_id."'";
         
       
        
	$res = mysql_query($headquarterSql);
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab3|ChildVerticalTab_13|companyInfoTab2');
	break;
case "membership":
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab3|ChildVerticalTab_13|companyInfoTab3');
	break;
	
	
	case "other":
		
	$userId = $_REQUEST['userId'];
		
	$company_id = isset($_REQUEST['company_id'])?$_REQUEST['company_id']:"";
        
        
        /* First Company Name */
        
        $company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
	$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
	$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
	$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
	$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
	$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
	$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
	$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
	$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
	$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
	$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
        
        /* End First company name */
        
        if($company_name_english!='' || $company_name_chinese!='' || $company_address!='' || $company_city!='' 
                || $province_area_english!='' || $china_office_address!='' || $china_office_city!='' || $company_zipCode!='' 
                || $company_generalPhone!='' || $company_email!='' || $company_website!='') 
        {
            
            $MainCompanySql = "UPDATE `sc_c_company_details`
		                 SET `company_name_english`='".$company_name_english."',
		                     `company_name_chinese`='".$company_name_chinese."',
		                     `company_address`='".$company_address."',
		                     `company_city`='".$company_city."',
		                     `province_area_english`='".$province_area_english."',
		                     `china_office_address`='".$china_office_address."',
		                     `china_office_city`='".$china_office_city."',
		                     `company_zipCode`='".$company_zipCode."',
		                     `company_generalPhone`='".$company_generalPhone."',
		                     `company_email`='".$company_email."',
		                     `company_website`='".$company_website."'
		                     
		               WHERE `company_id` = '".$company_id."'"; 
           
           $res = mysql_query($MainCompanySql);
        }
        
        
        
        
	$deleteQuery="DELETE FROM `sc_c_company_other_contact_details` WHERE `company_id`='".$company_id."'";
	mysql_query($deleteQuery);
	$count=count($_POST['other_company_name_english']);
	for($i=0;$i<$count;$i++){
		$other_company_name_english = isset($_REQUEST['other_company_name_english'][$i])?addslashes($_REQUEST['other_company_name_english'][$i]):"";
		$other_company_name_chinese = isset($_REQUEST['other_company_name_chinese'][$i])?addslashes($_REQUEST['other_company_name_chinese'][$i]):"";
		$other_company_address = isset($_REQUEST['other_company_address'][$i])?addslashes($_REQUEST['other_company_address'][$i]):"";
		$other_company_city = isset($_REQUEST['other_company_city'][$i])?addslashes($_REQUEST['other_company_city'][$i]):"";
		$other_province_area_english = isset($_REQUEST['other_province_area_english'][$i])?addslashes($_REQUEST['other_province_area_english'][$i]):"";
		$other_china_office_address = isset($_REQUEST['other_china_office_address'][$i])?addslashes($_REQUEST['other_china_office_address'][$i]):"";
		$other_china_office_city = isset($_REQUEST['other_china_office_city'][$i])?addslashes($_REQUEST['other_china_office_city'][$i]):"";
		$other_company_zipCode = isset($_REQUEST['other_company_zipCode'][$i])?addslashes($_REQUEST['other_company_zipCode'][$i]):"";
		$other_company_generalPhone = isset($_REQUEST['other_company_generalPhone'][$i])?addslashes($_REQUEST['other_company_generalPhone'][$i]):"";
		$other_company_email = isset($_REQUEST['other_company_email'][$i])?addslashes($_REQUEST['other_company_email'][$i]):"";
		$other_company_website = isset($_REQUEST['other_company_website'][$i])?addslashes($_REQUEST['other_company_website'][$i]):"";
		
		
		 $insertSql = "INSERT INTO `sc_c_company_other_contact_details`
		                 SET `company_id`='".$company_id."',
		                     `other_company_name_english`='".$other_company_name_english."',
		                     `other_company_name_chinese`='".$other_company_name_chinese."',
		                     `other_company_address`='".$other_company_address."',
		                     `other_company_city`='".$other_company_city."',
		                     `other_province_area_english`='".$other_province_area_english."',
		                     `other_china_office_address`='".$other_china_office_address."',
		                     `other_china_office_city`='".$other_china_office_city."',
		                     `other_company_zipCode`='".$other_company_zipCode."',
		                     `other_company_generalPhone`='".$other_company_generalPhone."',
		                     `other_company_email`='".$other_company_email."',
		                     `other_company_website`='".$other_company_website."'";
		
               
                
		mysql_query($insertSql);
                
                
	}
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab3|companyInfoTab4');
	break;
	
	
default:
	header('Location: admin_edit_membership.php');
	break;
}

  }
?>