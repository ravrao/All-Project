<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swisscham | Log in and Registration</title>
    <link rel="stylesheet" href="css/app.css">
    <!-- Favicon -->
    <link rel="icon" href="favicon.png">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <style type="text/css">
        .error_cl{
            
            border: 1px solid;
            border-color: red !important;
        }
    </style>
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/registration.js"></script>
</head>

<body>
    <div id="page">
<?php  
require_once(__ROOT__.'/includes/header.php'); 
?>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="index.html">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> MEMBERSHIP APPLICATION FORM
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row" data-equalizer data-equalize-on="medium">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">Membership Application Form</h1>
                    </div>
                    <div class="large-12 columns dowedo_top margin_top10">
                        <p>Please fill the form hereunder to apply for a Membership with SwissCham.</p>
                        <p>Note that this form is an initial contact and that the SwissCham Management Team will contact you for possible additional information. Please contact your local office to receive the updated information and membership application form (Beijing: <a href="#" class="small_link">members@bei.swisscham.org</a>, Shanghai: <a href="#" class="small_link">info@sha.swisscham.org</a>, Guangzhou: <a href="#" class="small_link">info@swisscham-gz.org</a>).</p>
                        <p><a href="#">Click here for more information about the benefits and fees</a> of becoming part of SwissCham's network.</p>
                       

                        <form name="registration" id="registrationFrm" action="registration_process.php" method="POST">


                            <div class="row" id="firstPortion">
                                <div class="small-10 small-centered large-9 large-centered columns margin_top10">
                                    <div class="medium-12 columns membership_from">
                                        <legend>Title <span class="mandatory_tag">*</span></legend>
                                        <input type="radio" name="user_title" value="Mr." id="mister" class="user_title" checked="checked">
                                        <label for="mister">Mr.</label>
                                        <input type="radio" name="user_title" value="Ms." id="miss" class="user_title">
                                        <label for="miss">Ms.</label>
                                        <input type="radio" name="user_title" value="Dr." id="doctor" class="user_title">
                                        <label for="doctor">Dr.</label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Family Name <span class="mandatory_tag">*</span>
                                            <input type="text" value="" name="family_name" id="family_name">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Given Name(s) <span class="mandatory_tag">*</span>
                                            <input type="text" name="given_name" id="given_name">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Chinese Name 
                                            <input type="text" name="chinese_name" id="chinese_name">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <legend>Nationality <span class="mandatory_tag">*</span></legend>
                                        <input type="radio" name="nationality" value="Swiss" id="swiss" checked="checked">
                                        <label for="swiss">Swiss</label>
                                        <input type="radio" name="nationality" value="Chinese" id="chinese">
                                        <label for="chinese">Chinese</label>
                                        <input type="radio" name="nationality" value="Other" id="other">
                                        <label for="other">Other</label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Membership's Location <span class="mandatory_tag">*</span>
                                            <select name="membership_location" id="membership_location">
                                             <option value="">-Select Membership's Location-</option>
                                            
                                                <option value="beijing">Beijing</option>
                                                <option value="shanghai">Shanghai</option>
                                                <option value="guangzhou">Guangzhou</option>
                                                </select>
                                               
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Membership's Type (see types and fees) <span class="mandatory_tag">*</span>
                                            <select name="membership_type" id="membership_type">
                                                <option value="">-Select Membership's Type-</option>
                                                <optgroup label="General (Beijing, Shanghai, Guangzhou)">
                                                <option value="gen_corporate_more_100">Large Corporate with &gt; 100 employees in mainland China</option>
                                                <option value="gen_corporate_less_100">Small and Medium Corporate with ≤ 100 employees in mainland China</option>
                                                </optgroup>
                                                <optgroup label="Beijing">
                                                <option value="bei_corporate_more_100">Large Corporate with &gt; 100 employees in mainland China</option>
                                                <option value="bei_corporate_less_100i">Small and Medium Corporate with ≤ 100 employees in mainland China</option>
                                                <option value="bei_corporate_affiliate">Corporate Affiliate</option>
                                                <option value="bei_individual">Individual</option>
                                                <option value="bei_associate">Associate</option>
                                                </optgroup>
                                                <optgroup label="Shanghai">
                                                <option value="sh_corporate_more_100">Swiss large company with &gt; 100 employees</option>
                                                <option value="sh_corporate_less_100">Swiss small and medium company with &lt; 100 employees</option>
                                                <option value="sh_corporate_affiliate_more_100">Non-Swiss large company with &gt; 100 employees</option>
                                                <option value="sh_corporate_affiliate_less_100">Non-Swiss small and medium company with &lt; 100 employees</option>
                                                <option value="sh_individual">Swiss individual member</option>
                                                <option value="sh_associate">Non-Swiss individual member</option>
                                                <option value="sh_young_pro">Young professional (students and interns)</option>
                                                </optgroup>
                                                <optgroup label="Guangzhou">
                                                <option value="gz_corporate_more_100">Large Corporate with &gt; 100 employees in mainland China</option>
                                                <option value="gz_corporate_less_100">Small and Medium Corporate with ≤ 100 employees in mainland China</option>
                                                <option value="gz_individual">Individual</option>
                                                <option value="gz_associate">Associate</option>
                                                </optgroup>                                            
                                            </select>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Company Name in English <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="company_name_english" id="company_name_english">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Company Name in Chinese
                                            <input type="text" placeholder="" name="company_name_chinese" id="company_name_chinese">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Position within the Company <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="positionIn_company" id="positionIn_company">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>
                                            Address in English <span class="mandatory_tag">*</span>
                                            <textarea placeholder="" rows="2" name="address_english" id="address_english"></textarea>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>
                                            Address in Chinese <span class="mandatory_tag">*</span>
                                            <textarea placeholder="" rows="2" name="address_chinese" id="address_chinese"></textarea>
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>City <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="city" id="city">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>ZIP Code <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="zip_code" id="zip_code">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Website 
                                            <input type="text" placeholder="" name="website" id="website">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>General Phone <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="general_phone" id="general_phone">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>General Email <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="general_email" id="general_email">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Direct Fax 
                                            <input type="text" placeholder="" name="direct_fax" id="direct_fax">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Direct Phone <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="direct_phone" id="direct_phone">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Direct Email <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="direct_email" id="direct_email">
                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Mobile Phone (for internal use only) <span class="mandatory_tag">*</span>
                                            <input type="text" placeholder="" name="mobile_phone" id="mobile_phone">
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="nextPage">Next Page</a></p>
                                    </div>
                                </div>
                            </div>


                            <div class="row" id="secondPortion" style="display:none;">
                                <div class="small-10 small-centered large-9 large-centered columns margin_top10">
                                    <div class="medium-12 columns membership_from">
                                        <label>Industry (select up to three choices) <span class="mandatory_tag">*</span>
                                            <select multiple="multiple" name="industry[]" id="industry" size="4" class="form-select required">
                                            <option value="">-Select Industry-</option>>
                                                <?php
                                                $sql = "SELECT * FROM sc_c_industry";
                                                $result = mysql_query($sql); 
                                                while ($row = mysql_fetch_array($result))   
                                                { ?>
                                                  <option value="<?=$row['industry_id']?>">
                                                  <?=$row['industry_name']?>
                                                  </option> 
                                                <?php }
                                                ?>


                                            </select>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>Other
                                            <input type="text" placeholder="" name="other_industry" id="other_industry">
                                            <small>Please fill this field if your Business Scope doesn't appear among the options listed above </small>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>
                                            Business Scope (max. 100 words) <span class="mandatory_tag">*</span>
                                            <textarea placeholder="" rows="2" name="business_scope" id="business_scope"></textarea>
                                            <small>Please write down a short introduction of your company and describe what your core business is (for corporate members only).</small>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <legend>Legal Entity <span class="mandatory_tag">*</span></legend>
                                        <input type="radio" name="legal_entity" value="chinese-domestic" id="chineseDomestic"  checked="checked">
                                        <label for="chineseDomestic">Chinese Domestic </label>
                                        <input type="radio" name="legal_entity" value="joint-venture" id="jointVenture">
                                        <label for="jointVenture"> Joint-Venture </label>
                                        <input type="radio" name="legal_entity" value="wholly-foreign-owned" id="whollyForeignOwned">
                                        <label for="whollyForeignOwned">Wholly Foreign-Owned </label>
                                        <input type="radio" name="legal_entity" value="representative-office" id="representativeOffice">
                                        <label for="representativeOffice"> Representative Office </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Number of Employees in Mainland China <span class="mandatory_tag">*</span>
                                            <input type="text" id="employees_mainland_chinese" name="employees_mainland_chinese" step="0" min="0" class="form-text form-number required">

                                        </label>
                                    </div>
                                    <div class="medium-6 columns membership_from">
                                        <label>Number of Employees in Asia<span class="mandatory_tag">*</span>

                                            <input type="text" id="employees_asia" name="employees_asia" step="0" min="0" class="form-text form-number required">
                                        </label>
                                    </div>
                                    <div class="medium-4 columns membership_from">
                                        <legend>Is your Company Swiss-invested ?</legend>
                                        <input type="radio" name="country_swissInvested" value="yes" id="country_swissInvested"  checked="checked">
                                        <label for="swiss-comp-yes">Yes</label>
                                        <input type="radio" name="country_swissInvested" value="no" id="country_swissInvested">
                                        <label for="swiss-comp-no">No</label>
                                    </div>
                                    <div class="medium-4 columns membership_from">
                                        <legend>Is your Company Swiss-registered ?</legend>
                                        <input type="radio" name="country_swiss_registered" value="yes" id="country_swiss_registered"  checked="checked">
                                        <label for="swiss-reg-yes">Yes</label>
                                        <input type="radio" name="country_swiss_registered" value="no" id="country_swiss_registered">
                                        <label for="swiss-reg-no">No</label>
                                    </div>
                                    <div class="medium-4 columns membership_from">
                                        <legend>Are you registered in PRC with a valid business licence ? <span class="mandatory_tag">*</span></legend>
                                        <input type="radio" name="registered_PRC" value="yes" id="reg-in-prc-yes" class="registered_PRC"  checked="checked">
                                        <label for="reg-in-prc-yes">Yes</label>
                                        <input type="radio" name="registered_PRC" value="no" id="registered_PRC" class="registered_PRC">
                                        <label for="reg-in-prc-no">No</label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>
                                            Comments
                                            <textarea placeholder="" rows="2" name="comments" id="comments"></textarea>
                                            <small>Questions, comments, notes (ways we could help you improve your business, feedback etc.)</small>
                                        </label>
                                    </div>
                                    <div class="medium-12 columns membership_from">
                                        <label>test
                                            <input type="text" placeholder="" name="test" id="test">
                                        </label>
                                    </div>

                                    <div class="medium-12 columns membership_from">
                                        <p class="text-right"><a href="javascript:void(0)" class="button holo_btn" id="previousPage">Previous Page</a> <a href="javascript:void(0)" class="button regnext_btn" id="finalSubmit">Submit</a></p>
                                    </div>
                                </div>
                            </div>




                        </form>

                    </div>
                </div>

                <div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                            <p class="text-center">Because Connections Matter.</p>
                            <ul class="fa-ul join_button_group">
                                <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                            </ul>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Strategic Partner</h3>
                            <ul class="fa-ul inner_sponser_img">
                                <li><img src="images/inner_sponser1.jpg" /></li>
                                <li><img src="images/inner_sponser2.jpg" /></li>
                                <li><img src="images/inner_sponser3.jpg" /></li>
                            </ul>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">Upcoming events</h3>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                            </div>
                            <div class="tab_list_item">
                                <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                <h5>Venue Name</h5>
                                <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                            </div>
                            <a class="see_more_link" href="#">read more</a>
                        </div>
                        <div class="large-12 columns">
                            <hr class="right_devider" />
                        </div>
                        <div class="large-12 columns right_y_join margin_top10">
                            <h3 class="common_subheading">NEWSLETTER</h3>
                            <p class="">Interested in trying one? Use the form below to get in touch.</p>
                            <form>
                                <ul class="fa-ul right_newsletter_form">
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Name">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Surname">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Company">
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="text" placeholder="Email">
                                        </label>
                                    </li>
                                    <li class="text-left newsletter_button_sec">
                                        <a href="#" class="button newsletter_button">Subscribe</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <?php 

//require_once(__ROOT__.'/include/config.php'); 
require_once(__ROOT__.'/includes/footer.php'); 
?>
      
        <!-- Login Modal Start -->
        <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
            <h1>Please fill the information to Login</h1>
            <p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>
            <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                <div class="row">
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>User ID <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                        </label>
                    </div>
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>Password <span class="mandatory_tag">*</span>
                            <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from no_padding">
                        <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                    </div>
                </div>
            </form>
            <button class="close-button" data-close aria-label="Close reveal" type="button">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <!-- Login Modal End -->

        <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
        <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


        <nav id="log_togg">
            <ul class="logsec_sidenav">
                <li><a href="#">Login</a></li>
                <li class="side_joinnow"><a href="#">Join US</a></li>
                <li class="right_menu_heading show-for-medium-only">Select Language</li>
                <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
            </ul>
        </nav>

        <nav id="menu">
            <ul>
                <!--
                <li class="region_side_icon"></li>
                <li class="region_side_icon"><a href="beijing.html">Beijing</a></li>
                <li class="region_side_icon"><a href="shanghai.html">Shanghai</a></li>
                <li class="region_side_icon"><a href="guangzhou.html">Guangzhou</a></li>
                <li class="region_side_icon"><a href="hongkong.html">Hong Kong</a></li>
-->
                <!--                <li class="right_menu_heading show-for-small-only">Select Language</li>-->
                <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                <!--               <li class="right_menu_heading inlineblock_element">Select Location</li>-->
                <li class="region_side_icon">
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                        <option value="index.html">Home</option>
                        <option value="beijing.html">Beijing</option>
                        <option value="shanghai.html">Shanghai</option>
                        <option value="guangzhou.html">Guangzhou</option>
                        <option value="hongkong.html">Hong Kong</option>
                    </select>
                </li>

                <li><a href="#about">ABOUT US</a>
                    <ul>
                        <li><a href="#">Who are we?</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">History</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Rules</a></li>
                        <li><a href="#">Board of Directors</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Guangzhou</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Management</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </li>
                <li><a href="#about">MEMBERSHIP</a>
                    <ul>
                        <li><a href="#">Why join us?</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Online Application</a></li>
                        <li><a href="#">Members Directory</a></li>
                        <li><a href="#">Investment Zones</a></li>
                        <li><a href="#">Member Benefits Program</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#about">EVENTS</a>
                    <ul>
                        <li><a href="#">Upcoming Events</a>

                        </li>
                        <li><a href="#">Events Calendar</a></li>
                        <li><a href="#">Events Overview</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Guangzhou</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#about">PUBLICATIONS</a>
                    <ul>
                        <li><a href="#">The Bridge</a></li>
                        <li><a href="#">Sino-Swiss Business News</a></li>
                        <li><a href="#">Reader’s Digest</a></li>
                        <li><a href="#">Legal & Investment Updates</a></li>
                        <li><a href="#">Invest in Switzerland</a></li>
                        <li><a href="#">BusinessPublications</a>
                            <ul>
                                <li><a href="#">economic report</a></li>
                                <li><a href="#">business sentiment survey</a></li>
                                <li><a href="#">embassy</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Other Links</a></li>
                    </ul>
                </li>
                <li><a href="#about">SERVICES</a>
                    <ul>
                        <li><a href="#">Our services</a></li>
                        <li><a href="#">Advertise With Us</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">JobOpportunities</a></li>
                        <li><a href="#">Training</a></li>
                        <li><a href="#">Lobbying Activities(IPR complaints, Social Security) Wechat?</a></li>
                    </ul>
                </li>
            </ul>
        </nav>


    </div>

    <a href="#0" class="cd-top">Top</a>




    <script src="bower_components/jquery/dist/jquery.js"></script>
    <script src="bower_components/what-input/what-input.js"></script>
    <script src="bower_components/foundation-sites/dist/foundation.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
    <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
    <script type="text/javascript" src="js/pace.js"></script>
    <script type="text/javascript">
        $(function() {
            $('nav#menu').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: true,
                counters: false,
                "offCanvas": {
                    "position": "left"
                },
                navbar: {
                    title: 'SWISSCHAM'
                },
                navbars: [{
                    position: 'top',
                    content: ['searchfield']
                }, {
                    position: 'top',
                    content: [
                        'prev',
                        'title',
                        'close'
                    ]
                }, {
                    position: 'bottom',
                    content: [
                        //                        '<a href="http://mmenu.frebsite.nl/wordpress-plugin.html" target="_blank">WordPress plugin</a>'
                    ]
                }]
            });
            $('nav#log_togg').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: false,
                counters: false,
                navbar: {
                    title: 'Welcome to Swisscham'
                },

            });

        });

    </script>
    <script src="js/app.js"></script>

</body>

</html>
