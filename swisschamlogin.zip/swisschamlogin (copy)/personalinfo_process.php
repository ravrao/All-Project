<?php
	define('__ROOT__', dirname(__FILE__)); 
	require_once(__ROOT__.'/includes/config.php');
	if($_POST){
	if(!empty($_POST['user_title'])){
	$user_title=$_POST['user_title'];
	} else{
	    $user_title='';
	}
	if(!empty($_POST['family_name'])){
	$family_name=addslashes($_POST['family_name']);
	} else{
	    $family_name='';
	}
	if(!empty($_POST['given_name'])){
	$given_name=addslashes($_POST['given_name']);
	} else{
	    $given_name='';
	}
	if(!empty($_POST['nationality'])){
	$nationality=addslashes($_POST['nationality']);
	} else{
	    $nationality='';
	}
	if(!empty($_POST['positionIn_company'])){
	$positionIn_company=addslashes($_POST['positionIn_company']);
	} else{
	    $positionIn_company='';
	}
	if(!empty($_POST['company_name'])){
	$company_name=addslashes($_POST['company_name']);
	} else{
	    $company_name='';
	}
	if(!empty($_POST['year_of_birth'])){
	$year_of_birth=$_POST['year_of_birth'];
	} else{
	    $year_of_birth='';
	}
	



	if((isset($_FILES['profile_picture']['name'])) && (!empty($_FILES['profile_picture']['name']))){
		//print_r($_FILES['profile_picture']);
      $errors= array();
      $file_name = $_FILES['profile_picture']['name'];
      $file_size =$_FILES['profile_picture']['size'];
      $file_tmp =$_FILES['profile_picture']['tmp_name'];
      $file_type=$_FILES['profile_picture']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['profile_picture']['name'])));
      
      $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      $file_name="profilePic_".time().$file_ext;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $profile_picture="uploads/".$file_name; 
      }else{
         print_r($errors);
		 header('Location: membership.php');
      }
   } else{
	   $profile_picture='';
   }
	if(!empty($_POST['general_phone'])){
	$general_phone=addslashes($_POST['general_phone']);
	} else{
	    $general_phone='';
	}
	if(!empty($_POST['direct_fax'])){
	$direct_fax=addslashes($_POST['direct_fax']);
	} else{
	    $direct_fax='';
	}
	if(!empty($_POST['mobile_phone'])){
	$mobile_phone=addslashes($_POST['mobile_phone']);
	} else{
	    $mobile_phone='';
	}
	if(!empty($_POST['direct_email'])){
	$direct_email=addslashes($_POST['direct_email']);
	} else{
	    $direct_email='';
	}
	if(!empty($_POST['website'])){
	$website=addslashes($_POST['website']);
	} else{
	    $website='';
	}
	$userId=$_SESSION["userId"]; 
	//print_r($_FILES['profile_picture']); die;
	if($profile_picture==''){
	$personalInfo="UPDATE `sc_c_userdetails` SET 
						`user_title`='$user_title',
						`family_name`='$family_name',
						`given_name`='$given_name',
						`nationality`='$nationality',
						`positionIn_company`='$positionIn_company',
						`company_name`='$company_name',
						`year_of_birth`='$year_of_birth',
						`direct_phone`='$general_phone',
						`direct_fax`='$direct_fax',
						`mobile_phone`='$mobile_phone',
						`direct_email`='$direct_email',
						`website`='$website'
				WHERE `userId`='$userId' ";

	} else{
	$personalInfo="UPDATE `sc_c_userdetails` SET 
						`user_title`='$user_title',
						`family_name`='$family_name',
						`given_name`='$given_name',
						`nationality`='$nationality',
						`positionIn_company`='$positionIn_company',
						`company_name`='$company_name',
						`year_of_birth`='$year_of_birth',
						`profile_picture`='$profile_picture',
						`general_phone`='$general_phone',
						`direct_fax`='$direct_fax',
						`mobile_phone`='$mobile_phone',
						`direct_email`='$direct_email',
						`website`='$website'
				WHERE `userId`='$userId' "; 
	}
	//echo $personalInfo; die;
	mysql_query($personalInfo);
	$inSql="DELETE FROM `sc_c_user_to_industry` WHERE `userId`='$userId'";
	mysql_query($inSql);
	if(!empty($_POST['industry'])){
	$industry_temp=$_POST['industry'];
	$industry_count=count($_POST['industry']); 
	for($j=0;$j<$industry_count;$j++){
		$insertindSql="INSERT INTO `sc_c_user_to_industry` (userId,industry_id) VALUES('$userId','$industry_temp[$j]')";
		mysql_query($insertindSql);
	}
	}
	//echo $personalInfo; die; 
	
	header('Location: membership.php');

}
?>