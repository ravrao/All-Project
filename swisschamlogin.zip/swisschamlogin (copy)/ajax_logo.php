<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
$company_id=$_POST['company_id'];
$logo_name="";
$updateCompany="UPDATE sc_c_company_details SET 
						logo_name='$logo_name'
						WHERE company_id='$company_id' "; 
mysql_query($updateCompany);
echo 1; exit();
?>