<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
mysql_query("SET character_set_client=utf8")or die(mysql_error());
mysql_query("SET character_set_connection=utf8")or die(mysql_error());
if($_POST){

    $admin_generated_userId=$_POST['admin_generated_userId'];
    $admin_generated_password=$_POST['admin_generated_password']; 
	
   
	
	if($admin_generated_userId == "admin" && $admin_generated_password=="abcd1234"){
		
		 $sqladmin = "SELECT * FROM sc_c_userdetails 
		                    WHERE admin_generated_userId='".$admin_generated_userId."' 
		                      AND admin_generated_password='".$admin_generated_password."'
		                      AND admin_approval='Yes'";
		
		$result = mysql_query($sqladmin); 
		$adminrow = mysql_fetch_array($result);
		
		$_SESSION["userId"] = $adminrow['userId'];
    	$_SESSION["family_name"] = $adminrow['family_name'];
    	$_SESSION["given_name"] = $adminrow['given_name'];
		header('Location: admin.php');
	}else{
		    $sql = "SELECT * FROM sc_c_userdetails 
		                    WHERE admin_generated_userId='".$admin_generated_userId."' 
		                      AND admin_generated_password='".$admin_generated_password."'
		                      AND admin_approval='Yes'";
		
		    $result = mysql_query($sql); 
		
		    $row = mysql_fetch_array($result);
                    
                    if($row['assignables_role']!='member_derectory')
                    {
		   
		    if(($row['admin_generated_userId']==$admin_generated_userId) && 
		    	($row['admin_generated_password']==$admin_generated_password)){
		
		    	$_SESSION["userId"] = $row['userId'];
		    	$_SESSION["family_name"] = $row['family_name'];
		    	$_SESSION["given_name"] = $row['given_name'];
			if(empty($_POST['uid'])){
                        require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
                    $creds = array(); 
                    $creds['user_login'] = $admin_generated_userId; 
                    $creds['user_password'] = $admin_generated_password; 
                    $creds['remember'] = true; 
                    $user = wp_signon( $creds, false ); 
                    //if ( is_wp_error($user) ) 
                        //echo $user->get_error_message(); 
					header('Location: membership.php');
				} else{
					if($_POST['uid']=='c'){
						header('Location: member_directory_general_page.php?p=1');
					} else{
						$id=$_POST['uid'];
						header("Location: member_directory.php?id=$id");
					}
				}
		    }else{
				if(empty($_POST['uid'])){
                                    //header('Location: online_application.php');     
                                    header('Location:'. $_SERVER['HTTP_REFERER'].'?loginerror=1');
                                    
                                    //echo '<meta http-equiv="refresh" content="0; url='.$_SERVER['HTTP_REFERER'].'?loginerror=1">';
                                    //echo '<script> alert("User ID And Password Wrong");</script>';
				} else{
					header('Location: member_directory_general_page.php?p=1');
				}
		    	
		    }
		
                    }
                    else {
                        $_SESSION["userId"] = $row['userId'];
                        $id=$_POST['uid'];
						
                        header("Location: member_directory_general_page.php");
                        
                    }
                 
                    
                }
  }
?>