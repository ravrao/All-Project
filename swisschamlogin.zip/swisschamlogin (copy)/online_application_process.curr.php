<?php
ini_set('display_errors', '1');

define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 
function check($rand1){
    $check="SELECT * FROM sc_c_userdetails
                     WHERE admin_generated_userId='$rand1'";
    $resultCheck = mysql_query($check); 
    $rowCheck = mysql_fetch_array($resultCheck);
    return $rowCheck;
}
function autoUserId(){
    $ch_seed = str_split('abcdefghijklmnopqrstuvwxyz'
                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                 .'0123456789!@#$%^&*()'); // and any other characters
    shuffle($ch_seed); // probably optional since array_is randomized; this may be redundant
    $rand1='';
    foreach (array_rand($ch_seed, 10) as $k1) $rand1 .= $ch_seed[$k1];
    $ck=check($rand1);
    if(empty($ck)){
        return $rand1;
    } else{
        autoUserId();
    }
}

if($_POST){
//echo "<pre/>";
//print_r($_POST); exit; 

/***Company information start***/
mysql_query("SET character_set_client=utf8")or die(mysql_error());
mysql_query("SET character_set_connection=utf8")or die(mysql_error());

$company_chamber='';
$company_membership='';
$swiss_invested='';
$company_have='';
$apply_for='';


//$string = str_replace("‐",",",$string);

if(!empty($_POST['company_chamber'])){
	$company_chamber=addslashes(str_replace("_"," ",$_POST['company_chamber']));
}

//-- company membership 

if(!empty($_POST['b_view_1'])){
	$company_membership=addslashes(str_replace("_"," ",$_POST['b_view_1']));
}
if(!empty($_POST['s_view_1'])){
	$company_membership=addslashes(str_replace("_"," ",$_POST['s_view_1']));
}
if(!empty($_POST['g_view_1'])){
	$company_membership=addslashes(str_replace("_"," ",$_POST['g_view_1']));
}
if(!empty($_POST['h_view_1'])){
	$company_membership=addslashes(str_replace("_"," ",$_POST['h_view_1']));
}
if(!empty($_POST['c_view_1'])){
	$company_membership=addslashes(str_replace("_"," ",$_POST['c_view_1']));
}


if(!empty($_POST['b_view_2'])){
	$swiss_invested=addslashes(str_replace("_"," ",$_POST['b_view_2']));
}
if(!empty($_POST['s_view_2'])){
	$swiss_invested=addslashes(str_replace("_"," ",$_POST['s_view_2']));
}
if(!empty($_POST['g_view_2'])){
	$swiss_invested=addslashes(str_replace("_"," ",$_POST['g_view_2']));
}
if(!empty($_POST['c_view_2'])){
	$swiss_invested=addslashes(str_replace("_"," ",$_POST['c_view_2']));
}
if(!empty($_POST['h_view_3'])){
	$swiss_invested=addslashes(str_replace("_"," ",$_POST['h_view_3']));
}

if(!empty($_POST['b_view_3'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['b_view_3']));
}
if(!empty($_POST['s_view_3'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['s_view_3']));
}
//if(!empty($_POST['g_view_5'])){
//	$company_have=addslashes(str_replace("_"," ",$_POST['g_view_5']));
      
//}
if(!empty($_POST['g_view_4'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['g_view_4']));
}
if(!empty($_POST['g_view_3'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['g_view_3']));
}
if(!empty($_POST['h_view_2'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['h_view_2']));
}
if(!empty($_POST['c_view_3'])){
	$company_have=addslashes(str_replace("_"," ",$_POST['c_view_3']));
}


if(!empty($_POST['b_view_4'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['b_view_4']));
}
if(!empty($_POST['b_view_5'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['b_view_5']));
}
if(!empty($_POST['s_view_5'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['s_view_5']));
}
if(!empty($_POST['h_view_3'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['h_view_3']));
}
if(!empty($_POST['h_view_4'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['h_view_4']));
}
if(!empty($_POST['c_view_4'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['c_view_4']));
}
if(!empty($_POST['g_view_5'])){
	$apply_for=addslashes(str_replace("_"," ",$_POST['g_view_5']));
}


$membership_fee='';
if(!empty($_POST['b_view_5'])){
	$membership_fee=addslashes(str_replace("_"," ",$_POST['b_view_5']));
}
if(!empty($_POST['s_view_3'])){
	$membership_fee=addslashes(str_replace("_"," ",$_POST['s_view_3']));
}


if(!empty($_POST['s_view_4'])){
	$mainland_china=addslashes(str_replace("_"," ",$_POST['s_view_4']));
} else{
        $mainland_china='';
}


/*company info start*/

if($company_membership == 'A company'){
	/* First Contact Details*/
	$npo_organization_type='';
	$npo_organization_description='';
	$media_type='';
	$media_description='';
	$user_title = isset($_REQUEST['company_first_contact_title'])?addslashes($_REQUEST['company_first_contact_title']):"";
	$year_of_birth = isset($_REQUEST['company_first_contact_dob'])?addslashes($_REQUEST['company_first_contact_dob']):"";
	//$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['company_first_contact_familyName'])?addslashes($_REQUEST['company_first_contact_familyName']):"";
	$given_name = isset($_REQUEST['company_first_contact_givenName'])?addslashes($_REQUEST['company_first_contact_givenName']):"";
	$chinese_name = isset($_REQUEST['company_first_contact_chineseName'])?addslashes($_REQUEST['company_first_contact_chineseName']):"";
	$nationality = isset($_REQUEST['company_first_contact_nationality'])?addslashes($_REQUEST['company_first_contact_nationality']):"";
	$positionIn_company = isset($_REQUEST['company_first_contact_position'])?addslashes($_REQUEST['company_first_contact_position']):"";
	
	$direct_phone = isset($_REQUEST['company_first_contact_direct_phone'])?addslashes($_REQUEST['company_first_contact_direct_phone']):"";
	$direct_email = isset($_REQUEST['company_first_contact_direct_email'])?addslashes($_REQUEST['company_first_contact_direct_email']):"";
	$mobile_phone = isset($_REQUEST['company_first_contact_mobile'])?addslashes($_REQUEST['company_first_contact_mobile']):"";
	
	/*Second Contact*/
	$other_contact_title = isset($_REQUEST['company_second_contact_person_title'])?addslashes($_REQUEST['company_second_contact_person_title']):"";
	$other_contact_dob = isset($_REQUEST['company_second_contact_person_dob'])?addslashes($_REQUEST['company_second_contact_person_dob']):"";
	//$other_contact_dob=date('Y-m-d',strtotime($other_contact_dob));
	$other_contact_familyName = isset($_REQUEST['company_second_contact_person_familyName'])?addslashes($_REQUEST['company_second_contact_person_familyName']):"";
	$other_contact_givenName = isset($_REQUEST['company_second_contact_person_givenName'])?addslashes($_REQUEST['company_second_contact_person_givenName']):"";
	$other_contact_chineseName = isset($_REQUEST['second_contact_person_chineseName'])?addslashes($_REQUEST['second_contact_person_chineseName']):"";
	$other_contact_nationality = isset($_REQUEST['company_second_contact_person_nationality'])?addslashes($_REQUEST['company_second_contact_person_nationality']):"";
	$other_contact_position = isset($_REQUEST['company_second_contact_position'])?addslashes($_REQUEST['company_second_contact_position']):"";
	$other_contact_address_english = isset($_REQUEST['company_second_contact_person_address_english'])?addslashes($_REQUEST['company_second_contact_person_address_english']):"";
	$other_contact_city_english = isset($_REQUEST['company_second_contact_person_city_english'])?addslashes($_REQUEST['company_second_contact_person_city_english']):"";
	$other_contact_province_area = isset($_REQUEST['company_second_contact_person_area'])?addslashes($_REQUEST['company_second_contact_person_area']):"";
	$other_contact_address_chinese = isset($_REQUEST['company_second_contact_person_address_chinese'])?addslashes($_REQUEST['company_second_contact_person_address_chinese']):"";
	$other_contact_city_chinese = isset($_REQUEST['company_second_contact_person_city_chinese'])?addslashes($_REQUEST['company_second_contact_person_city_chinese']):"";
	$other_contact_zipCode = isset($_REQUEST['company_second_contact_person_zipCode'])?addslashes($_REQUEST['company_second_contact_person_zipCode']):"";
	$other_contact_mobile = isset($_REQUEST['second_contact_person_mobile'])?addslashes($_REQUEST['second_contact_person_mobile']):"";
	$other_contact_directPhone = isset($_REQUEST['second_contact_person_directPhone'])?addslashes($_REQUEST['second_contact_person_directPhone']):"";
	$other_contact_directEmail = isset($_REQUEST['second_contact_person_directMail'])?addslashes($_REQUEST['second_contact_person_directMail']):"";
	
} else if($company_membership == 'NPO Journalist 500 RMB'){
	
	/* First Contact Details*/
	$npo_organization_type= isset($_REQUEST['npo_organization_type'])?addslashes($_REQUEST['npo_organization_type']):"";
	$npo_organization_description= isset($_REQUEST['npo_organization_description'])?addslashes($_REQUEST['npo_organization_description']):"";
	$media_type='';
	$media_description='';
	$user_title = isset($_REQUEST['npo_contact_title'])?addslashes($_REQUEST['npo_contact_title']):"";
	$year_of_birth = isset($_REQUEST['npo_contact_dob'])?addslashes($_REQUEST['npo_contact_dob']):"";
	//$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['npo_contact_familyName'])?addslashes($_REQUEST['npo_contact_familyName']):"";
	$given_name = isset($_REQUEST['npo_contact_givenName'])?addslashes($_REQUEST['npo_contact_givenName']):"";
	$chinese_name = isset($_REQUEST['npo_contact_chineseName'])?addslashes($_REQUEST['npo_contact_chineseName']):"";
	$nationality = isset($_REQUEST['npo_contact_Nationality'])?addslashes($_REQUEST['npo_contact_Nationality']):"";
	$positionIn_company = "";
	
	$zip_code_english = isset($_REQUEST['npo_contact_zip_chinese'])?addslashes($_REQUEST['npo_contact_zip_chinese']):"";
	$direct_phone = isset($_REQUEST['npo_contact_phone'])?addslashes($_REQUEST['npo_contact_phone']):"";
	$direct_email = isset($_REQUEST['npo_contact_email'])?addslashes($_REQUEST['npo_contact_email']):"";
	$mobile_phone = isset($_REQUEST['npo_contact_mobile'])?addslashes($_REQUEST['npo_contact_mobile']):"";
	
	/* Second Contact Details*/
	
	$other_contact_title = isset($_REQUEST['npo_second_contact_title'])?addslashes($_REQUEST['npo_second_contact_title']):"";
	$other_contact_dob = isset($_REQUEST['npo_second_contact_dob'])?addslashes($_REQUEST['npo_second_contact_dob']):"";
	//$other_contact_dob=date('Y-m-d',strtotime($other_contact_dob));
	$other_contact_familyName = isset($_REQUEST['npo_second_contact_familyName'])?addslashes($_REQUEST['npo_second_contact_familyName']):"";
	$other_contact_givenName = isset($_REQUEST['npo_second_contact_givenName'])?addslashes($_REQUEST['npo_second_contact_givenName']):"";
	$other_contact_chineseName = isset($_REQUEST['npo_second_contact_chineseName'])?addslashes($_REQUEST['npo_second_contact_chineseName']):"";
	$other_contact_nationality = isset($_REQUEST['npo_second_contact_nationality'])?addslashes($_REQUEST['npo_second_contact_nationality']):"";
	$other_contact_position = "";
	
	$other_contact_mobile = isset($_REQUEST['npo_second_contact_mobile'])?addslashes($_REQUEST['npo_second_contact_mobile']):"";
	$other_contact_directPhone = isset($_REQUEST['npo_second_contact_phone'])?addslashes($_REQUEST['npo_second_contact_phone']):"";
	$other_contact_directEmail = isset($_REQUEST['npo_second_contact_email'])?addslashes($_REQUEST['npo_second_contact_email']):"";
	
} else if($company_membership == 'An investment zone'){
	
	/* First Contact Details*/
	$npo_organization_type= "";
	$npo_organization_description= "";
	$media_type='';
	$media_description='';
	$user_title = isset($_REQUEST['investZone_contact_title'])?addslashes($_REQUEST['investZone_contact_title']):"";
	$year_of_birth = isset($_REQUEST['investZone_contact_dob'])?addslashes($_REQUEST['investZone_contact_dob']):"";
	//$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['investZone_contact_familyName'])?addslashes($_REQUEST['investZone_contact_familyName']):"";
	$given_name = isset($_REQUEST['investZone_contact_givenName'])?addslashes($_REQUEST['investZone_contact_givenName']):"";
	$chinese_name = isset($_REQUEST['investZone_contact_chineseName'])?addslashes($_REQUEST['investZone_contact_chineseName']):"";
	$nationality = isset($_REQUEST['investZone_contact_nationality'])?addslashes($_REQUEST['investZone_contact_nationality']):"";
	$positionIn_company = isset($_REQUEST['investZone_contact_position'])?addslashes($_REQUEST['investZone_contact_position']):"";
	
	$direct_phone = isset($_REQUEST['investZone_contact_directPhone'])?addslashes($_REQUEST['investZone_contact_directPhone']):"";
	$direct_email = isset($_REQUEST['investZone_contact_directEmail'])?addslashes($_REQUEST['investZone_contact_directEmail']):"";
	$mobile_phone = isset($_REQUEST['investZone_contact_mobile'])?addslashes($_REQUEST['investZone_contact_mobile']):"";
	
	/* Second Contact Details*/
	
	$other_contact_title = isset($_REQUEST['investZone_second_contact_title'])?addslashes($_REQUEST['investZone_second_contact_title']):"";
	$investZone_second_contact_dob = isset($_REQUEST['investZone_second_contact_dob'])?addslashes($_REQUEST['investZone_second_contact_dob']):"";
	//$other_contact_dob=date('Y-m-d',strtotime($investZone_second_contact_dob));
        $other_contact_dob=$investZone_second_contact_dob;
	$other_contact_familyName = isset($_REQUEST['investZone_second_contact_familyName'])?addslashes($_REQUEST['investZone_second_contact_familyName']):"";
	$other_contact_givenName = isset($_REQUEST['investZone_second_contact_givenName'])?addslashes($_REQUEST['investZone_second_contact_givenName']):"";
	$other_contact_chineseName = isset($_REQUEST['investZone_second_contact_chineseName'])?addslashes($_REQUEST['investZone_second_contact_chineseName']):"";
	$other_contact_nationality = isset($_REQUEST['investZone_second_contact_nationality'])?addslashes($_REQUEST['investZone_second_contact_nationality']):"";
	$other_contact_position = "";
	$other_contact_mobile = isset($_REQUEST['investZone_second_contact_mobile'])?addslashes($_REQUEST['investZone_second_contact_mobile']):"";
	$other_contact_directPhone = isset($_REQUEST['investZone_second_contact_phone'])?addslashes($_REQUEST['investZone_second_contact_phone']):"";
	$other_contact_directEmail = isset($_REQUEST['investZone_second_contact_email'])?addslashes($_REQUEST['investZone_second_contact_email']):"";
		
} else if($company_membership == 'An individual'){
	
	if($swiss_invested== 'journalist'){
	/* First Contact Details*/
	$npo_organization_type= "";
	$npo_organization_description= "";
	$media_type= isset($_REQUEST['media_type'])?addslashes($_REQUEST['media_type']):"";
	$media_description= isset($_REQUEST['media_description'])?addslashes($_REQUEST['media_description']):"";
	$user_title = isset($_REQUEST['journalist_contact_title'])?addslashes($_REQUEST['journalist_contact_title']):"";
	$year_of_birth = isset($_REQUEST['journalist_contact_dob'])?addslashes($_REQUEST['journalist_contact_dob']):"";
	//$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['journalist_contact_familyName'])?addslashes($_REQUEST['journalist_contact_familyName']):"";
	$given_name = isset($_REQUEST['journalist_contact_givenName'])?addslashes($_REQUEST['journalist_contact_givenName']):"";
	$chinese_name = isset($_REQUEST['journalist_contact_chineseName'])?addslashes($_REQUEST['journalist_contact_chineseName']):"";
	$nationality = isset($_REQUEST['journalist_contact_Nationality'])?addslashes($_REQUEST['journalist_contact_Nationality']):"";
	$positionIn_company = "";
	$direct_phone = isset($_REQUEST['journalist_contact_phone'])?addslashes($_REQUEST['journalist_contact_phone']):"";
	$mobile_phone = isset($_REQUEST['journalist_contact_mobile'])?addslashes($_REQUEST['journalist_contact_mobile']):"";
	$direct_email = isset($_REQUEST['journalist_contact_email'])?addslashes($_REQUEST['journalist_contact_email']):"";
	
	/* Second Contact Details*/
	
	$other_contact_title = isset($_REQUEST['journalist_second_contact_title'])?addslashes($_REQUEST['journalist_second_contact_title']):"";
	$journalist_second_contact_dob = isset($_REQUEST['journalist_second_contact_dob'])?addslashes($_REQUEST['journalist_second_contact_dob']):"";
	//$other_contact_dob=date('Y-m-d',strtotime($journalist_second_contact_dob));
        $other_contact_dob=$journalist_second_contact_dob;
	$other_contact_familyName = isset($_REQUEST['journalist_second_contact_familyName'])?addslashes($_REQUEST['journalist_second_contact_familyName']):"";
	$other_contact_givenName = isset($_REQUEST['journalist_second_contact_givenName'])?addslashes($_REQUEST['journalist_second_contact_givenName']):"";
	$other_contact_chineseName = isset($_REQUEST['journalist_second_contact_chineseName'])?addslashes($_REQUEST['journalist_second_contact_chineseName']):"";
	$other_contact_nationality = isset($_REQUEST['journalist_second_contact_nationality'])?addslashes($_REQUEST['journalist_second_contact_nationality']):"";
	$other_contact_position = "";
	$other_contact_mobile = isset($_REQUEST['journalist_second_contact_mobile'])?addslashes($_REQUEST['journalist_second_contact_mobile']):"";
	$other_contact_directPhone = isset($_REQUEST['journalist_second_contact_phone'])?addslashes($_REQUEST['journalist_second_contact_phone']):"";
	$other_contact_directEmail = isset($_REQUEST['journalist_second_contact_email'])?addslashes($_REQUEST['journalist_second_contact_email']):"";

} else{

	/* First Contact Details*/
	$npo_organization_type= "";
	$npo_organization_description= "";
	$media_type='';
	$media_description='';
	$user_title = isset($_REQUEST['individual_contact_title'])?addslashes($_REQUEST['individual_contact_title']):"";
	$year_of_birth = isset($_REQUEST['individual_contact_dob'])?addslashes($_REQUEST['individual_contact_dob']):"";
	//$year_of_birth=date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['individual_contact_familyName'])?addslashes($_REQUEST['individual_contact_familyName']):"";
	$given_name = isset($_REQUEST['individual_contact_givenName'])?addslashes($_REQUEST['individual_contact_givenName']):"";
	$chinese_name = isset($_REQUEST['individual_contact_chineseName'])?addslashes($_REQUEST['individual_contact_chineseName']):"";
	$nationality = isset($_REQUEST['individual_contact_Nationality'])?addslashes($_REQUEST['individual_contact_Nationality']):"";
	$positionIn_company = "";
        $address_english = isset($_REQUEST['individual_contact_address_english'])?addslashes($_REQUEST['individual_contact_address_english']):"";
	$city_english = isset($_REQUEST['individual_contact_city_english'])?addslashes($_REQUEST['individual_contact_city_english']):"";
	$province_area = isset($_REQUEST['individual_contact_province_area'])?addslashes($_REQUEST['individual_contact_province_area']):"";
	$address_chinese = isset($_REQUEST['individual_contact_address_chinese'])?addslashes($_REQUEST['individual_contact_address_chinese']):"";
	$city_chinese = isset($_REQUEST['individual_contact_city_chinese'])?addslashes($_REQUEST['individual_contact_city_chinese']):"";
	$zip_code_english = isset($_REQUEST['individual_contact_zip_chinese'])?addslashes($_REQUEST['individual_contact_zip_chinese']):"";
        
	$direct_phone = isset($_REQUEST['individual_contact_directPhone'])?addslashes($_REQUEST['individual_contact_directPhone']):"";
	$direct_email = isset($_REQUEST['individual_contact_email'])?addslashes($_REQUEST['individual_contact_email']):"";
	$mobile_phone = isset($_REQUEST['individual_contact_phone'])?addslashes($_REQUEST['individual_contact_phone']):"";
	
	/* Second Contact Details*/
	
	$other_contact_title = isset($_REQUEST['individual_second_contact_title'])?addslashes($_REQUEST['individual_second_contact_title']):"";
	$other_contact_dob = isset($_REQUEST['individual_second_contact_dob'])?addslashes($_REQUEST['individual_second_contact_dob']):"";
	//$other_contact_dob=date('Y-m-d',strtotime($other_contact_dob));
	$other_contact_familyName = isset($_REQUEST['individual_second_contact_familyName'])?addslashes($_REQUEST['individual_second_contact_familyName']):"";
	$other_contact_givenName = isset($_REQUEST['individual_second_contact_givenName'])?addslashes($_REQUEST['individual_second_contact_givenName']):"";
	$other_contact_chineseName = isset($_REQUEST['individual_second_contact_chineseName'])?addslashes($_REQUEST['individual_second_contact_chineseName']):"";
	$other_contact_nationality = isset($_REQUEST['individual_second_contact_Nationality'])?addslashes($_REQUEST['individual_second_contact_Nationality']):"";
	$other_contact_position = isset($_REQUEST['individual_second_contact_position'])?addslashes($_REQUEST['individual_second_contact_position']):"";
	$other_contact_mobile = isset($_REQUEST['individual_second_contact_mobile'])?addslashes($_REQUEST['individual_second_contact_mobile']):"";
	$other_contact_directPhone = isset($_REQUEST['individual_second_contact_phone'])?addslashes($_REQUEST['individual_second_contact_phone']):"";
	$other_contact_directEmail = isset($_REQUEST['individual_second_contact_email'])?addslashes($_REQUEST['individual_second_contact_email']):"";
	
      }
		
}


if($company_membership == 'A company'){

  $userFirstContactDetailsAql = "INSERT INTO `sc_c_userdetails`
				SET `user_title`='".$user_title."',
					 `npo_organization_description`='".$npo_organization_description."',
					 `npo_organization_type`='".$npo_organization_type."',
					 `media_type`='".$media_type."',
					 `media_description`='".$media_description."',
					 `year_of_birth`='".$year_of_birth."',
					 `family_name`='".$family_name."',
					 `given_name`='".$given_name."',
					 `chinese_name`='".$chinese_name."',
					 `nationality`='".$nationality."',
					 `positionIn_company`='".$positionIn_company."',
					 `direct_phone`='".$direct_phone."',
					 `mobile_phone`='".$mobile_phone."',
					 `direct_email`='".$direct_email."',
                                         `assignables_role`='company_holder'"; 

        mysql_query($userFirstContactDetailsAql);

	$last_id=mysql_insert_id();

	  $userSecondContactDetailsAql = "INSERT INTO `sc_c_other_contact`
					 SET `userId`='".$last_id."',
					  `other_contact_title`='".$other_contact_title."',
					  `other_contact_dob`='".$other_contact_dob."',
					  `other_contact_familyName`='".$other_contact_familyName."',
					  `other_contact_givenName`='".$other_contact_givenName."',
					  `other_contact_chineseName`='".$other_contact_chineseName."',
					  `other_contact_nationality`='".$other_contact_nationality."',
					  `other_contact_position`='".$other_contact_position."',
					  `other_contact_mobile`='".$other_contact_mobile."',
					  `other_contact_directPhone`='".$other_contact_directPhone."',
					  `other_contact_directEmail`='".$other_contact_directEmail."',
                                          `assignables_role`='company_member'";
         
	mysql_query($userSecondContactDetailsAql);
        
        
        // 2nd phase developer insert Contect 1 Data in sc_c_userdetails table //
        $created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
					 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
					 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	$admin_generated_userId= autoUserId(); 
	$admin_generated_userId; 
	$admin_generated_password= $rand;  
        $userFirstContactDetailsAql_inusertable = "INSERT INTO `sc_c_userdetails`
                                          SET `other_contect_userid`='".$last_id."',
                                         `user_title`='".$other_contact_title."',
					 `year_of_birth`='".$other_contact_dob."',
					 `family_name`='".$other_contact_familyName."',
					 `given_name`='".$other_contact_givenName."',
					 `chinese_name`='".$other_contact_chineseName."',
					 `nationality`='".$other_contact_nationality."',
					 `positionIn_company`='".$other_contact_position."',
					 `direct_phone`='".$other_contact_directPhone."',
					 `mobile_phone`='".$other_contact_mobile."',
					 `direct_email`='".$other_contact_directEmail."',
                                             
                                         `admin_generated_userId`='".$admin_generated_userId."',
                                         `admin_generated_password`='".$admin_generated_password."',    
                                          `created_date`='".$created_date."',   
                                         `assignables_role`='company_member'"; 

        mysql_query($userFirstContactDetailsAql_inusertable);


}
else{ 

	   $userFirstContactDetailsAql = "INSERT INTO `sc_c_userdetails`
					 SET `user_title`='".$user_title."',
						`npo_organization_description`='".$npo_organization_description."',
						`npo_organization_type`='".$npo_organization_type."',
						`media_type`='".$media_type."',
						`media_description`='".$media_description."',
						`year_of_birth`='".$year_of_birth."',
						`family_name`='".$family_name."',
						`given_name`='".$given_name."',
						`chinese_name`='".$chinese_name."',
						`nationality`='".$nationality."',
						`positionIn_company`='".$positionIn_company."',
                                                `address_english`='".$address_english."',
						`city_english`='".$city_english."',
						`province_area`='".$province_area."',
						`address_chinese`='".$address_chinese."',
						`city_chinese`='".$city_chinese."',
						`zip_code_english`='".$zip_code_english."',    
						`direct_phone`='".$direct_phone."',
						`mobile_phone`='".$mobile_phone."',
						`direct_email`='".$direct_email."'"; 
	mysql_query($userFirstContactDetailsAql);

	$last_id=mysql_insert_id();

	$userSecondContactDetailsAql = "INSERT INTO `sc_c_other_contact`
					 SET `userId`='".$last_id."',
					 `other_contact_title`='".$other_contact_title."',
					 `other_contact_dob`='".$other_contact_dob."',
					 `other_contact_familyName`='".$other_contact_familyName."',
					 `other_contact_givenName`='".$other_contact_givenName."',
					 `other_contact_chineseName`='".$other_contact_chineseName."',
					 `other_contact_nationality`='".$other_contact_nationality."',
					 `other_contact_position`='".$other_contact_position."',
					 `other_contact_mobile`='".$other_contact_mobile."',
					 `other_contact_directPhone`='".$other_contact_directPhone."',
					 `other_contact_directEmail`='".$other_contact_directEmail."'";

	mysql_query($userSecondContactDetailsAql);
        
         
        // 2nd phase developer insert Contect 1 Data in sc_c_userdetails table //
        
        $userSecondContactDetailsAql_inusertable = "INSERT INTO `sc_c_userdetails`
                                          SET `other_contect_userid`='".$last_id."',
                                         `user_title`='".$other_contact_title."',
					 `year_of_birth`='".$other_contact_dob."',
					 `family_name`='".$other_contact_familyName."',
					 `given_name`='".$other_contact_givenName."',
					 `chinese_name`='".$other_contact_chineseName."',
					 `nationality`='".$other_contact_nationality."',
					 `positionIn_company`='".$other_contact_position."',
					 `direct_phone`='".$other_contact_directPhone."',
					 `mobile_phone`='".$other_contact_mobile."',
					 direct_email`='".$other_contact_directEmail."',
                                         `admin_generated_userId`='".$admin_generated_userId."',
                                         `admin_generated_password`='".$admin_generated_password."',    
                                          `created_date`='".$created_date."'";
                                         

        mysql_query($userSecondContactDetailsAql_inusertable);

}

	$created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
					 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
					 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	$admin_generated_userId= autoUserId(); 
	$admin_generated_userId; 
	$admin_generated_password= $rand;    
	$userUpdateSql = "UPDATE `sc_c_userdetails`
			SET `created_by`='".$last_id."',
				`admin_generated_userId`='".$admin_generated_userId."',
				`admin_generated_password`='".$admin_generated_password."',
				`created_date`='".$created_date."'
				WHERE `userId`='".$last_id."'"; 
	mysql_query($userUpdateSql);

	/*other contact insert*/

	if($company_membership == 'A company'){
		$ct=count($_POST['other_contact_familyNamec']);
		for($i=0;$i<$ct;$i++){
			$j=$i+1;
		$userId=$last_id;
		$other_contact_title=addslashes($_POST['other_contact_titlec'.$i]);
		$other_contact_dob = isset($_POST['other_contact_dobc'][$i])?addslashes($_POST['other_contact_dobc'][$i]):"";
		//$other_contact_dob=date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName=addslashes($_POST['other_contact_familyNamec'][$i]);
		$other_contact_givenName=addslashes($_POST['other_contact_givenNamec'][$i]);
		$other_contact_chineseName=addslashes($_POST['other_contact_chineseNamec'][$i]);
		$other_contact_nationality=addslashes($_POST['other_contact_nationalityc'.$i]);
		$other_contact_position=addslashes($_POST['other_contact_positionc'][$i]);
		$other_contact_mobile=addslashes($_POST['other_contact_mobilec'][$i]);
		$other_contact_directPhone=addslashes($_POST['other_contact_directPhonec'][$i]);
		$other_contact_directEmail=addslashes($_POST['other_contact_directEmailc'][$i]);

		$userotherContactDetailsAql = "INSERT INTO `sc_c_other_contact`
						SET `userId`='".$last_id."',
						 `other_contact_title`='".$other_contact_title."',
                                                 `other_contact_dob`='".$other_contact_dob."',    
						 `other_contact_familyName`='".$other_contact_familyName."',
						 `other_contact_givenName`='".$other_contact_givenName."',
						 `other_contact_chineseName`='".$other_contact_chineseName."',
						 `other_contact_nationality`='".$other_contact_nationality."',
						 `other_contact_position`='".$other_contact_position."',
						 `other_contact_mobile`='".$other_contact_mobile."',
						 `other_contact_directPhone`='".$other_contact_directPhone."',
						 `other_contact_directEmail`='".$other_contact_directEmail."',
                                                 `assignables_role`='company_member'";

		mysql_query($userotherContactDetailsAql);
                
                
                
                
                 // 2nd phase developer insert Contect 1 Data in sc_c_userdetails table // 
                
                
                $created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
					 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
					 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	$admin_generated_userId= autoUserId(); 
	$admin_generated_userId; 
	$admin_generated_password= $rand;            
        
         $userFirstContactDetailsAql_inusertable_second = "INSERT INTO `sc_c_userdetails`
                                          SET `other_contect_userid`='".$last_id."',
                                         `user_title`='".$other_contact_title."',
					 `year_of_birth`='".$other_contact_dob."',
					 `family_name`='".$other_contact_familyName."',
					 `given_name`='".$other_contact_givenName."',
					 `chinese_name`='".$other_contact_chineseName."',
					 `nationality`='".$other_contact_nationality."',
					 `positionIn_company`='".$other_contact_position."',
					 `direct_phone`='".$other_contact_directPhone."',
					 `mobile_phone`='".$other_contact_mobile."',
					 `direct_email`='".$other_contact_directEmail."',
                                         `admin_generated_userId`='".$admin_generated_userId."',
                                         `admin_generated_password`='".$admin_generated_password."',    
                                         `created_date`='".$created_date."',   
                                          `assignables_role`='company_member'";
                                         

        mysql_query($userFirstContactDetailsAql_inusertable_second);

		}

	} else{
		$ct=count($_POST['other_contact_familyName']);
		for($i=0;$i<$ct;$i++){
			$j=$i+1;
		$userId=$last_id;
		$other_contact_title=addslashes($_POST['other_contact_title'.$i]);
		$other_contact_dob = isset($_POST['other_contact_dob'][$i])?addslashes($_POST['other_contact_dob'][$i]):"";
		//$other_contact_dob=date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName=addslashes($_POST['other_contact_familyName'][$i]);
		$other_contact_givenName=addslashes($_POST['other_contact_givenName'][$i]);
		$other_contact_chineseName=addslashes($_POST['other_contact_chineseName'][$i]);
		$other_contact_nationality=addslashes($_POST['other_contact_nationality'.$i]);
		$other_contact_position=addslashes($_POST['other_contact_position'][$i]);
		$other_contact_mobile=addslashes($_POST['other_contact_mobile'][$i]);
		$other_contact_directPhone=addslashes($_POST['other_contact_directPhone'][$i]);
		$other_contact_directEmail=addslashes($_POST['other_contact_directEmail'][$i]);
                 $userotherContactDetailsAql = "INSERT INTO `sc_c_other_contact`
						SET `userId`='".$last_id."',
						 `other_contact_title`='".$other_contact_title."',
                                                  `other_contact_dob`='".$other_contact_dob."',   
                                                  `other_contact_familyName`='".$other_contact_familyName."',
						 `other_contact_givenName`='".$other_contact_givenName."',
						 `other_contact_chineseName`='".$other_contact_chineseName."',
						 `other_contact_nationality`='".$other_contact_nationality."',
						 `other_contact_position`='".$other_contact_position."',
						 `other_contact_mobile`='".$other_contact_mobile."',
						 `other_contact_directPhone`='".$other_contact_directPhone."',
						 `other_contact_directEmail`='".$other_contact_directEmail."',
                                                 `assignables_role`='company_member'";
		
                mysql_query($userotherContactDetailsAql);
                
                
        // 2nd phase developer insert Contect 1 Data in sc_c_userdetails table //
                
        $created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
					 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
					 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	$admin_generated_userId= autoUserId(); 
	$admin_generated_userId; 
	$admin_generated_password= $rand;            
        
         $userFirstContactDetailsAql_inusertable_second = "INSERT INTO `sc_c_userdetails`
                                          SET `other_contect_userid`='".$last_id."',
                                         `user_title`='".$other_contact_title."',
					 `year_of_birth`='".$other_contact_dob."',
					 `family_name`='".$other_contact_familyName."',
					 `given_name`='".$other_contact_givenName."',
					 `chinese_name`='".$other_contact_chineseName."',
					 `nationality`='".$other_contact_nationality."',
					 `positionIn_company`='".$other_contact_position."',
					 `direct_phone`='".$other_contact_directPhone."',
					 `mobile_phone`='".$other_contact_mobile."',
					 `direct_email`='".$other_contact_directEmail."',
                                         `admin_generated_userId`='".$admin_generated_userId."',
                                         `admin_generated_password`='".$admin_generated_password."',    
                                         `created_date`='".$created_date."'";
                                         

        mysql_query($userFirstContactDetailsAql_inusertable_second);
                
	}
	}
	$business_scope='';
	$other_business_scope='';
	$business_description_english='';
	$business_description_chinese='';
	$company_name_english='';
	$company_name_chinese='';
	$company_address='';
	$company_city='';
	$province_area_english='';
	$china_office_address='';
	$china_office_city='';
	$company_zipCode='';
	$company_generalPhone='';
	$company_email='';
	$company_website='';
	$legal_entity='';
	$no_of_employees='';
	$is_company_swiss_registered='';
	$is_company_registered_PRC='';
	$establishment_hongkong='';
	$geographical_responsibility_hongkong='';
	$headquarter_name='';
	$headquarter_address='';
	$headquarter_city='';
	$headquarter_zipCode='';
	$headquarter_phone='';
	$logo_name='';
	if($company_membership == 'A company'){
		$business_scope = isset($_REQUEST['business_scope'])?addslashes($_REQUEST['business_scope']):"";
		$other_business_scope = isset($_REQUEST['other_business_scope'])?addslashes($_REQUEST['other_business_scope']):"";
		$business_description_english = isset($_REQUEST['business_description_english'])?addslashes($_REQUEST['business_description_english']):"";
		$business_description_chinese = isset($_REQUEST['business_description_chinese'])?addslashes($_REQUEST['business_description_chinese']):"";
		$company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
		$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
		$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
		$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
		$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
		$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
		$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
		$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
		$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
		$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
		$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
		$legal_entity = isset($_REQUEST['legal_entity'])?addslashes($_REQUEST['legal_entity']):"";
		$no_of_employees = isset($_REQUEST['no_of_employees'])?addslashes($_REQUEST['no_of_employees']):"";
		
		if($company_chamber=='HongKong'){
		$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
		$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";	
		} else{
		$is_company_swiss_registered = isset($_REQUEST['is_company_swiss_registered'])?addslashes($_REQUEST['is_company_swiss_registered']):"";
		$is_company_registered_PRC = isset($_REQUEST['is_company_registered_PRC'])?addslashes($_REQUEST['is_company_registered_PRC']):"";
		}
		
		
		$headquarter_name = isset($_REQUEST['headquarter_name'])?addslashes($_REQUEST['headquarter_name']):"";
		$headquarter_address = isset($_REQUEST['headquarter_address'])?addslashes($_REQUEST['headquarter_address']):"";
		$headquarter_city = isset($_REQUEST['headquarter_city'])?addslashes($_REQUEST['headquarter_city']):"";
		$headquarter_zipCode = isset($_REQUEST['headquarter_zipCode'])?addslashes($_REQUEST['headquarter_zipCode']):"";
		$headquarter_phone = isset($_REQUEST['headquarter_phone'])?addslashes($_REQUEST['headquarter_phone']):"";
		$headquarter_province_area_english = isset($_REQUEST['headquarter_province_area_english'])?addslashes($_REQUEST['headquarter_province_area_english']):"";
		
		$company_chamber = $company_chamber;
		$company_membership = $company_membership;
		$swiss_invested = $swiss_invested;
		$company_have = $company_have;
		$apply_for = $apply_for;
		$membership_fee = $membership_fee;
		$mainland_china = $mainland_china;
		if((isset($_FILES['logo_name']['name'])) && (!empty($_FILES['logo_name']['name']))){
		  $errors= array();
		  $file_name = $_FILES['logo_name']['name'];
		  $file_size =$_FILES['logo_name']['size'];
		  $file_tmp =$_FILES['logo_name']['tmp_name'];
		  $file_type=$_FILES['logo_name']['type'];
		  $file_ext=strtolower(end(explode('.',$_FILES['logo_name']['name'])));
		  
		  $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
		 
		  if(in_array($file_ext,$expensions)=== false){
			 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  }
		  
		  if($file_size > 2097152){
			 $errors[]='File size must be excately 2 MB';
		  }
		  $file_name="logo_name".time().$file_ext;
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 $logo_name="uploads/".$file_name; 
		  }else{
			 print_r($errors);
			 header('Location: online_application.php');
		  }
	   } else{
		   $logo_name="";
	   }
	} else if($company_membership == 'NPO Journalist 500 RMB'){
		$business_scope = "";
		$other_business_scope = isset($_REQUEST['other_business_scope'])?addslashes($_REQUEST['other_business_scope']):"";
		$business_description_english = isset($_REQUEST['business_description_english'])?addslashes($_REQUEST['business_description_english']):"";
		$business_description_chinese = isset($_REQUEST['business_description_chinese'])?addslashes($_REQUEST['business_description_chinese']):"";
		$company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
		$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
		$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
		$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
		$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
		$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
		$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
		$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
		$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
		$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
		$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
		$legal_entity = isset($_REQUEST['legal_entity'])?addslashes($_REQUEST['legal_entity']):"";
		$no_of_employees = isset($_REQUEST['no_of_employees'])?addslashes($_REQUEST['no_of_employees']):"";
		
		if($company_chamber=='HongKong'){
		$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
		$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";	
		} else{
		$is_company_swiss_registered = isset($_REQUEST['is_company_swiss_registered'])?addslashes($_REQUEST['is_company_swiss_registered']):"";
		$is_company_registered_PRC = isset($_REQUEST['is_company_registered_PRC'])?addslashes($_REQUEST['is_company_registered_PRC']):"";
		}
		
		
		$headquarter_name = isset($_REQUEST['headquarter_name'])?addslashes($_REQUEST['headquarter_name']):"";
		$headquarter_address = isset($_REQUEST['headquarter_address'])?addslashes($_REQUEST['headquarter_address']):"";
		$headquarter_city = isset($_REQUEST['headquarter_city'])?addslashes($_REQUEST['headquarter_city']):"";
		$headquarter_zipCode = isset($_REQUEST['headquarter_zipCode'])?addslashes($_REQUEST['headquarter_zipCode']):"";
		$headquarter_phone = isset($_REQUEST['headquarter_phone'])?addslashes($_REQUEST['headquarter_phone']):"";
		$headquarter_province_area_english = isset($_REQUEST['headquarter_province_area_english'])?addslashes($_REQUEST['headquarter_province_area_english']):"";
		
		$company_chamber = $company_chamber;
		$company_membership = $company_membership;
		$swiss_invested = $swiss_invested;
		$company_have = $company_have;
		$apply_for = $apply_for;
		$membership_fee = $membership_fee;
		$mainland_china = $mainland_china;
		if((isset($_FILES['logo_name']['name'])) && (!empty($_FILES['logo_name']['name']))){
		  $errors= array();
		  $file_name = $_FILES['logo_name']['name'];
		  $file_size =$_FILES['logo_name']['size'];
		  $file_tmp =$_FILES['logo_name']['tmp_name'];
		  $file_type=$_FILES['logo_name']['type'];
		  $file_ext=strtolower(end(explode('.',$_FILES['logo_name']['name'])));
		  
		  $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
		 
		  if(in_array($file_ext,$expensions)=== false){
			 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  }
		  
		  if($file_size > 2097152){
			 $errors[]='File size must be excately 2 MB';
		  }
		  $file_name="logo_name".time().$file_ext;
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 $logo_name="uploads/".$file_name; 
		  }else{
			 print_r($errors);
			 header('Location: online_application.php');
		  }
	   } else{
		   $logo_name="";
	   }
	} else if($company_membership == 'An investment zone'){
		$business_scope = "";
		$other_business_scope = isset($_REQUEST['other_business_scope'])?addslashes($_REQUEST['other_business_scope']):"";
		$business_description_english = isset($_REQUEST['business_description_english'])?addslashes($_REQUEST['business_description_english']):"";
		$business_description_chinese = isset($_REQUEST['business_description_chinese'])?addslashes($_REQUEST['business_description_chinese']):"";
		$company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
		$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
		$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
		$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
		$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
		$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
		$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
		$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
		$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
		$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
		$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
		$legal_entity = isset($_REQUEST['legal_entity'])?addslashes($_REQUEST['legal_entity']):"";
		$no_of_employees = isset($_REQUEST['no_of_employees'])?addslashes($_REQUEST['no_of_employees']):"";
		
		if($company_chamber=='HongKong'){
		$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
		$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";	
		} else{
		$is_company_swiss_registered = isset($_REQUEST['is_company_swiss_registered'])?addslashes($_REQUEST['is_company_swiss_registered']):"";
		$is_company_registered_PRC = isset($_REQUEST['is_company_registered_PRC'])?addslashes($_REQUEST['is_company_registered_PRC']):"";
		}
		
		
		$headquarter_name = isset($_REQUEST['headquarter_name'])?addslashes($_REQUEST['headquarter_name']):"";
		$headquarter_address = isset($_REQUEST['headquarter_address'])?addslashes($_REQUEST['headquarter_address']):"";
		$headquarter_city = isset($_REQUEST['headquarter_city'])?addslashes($_REQUEST['headquarter_city']):"";
		$headquarter_zipCode = isset($_REQUEST['headquarter_zipCode'])?addslashes($_REQUEST['headquarter_zipCode']):"";
		$headquarter_phone = isset($_REQUEST['headquarter_phone'])?addslashes($_REQUEST['headquarter_phone']):"";
		$headquarter_province_area_english = isset($_REQUEST['headquarter_province_area_english'])?addslashes($_REQUEST['headquarter_province_area_english']):"";
		
		$company_chamber = $company_chamber;
		$company_membership = $company_membership;
		$swiss_invested = $swiss_invested;
		$company_have = $company_have;
		$apply_for = $apply_for;
		$membership_fee = $membership_fee;
		$mainland_china = $mainland_china;
		if((isset($_FILES['logo_name']['name'])) && (!empty($_FILES['logo_name']['name']))){
		  $errors= array();
		  $file_name = $_FILES['logo_name']['name'];
		  $file_size =$_FILES['logo_name']['size'];
		  $file_tmp =$_FILES['logo_name']['tmp_name'];
		  $file_type=$_FILES['logo_name']['type'];
		  $file_ext=strtolower(end(explode('.',$_FILES['logo_name']['name'])));
		  
		  $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
		 
		  if(in_array($file_ext,$expensions)=== false){
			 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  }
		  
		  if($file_size > 2097152){
			 $errors[]='File size must be excately 2 MB';
		  }
		  $file_name="logo_name".time().$file_ext;
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 $logo_name="uploads/".$file_name; 
		  }else{
			 print_r($errors);
			 header('Location: online_application.php');
		  }
	   } else{
		   $logo_name="";
	   }
	} else if($company_membership == 'An individual'){
		if($swiss_invested== 'journalist'){
		$business_scope = isset($_REQUEST['business_scope'])?addslashes($_REQUEST['business_scope']):"";
		$other_business_scope = isset($_REQUEST['other_business_scope'])?addslashes($_REQUEST['other_business_scope']):"";
		$business_description_english = isset($_REQUEST['business_description_english'])?addslashes($_REQUEST['business_description_english']):"";
		$business_description_chinese = isset($_REQUEST['business_description_chinese'])?addslashes($_REQUEST['business_description_chinese']):"";
		$company_name_english = isset($_REQUEST['company_name_english'])?addslashes($_REQUEST['company_name_english']):"";
		$company_name_chinese = isset($_REQUEST['company_name_chinese'])?addslashes($_REQUEST['company_name_chinese']):"";
		$company_address = isset($_REQUEST['company_address'])?addslashes($_REQUEST['company_address']):"";
		$company_city = isset($_REQUEST['company_city'])?addslashes($_REQUEST['company_city']):"";
		$province_area_english = isset($_REQUEST['province_area_english'])?addslashes($_REQUEST['province_area_english']):"";
		$china_office_address = isset($_REQUEST['china_office_address'])?addslashes($_REQUEST['china_office_address']):"";
		$china_office_city = isset($_REQUEST['china_office_city'])?addslashes($_REQUEST['china_office_city']):"";
		$company_zipCode = isset($_REQUEST['company_zipCode'])?addslashes($_REQUEST['company_zipCode']):"";
		$company_generalPhone = isset($_REQUEST['company_generalPhone'])?addslashes($_REQUEST['company_generalPhone']):"";
		$company_email = isset($_REQUEST['company_email'])?addslashes($_REQUEST['company_email']):"";
		$company_website = isset($_REQUEST['company_website'])?addslashes($_REQUEST['company_website']):"";
		$legal_entity = isset($_REQUEST['legal_entity'])?addslashes($_REQUEST['legal_entity']):"";
		$no_of_employees = isset($_REQUEST['no_of_employees'])?addslashes($_REQUEST['no_of_employees']):"";
		
		if($company_chamber=='HongKong'){
		$establishment_hongkong = isset($_REQUEST['establishment_hongkong'])?addslashes($_REQUEST['establishment_hongkong']):"";
		$geographical_responsibility_hongkong = isset($_REQUEST['geographical_responsibility_hongkong'])?addslashes($_REQUEST['geographical_responsibility_hongkong']):"";	
		} else{
		$is_company_swiss_registered = isset($_REQUEST['is_company_swiss_registered'])?addslashes($_REQUEST['is_company_swiss_registered']):"";
		$is_company_registered_PRC = isset($_REQUEST['is_company_registered_PRC'])?addslashes($_REQUEST['is_company_registered_PRC']):"";
		}
		
		
		$headquarter_name = isset($_REQUEST['headquarter_name'])?addslashes($_REQUEST['headquarter_name']):"";
		$headquarter_address = isset($_REQUEST['headquarter_address'])?addslashes($_REQUEST['headquarter_address']):"";
		$headquarter_city = isset($_REQUEST['headquarter_city'])?addslashes($_REQUEST['headquarter_city']):"";
		$headquarter_zipCode = isset($_REQUEST['headquarter_zipCode'])?addslashes($_REQUEST['headquarter_zipCode']):"";
		$headquarter_phone = isset($_REQUEST['headquarter_phone'])?addslashes($_REQUEST['headquarter_phone']):"";
		$headquarter_province_area_english = isset($_REQUEST['headquarter_province_area_english'])?addslashes($_REQUEST['headquarter_province_area_english']):"";
		
		$company_chamber = $company_chamber;
		$company_membership = $company_membership;
		$swiss_invested = $swiss_invested;
		$company_have = $company_have;
		$apply_for = $apply_for;
		$membership_fee = $membership_fee;
		$mainland_china = $mainland_china;
		if((isset($_FILES['logo_name']['name'])) && (!empty($_FILES['logo_name']['name']))){
		  $errors= array();
		  $file_name = $_FILES['logo_name']['name'];
		  $file_size =$_FILES['logo_name']['size'];
		  $file_tmp =$_FILES['logo_name']['tmp_name'];
		  $file_type=$_FILES['logo_name']['type'];
		  $file_ext=strtolower(end(explode('.',$_FILES['logo_name']['name'])));
		  
		  $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
		 
		  if(in_array($file_ext,$expensions)=== false){
			 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  }
		  
		  if($file_size > 2097152){
			 $errors[]='File size must be excately 2 MB';
		  }
		  $file_name="logo_name".time().$file_ext;
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 $logo_name="uploads/".$file_name; 
		  }else{
			 print_r($errors);
			 header('Location: online_application.php');
		  }
		   } else{
			   $logo_name="";
		   }
		} else{
		$business_scope='';
		$other_business_scope='';
		$business_description_english='';
		$business_description_chinese='';
		$company_name_english='';
		$company_name_chinese='';
		$company_address='';
		$company_city='';
		$province_area_english='';
		$china_office_address='';
		$china_office_city='';
		$company_zipCode='';
		$company_generalPhone='';
		$company_email='';
		$company_website='';
		$legal_entity='';
		$no_of_employees='';
		$is_company_swiss_registered='';
		$is_company_registered_PRC='';
		$establishment_hongkong='';
		$geographical_responsibility_hongkong='';
		$headquarter_name='';
		$headquarter_address='';
		$headquarter_city='';
		$headquarter_zipCode='';
		$headquarter_phone='';
		$headquarter_province_area_english = "";
		$logo_name='';
		}
	}
	 $companyDetailsSql = "INSERT INTO `sc_c_company_details`
				SET `userId`='".$last_id."',
				 `business_scope`='".$business_scope."',
				 `other_business_scope`='".$other_business_scope."',
				 `business_description_english`='".$business_description_english."',
				 `business_description_chinese`='".$business_description_chinese."',
				 `company_name_english`='".$company_name_english."',
				 `company_name_chinese`='".$company_name_chinese."',
				 `company_address`='".$company_address."',
				 `company_city`='".$company_city."',
				 `province_area_english`='".$province_area_english."',
				 `china_office_address`='".$china_office_address."',
				 `china_office_city`='".$china_office_city."',
				 `company_zipCode`='".$company_zipCode."',
				 `company_generalPhone`='".$company_generalPhone."',
				 `company_email`='".$company_email."',
				 `company_website`='".$company_website."',
				 `legal_entity`='".$legal_entity."',
				 `no_of_employees`='".$no_of_employees."',
				 `is_company_swiss_registered`='".$is_company_swiss_registered."',
				 `is_company_registered_PRC`='".$is_company_registered_PRC."',
				 `establishment_hongkong`='".$establishment_hongkong."',
				 `geographical_responsibility_hongkong`='".$geographical_responsibility_hongkong."',
				 `headquarter_name`='".$headquarter_name."',
				 `headquarter_address`='".$headquarter_address."',
				 `headquarter_city`='".$headquarter_city."',
				 `headquarter_zipCode`='".$headquarter_zipCode."',
				 `headquarter_phone`='".$headquarter_phone."',
				 `headquarter_province_area_english`='".$headquarter_province_area_english."',
				 `company_chamber`='".$company_chamber."',
				 `company_membership`='".$company_membership."',
				 `swiss_invested`='".$swiss_invested."',
				 `company_have`='".$company_have."',
				 `apply_for`='".$apply_for."',
				 `membership_fee`='".$membership_fee."',
				 `mainland_china`='".$mainland_china."',
				 `logo_name`='".$logo_name."'";

		mysql_query($companyDetailsSql);
		$created_date=date("Y-m-d");
		$updateCompanyQuery="UPDATE `sc_c_company_details`
					 SET `created_by`='".$last_id."',
					 `created_date`='".$created_date."'";
		mysql_query($updateCompanyQuery);

header('Location: success.php');


}   

?>