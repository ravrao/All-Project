<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
?>
<?php

if($_SESSION['userId']=='44'){
    ?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swisscham | Membership - Admin</title>
    <link rel="stylesheet" href="css/app.css">
   <link rel="stylesheet" href="css/membership_steps.css">
   <link rel="stylesheet" href="css/custom_dev.css">
    <!-- Favicon -->
   <link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.css" rel="stylesheet">
        <link href="css/dev1.css" rel="stylesheet">
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }

        </style>
        <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="js/dashboard.js">


        </script>
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }
            .common_heading2{ width:100%; float: left; margin-top: 40px; padding-left: 14px; color: #aa0008; }
            iframe{ width:100%; border:none; padding:0 15px; margin-bottom:-75px; }

        </style>
</head>
<body>
    <div id="page">
    	<?php 
    		require_once(__ROOT__.'/includes/admin_header.php'); 
    	?>
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="beijing.html">Home</a></li>
                        <li><span class="show-for-sr">Current: </span> Membership login</li>
                    </ul>
                </nav>
            </div>
        </section>
        <?php
	   $userId = $_SESSION["userId"];			
	   $row = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$userId."'"));	
        ?>
<section>
<div class="row">
    <div class="large-12 medium-12 small-12 columns no_padding margin_top15">
        <div class="large-12 columns dowedo_top">
            <h1 class="common_heading">Admin login</h1>
        </div>
        <div class="large-12 columns margin_bottom5">
           <div class="large-6 columns margin_bottom5">
            <h3 class="login_user_name">Welcome, <span>Admin</span></h3>
           </div>
           <div class="large-6 columns margin_bottom5">
            <a href="online_application.php" target="_blank" style="float:right;"><h3 class="login_user_name"><span>Add New Member</span></h3></a>
           </div>
        </div>

<div class="large-12 columns">
    <div id="eventListTab">
        <ul class="resp-tabs-list hor_1 memberdir_tab user_tab_width adminlist">
            <li class="tab_active">View</li>
            <li class="">Edit Personal Info</li>
            <li>Newsletters</li>
            <!--<li>Shortcuts</li>-->
            <!--<li>Ask an expert</li>
            <li>Expert's Corner Article</li>-->
            <li>User Manage</li>
            
            <li>Directory Users</li>
          
           

        </ul>
    <div class="resp-tabs-container hor_1 eventtab_list_details">
<div>
    <div class="row">
        <div class="large-12 columns">
            <h5>Personal Info</h5>
        </div>
        <div class="large-12 columns no_padding">
            <div class="large-2 columns small_padding">
                <p class="text-center directory_logo"><img src="uploads/<?=$row['profile_picture'];?>" /></p>
            </div>
            <div class="large-10 columns directory_item_details small_padding">
                <h2><?=$row['given_name']." ".$row['family_name']?></h2>
                <h3 class="common_subheading">Head</h3>
                <h5 class="common_link"><a href="#"></a></h5>
                <hr class="common_devider" />

                <?php
                        $name = $row['user_title']." ".$row['given_name']." ".$row['family_name'];
                ?>

                <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Name</h3>
                    <h5><?=$name?></h5>
                    <hr class="common_devider" />
                </div>
                 <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">E-mail</h3>
                    <h5><?=isset($row['direct_email'])?$row['direct_email']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>
                <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Direct Phone</h3>
                    <h5><?=isset($row['direct_phone'])?$row['direct_phone']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>
                <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Mobile Phone</h3>
                    <h5><?=isset($row['mobile_phone'])?$row['mobile_phone']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>


                 <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Nationality</h3>
                    <h5><?=isset($row['nationality'])?$row['nationality']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>

                <!--<div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Company</h3>
                    <h5><?=isset($row['company_name'])?$row['company_name']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>-->
                <div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Fax</h3>
                    <h5><?=isset($row['direct_fax'])?$row['direct_fax']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>
                <!--<div class="large-6 columns directory_item_details small_padding">
                    <h3 class="common_subheading">Industry</h3>
                    <h5><?=isset($row['direct_fax'])?$row['direct_fax']:"N/A";?></h5>
                    <hr class="common_devider" />
                </div>-->


            </div>
        </div>
    </div>
</div>
        <div>
            <div class="row">
<div id="ChildVerticalTab_1">
    <ul class="resp-tabs-list ver_1">
        <li>Account Info *</li>
        <li>Personal Details *</li>

    </ul>
    <div class="resp-tabs-container ver_1">
        <div>
<form action="admin_process.php" method="POST" name="accountinfofrom" id="accountinfoFrom">

<input type="hidden" name="type" value="account_info"/>
<div class="row">

<div class="large-12 columns">
    <h5 class="tab_subheading">Change your Password and E-mail</h5>
</div>
<div class="large-12 columns">
    <hr class="common_devider" />
</div>
<div class="large-12 columns no_padding">                                                            
        <div class="medium-12 columns membership_from">
            <label>Username<span class="mandatory_tag">*</span>
                <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId" value="<?=isset($row['admin_generated_userId'])?$row['admin_generated_userId']:"";?>" disabled="disabled">
                <small>Spaces are not allowed; minimum 6 charecters.</small>
            </label>
        </div>
        <div class="medium-12 columns membership_from">
            <label>E-mail address <span class="mandatory_tag">*</span>
                <input type="text" placeholder="" name="direct_email" id="direct_email" value="<?=isset($row['direct_email'])?$row['direct_email']:"";?>">
               <small>A valid e-mail address. All e-mails from the system will be sent to this address. The e-mail address is not made public and will only be used if you wish to receive a new password or wish to receive certain news or notifications by e-mail.</small>
            </label>
        </div>
        <div class="medium-12 columns membership_from">
            <label>Password
                <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password" value="<?=isset($row['admin_generated_password'])?$row['admin_generated_password']:"";?>">
            </label>
        </div>

        <!--<div class="password-strength-title">Password strength:</div>
                                                                        <div class="password-indicator"><div class="indicator"></div></div> -->

        <div class="medium-12 columns membership_from">
            <label>Confirm password
                <input type="password" placeholder="" value="">
                <small>To change the current user password, enter the new password in both fields.</small>
            </label>
        </div>
        <!--<div class="medium-12 columns membership_from">
            <legend>Status</legend>
            <input type="radio" name="lang-ce" value="Chinese" id="chinese">
            <label for="chinese"> Blocked</label>
            <input type="radio" name="lang-ce" value="English" id="english" checked="">
            <label for="english"> Active</label>
        </div>-->

        <?php

        if(isset($row['assignables_role']))
                $assignable_roles = explode(",", $row['assignables_role']);
               else
                $assignable_roles = "";

                $con = count($assignable_roles);
        ?>

        <div class="medium-12 columns membership_from">
            <legend>Assignable roles</legend>
            <div>
                <input name="assignables_role[]" id="company_holder" value="company_holder" type="checkbox"
                        <?php
                        if($con> 0){
                                if(in_array("company_holder", $assignable_roles))
                               echo "checked='checked'";
                               else
                               echo "";
                        }
                        ?>>
                <label for="general">company holder</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="company_member" value="company_member" type="checkbox" 
                <?php
                        if($con> 0){
                                if(in_array("company_member", $assignable_roles))
                                echo "checked='checked'";
                                else
                                echo "";
                        }
                        ?>>
                <label for="checkbox2">company member</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="directory_user" value="directory_user" type="checkbox"
                <?php
                        if($con> 0){
                                if(in_array("directory_user", $assignable_roles))
                                echo "checked='checked'";
                                else
                                echo "";
                        }
                        ?>

                 >
                <label for="checkbox3">directory user</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="beijing_editor" value="beijing_editor" type="checkbox" 

                <?php
                        if($con> 0){
                                if(in_array("beijing_editor", $assignable_roles))
                                echo "checked='checked'";
                                else
                                echo "";
                        }
                        ?>>
                <label for="guang">Beijing editor</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="shanghai_editor" value="shanghai_editor" type="checkbox" 

                <?php
                        if($con> 0){
                                if(in_array("shanghai_editor", $assignable_roles))
                                        echo "checked='checked'";
                                else
                                        echo "";
                        }
                        ?>>
                <label for="hong_kong">Shanghai editor</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="guangzhou_editor" value="guangzhou_editor" type="checkbox" 

                 <?php
                        if($con> 0){
                                if(in_array("guangzhou_editor", $assignable_roles))
                                        echo "checked='checked'";
                                else
                                        echo "";
                        }
                        ?>>
                <label for="hong_kong">Guangzhou editor</label>
            </div>
            <div>
                <input  name="assignables_role[]" id="hong_kong_editor" value="hong_kong_editor" type="checkbox" 

                 <?php
                        if($con> 0){
                                if(in_array("company_holder", $assignable_roles))
                                        echo "checked='checked'";
                                else
                                        echo "";
                        }
                        ?>
                >
                <label for="hong_kong">Hong Kong editor</label>
            </div>
            <small> The user receives the combined permissions of all roles selected here and the following roles: authenticated user.</small>
        </div>

</div>

<!--<div class="large-12 columns">
    <h5 class="tab_subheading">Locale settings</h5>
</div>
<div class="large-12 columns">
    <hr class="common_devider" />
</div>
<div class="large-12 columns no_padding">

        <div class="medium-12 columns membership_from">
            <label for="edit-timezone--2">Time zone </label>
            <select id="edit-timezone--2" name="timezone" class="form-select">
                <option value="Africa/Abidjan">Africa/Abidjan: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Accra">Africa/Accra: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Addis_Ababa">Africa/Addis Ababa: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Algiers">Africa/Algiers: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Asmara">Africa/Asmara: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Bamako">Africa/Bamako: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Bangui">Africa/Bangui: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Banjul">Africa/Banjul: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Bissau">Africa/Bissau: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Blantyre">Africa/Blantyre: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Brazzaville">Africa/Brazzaville: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Bujumbura">Africa/Bujumbura: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Cairo">Africa/Cairo: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Casablanca">Africa/Casablanca: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Ceuta">Africa/Ceuta: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Conakry">Africa/Conakry: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Dakar">Africa/Dakar: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Dar_es_Salaam">Africa/Dar es Salaam: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Djibouti">Africa/Djibouti: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Douala">Africa/Douala: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/El_Aaiun">Africa/El Aaiun: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Freetown">Africa/Freetown: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Gaborone">Africa/Gaborone: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Harare">Africa/Harare: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Johannesburg">Africa/Johannesburg: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Juba">Africa/Juba: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Kampala">Africa/Kampala: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Khartoum">Africa/Khartoum: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Kigali">Africa/Kigali: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Kinshasa">Africa/Kinshasa: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Lagos">Africa/Lagos: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Libreville">Africa/Libreville: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Lome">Africa/Lome: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Luanda">Africa/Luanda: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Lubumbashi">Africa/Lubumbashi: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Lusaka">Africa/Lusaka: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Malabo">Africa/Malabo: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Maputo">Africa/Maputo: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Maseru">Africa/Maseru: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Mbabane">Africa/Mbabane: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Mogadishu">Africa/Mogadishu: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Monrovia">Africa/Monrovia: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Nairobi">Africa/Nairobi: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Africa/Ndjamena">Africa/Ndjamena: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Niamey">Africa/Niamey: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Nouakchott">Africa/Nouakchott: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Ouagadougou">Africa/Ouagadougou: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Porto-Novo">Africa/Porto-Novo: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Sao_Tome">Africa/Sao Tome: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Africa/Tripoli">Africa/Tripoli: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Africa/Tunis">Africa/Tunis: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Africa/Windhoek">Africa/Windhoek: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="America/Adak">America/Adak: Tuesday, October 4, 2016 - 03:34 -0900</option>
                <option value="America/Anchorage">America/Anchorage: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/Anguilla">America/Anguilla: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Antigua">America/Antigua: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Araguaina">America/Araguaina: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Buenos_Aires">America/Argentina/Buenos Aires: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Catamarca">America/Argentina/Catamarca: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Cordoba">America/Argentina/Cordoba: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Jujuy">America/Argentina/Jujuy: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/La_Rioja">America/Argentina/La Rioja: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Mendoza">America/Argentina/Mendoza: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Rio_Gallegos">America/Argentina/Rio Gallegos: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Salta">America/Argentina/Salta: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/San_Juan">America/Argentina/San Juan: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/San_Luis">America/Argentina/San Luis: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Tucuman">America/Argentina/Tucuman: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Argentina/Ushuaia">America/Argentina/Ushuaia: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Aruba">America/Aruba: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Asuncion">America/Asuncion: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Atikokan">America/Atikokan: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Bahia_Banderas">America/Bahia Banderas: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Bahia">America/Bahia: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Barbados">America/Barbados: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Belem">America/Belem: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Belize">America/Belize: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Blanc-Sablon">America/Blanc-Sablon: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Boa_Vista">America/Boa Vista: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Bogota">America/Bogota: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Boise">America/Boise: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Cambridge_Bay">America/Cambridge Bay: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Campo_Grande">America/Campo Grande: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Cancun">America/Cancun: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Caracas">America/Caracas: Tuesday, October 4, 2016 - 08:04 -0430</option>
                <option value="America/Cayenne">America/Cayenne: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Cayman">America/Cayman: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Chicago">America/Chicago: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Chihuahua">America/Chihuahua: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Costa_Rica">America/Costa Rica: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Creston">America/Creston: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Cuiaba">America/Cuiaba: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Curacao">America/Curacao: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Danmarkshavn">America/Danmarkshavn: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="America/Dawson_Creek">America/Dawson Creek: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Dawson">America/Dawson: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Denver">America/Denver: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Detroit">America/Detroit: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Dominica">America/Dominica: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Edmonton">America/Edmonton: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Eirunepe">America/Eirunepe: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/El_Salvador">America/El Salvador: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Fort_Nelson">America/Fort Nelson: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Fortaleza">America/Fortaleza: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Glace_Bay">America/Glace Bay: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Godthab">America/Godthab: Tuesday, October 4, 2016 - 10:34 -0200</option>
                <option value="America/Goose_Bay">America/Goose Bay: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Grand_Turk">America/Grand Turk: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Grenada">America/Grenada: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Guadeloupe">America/Guadeloupe: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Guatemala">America/Guatemala: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Guayaquil">America/Guayaquil: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Guyana">America/Guyana: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Halifax">America/Halifax: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Havana">America/Havana: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Hermosillo">America/Hermosillo: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Indiana/Indianapolis">America/Indiana/Indianapolis: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Indiana/Knox">America/Indiana/Knox: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Indiana/Marengo">America/Indiana/Marengo: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Indiana/Petersburg">America/Indiana/Petersburg: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Indiana/Tell_City">America/Indiana/Tell City: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Indiana/Vevay">America/Indiana/Vevay: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Indiana/Vincennes">America/Indiana/Vincennes: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Indiana/Winamac">America/Indiana/Winamac: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Inuvik">America/Inuvik: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Iqaluit">America/Iqaluit: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Jamaica">America/Jamaica: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Juneau">America/Juneau: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/Kentucky/Louisville">America/Kentucky/Louisville: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Kentucky/Monticello">America/Kentucky/Monticello: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Kralendijk">America/Kralendijk: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/La_Paz">America/La Paz: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Lima">America/Lima: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Los_Angeles">America/Los Angeles: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Lower_Princes">America/Lower Princes: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Maceio">America/Maceio: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Managua">America/Managua: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Manaus">America/Manaus: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Marigot">America/Marigot: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Martinique">America/Martinique: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Matamoros">America/Matamoros: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Mazatlan">America/Mazatlan: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Menominee">America/Menominee: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Merida">America/Merida: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Metlakatla">America/Metlakatla: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/Mexico_City">America/Mexico City: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Miquelon">America/Miquelon: Tuesday, October 4, 2016 - 10:34 -0200</option>
                <option value="America/Moncton">America/Moncton: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Monterrey">America/Monterrey: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Montevideo">America/Montevideo: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Montserrat">America/Montserrat: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Nassau">America/Nassau: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/New_York">America/New York: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Nipigon">America/Nipigon: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Nome">America/Nome: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/Noronha">America/Noronha: Tuesday, October 4, 2016 - 10:34 -0200</option>
                <option value="America/North_Dakota/Beulah">America/North Dakota/Beulah: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/North_Dakota/Center">America/North Dakota/Center: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/North_Dakota/New_Salem">America/North Dakota/New Salem: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Ojinaga">America/Ojinaga: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Panama">America/Panama: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Pangnirtung">America/Pangnirtung: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Paramaribo">America/Paramaribo: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Phoenix">America/Phoenix: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Port_of_Spain">America/Port of Spain: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Port-au-Prince">America/Port-au-Prince: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Porto_Velho">America/Porto Velho: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Puerto_Rico">America/Puerto Rico: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Rainy_River">America/Rainy River: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Rankin_Inlet">America/Rankin Inlet: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Recife">America/Recife: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Regina">America/Regina: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Resolute">America/Resolute: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Rio_Branco">America/Rio Branco: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Santarem">America/Santarem: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Santiago">America/Santiago: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Santo_Domingo">America/Santo Domingo: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Sao_Paulo">America/Sao Paulo: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Scoresbysund">America/Scoresbysund: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="America/Sitka">America/Sitka: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/St_Barthelemy">America/St Barthelemy: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/St_Johns">America/St Johns: Tuesday, October 4, 2016 - 10:04 -0230</option>
                <option value="America/St_Kitts">America/St Kitts: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/St_Lucia">America/St Lucia: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/St_Thomas">America/St Thomas: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/St_Vincent">America/St Vincent: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Swift_Current">America/Swift Current: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Tegucigalpa">America/Tegucigalpa: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="America/Thule">America/Thule: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="America/Thunder_Bay">America/Thunder Bay: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Tijuana">America/Tijuana: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Toronto">America/Toronto: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Tortola">America/Tortola: Tuesday, October 4, 2016 - 08:34 -0400</option>
                <option value="America/Vancouver">America/Vancouver: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Whitehorse">America/Whitehorse: Tuesday, October 4, 2016 - 05:34 -0700</option>
                <option value="America/Winnipeg">America/Winnipeg: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="America/Yakutat">America/Yakutat: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="America/Yellowknife">America/Yellowknife: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="Antarctica/Casey">Antarctica/Casey: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Antarctica/Davis">Antarctica/Davis: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Antarctica/DumontDUrville">Antarctica/DumontDUrville: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Antarctica/Macquarie">Antarctica/Macquarie: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Antarctica/Mawson">Antarctica/Mawson: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Antarctica/McMurdo">Antarctica/McMurdo: Wednesday, October 5, 2016 - 01:34 +1300</option>
                <option value="Antarctica/Palmer">Antarctica/Palmer: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="Antarctica/Rothera">Antarctica/Rothera: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="Antarctica/Syowa">Antarctica/Syowa: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Antarctica/Troll">Antarctica/Troll: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Antarctica/Vostok">Antarctica/Vostok: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Arctic/Longyearbyen">Arctic/Longyearbyen: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Asia/Aden">Asia/Aden: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Almaty">Asia/Almaty: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Amman">Asia/Amman: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Anadyr">Asia/Anadyr: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Asia/Aqtau">Asia/Aqtau: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Aqtobe">Asia/Aqtobe: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Ashgabat">Asia/Ashgabat: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Baghdad">Asia/Baghdad: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Bahrain">Asia/Bahrain: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Baku">Asia/Baku: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Asia/Bangkok">Asia/Bangkok: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Barnaul">Asia/Barnaul: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Beirut">Asia/Beirut: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Bishkek">Asia/Bishkek: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Brunei">Asia/Brunei: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Chita">Asia/Chita: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Choibalsan">Asia/Choibalsan: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Colombo">Asia/Colombo: Tuesday, October 4, 2016 - 18:04 +0530</option>
                <option value="Asia/Damascus">Asia/Damascus: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Dhaka">Asia/Dhaka: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Dili">Asia/Dili: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Dubai">Asia/Dubai: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Asia/Dushanbe">Asia/Dushanbe: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Gaza">Asia/Gaza: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Hebron">Asia/Hebron: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Ho_Chi_Minh">Asia/Ho Chi Minh: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Hong_Kong">Asia/Hong Kong: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Hovd">Asia/Hovd: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Irkutsk">Asia/Irkutsk: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Jakarta">Asia/Jakarta: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Jayapura">Asia/Jayapura: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Jerusalem">Asia/Jerusalem: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Kabul">Asia/Kabul: Tuesday, October 4, 2016 - 17:04 +0430</option>
                <option value="Asia/Kamchatka">Asia/Kamchatka: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Asia/Karachi">Asia/Karachi: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Kathmandu">Asia/Kathmandu: Tuesday, October 4, 2016 - 18:19 +0545</option>
                <option value="Asia/Khandyga">Asia/Khandyga: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Kolkata">Asia/Kolkata: Tuesday, October 4, 2016 - 18:04 +0530</option>
                <option value="Asia/Krasnoyarsk">Asia/Krasnoyarsk: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Kuala_Lumpur">Asia/Kuala Lumpur: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Kuching">Asia/Kuching: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Kuwait">Asia/Kuwait: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Macau">Asia/Macau: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Magadan">Asia/Magadan: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Asia/Makassar">Asia/Makassar: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Manila">Asia/Manila: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Muscat">Asia/Muscat: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Asia/Nicosia">Asia/Nicosia: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Novokuznetsk">Asia/Novokuznetsk: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Novosibirsk">Asia/Novosibirsk: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Omsk">Asia/Omsk: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Oral">Asia/Oral: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Phnom_Penh">Asia/Phnom Penh: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Pontianak">Asia/Pontianak: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Pyongyang">Asia/Pyongyang: Tuesday, October 4, 2016 - 21:04 +0830</option>
                <option value="Asia/Qatar">Asia/Qatar: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Qyzylorda">Asia/Qyzylorda: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Rangoon">Asia/Rangoon: Tuesday, October 4, 2016 - 19:04 +0630</option>
                <option value="Asia/Riyadh">Asia/Riyadh: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Asia/Sakhalin">Asia/Sakhalin: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Asia/Samarkand">Asia/Samarkand: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Seoul">Asia/Seoul: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Shanghai">Asia/Shanghai: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Singapore">Asia/Singapore: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Srednekolymsk">Asia/Srednekolymsk: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Asia/Taipei">Asia/Taipei: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Tashkent">Asia/Tashkent: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Tbilisi">Asia/Tbilisi: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Asia/Tehran">Asia/Tehran: Tuesday, October 4, 2016 - 16:04 +0330</option>
                <option value="Asia/Thimphu">Asia/Thimphu: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Tokyo">Asia/Tokyo: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Ulaanbaatar">Asia/Ulaanbaatar: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Asia/Urumqi">Asia/Urumqi: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Asia/Ust-Nera">Asia/Ust-Nera: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Asia/Vientiane">Asia/Vientiane: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Asia/Vladivostok">Asia/Vladivostok: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Asia/Yakutsk">Asia/Yakutsk: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Asia/Yekaterinburg">Asia/Yekaterinburg: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Asia/Yerevan">Asia/Yerevan: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Atlantic/Azores">Atlantic/Azores: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Atlantic/Bermuda">Atlantic/Bermuda: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="Atlantic/Canary">Atlantic/Canary: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Atlantic/Cape_Verde">Atlantic/Cape Verde: Tuesday, October 4, 2016 - 11:34 -0100</option>
                <option value="Atlantic/Faroe">Atlantic/Faroe: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Atlantic/Madeira">Atlantic/Madeira: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Atlantic/Reykjavik">Atlantic/Reykjavik: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Atlantic/South_Georgia">Atlantic/South Georgia: Tuesday, October 4, 2016 - 10:34 -0200</option>
                <option value="Atlantic/St_Helena">Atlantic/St Helena: Tuesday, October 4, 2016 - 12:34 +0000</option>
                <option value="Atlantic/Stanley">Atlantic/Stanley: Tuesday, October 4, 2016 - 09:34 -0300</option>
                <option value="Australia/Adelaide">Australia/Adelaide: Tuesday, October 4, 2016 - 23:04 +1030</option>
                <option value="Australia/Brisbane">Australia/Brisbane: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Australia/Broken_Hill">Australia/Broken Hill: Tuesday, October 4, 2016 - 23:04 +1030</option>
                <option value="Australia/Currie">Australia/Currie: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Australia/Darwin">Australia/Darwin: Tuesday, October 4, 2016 - 22:04 +0930</option>
                <option value="Australia/Eucla">Australia/Eucla: Tuesday, October 4, 2016 - 21:19 +0845</option>
                <option value="Australia/Hobart">Australia/Hobart: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Australia/Lindeman">Australia/Lindeman: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Australia/Lord_Howe">Australia/Lord Howe: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Australia/Melbourne">Australia/Melbourne: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Australia/Perth">Australia/Perth: Tuesday, October 4, 2016 - 20:34 +0800</option>
                <option value="Australia/Sydney">Australia/Sydney: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Europe/Amsterdam">Europe/Amsterdam: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Andorra">Europe/Andorra: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Astrakhan">Europe/Astrakhan: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Europe/Athens">Europe/Athens: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Belgrade">Europe/Belgrade: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Berlin">Europe/Berlin: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Bratislava">Europe/Bratislava: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Brussels">Europe/Brussels: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Bucharest">Europe/Bucharest: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Budapest">Europe/Budapest: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Busingen">Europe/Busingen: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Chisinau">Europe/Chisinau: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Copenhagen">Europe/Copenhagen: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Dublin">Europe/Dublin: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Gibraltar">Europe/Gibraltar: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Guernsey">Europe/Guernsey: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Helsinki">Europe/Helsinki: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Isle_of_Man">Europe/Isle of Man: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Istanbul">Europe/Istanbul: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Jersey">Europe/Jersey: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Kaliningrad">Europe/Kaliningrad: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Kiev">Europe/Kiev: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Lisbon">Europe/Lisbon: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Ljubljana">Europe/Ljubljana: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/London">Europe/London: Tuesday, October 4, 2016 - 13:34 +0100</option>
                <option value="Europe/Luxembourg">Europe/Luxembourg: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Madrid">Europe/Madrid: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Malta">Europe/Malta: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Mariehamn">Europe/Mariehamn: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Minsk">Europe/Minsk: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Monaco">Europe/Monaco: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Moscow">Europe/Moscow: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Oslo">Europe/Oslo: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Paris">Europe/Paris: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Podgorica">Europe/Podgorica: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Prague">Europe/Prague: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Riga">Europe/Riga: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Rome">Europe/Rome: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Samara">Europe/Samara: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Europe/San_Marino">Europe/San Marino: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Sarajevo">Europe/Sarajevo: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Simferopol">Europe/Simferopol: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Skopje">Europe/Skopje: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Sofia">Europe/Sofia: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Stockholm">Europe/Stockholm: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Tallinn">Europe/Tallinn: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Tirane">Europe/Tirane: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Ulyanovsk">Europe/Ulyanovsk: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Europe/Uzhgorod">Europe/Uzhgorod: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Vaduz">Europe/Vaduz: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Vatican">Europe/Vatican: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Vienna">Europe/Vienna: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Vilnius">Europe/Vilnius: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Volgograd">Europe/Volgograd: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Warsaw">Europe/Warsaw: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Zagreb">Europe/Zagreb: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Europe/Zaporozhye">Europe/Zaporozhye: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Europe/Zurich">Europe/Zurich: Tuesday, October 4, 2016 - 14:34 +0200</option>
                <option value="Indian/Antananarivo">Indian/Antananarivo: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Indian/Chagos">Indian/Chagos: Tuesday, October 4, 2016 - 18:34 +0600</option>
                <option value="Indian/Christmas">Indian/Christmas: Tuesday, October 4, 2016 - 19:34 +0700</option>
                <option value="Indian/Cocos">Indian/Cocos: Tuesday, October 4, 2016 - 19:04 +0630</option>
                <option value="Indian/Comoro">Indian/Comoro: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Indian/Kerguelen">Indian/Kerguelen: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Indian/Mahe">Indian/Mahe: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Indian/Maldives">Indian/Maldives: Tuesday, October 4, 2016 - 17:34 +0500</option>
                <option value="Indian/Mauritius">Indian/Mauritius: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Indian/Mayotte">Indian/Mayotte: Tuesday, October 4, 2016 - 15:34 +0300</option>
                <option value="Indian/Reunion">Indian/Reunion: Tuesday, October 4, 2016 - 16:34 +0400</option>
                <option value="Pacific/Apia">Pacific/Apia: Wednesday, October 5, 2016 - 02:34 +1400</option>
                <option value="Pacific/Auckland">Pacific/Auckland: Wednesday, October 5, 2016 - 01:34 +1300</option>
                <option value="Pacific/Bougainville">Pacific/Bougainville: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Chatham">Pacific/Chatham: Wednesday, October 5, 2016 - 02:19 +1345</option>
                <option value="Pacific/Chuuk">Pacific/Chuuk: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Pacific/Easter">Pacific/Easter: Tuesday, October 4, 2016 - 07:34 -0500</option>
                <option value="Pacific/Efate">Pacific/Efate: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Enderbury">Pacific/Enderbury: Wednesday, October 5, 2016 - 01:34 +1300</option>
                <option value="Pacific/Fakaofo">Pacific/Fakaofo: Wednesday, October 5, 2016 - 01:34 +1300</option>
                <option value="Pacific/Fiji">Pacific/Fiji: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Funafuti">Pacific/Funafuti: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Galapagos">Pacific/Galapagos: Tuesday, October 4, 2016 - 06:34 -0600</option>
                <option value="Pacific/Gambier">Pacific/Gambier: Tuesday, October 4, 2016 - 03:34 -0900</option>
                <option value="Pacific/Guadalcanal">Pacific/Guadalcanal: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Guam">Pacific/Guam: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Pacific/Honolulu">Pacific/Honolulu: Tuesday, October 4, 2016 - 02:34 -1000</option>
                <option value="Pacific/Johnston">Pacific/Johnston: Tuesday, October 4, 2016 - 02:34 -1000</option>
                <option value="Pacific/Kiritimati">Pacific/Kiritimati: Wednesday, October 5, 2016 - 02:34 +1400</option>
                <option value="Pacific/Kosrae">Pacific/Kosrae: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Kwajalein">Pacific/Kwajalein: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Majuro">Pacific/Majuro: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Marquesas">Pacific/Marquesas: Tuesday, October 4, 2016 - 03:04 -0930</option>
                <option value="Pacific/Midway">Pacific/Midway: Tuesday, October 4, 2016 - 01:34 -1100</option>
                <option value="Pacific/Nauru">Pacific/Nauru: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Niue">Pacific/Niue: Tuesday, October 4, 2016 - 01:34 -1100</option>
                <option value="Pacific/Norfolk">Pacific/Norfolk: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Noumea">Pacific/Noumea: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Pago_Pago">Pacific/Pago Pago: Tuesday, October 4, 2016 - 01:34 -1100</option>
                <option value="Pacific/Palau">Pacific/Palau: Tuesday, October 4, 2016 - 21:34 +0900</option>
                <option value="Pacific/Pitcairn">Pacific/Pitcairn: Tuesday, October 4, 2016 - 04:34 -0800</option>
                <option value="Pacific/Pohnpei">Pacific/Pohnpei: Tuesday, October 4, 2016 - 23:34 +1100</option>
                <option value="Pacific/Port_Moresby">Pacific/Port Moresby: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Pacific/Rarotonga">Pacific/Rarotonga: Tuesday, October 4, 2016 - 02:34 -1000</option>
                <option value="Pacific/Saipan">Pacific/Saipan: Tuesday, October 4, 2016 - 22:34 +1000</option>
                <option value="Pacific/Tahiti">Pacific/Tahiti: Tuesday, October 4, 2016 - 02:34 -1000</option>
                <option value="Pacific/Tarawa">Pacific/Tarawa: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Tongatapu">Pacific/Tongatapu: Wednesday, October 5, 2016 - 01:34 +1300</option>
                <option value="Pacific/Wake">Pacific/Wake: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="Pacific/Wallis">Pacific/Wallis: Wednesday, October 5, 2016 - 00:34 +1200</option>
                <option value="UTC">UTC: Tuesday, October 4, 2016 - 12:34 +0000</option>
            </select>
            <!--<label>Select Menu <span class="mandatory_tag">*</span>
                <select>
                    <option value="husker">Husker</option>
                    <option value="starbuck">Starbuck</option>
                    <option value="hotdog">Hot Dog</option>
                    <option value="apollo">Apollo</option>
                </select>
            </label>-->
           <!-- <small>Select the desired local time and time zone. Dates and times throughout this site will be displayed using this time zone.</small>
        </div>

</div>-->
<div class="large-12 columns">
    <h5 class="tab_subheading">Language settings</h5>
</div>
<div class="large-12 columns">
    <hr class="common_devider" />
</div>
<div class="large-12 columns no_padding">
        <div class="medium-12 columns membership_from">
            <legend>Language</legend>
            <input type="radio" value="Chinese" name="language" id="language_ch" <?=($row['language']=='Chinese')?"checked='checked'":"";?>>
            <label for="chinese"> Chinese, Simplified (简体中文)</label>
            <input type="radio" value="English" name="language" id="language_en" <?=($row['language']=='English')?"checked='checked'":"";?>>
            <label for="english"> English</label>
        </div>
        <div class="medium-12 columns membership_from">
            <small>This account's default language for e-mails, and preferred language for site presentation.</small>
        </div>
</div>
<div class="medium-12 columns membership_from">
    <p class="text-right no_margin_bottom">


        <a onclick="$('#accountinfoFrom').submit();" class="button regnext_btn">Save</a>
         <!--<a class="button holo_btn">Cancel account</a></p>-->
</div>
</div>

</form>   


</div>
<div>

<form action="admin_process.php" method="POST" name="accountinfofrom" id="personalInfoForm" enctype="multipart/form-data">

    <input type="hidden" name="type" value="personal_details"/>

<div class="row">
    <div class="medium-12 columns membership_from">
        <legend>Title <span class="mandatory_tag">*</span></legend>
        <input type="radio" name="user_title" value="Dr" id="missus" checked <?=($row['user_title']=='Dr')?"checked='checked'":"";?>>
        <label for="missus">Dr.</label>
        <input type="radio" name="user_title" value="Mr" id="mister" <?=($row['user_title']=='Mr')?"checked='checked'":"";?>>
        <label for="mister"> Mr.</label>
        <input type="radio" name="user_title" value="Ms" id="Ms" <?=($row['user_title']=='Ms')?"checked='checked'":"";?>>
        <label for="miss">Ms.</label>
    </div>



     <!--<div class="medium-6 columns membership_from">
        <label>Date of Birth<span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="<?=isset($row['year_of_birth'])?$row['year_of_birth']:"";?>" name="year_of_birth" id="year_of_birth">
        </label>
    </div>-->


    <div class="medium-6 columns membership_from">
        <label>Date of Birth<span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="<?php if(!empty($row['year_of_birth'])){ echo $row['year_of_birth'];  }?>" name="year_of_birth" id="year_of_birth" />
        </label>
    </div>

    <div class="medium-6 columns membership_from">
        <label>Family name <span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="<?=isset($row['family_name'])?$row['family_name']:"";?>" name="family_name" id="family_name">
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>Given name<span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="<?=isset($row['given_name'])?$row['given_name']:"";?>" name="given_name" id="given_name">
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>Chinese name<!--<span class="mandatory_tag">*</span>-->
            <input type="text" value="<?=isset($row['chinese_name'])?$row['chinese_name']:"";?>" name="chinese_name" id="chinese_name">
        </label>
    </div>

    <div class="medium-12 columns membership_from second_form_field">
        <legend> Nationality:</legend>
        <input type="radio" name="nationality" value="Swiss" id="indiv_nationality_swiss" <?=($row['nationality']=="Swiss")?'checked="checked"':'';?>>
        <label for="indiv_nationality_swiss"> Swiss</label>

        <input type="radio" name="nationality" value="Chinese" id="indiv_nationality_chinese" <?=($row['nationality']=="Chinese")?'checked="checked"':'';?>>
        <label for="indiv_nationality_chinese"> Chinese</label>

                                                                    <input type="radio" name="nationality" value="HongKong" id="indiv_nationality_HongKong" <?=($row['nationality']=="HongKong")?'checked="checked"':'';?>>
        <label for="indiv_nationality_HongKong"> HongKong</label>

        <input type="radio" name="nationality" value="Other" id="indiv_nationality_other" <?=($row['nationality']=="Other")?'checked="checked"':'';?>>
        <label for="indiv_nationality_other"> Other</label>
    </div>

    <!--<div class="medium-12 columns membership_from">
        <label>Address in English:<span>*</span>
            <textarea rows="3" name="address_english" id="address_english">
                <?=isset($row['address_english'])?$row['address_english']:"";?> 
                </textarea>
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>City in English<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['city_english'])?$row['city_english']:'';?>" name="city_english" id="city_english">
        </label>
    </div>-->
    <!--<div class="medium-6 columns membership_from">
        <label>Province/Area in English<span class="mandatory_tag">*</span>
            <select name="province_area" id="province_area" style="margin-top:0px !important;">
                <option value="Beijing" <?=($row['province_area']=="Beijing")?'selected="selected"':'';?>>Beijing</option>
                <option value="Shanghai" <?=($row['province_area']=="Shanghai")?'selected="selected"':'';?>>Shanghai</option>
                <option value="Guangzhou" <?=($row['province_area']=="Guangzhou")?'selected="selected"':'';?>>Guangzhou</option>
                <option value="HongKong" <?=($row['province_area']=="HongKong")?'selected="selected"':'';?>>Hong Kong</option>
                <option value="ChinaMainland" <?=($row['province_area']=="ChinaMainland")?'selected="selected"':'';?>>China Mainland</option>
            </select>
        </label>
    </div>-->

   <!-- <div class="medium-6 columns membership_from">
        <label>Province/Area in English<span class="mandatory_tag">*</span>
            <input type="text" value="<?php if(!empty($row['province_area'])){ echo $row['province_area']; }?>" name="province_area" id="province_area">

        </label>
    </div>



    <div class="medium-12 columns membership_from">
        <label>Address in Chinese:<span>*</span>
            <textarea rows="3" name="address_chinese" id="address_chinese">
                <?=isset($row['address_chinese'])?$row['address_chinese']:"";?>
                </textarea>
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>City in Chinese<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['city_chinese'])?$row['city_chinese']:"";?>" name="city_chinese" id="city_chinese">
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>Zip code<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['zip_code_english'])?$row['zip_code_english']:"";?>" name="zip_code_english" id="zip_code_english">
        </label>
    </div>-->


    <div class="medium-6 columns membership_from">
        <label>Position in company<span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="<?=isset($row['positionIn_company'])?$row['positionIn_company']:"";?>" name="positionIn_company" id="positionIn_company">
        </label>
    </div>
   <!-- <div class="medium-6 columns membership_from">
        <label>Company name <span class="mandatory_tag">*</span>
            <input type="text" placeholder="" value="" name="company_name" id="company_name">
        </label>
    </div>-->                            

     <!--<div class="large-12 columns">
        <h5 class="tab_subheading">Picture</h5>
    </div>
    <div class="large-12 columns">
        <hr class="common_devider" />
    </div>
    <div class="large-12 columns">
        <legend> Picture</legend>
        <a href="/users/nandi" title="View user profile."><img typeof="foaf:Image" src="uploads/<?=$row['profile_picture']?>" width="100" alt="nandi's picture" title="nandi's picture"></a>
        <br/>
        <label for="exampleFileUpload" class="button no_margin_bottom">Upload Picture</label>
        <br>
        <input type="file" name="profile_picture" id="exampleFileUpload" class="show-for-sr"> <small>Your virtual face or picture. Pictures larger than 1024x1024 pixels will be scaled down.</small>
    </div>-->


    <div class="large-12 columns">
        <h5 class="tab_subheading">Contact Details</h5>
    </div>
    <div class="large-12 columns">
        <hr class="common_devider" />
    </div>
    <div class="medium-6 columns membership_from">
        <label>Direct Phone<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['direct_phone'])?$row['direct_phone']:"";?>" name="direct_phone" id="direct_phone">
        </label>
    </div>

    <div class="medium-6 columns membership_from">
        <label>Mobile phone<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['mobile_phone'])?$row['mobile_phone']:"";?>" name="mobile_phone" id="mobile_phone">
        </label>
    </div>
    <div class="medium-6 columns membership_from">
        <label>Direct E-mail<span class="mandatory_tag">*</span>
            <input type="text" value="<?=isset($row['direct_email'])?$row['direct_email']:"";?>" name="direct_email" id="direct_email" />
            <small>Your public e-mail address. The email address you registered with will be kept private.</small>
        </label>
    </div>




    <div class="medium-12 columns membership_from">
    <p class="text-right no_margin_bottom"><a  class="button regnext_btn no_margin_bottom fixed_button" id="personalInfoSave">Save</a></p>
    </div>

  </div>



</form>

        </div>
    </div>
</div>
            </div>
        </div>

        <div>
                <!--<form name="newsletterfrm" id="newsletterfrm" action="admin_process.php" method="post">
                                                        <input type="hidden" name="type" value="newsletter" />
            <div class="row">
                <div class="large-12 columns">
                    <h5 class="tab_subheading">Tick the box to subscribe to the following newsletter:</h5>
                </div>
                <div class="large-12 columns">
                    <hr class="common_devider" />
                </div>
                <div class="medium-12 columns membership_from">
                    <legend>Check these out</legend>
                    <div>
                        <?php
                        $checkarr = explode(",", $row['newsletter']);
                        ?>
                        <input id="bj_news" value="bj_news" type="checkbox"  name="newsletter[]" id="newsletter" <?=in_array("bj_news",$checkarr)?"checked='checked'":""?>>
                        <label for="bj_news">Reader's Digest + BJ Newsletter</label>
                    </div>
                    <small>Compilation of Sino-Swiss Business related news sent every other Fridays + BJ Newsletter</small>
                    <div>
                        <input id="sha_news" value="sha_news" type="checkbox"  name="newsletter[]" id="newsletter" <?=in_array("sha_news",$checkarr)?"checked='checked'":""?>>
                        <label for="sha_news">Reader's Digest + SHA Newsletter</label>
                    </div>
                    <small>Compilation of Sino-Swiss Business related news sent every other Fridays + SHA Newsletter</small>
                    <div>
                        <input id="gz_news" value="gz_news" type="checkbox" name="newsletter[]" id="newsletter" <?=in_array("gz_news",$checkarr)?"checked='checked'":""?>>
                        <label for="gz_news"> Reader's Digest + GZ Newsletter</label>
                    </div>
                    <small>Compilation of Sino-Swiss Business related news sent every other Fridays + GZ Newsletter</small>
                </div>
                <div class="medium-12 columns membership_from">
                    <p class="text-right no_margin_bottom"><a onclick="$('#newsletterfrm').submit();" class="button regnext_btn no_margin_bottom fixed_button">Save</a></p>
                </div>
            </div>
            </form>-->
            
            
            <legend>Check these out</legend>
  
<!-- NewsLetter Start From Here -->
<iframe id="framebei" src="<?php echo $site_url ; ?>swisschamlogin/iframe_beijing.php"></iframe>

<iframe id="framesha" src="<?php echo $site_url ; ?>swisschamlogin/iframe_shanghai.php"></iframe>

<iframe id="framegz" src="<?php echo $site_url ; ?>swisschamlogin/iframe_guan.php"></iframe>
<!-- Newsletter End From Here ---->
            
            
        </div>


      <!-- <div>
            <div class="row">
                <div class="large-12 columns">
                    <h5 class="tab_subheading">Choose a set of shortcuts to use</h5>
                </div>
                <div class="large-12 columns">
                    <hr class="common_devider" />
                </div>
                <div class="medium-12 columns membership_from">
                    <div>
                        <input type="radio" name="lang-ce" value="defaultSet" id="default_set" required="">
                        <label for="default_set"> Default</label>
                    </div>

                    <div>
                        <input type="radio" name="lang-ce" value="newSet" id="new_set" checked="">
                        <label for="new_set"> New set</label>
                    </div>
                    <small><input type="text" placeholder="" value=""></small>
                    <small>The new set is created by copying items from your default shortcut set.</small>
                </div>
                <div class="medium-12 columns membership_from">
                    <p class="text-right no_margin_bottom"><a href="#" class="button regnext_btn no_margin_bottom fixed_button">Change set</a></p>
                </div>
            </div>
      </div>-->


        <!--<div>
                <form name="questionfrm" id="questionfrm" action="admin_process.php" method="post">
                                                        <input type="hidden" name="type" value="question" />
            <div class="row">
                <div class="large-12 columns">
                    <h5 class="tab_subheading">SUBMIT A QUESTION</h5>
                </div>
                <div class="large-12 columns">
                    <hr class="common_devider" />
                </div>
                <div class="medium-12 columns membership_from">
                    <small>If you have a question for the Experts' Corner, please enter it below.</small>
                    <label>
                        Enter your question below<span class="mandatory_tag">*</span>
                        <textarea placeholder="" name="question" id="question" rows="2"><?=isset($row['question'])?$row['question']:"";?></textarea>
                        <small>Please write down a short introduction of your company and describe what your core business is (for corporate members only).</small>
                    </label>
                </div>

                <div class="medium-12 columns membership_from">
                    <p class="text-right no_margin_bottom"><a onclick="$('#questionfrm').submit();" class="button regnext_btn no_margin_bottom fixed_button">Submit</a></p>
                </div>
            </div>
           </form>
        </div>-->
        <?php
                /*$expertres = mysql_query("select * from `sc_c_expert_corner_article` where userId='".$userId."'");

                                                if(mysql_num_rows($expertres) > 0){											
                                                        $expertrow = mysql_fetch_array($expertres);
                                                }*/
        ?>
       <!-- <div>

                <form name="expertcornerfrm" id="expertcornerfrm" action="admin_process.php" method="post" enctype="multipart/form-data">
                                                        <input type="hidden" name="type" value="expert_corner_article" />

            <div class="row">
                <div class="medium-12 columns membership_from">
                    <label>Title <span class="mandatory_tag">*</span>
                        <input type="text" placeholder=""  name="corner_title" id="corner_title" value="<?=isset($expertrow['corner_title'])?$expertrow['corner_title']:"";?>">
                    </label>
                </div>
                <div class="medium-12 columns membership_from">

                    <label>
                        Body (Edit summary)
                        <textarea placeholder="" rows="2" name="corner_body" id="corner_body"><?=isset($expertrow['corner_body'])?$expertrow['corner_body']:"";?></textarea>
                        <small>Disable rich-text</small>
                    </label>
                </div>
                <div class="medium-12 columns membership_from">
                    <label>Text format
                        <select name="text_format" id="text_format">
                            <option value="filtered_html" <?=($expertrow['question']=="filtered_html")?"selected='selected'":"";?>>Filtered HTML</option>
                            <option value="plain_text" <?=($expertrow['question']="plain_text")?"selected='selected'":"";?>>Plain Text</option>
                        </select>
                    </label>
                </div>
                <div class="medium-12 columns membership_from">
                    <ul class="tab_list">
                        <li>Web page addresses and e-mail addresses turn into links automatically.</li>
                        <li>
                            <p class="no_margin_bottom">Allowed HTML tags:
                                <br /> &lt;a&gt; &lt;em&gt; &lt;strong&gt; &lt;cite&gt; &lt;blockquote&gt; &lt;code&gt; &lt;ul&gt; &lt;ol&gt; &lt;li&gt; &lt;dl&gt; &lt;dt&gt; &lt;dd&gt; &lt;p&gt; &lt;br&gt;
                            </p>
                        </li>
                        <li>Lines and paragraphs break automatically.</li>
                    </ul>
                </div>
                <div class="medium-12 columns membership_from">
                    <label>Tags
                        <input type="text" placeholder=""  name="tag_name" id="tag_name" value="<?=isset($expertrow['tag_name'])?$expertrow['tag_name']:"";?>">
                    </label>
                </div>

                <div class="large-12 columns">
                    <h5 class="tab_subheading">Add a new file</h5>
                </div>
                <div class="large-12 columns">
                    <hr class="common_devider">
                </div>
                <div class="large-12 columns">
                    <div>
                        <img src="uploads/<?=$expertrow['expert_file']?>" height="80" width="80"/>                                            	

                       <label for="exampleFileUpload1" class="button no_margin_bottom">Upload File</label>
                        <input type="file" id="exampleFileUpload1" class="show-for-sr" name="expert_file" onchange="showImage2(this,0);">
                    </div>
                    <div id="expert_corner_process_file">

                                                           </div>
                    <small>Files must be less than 20 MB. <br>
                           Allowed file types: jpg jpeg gif png pdf mp4 doc docx xls xlsx.</small>
                </div>
                <div class="medium-12 columns membership_from">
                    <p class="text-right no_margin_bottom"> 
                        <a onclick="$('#expertcornerfrm').submit();" class="button regnext_btn">Save</a> 
                        <a class="button holo_btn">Preview</a></p>
                </div>
            </div>
            </form>
        </div>-->
        <div>

           <div class="row ulSection">
                <div class="large-12 columns heading_advanced">
                    <h5 class="tab_subheading">User List <a href="javascript:void(0)" class="user_report_btn float-right ul_trigger button_for_advanced">Advance user report</a></h5>
                </div>

                        <?php
                        //if(!isset($_REQUEST['user'])){
                        ?>

                <div class="large-12 columns user_report_advanced no_padding">
                    <div class="large-12 columns">
                        <hr class="common_devider" />
                    </div>

                    <div class="medium-12 columns no_padding">
                        <div class="medium-12 columns membership_from">
                            <div class="common_border" style="float:left; width:50%;">
                                <label>Operations
                                    <p class="text-left no_margin_bottom"><a onclick="sendProfileActiveNotification();" class="button regnext_btn no_margin_bottom no_margin_top">Send a login one-time email</a></p>
                                </label>
                            </div>
                            <div style="float:left; width:50%;">
                                <label style="text-align: right;">Excel Report
                                    <p style="text-align: right;"><a href="excel.php?excl=ulist" class="button regnext_btn no_margin_bottom no_margin_top">Download</a>
                                    <a onclick="deleteMultipleUsers();" class="button regnext_btn no_margin_bottom no_margin_top">Delete</a></p>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="medium-12 columns membership_from">
                         <table class="table-scroll user_table">
                            <thead>
                                <tr>
                                    <th width="20">
                                        <input id="check_control" name="check_control" onclick="check_uncheck();" type="checkbox">
                                    </th>
                                    
                                     <th>Company Name English</th>
                                     <th>Company Name Chinese</th>
                                     <th>Membership To</th>
                                     <th>Type Of membership</th>
                                     <th>Company Holder Name</th> 
                                     
                              
                                    <th width="">EDIT</th>
                                    <th width="">DELETE</th>
                                </tr>
                            </thead>
                            <tbody>
<?php
$searchString = "";
$searchQuery = "";

if(isset($_REQUEST['user']) && $_REQUEST['user'] == "advanced")
{

    $searchString = "";
    $searchQuery = "";

    if(isset($_REQUEST['src_company_name_eng']) && $_REQUEST['src_company_name_eng']!=""){
            $searchString.= "&src_company_name_eng=".$_REQUEST['src_company_name_eng'];
            $searchQuery.= " AND SCD.company_name_english LIKE '%".$_REQUEST['src_company_name_eng']."%'";
    }
    
    if(isset($_REQUEST['src_company_name_chi']) && $_REQUEST['src_company_name_chi']!=""){
            $searchString.= "&src_company_name_chi=".$_REQUEST['src_company_name_chi'];
            $searchQuery.= " AND SCD.company_name_chinese LIKE '%".$_REQUEST['src_company_name_chi']."%'";
    }	

    if(isset($_REQUEST['src_type_member']) && $_REQUEST['src_type_member']!=""){
            $searchString.= "&src_type_member=".$_REQUEST['src_type_member'];
            $searchQuery.= " AND SCD.apply_for LIKE '%".$_REQUEST['src_type_member']."%'";
    }	

   
    if(isset($_REQUEST['src_company']) && $_REQUEST['src_company']!=""){
            $searchString.= "&src_company=".$_REQUEST['src_company'];
            $searchQuery.= " AND SCD.company_name_english LIKE '%".$_REQUEST['src_company']."%'";
    }
    
    
    
    if(isset($_REQUEST['src_chamber']) && $_REQUEST['src_chamber']!=""){
            $searchString.= "&chamber=".$_REQUEST['src_chamber'];
            $searchQuery.= "AND SCD.company_chamber LIKE '".$_REQUEST['src_chamber']."'";
    }

$query_listing = "SELECT SCU_SCUI_SCI.userId,
SCU_SCUI_SCI.admin_generated_userId,
                SCU_SCUI_SCI.family_name as family_name,
                SCU_SCUI_SCI.given_name as given_name,
                SCU_SCUI_SCI.direct_email as direct_email,
                SCU_SCUI_SCI.nationality as nationality,
                SCU_SCUI_SCI.direct_phone as direct_phone,
                SCU_SCUI_SCI.mobile_phone as mobile_phone,
                SCU_SCUI_SCI.province_area as province_area,

                SCU_SCUI_SCI.address_chinese as address_chinese,
                SCU_SCUI_SCI.city_english as city_english,
                SCU_SCUI_SCI.zip_code_english as zip_code_english,

            SCD.company_chamber as company_chamber,
            SCD.company_name_english as company_name_english,
            SCD.company_name_chinese as company_name_chinese,
            SCD.company_website as company_website,
            SCD.headquarter_name as headquarter_name,
            SCD.headquarter_address as headquarter_address,
            SCD.headquarter_city as headquarter_city,
            SCD.headquarter_zipCode as headquarter_zipCode,
            SCD.headquarter_phone as headquarter_phone,
            SCD.headquarter_province_area_english as headquarter_province_area_english,
            SCD.business_description_english as business_description_english,
            SCD.business_description_chinese as business_description_chinese,
            SCD.swiss_invested as swiss_invested,
            SCD.company_have as company_have,
            SCD.company_address as company_address,
            SCD.company_city as company_city,

    SCD.apply_for as apply_for
FROM `sc_c_company_details` SCD
JOIN (
SELECT SCU.userId,
SCU.admin_generated_userId,
      SCU.family_name as family_name,
      SCU.given_name as given_name,
      SCU.direct_email as direct_email,
      SCU.nationality as nationality,
      SCU.direct_phone as direct_phone,
      SCU.mobile_phone as mobile_phone,
      SCU.province_area as province_area,
      SCU.address_chinese as address_chinese,
      SCU.city_english as city_english,
      SCU.zip_code_english as zip_code_english																						 

FROM `sc_c_userdetails` SCU
WHERE  SCU.admin_generated_userId <> 'admin'
)SCU_SCUI_SCI
ON SCD.userId = SCU_SCUI_SCI.userId  WHERE 1 ".$searchQuery;
}    
else
{
    $query_listing = "SELECT SCU_SCUI_SCI.userId,
            SCU_SCUI_SCI.admin_generated_userId,
                            SCU_SCUI_SCI.family_name as family_name,
                            SCU_SCUI_SCI.given_name as given_name,
                            SCU_SCUI_SCI.direct_email as direct_email,
                            SCU_SCUI_SCI.nationality as nationality,
                            SCU_SCUI_SCI.direct_phone as direct_phone,
                            SCU_SCUI_SCI.mobile_phone as mobile_phone,
                            SCU_SCUI_SCI.province_area as province_area,

                            SCU_SCUI_SCI.address_chinese as address_chinese,
                            SCU_SCUI_SCI.city_english as city_english,
                            SCU_SCUI_SCI.zip_code_english as zip_code_english,
                            SCU_SCUI_SCI.year_of_birth as year_of_birth,
                            SCU_SCUI_SCI.chinese_name as chinese_name,
                            SCU_SCUI_SCI.positionIn_company as positionIn_company,
                            
                            

                         SCD.company_chamber as company_chamber,
                         SCD.company_name_english as company_name_english,
                         SCD.company_name_chinese as company_name_chinese,
                         SCD.company_website as company_website,
                         SCD.headquarter_name as headquarter_name,
                         SCD.headquarter_address as headquarter_address,
                         SCD.headquarter_city as headquarter_city,
                         SCD.headquarter_zipCode as headquarter_zipCode,
                         SCD.headquarter_phone as headquarter_phone,
                         SCD.headquarter_province_area_english as headquarter_province_area_english,
                         SCD.business_description_english as business_description_english,
                         SCD.business_description_chinese as business_description_chinese,

                         SCD.apply_for as apply_for,
                         SCD.business_scope as business_scope,
                         SCD.legal_entity as legal_entity,
                         SCD.no_of_employees as no_of_employees,
                         SCD.is_company_swiss_registered as is_company_swiss_registered,
                         SCD.is_company_registered_PRC as is_company_registered_PRC,
                         SCD.company_website as company_website,
                         SCD.swiss_invested as swiss_invested,
                         SCD.company_have as company_have,
                         SCD.company_address as company_address,
                         SCD.company_city as company_city,
                         SCD.province_area_english as province_area_english,
                         SCD.china_office_address as china_office_address,
                         SCD.china_office_city as china_office_city,
                         SCD.company_zipCode as company_zipCode,
                         SCD.company_generalPhone as company_generalPhone,
                         SCD.company_email as company_email
                         
                         
                   
                         
                         
FROM `sc_c_company_details` SCD
    JOIN (
            SELECT SCU.userId,
           SCU.admin_generated_userId,
                           SCU.family_name as family_name,
                           SCU.given_name as given_name,
                           SCU.direct_email as direct_email,
                           SCU.nationality as nationality,
                           SCU.direct_phone as direct_phone,
                           SCU.mobile_phone as mobile_phone,
                           SCU.province_area as province_area,
                           SCU.address_chinese as address_chinese,
                           SCU.city_english as city_english,
                           SCU.zip_code_english as zip_code_english,
                           SCU.year_of_birth as year_of_birth,
                           SCU.chinese_name as chinese_name,
                           SCU.positionIn_company as positionIn_company
                            



FROM `sc_c_userdetails` SCU
WHERE  SCU.admin_generated_userId <> 'admin'  
                    )SCU_SCUI_SCI
    ON SCD.userId = SCU_SCUI_SCI.userId
ORDER 
   By SCU_SCUI_SCI.userId DESC                               
";
}

$usr_details_res_cnt = mysql_query($query_listing);
$no_of_records = mysql_num_rows($usr_details_res_cnt);

//if($no_of_records > 0){

        $limit = 20;
        $total_pages = ceil($no_of_records/$limit);	

        $page = isset($_REQUEST['page'])?$_REQUEST['page'] : "1";
        if($page > 1){
                if($page == $total_pages){
                        $prev = $page-1;
                        $next = $total_pages;
                }else{
                        $prev = $page-1;
                        $next = $page+1;
                }
                $start = ($page-1)*$limit;
        }else{
                $start = 0;
                $prev = 1;

                if($total_pages == 1)
                        $next = 1;
                else
                    $next = $page+1;
        }

        $_SESSION['qry_listing'] = $query_listing;
        $query_listing.= " LIMIT ".$start.",".$limit;

        

  $usr_details_res = mysql_query($query_listing);								  
while($usr_details_row = mysql_fetch_array($usr_details_res)){
                                        ?>
<tr>
    <td><input id="profile_active_checkbox" for="check" name="user_login" type="checkbox" value="<?=$usr_details_row['userId']?>"></td>
    
   <td><?=$usr_details_row['company_name_english']?></td>
    <td><?=$usr_details_row['company_name_chinese']?></td>
    <td><?=$usr_details_row['company_chamber']?></td>
    <td><?php echo $usr_details_row['apply_for'];?></td>
    
    <td><?=$usr_details_row['given_name']?></td>	                                                             
    
    
    <td><a href="admin_edit_membership.php?id=<?=$usr_details_row['userId']?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>

    <!-- Delete section start -->
    <td><a href="admin_trash_membership.php?id=<?=$usr_details_row['userId']?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
    <!-- Delete section end -->

</tr>
<?php
}
        ?>
    </tbody>
</table>
</div>
<div class="medium-12 columns membership_from">
    <ul class="pagination user_pagination" role="navigation" aria-label="Pagination">
        <li class="pagination-previous <?=($page==1)?'disabled':'';?>">
                    <?php
                    if($page==1){
                    ?>
                    <a href="admin.php?user=advanced&page=<?=$prev.$searchString?>#eventListTab4">Previous <span class="show-for-sr">page</span></a>
            <?php
                                                                    }else{
            ?>
                    <a href="#">Previous <span class="show-for-sr">page</span></a>
            <?php
                                                                    }
            ?>
            </li>
       <?php
        for($i=1; $i<=$total_pages; $i++){
        ?>
            <li <?=($page==$i)?'class="current"':'';?>><span class="show-for-sr">You're on page</span><a href="admin.php?user=advanced&page=<?=$i?><?=$searchString?>#eventListTab4"><?=$i?></a></li>
        <?php
                                                            }
        ?>
        <li class="pagination-next <?=($page==$total_pages)?'disabled':'';?>">

            <?php
                    if($page==$total_pages){
                    ?>
                    <a href="admin.php?user=advanced&page=<?=$next.$searchString?>#eventListTab4" aria-label="Next page">Next <span class="show-for-sr">page</span></a>
            <?php
                                                                    }else{
            ?>
                    <a href="#">Next <span class="show-for-sr">page</span></a></li>
            <?php
                                                                    }
            ?>
        </li>
    </ul>
</div>

                </div>

                <?php
               // }
                ?>



            </div>






<div class="row aurSection" style="display:none;">

    <div class="large-12 columns heading_people">
        <h5 class="tab_subheading">Advanced user report<a href="javascript:void(0)" class="user_report_btn float-right aur_trigger button_for_user_list">User List</a></h5>
    </div>
    <div class="large-12 columns list_user no_padding">
        <div class="large-12 columns">
            <hr class="common_devider"/>
        </div>

        <div style="float:right; width:50%;">
            <label style="text-align: right;margin-right: 15px;">Excel Report
                <p style="text-align: right;"><a href="excel.php?excl=adv" class="button regnext_btn no_margin_bottom no_margin_top">Download</a></p>
            </label>
        </div>

                    <!--<div class="large-12 columns">
                         <div class="medium-4 columns membership_from">
                                <label>Email Id
                                    <input type="text" placeholder="" value="" name="admin_added_uase" id="admin_added_user">
                                    <small></small>
                                </label>
                            </div>
                        <div style="float: left; padding-top: 35px;">
                                <h5 class="tab_subheading"><a onclick="addNewUser();" class="add_nbutton"><i class="fa fa-user-plus" aria-hidden="true"></i> Add new user</a></h5>
                            </div>
                    </div>-->



<form name="searchfrm" id="searchfrm" method="post" action="admin.php?user=advanced#eventListTab4">
         <div class="medium-12 columns no_padding">
             
             <div class="medium-12 columns no_padding">
                 <div class="medium-4 columns membership_from">
                     <label>Company Name English
                         <input type="text" placeholder="" value="<?=isset($_REQUEST['src_company_name_eng'])?$_REQUEST['src_company_name_eng']:"";?>" name="src_company_name_eng" id="src_company_name_eng">
                         <small></small>
                     </label>
                 </div>
                 <div class="medium-4 columns membership_from">
                     <label>Company Name Chinese
                         <input type="text" placeholder="" value="<?=isset($_REQUEST['src_company_name_chi'])?$_REQUEST['src_company_name_chi']:"";?>" name="src_company_name_chi" id="src_company_name_chi">
                         <small></small>
                     </label>
                 </div>
                  <div class="medium-4 columns membership_from">
                     <label>Type Of membership
                         <input type="text" placeholder="" value="<?=isset($_REQUEST['src_type_member'])?$_REQUEST['src_type_member']:"";?>" name="src_type_member" id="src_type_member">
                         <small></small>
                     </label>
                 </div>
             </div>

             <div class="medium-12 columns no_padding">
                 
                
                 <div class="medium-4 columns membership_from">
                     <label>Company Holder Name 	
                         <input type="text" placeholder="" value="<?=isset($_REQUEST['src_company'])?$_REQUEST['src_company']:"";?>" name="src_company" id="src_company">
                         <small></small>
                     </label>
                 </div>
                 
                 <div class="medium-2 columns membership_from">
                     <label>Membership To
                         <select id="stateDrop" name="src_chamber" id="src_chamber">
                                                 <option value="">-Select-</option>
                                                 <option value="Beijing" id="beijingDrop" <?php if(isset($_REQUEST['src_chamber'])){if($_REQUEST['src_chamber']=="Beijing") echo "selected='selected'";}?>>Beijing</option>
                                                 <option value="Shanghai" id="shangDrop" <?php if(isset($_REQUEST['src_chamber'])){if($_REQUEST['src_chamber']=="Shanghai") echo "selected='selected'";}?>>Shanghai</option>
                                                 <option value="Guangzhou" id="guangDrop" <?php if(isset($_REQUEST['src_chamber'])){if($_REQUEST['src_chamber']=="Guangzhou") echo "selected='selected'";}?>>Guangzhou</option>
                                                 <option value="HongKong" id="hkDrop" <?php if(isset($_REQUEST['src_chamber'])){if($_REQUEST['src_chamber']=="HongKong") echo "selected='selected'";}?>>Hong Kong</option>
                                                 <option value="ChinaMainland" id="chDrop" <?php if(isset($_REQUEST['src_chamber'])){if($_REQUEST['src_chamber']=="ChinaMainland") echo "selected='selected'";}?>>China Mainland</option>
                                             </select>
                     </label>
                 </div>
             </div>
             <div class="medium-12 columns membership_from">
                 <p class="text-right no_margin_bottom"><button type="submit" onclick="$('#searchfrm').submit();" class="button regnext_btn no_margin_bottom fixed_button no_margin_top">Search</button</p>
             </div>
         </div>
</form>




                </div>
            </div>

        </div>
       
       
       
       

    
<!-------------------------------------- Ravi Directory Users  ********Start******** ------------------------------------>
<div>
    
    
<!-------------------------------------- Ravi Add Member Directory ********Start******** ------------------------------------>
<?php if ($_GET['AddUsers']=='addusersdir' || $_GET['Userid']!=''){ ?>
<div class="row ulSection">


    <div class="large-12 columns heading_advanced">
    

<div class="row">

    <form name="memberdirectory" id="memberdirectoryForm" action="admin_userinfo_process.php?info=memberderectory" method="POST" enctype='multipart/form-data'>
   <input type="hidden" name="compsnyORnot" id="compsnyORnot" value="<?php if(empty($row['positionIn_company'])){ echo "0";} else{ echo "1";} ?>" />
   <input type="hidden" value="<?=$userId?>" name="userId" id="userId" />
   <input type="hidden" value="<?php echo $_GET['Userid'] ?>" name="userIdForMemberdiretcory" id="userIdForMemberdiretcory" />

   <?php
 
   $rowmember_dire = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$_GET['Userid']."'")); 
   ?>
<div class="row">

    <!-- Loop Start Here -->


<div class="large-12 columns">
<h5 class="tab_subheading">Add Directory Users </h5>

<a href="javascript:void(0);" class="button regnext_btn no_margin_bottom" style="float:right; margin-right: 48px; margin-top: -23px;" onclick="history.back();"> Back</a>
</div>
    
<div class="large-12 columns">
    <hr class="common_devider" />
</div>
<div class="medium-12 columns membership_from">
    <legend>Title <span class="mandatory_tag">*</span></legend>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Dr' ){ echo "checked"; }?> value="Dr" id="Dr" >
    <label for="missus">Dr.</label>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Mr' ){ echo "checked"; }?> value="Mr" id="Mr" >
    <label for="mister"> Mr.</label>
    <input type="radio" name="other_contact_title_dir" <?php if($rowmember_dire['user_title']=='Ms' ){ echo "checked"; }?> value="Ms" id="Ms" >
    <label for="miss">Ms.</label>
</div>
<div class="medium-6 columns membership_from">
    <label>Date of Birth: <span class="mandatory_tag">*</span>
        <input type="text" name="other_contact_dob_dir" id="other_contact_dob_dir" value="<?php if(!empty($rowmember_dire['year_of_birth'])){ echo date('m/d/Y',strtotime($rowmember_dire['year_of_birth'])); }?>" class="other_contact_dob">
    </label>
</div>

<div class="medium-6 columns membership_from">
    <label>Family name <span class="mandatory_tag">*</span>
        <input type="text" name="other_contact_familyName_dir" value="<?php echo $rowmember_dire['family_name']; ?>" id="other_contact_familyName_dir">
    </label>
</div>
<div class="medium-6 columns membership_from">
    <label>Given name<span class="mandatory_tag">*</span>
        <input type="text" placeholder=""  name="other_contact_givenName_dir" value="<?php echo $rowmember_dire['given_name'];?>" id="other_contact_givenName_dir">
    </label>
</div>
<div class="medium-6 columns membership_from">
    <label>Chinese name
        <input type="text" placeholder=""  name="other_contact_chineseName_dir" value="<?php echo $rowmember_dire['chinese_name']; ?>" id="other_contact_chineseName_dir">
    </label>
</div>


<div class="medium-6 columns membership_from">
<label>Mobile<span class="mandatory_tag">*</span>
<input type="text" placeholder=""  name="other_contact_mobile_dir" value="<?php echo $rowmember_dire['mobile_phone']; ?>" id="other_contact_mobile_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct phone<span class="mandatory_tag">*</span>
<input type="text" placeholder="" name="other_contact_directPhone_dir" value="<?php echo $rowmember_dire['direct_phone']; ?>" id="other_contact_directPhone_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>Direct E-mail<span class="mandatory_tag">*</span>
<input type="text" placeholder="" name="other_contact_directEmail_dir" value="<?php echo $rowmember_dire['direct_email']; ?>" id="other_contact_directEmail_dir">
</label>
</div>
<div class="medium-6 columns membership_from">
<label>
</label>
</div>
</div>
<div class="medium-12 columns membership_from">
        <legend>Status </legend>
        <input <?php if($rowmember_dire['admin_approval']=='No' ){ echo "checked"; }?> type="radio" id="status" value="No" name="admin_approval">
        <label for="chinese"> Blocked</label>
        <input <?php if($rowmember_dire['admin_approval']=='Yes' ){ echo "checked"; }?> type="radio" <?php if($_GET['Userid']=='') { ?>checked="checked" <?php } ?> id="status" value="Yes" name="admin_approval">
        <label for="english"> Active</label>
</div>   
   <div class="medium-12 columns membership_from">
<p class="text-right no_margin_bottom">
    <a href="javascript:void(0);" id="memberDirectorySave" class="button regnext_btn no_margin_bottom">Save</a></p>
</div>  
</form>
</div>                     


</div>
</div>

<?php } ?>
<!-------------------------------------- Ravi Add Member Directory ********End******** ------------------------------------>       
<?php if ($_GET['AddUsers']!='addusersdir' && $_GET['Userid']==''){ ?>       
    
<div class="row ulSection">
<div class="large-12 columns heading_advanced">
    <h5 class="tab_subheading Directory-title">Directory Users </h5>
    <a href="<?php echo $site_url ;?>swisschamlogin/admin.php?AddUsers=addusersdir#eventListTab5" class="button regnext_btn no_margin_bottom">Add New directory Users</a>
    <a onclick="deleteMultipleDirectory();" class="button regnext_btn no_margin_bottom">Delete</a>

    <form name="search" id="search" class="direct-search" action="" method="get">
        
        <label>Search By: </label>
            <input type="text" id="searchname" placeholder="Name Or Mobile Or Phone" value="<?php if($_GET['searchname']!='') { echo $_GET['searchname']; } ?>"  name="searchname">
    
            <input type="submit" value="Search" class="button regnext_btn no_margin_bottom" />
   
    </form> 
</div>

                    
<div class="large-12 columns user_report_advanced no_padding">
    <div class="large-12 columns">
        <hr class="common_devider" />
    </div>


    <div class="medium-12 columns membership_from">
         <table class="table-scroll user_table">
            <thead>
                <tr>
                    <th width="20">
                        <input id="directory_check_control" name="directory_check_control" onclick="directory_check_uncheck();" type="checkbox">
                    </th>                 
                    <th>User Name</th>
                    <th>Password</th>
                    <th width="">NAME</th>
                    <th width="">E-Mail</th>
                    <th width="">MOBILE</th>
                    <th width="">PHONE</th>
                  
                    <th width="">EDIT</th>
                    <th width="">DELETE</th>
                </tr>
            </thead>
            <tbody>
<?php
$searchString = "";
$searchQuery = "";

if($_GET['searchname']=='')
{

$query ="Select *from sc_c_userdetails where assignables_role='member_derectory' ORDER BY userId DESC";
}
 else {
$query ="Select *from sc_c_userdetails where assignables_role='member_derectory' AND `given_name` LIKE '".$_GET['searchname']."' OR `mobile_phone` LIKE '".$_GET['searchname']."' OR `direct_phone` LIKE '".$_GET['searchname']."'  ORDER BY userId DESC"; 
}
 
$usr_details_res_cnt = mysql_query($query);
$no_of_records = mysql_num_rows($usr_details_res_cnt);

//if($no_of_records > 0){

$limit = 20;
$total_pages = ceil($no_of_records/$limit);	

$page = isset($_REQUEST['page'])?$_REQUEST['page'] : "1";
if($page > 1){
if($page == $total_pages){
        $prev = $page-1;
        $next = $total_pages;
}else{
        $prev = $page-1;
        $next = $page+1;
}
$start = ($page-1)*$limit;
}else{
$start = 0;
$prev = 1;

if($total_pages == 1)
        $next = 1;
else
    $next = $page+1;
}

$query.= " LIMIT ".$start.",".$limit;

//$_SESSION['qry'] = $query;

$usr_details_res = mysql_query($query);								  
while($usr_details_row = mysql_fetch_array($usr_details_res)){

   $row = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_company_details` WHERE userId='".$usr_details_row['other_contect_userid']."'")); 
?>
<tr>

 <td><input id="profile_active_checkbox2" for="directory_check" name="user_login2" type="checkbox" value="<?=$usr_details_row['userId']?>"></td>

<td><?=$usr_details_row['admin_generated_userId'] ;?></td>

<td><?=$usr_details_row['admin_generated_password'] ;?></td>
<td><?=$usr_details_row['user_title'] .' '. $usr_details_row['given_name'] ;?></td>
<td><?=$usr_details_row['direct_email'] ;?></td>
<td><?=$usr_details_row['mobile_phone']?></td>
<td><?=$usr_details_row['direct_phone']?></td>

<td><a href="admin.php?Userid=<?=$usr_details_row['userId']?>#eventListTab5">
        <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>

<td><a href="admin_trash_directory.php?Userid=<?=$usr_details_row['userId']?>#eventListTab5">
        <i class="fa fa-trash-o" aria-hidden="true"></i></a></td>

</tr>
<?php
}
?>
</tbody>
</table>
</div>
<div class="medium-12 columns membership_from">
<ul class="pagination user_pagination" role="navigation" aria-label="Pagination">
<li class="pagination-previous <?=($page==1)?'disabled':'';?>">
    <?php
    if($page==1){
    ?>
    <a href="admin.php?user=advanced&page=<?=$prev.$searchString?>#eventListTab5">Previous <span class="show-for-sr">page</span></a>
<?php
                                                    }else{
?>
    <a href="#">Previous <span class="show-for-sr">page</span></a>
<?php
                                                    }
?>
</li>
<?php
for($i=1; $i<=$total_pages; $i++){
?>
<li <?=($page==$i)?'class="current"':'';?>><span class="show-for-sr">You're on page</span><a href="admin.php?user=advanced&page=<?=$i?><?=$searchString?>#eventListTab5"><?=$i?></a></li>
<?php
                                            }
?>
<li class="pagination-next <?=($page==$total_pages)?'disabled':'';?>">

<?php
    if($page==$total_pages){
    ?>
    <a href="admin.php?user=advanced&page=<?=$next.$searchString?>#eventListTab5" aria-label="Next page">Next <span class="show-for-sr">page</span></a>
<?php
                                                    }else{
?>
    <a href="#">Next <span class="show-for-sr">page</span></a></li>
<?php
                                                    }
?>
</li>
</ul>
</div>

</div>

        </div>
<?php } ?>

</div>
<!-------------------------------------- Ravi  Directory Users End ------------------------------------>




<!-------------------------------------- Ravi Event Registration ***********Start****** ------------------------------------>




<!-------------------------------------- Ravi Event Register End ------------------------------------>

<!-------------------------------------- Ravi Edit Event Registration ***********Start****** ------------------------------------>




    </div>
</div>
    </div>
    </div>
</section>
     <!-- <section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                    </div>
                </div>
            </div>
      </section>-->
       
       
      
       
       
       <?php 
    	require_once(__ROOT__.'/includes/footer.php'); 
       ?>

        <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
        <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


        <nav id="log_togg">
            <ul class="logsec_sidenav">
                <li><a href="#">Login</a></li>
                <li class="side_joinnow"><a href="#">Join US</a></li>
                <li class="right_menu_heading show-for-medium-only">Select Language</li>
                <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
            </ul>
        </nav>

        <nav id="menu">
            <ul>
                <!--
                <li class="region_side_icon"><a href="index.html">Home</a></li>
                <li class="region_side_icon"><a href="beijing.html">Beijing</a></li>
                <li class="region_side_icon"><a href="shanghai.html">Shanghai</a></li>
                <li class="region_side_icon"><a href="guangzhou.html">Guangzhou</a></li>
                <li class="region_side_icon"><a href="hongkong.html">Hong Kong</a></li>-->
                <!--<li class="right_menu_heading show-for-small-only">Select Language</li>-->
                <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                <!--                <li class="right_menu_heading inlineblock_element">Select Location</li>-->
                <li class="region_side_icon">
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                        <option value="index.html">Home</option>
                        <option value="beijing.html">Beijing</option>
                        <option value="shanghai.html">Shanghai</option>
                        <option value="guangzhou.html">Guangzhou</option>
                        <option value="hongkong.html">Hong Kong</option>
                    </select>
                </li>
                <li><a href="#about">ABOUT US</a>
                    <ul>
                        <li><a href="b-whatwedo.html">Who are we?</a></li>
                        <li><a href="#">History</a></li>
                        <li><a href="#">Rules</a></li>
                        <li><a href="#">Board of Directors</a></li>
                        <li><a href="#">Management</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </li>
                <li><a href="#about">MEMBERSHIP</a>
                    <ul>
                        <li>
                            <a href="#">Why join us?</a>
                        </li>
                        <li>
                            <a href="#">Online Application</a>
                        </li>
                        <li>
                            <a href="#">Members Directory</a>
                        </li>
                        <li>
                            <a href="#">Investment Zones</a>
                        </li>
                        <li>
                            <a href="#">Member Benefits Program</a>
                        </li>
                    </ul>
                </li>
                <li><a href="#about">EVENTS</a>
                    <ul>
                        <li>
                            <a href="b-events.html">Upcoming Events</a>
                        </li>
                        <li>
                            <a href="#">Events Calendar</a>
                        </li>
                        <li>
                            <a href="#">Events Overview</a>
                        </li>
                        <li>
                            <a href="#">Company Visits</a>
                        </li>
                    </ul>
                </li>


                <li><a href="#about">PUBLICATIONS</a>
                    <ul>
                        <li>
                            <a href="#">The Bridge</a>
                        </li>
                        <li>
                            <a href="b-news.html">Sino-Swiss Business News</a>
                        </li>
                        <li>
                            <a href="b-reader-digest.html">Reader’s Digest</a>
                        </li>
                        <li>
                            <a href="#">Legal & Investment Updates</a>
                        </li>
                        <li>
                            <a href="#">Invest in Switzerland</a>
                        </li>
                        <li>
                            <a href="#">Business Publications</a>
                        </li>
                        <li>
                            <a href="#">Other Links</a>
                        </li>
                    </ul>
                </li>

                <li><a href="#about">SERVICES</a>
                    <ul>
                        <li>
                            <a href="#">Our services</a>
                        </li>
                        <li>
                            <a href="#">Job Opportunities</a>
                        </li>
                        <li>
                            <a href="#">Advertise With Us</a>
                        </li>
                        <li>
                            <a href="#">Training</a>
                        </li>
                        <li>
                            <a href="#">Lobbying Activities</a>
                        </li>
                        <li>
                            <a href="#">Wechat?</a>
                        </li>
                    </ul>
                </li>
            </ul>

        </nav>


    </div>

    <a href="#0" class="cd-top">Top</a>




    <script src="bower_components/jquery/dist/jquery.js"></script>
    <script src="bower_components/what-input/what-input.js"></script>
    <script src="bower_components/foundation-sites/dist/foundation.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
    <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
    <script type="text/javascript" src="js/pace.js"></script>
     <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        <script>
          /*  setTimeout(function() {
                $("#year_of_birth").datepicker({
                    changeMonth: true,
                    changeYear: true
                });
            }, 1000);*/
            
            
            $(document).ready(function(){
            	$("#year_of_birth").datepicker({
                    changeMonth: true,
                    changeYear: true
                });
            	
            });
            

        </script>
    <script type="text/javascript">
        $(function() {
            $('nav#menu').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: true,
                counters: false,
                "offCanvas": {
                    "position": "left"
                },
                navbar: {
                    title: 'SWISSCHAM'
                },
                navbars: [{
                    position: 'top',
                    content: ['searchfield']
                }, {
                    position: 'top',
                    content: [
                        'prev',
                        'title',
                        'close'
                    ]
                }, {
                    position: 'bottom',
                    content: [
                        //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                    ]
                }]
            });
            $('nav#log_togg').mmenu({
                extensions: ['effect-slide-menu', 'pageshadow'],
                searchfield: false,
                counters: false,
                navbar: {
                    title: 'Welcome to Swisscham'
                },
                navbars: [{
                    position: 'bottom',
                    content: [
                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /> Wechat</a></span>',
                        '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /> LinkedIn</a></span>'
                    ]
                }]

            });

        });

    </script>
    <script src="js/app.js"></script>
    <script src="js/member_registration.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            //Horizontal Tab
            $('#eventListTab').easyResponsiveTabs({
                type: 'default', //Types: default, vertical, accordion
                width: 'auto', //auto or any width like 600px
                fit: true, // 100% fit in a container
                tabidentify: 'hor_1', // The tab groups identifier
                activate: function(event) { // Callback function if tab is switched
                    var $tab = $(this);
                    var $info = $('#nested-tabInfo');
                    var $name = $('span', $info);
                    $name.text($tab.text());
                    $info.show();
                }
            });
            // Child Tab
            $('#ChildVerticalTab_1').easyResponsiveTabs({
                type: 'vertical',
                width: 'auto',
                fit: true,
                tabidentify: 'ver_1', // The tab groups identifier
                activetab_bg: '#fff', // background color for active tabs in this group
                inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
                active_border_color: '#c1c1c1', // border color for active tabs heads in this group
                active_content_border_color: '#aa0008' // border color for active tabs contect in this group so that it matches the tab head border
            });



    

        });
        
        
        
        function addNewUser(){
        	var mail = $("#admin_added_user").val();
        	var page = <?=$page?>;
        	var data = 'mail='+mail+'&page='+page;
        	 $.ajax({
                    type: "POST", 		
                    url: "admin_new_user_process.php", 		
                    data: data,
                    success: function (ret) {
                       alert(ret); 
                    },
                });
        }
        
       function check_uncheck() {
    		if($("#check_control").is(":checked")){
    			$('input[for=check]').each(function () {        	
    				$(this).prop('checked', true);
    			});
    		}else{
    			$('input[for=check]').each(function () {        	
    				$(this).prop('checked', false);
    			});
    		}
         }

         function directory_check_uncheck(){
            if($("#directory_check_control").is(":checked")){
                $('input[for=directory_check]').each(function () {            
                    $(this).prop('checked', true);
                });
            }else{
                $('input[for=directory_check]').each(function () {            
                    $(this).prop('checked', false);
                });
            }
         }
                
         function event_check_uncheck(){
    		if($("#event_check_control").is(":checked")){
                    
    			$('input[for=event_check]').each(function () {
                            
    				$(this).prop('checked', true);
    			});
    		}else{
    			$('input[for=event_check]').each(function () {        	
    				$(this).prop('checked', false);
    			});
    		}
         }
         
         function adv_check_uncheck(){
    		if($("#adv_check_control").is(":checked")){
    			$('input[for=adv_check]').each(function () {        	
    				$(this).prop('checked', true);
    			});
    		}else{
    			$('input[for=adv_check]').each(function () {        	
    				$(this).prop('checked', false);
    			});
    		}
         }
        
        function sendProfileActiveNotification(){
        	
        	var checkedId = "";
        	
        	$('input[for=check]').each(function () {        	
        		if($(this).is(":checked")){
        			if(checkedId == "")
        				checkedId = $(this).val();
        			else
        				checkedId = checkedId + "," + $(this).val();	
        		}
        	});

            if(checkedId == '') {
                            alert('Please check atleast one data');
                            return false;
            }
        	
        	var data = 'type=activeUser&ids='+checkedId;
        	 $.ajax({
                    type: "POST", 		
                    url: "admin_process.php", 		
                    data: data,
                    success: function (ret) {
                       alert(ret); 
                    },
                });
              }

        function deleteMultipleUsers(){
            
            var checkedId = "";
            
            $('input[for=check]').each(function () {            
                if($(this).is(":checked")){
                    if(checkedId == "")
                        checkedId = $(this).val();
                    else
                        checkedId = checkedId + "," + $(this).val();    
                }
            });

            if(checkedId == '') {
                            alert('Please check atleast one data');
                            return false;
            }
            
            var data = 'ids='+checkedId;
             $.ajax({
                    type: "POST",       
                    url: "admin_trash_membership.php",       
                    data: data,
                    success: function (ret) {
                        alert('Data are deleted succefully!');
                        location.reload();  //Refresh page
 
                    },
                });
              }


              function deleteMultipleDirectory(){
            
            var checkedId = "";
            
            $('input[for=directory_check]').each(function () {            
                if($(this).is(":checked")){
                    if(checkedId == "")
                        checkedId = $(this).val();
                    else
                        checkedId = checkedId + "," + $(this).val();    
                }
            });

            if(checkedId == '') {
                            alert('Please check atleast one data');
                            return false;
            }
            
            var data = 'ids='+checkedId;
             $.ajax({
                    type: "POST",       
                    url: "admin_trash_directory.php",       
                    data: data,
                    success: function (ret) {
                        alert('Data are deleted succefully !');
                        location.reload();  //Refresh page
 
                    },
                });
              }


            
              
              
              
              function sendEventNotification(){
        	
        	var checkedId = "";
        	
        	$('input[for=event_check]').each(function () {        	
        		if($(this).is(":checked")){
        			if(checkedId == "")
        				checkedId = $(this).val();
        			else
        				checkedId = checkedId + "," + $(this).val();	
        		}
        	});
        	
        	var data = 'type=eventsucess&ids='+checkedId;
        	 $.ajax({
                    type: "POST", 		
                    url: "admin_process.php", 		
                    data: data,
                    success: function (ret) {
                       alert(ret); 
                    },
                });
              }
    </script>
</body>

</html>
<?php } else{
    
   
header('Location: http://www.swisschamofcommerce.com/swisschamlogin/membership.php');
}
?>
 

