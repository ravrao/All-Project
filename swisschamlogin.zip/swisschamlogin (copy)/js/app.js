$(document).foundation();

$(document).ready(function () {
    if ($.isFunction($.fn.slick)) {
    	
    	
    	
    	 $('.mainSponsor').slick({
            dots: false,
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: false,
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        dots: false,
                        autoplay: true,
                        autoplaySpeed: 5000,
                        arrows: false,
                        infinite: true,
                        slidesToShow: 4,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 900,
                    settings: {
                        dots: false,
                        autoplay: true,
                        autoplaySpeed: 5000,
                        arrows: false,
                        infinite: true,
                        slidesToShow: 3,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        dots: false,
                        autoplay: false,
                        autoplaySpeed: 5000,
                        arrows: false,
                        infinite: true,
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        dots: false,
                        autoplay: true,
                        autoplaySpeed: 5000,
                        arrows: false,
                        infinite: true,
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
    	
    	
    	
        $('.mainBanner').slick({
            dots: false,
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: true,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        dots: false,
                        autoplay: true,
                        autoplaySpeed: 5000,
                        arrows: true,
                        infinite: true,
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        dots: false,
                        autoplay: true,
                        autoplaySpeed: 5000,
                        arrows: false,
                        infinite: true,
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
        $('.memberList').slick({
            dots: true,
            autoplay: false,
            autoplaySpeed: 2000,
            arrows: true,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            vertical: true,
            customPaging: function (slider, i) {
                var thumb = $(slider.$slides[i]).data();
                var suma = parseInt(i) + parseInt(1);
                return '<a class="dot_numbering">' + suma + '</a>';
            },
            responsive: [

                {
                    breakpoint: 1023,
                    settings: {
                        dots: false,
                        autoplay: false,
                        autoplaySpeed: 2000,
                        arrows: true,
                        infinite: true,
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        vertical: true,
                        customPaging: function (slider, i) {
                            var thumb = $(slider.$slides[i]).data();
                            var suma = parseInt(i) + parseInt(1);
                            return '<a class="dot_numbering">' + suma + '</a>';
                        },
                    }
                },
                {
                    breakpoint: 766,
                    settings: {
                        dots: false,
                        autoplay: false,
                        autoplaySpeed: 2000,
                        arrows: true,
                        infinite: true,
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        vertical: true,
                        customPaging: function (slider, i) {
                            var thumb = $(slider.$slides[i]).data();
                            var suma = parseInt(i) + parseInt(1);
                            return '<a class="dot_numbering">' + suma + '</a>';
                        },
                    }
                }
            ]
        });
       
        $('.adSponsorItem').slick({
            dots: false,
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: false,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
        });
    }

    /* ===== page top button started ===== */

    // browser window scroll (in pixels) after which the "back to top" link is shown
    var offset = 300,
        //browser window scroll (in pixels) after which the "back to top" link opacity is reduced
        offset_opacity = 1200,
        //duration of the top scrolling animation (in ms)
        scroll_top_duration = 700,
        //grab the "back to top" link
        $back_to_top = $('.cd-top');

    //hide or show the "back to top" link
    $(window).scroll(function () {
        ($(this).scrollTop() > offset) ? $back_to_top.addClass('cd-is-visible'): $back_to_top.removeClass('cd-is-visible cd-fade-out');
        if ($(this).scrollTop() > offset_opacity) {
            $back_to_top.addClass('cd-fade-out');
        }
    });

    //smooth scroll to top
    $back_to_top.on('click', function (event) {
        event.preventDefault();
        $('body,html').animate({
            scrollTop: 0,
        }, scroll_top_duration);
    });

    /* ===== page top button end ===== */

    $(".click_sub_nav").hide();
    $(".click_sub_trigger a").removeClass("subnav_active");
    $(".click_sub_trigger a").click(function () { //$(".click_sub_nav").hide("slow");
        $(".click_sub_trigger a").removeClass("subnav_active");
        $(this).addClass("subnav_active");
        $(this).siblings(".click_sub_nav").slideToggle("slow");
    });

    //custom function showing current slide
    var $status = $('.pagingInfo');
    var $slickElement = $('.memberList');


    $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
        //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
        var i = (currentSlide ? currentSlide : 0) + 1;
        $status.text(i + '/' + slick.slideCount);
    });

    if ($.isFunction($.fn.owlCarousel)) {
        $("#readers_table").owlCarousel({
            autoPlay: 3000, //Set AutoPlay to 3 seconds

            items: 3,
            itemsDesktop: [1199, 3],
            itemsDesktopSmall: [979, 3],
            pagination: false,
        });

        var owl = $("#readers_table");

        owl.owlCarousel();

        // Custom Navigation Events
        $(".next").click(function () {
            owl.trigger('owl.next');
        })
        $(".prev").click(function () {
            owl.trigger('owl.prev');
        })
    }

//////////// Login Error Message Script /////////////////////


var urlstr = window.location.href;
if(urlstr.indexOf("loginerror") > 0){ 
  $(".top_strip .top_log_buttom li:first a").trigger('click');
}

/////////// End Login Error Message Script /////////////////

});


$(document).ready(function () {
    var stickyNavTop = $('.top_fixed_strip').offset().top;

    var stickyNav = function () {
        var scrollTop = $(window).scrollTop();

        if (scrollTop > stickyNavTop) {
            $('.top_fixed_strip').addClass('sticky');
        } else {
            $('.top_fixed_strip').removeClass('sticky');
        }
    };

    stickyNav();

    $(window).scroll(function () {
        stickyNav();
    });


    /* ===== Word limit Start =======*/

    function truncateText(truncated, maxLength) {

        // var element = document.querySelector(selector),
        // truncated = element.innerText;

        if (truncated.length > maxLength) {
            truncated = truncated.substr(0, maxLength) + '...';
        }
        return truncated;
    }
    var x = document.querySelectorAll(".wordLimit");
    var i;
    for (i = 0; i < x.length; i++) {

        x[i].innerText = truncateText(x[i].innerText, 50);
    }
    //document.querySelector('.wordLimit').innerText = truncateText('.wordLimit', 50);

    /* ===== Word limit End =======*/
	setTimeout(function(){
	$("div.actions ul li:eq(2)").click(function(){
		$("#onlineApplicationForm").submit();
	});
	}, 1000);
});


window.addEventListener("orientationchange", function () {
    document.location.reload(true);
}, false);


/* ACCORDION */

jQuery(document).ready(function () {
    "use strict";
    jQuery('#accordion-container').find('.accordion-header').toggleClass('inactive-header');
    jQuery('#accordion-container').find('.accordion-header').click(function () {
        if (jQuery(this).is('.inactive-header')) {
            jQuery('#accordion-container').find('.active-header').toggleClass('active-header').toggleClass('inactive-header').next().slideToggle().toggleClass('open-content');
            jQuery(this).toggleClass('active-header').toggleClass('inactive-header');
            jQuery(this).next().slideToggle().toggleClass('open-content');
        } else {
            jQuery(this).toggleClass('active-header').toggleClass('inactive-header');
            jQuery(this).next().slideToggle().toggleClass('open-content');
        }
    });
    return false;
});
