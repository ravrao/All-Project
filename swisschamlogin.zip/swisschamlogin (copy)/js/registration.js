$('document').ready(function(){
        /*     $('#nextPage').click(function(){
                var flag=0;
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;amily_name=$('#family_name').val();
                if(family_name==''){
                $("#family_name").focus();
                $("#family_name").addClass("error_cl");
               
                    flag==1;
                    return false;
                } else{
                   $("#family_name").removeClass("error_cl"); 
                }
                var given_name=$('#given_name').val();
                if(given_name==''){
                $("#given_name").addClass("error_cl");
                $("#given_name").focus();
                    flag==1;
                    return false;
                } else{
                   $("#given_name").removeClass("error_cl"); 
                }
                if($('input[name=nationality]:checked').length<=0)
                {
                 //alert("No radio checked")
                 flag=1;
                }
                var membership_location=$('#membership_location').val();
                if(membership_location==''){
                $("#membership_location").addClass("error_cl"); 
                $("#membership_location").focus();
                    flag==1;
                    return false;
                } else{
                   $("#membership_location").removeClass("error_cl");  
                }
                var membership_type=$('#membership_type').val();
                if(membership_type==''){
                $("#membership_type").addClass("error_cl");
                $("#membership_type").focus();
                    flag==1;
                    return false;
                } else{
                   $("#membership_type").removeClass("error_cl"); 
                }
                var company_name_english=$('#company_name_english').val();
                if(company_name_english==''){
                $("#company_name_english").addClass("error_cl");
                $("#company_name_english").focus();
                    flag==1;
                    return false;
                } else{
                   $("#company_name_english").removeClass("error_cl");  
                }
                 var positionIn_company=$('#positionIn_company').val();
                if(positionIn_company==''){
                $("#positionIn_company").addClass("error_cl");
                $("#positionIn_company").focus();
                    flag==1;
                    return false;
                } else{
                   $("#positionIn_company").removeClass("error_cl");
                }
                 var address_english=$('#address_english').val();
                if(address_english==''){
                $("#address_english").addClass("error_cl");
                $("#address_english").focus();
                    flag==1;
                    return false;
                } else{
                   $("#address_english").removeClass("error_cl");
                }
                var address_chinese=$('#address_chinese').val();
                if(address_chinese==''){
                $("#address_chinese").addClass("error_cl");
                $("#address_chinese").focus();
                    flag==1;
                    return false;
                } else{
                   $("#address_chinese").removeClass("error_cl");
                }
                var city=$('#city').val();
                if(city==''){
                $("#city").addClass("error_cl");
                $("#city").focus();
                    flag==1;
                    return false;
                } else{
                   $("#city").removeClass("error_cl");
                }
                var zip_code=$('#zip_code').val();
                if((zip_code=='') || (isNaN(zip_code))){
                $("#zip_code").addClass("error_cl");
                $("#zip_code").focus();
                    flag==1;
                    return false;
                } else{
                   $("#zip_code").removeClass("error_cl");
                }   
                var general_phone=$('#general_phone').val();
                if(general_phone==''){
                $("#general_phone").addClass("error_cl");
                $("#general_phone").focus();
                    flag==1;
                    return false;
                } else{
                   $("#general_phone").removeClass("error_cl");
                }
                var general_email=$('#general_email').val();
                if((!emailPattern.test(general_email)) || (general_email=='')){
                $("#general_email").addClass("error_cl");
                $("#general_email").focus();
                    flag==1;
                    return false;
                } else{
                   $("#general_email").removeClass("error_cl"); 
                }
                var direct_phone=$('#direct_phone').val();
                if(direct_phone==''){
                $("#direct_phone").addClass("error_cl");
                $("#direct_phone").focus();
                    flag==1;
                    return false;
                } else{
                   $("#direct_phone").removeClass("error_cl");  
                }
                var direct_email=$('#direct_email').val();
                if((!emailPattern.test(direct_email)) || (direct_email=='')){
                $("#direct_email").addClass("error_cl");
                $("#direct_email").focus();
                    flag==1;
                    return false;
                } else{
                   $("#direct_email").removeClass("error_cl"); 
                }
                var mobile_phone=$('#mobile_phone').val();
                if((mobile_phone=='') || (isNaN(mobile_phone))){
                $("#mobile_phone").addClass("error_cl");
                $("#mobile_phone").focus();
                    flag==1;
                    return false;
                } else{
                   $("#mobile_phone").removeClass("error_cl");  
                }
                if(flag==0){
                
                $('#secondPortion').show();
                $('#firstPortion').hide();
                }
                
            });
            $('#previousPage').click(function(){
                   $('#secondPortion').hide();
                 $('#firstPortion').show();
                });
            $('#finalSubmit').click(function(){
                var flag=0;
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                var industry=$('#industry').val();
                if(industry==null){
                    var other_industry=$('#other_industry').val();
                    if(other_industry==''){
                    $("#other_industry").addClass("error_cl");
                    $("#other_industry").focus();
                        flag==1;
                        return false;
                    } else{
                       $("#other_industry").removeClass("error_cl");  
                    }
                } else if(industry==54){
                    var other_industry=$('#other_industry').val();
                    if(other_industry==''){
                    $("#other_industry").addClass("error_cl");
                    $("#other_industry").focus();
                        flag==1;
                        return false;
                    } else{
                       $("#other_industry").removeClass("error_cl");  
                    }
                } else{
                    $("#other_industry").removeClass("error_cl");
                }   

                var business_scope=$('#business_scope').val();
                if(business_scope==''){
                   $("#business_scope").addClass("error_cl");
                    $("#business_scope").focus();
                        flag==1;
                        return false;
                    } else{
                       $("#business_scope").removeClass("error_cl"); 
                    }
                var employees_mainland_chinese=$('#employees_mainland_chinese').val();
                if((employees_mainland_chinese=='') || (isNaN(employees_mainland_chinese))){
                   $("#employees_mainland_chinese").addClass("error_cl");
                    $("#employees_mainland_chinese").focus();
                        flag==1;
                        return false;
                    } else{
                       $("#employees_mainland_chinese").removeClass("error_cl"); 
                    }
                var employees_asia=$('#employees_asia').val();
                if((employees_asia=='') || (isNaN(employees_asia))){
                    $("#employees_asia").addClass("error_cl");
                    $("#employees_asia").focus();
                        flag==1;
                        return false;
                    } else{
                       $("#employees_asia").removeClass("error_cl"); 
                    }
                if($('input[name=legal_entity]:checked').length<=0)
                {
                 //alert("No radio checked")
                 flag=1;
                 return false;
                }
                if(flag==0){
                    $('#registrationFrm').submit();
                }
            });  */
            $('#loginSubmit').click(function(){
                var flag=0;
                var admin_generated_userId=$('#admin_generated_userId').val();
                if(admin_generated_userId==''){
                $("#admin_generated_userId").addClass("error_cl");
                $("#admin_generated_userId").focus();
                    flag=1;
                } else{
                   $("#admin_generated_userId").removeClass("error_cl"); 
                }
                var admin_generated_password=$('#admin_generated_password').val();
                if(admin_generated_password==''){
                $("#admin_generated_password").addClass("error_cl");
                $("#admin_generated_password").focus();
                    flag=1;
                } else{
                   $("#admin_generated_password").removeClass("error_cl"); 
                }
                if(flag==0){
                    $('#logInForm').submit();
                }
            }); 


				$('#loginSubmit1').click(function(){
                var flag1=0;
                var admin_generated_userId=$('#admin_generated_userId1').val();
				
                if(admin_generated_userId==''){
					alert(admin_generated_userId);
                $("#admin_generated_userId1").addClass("error_cl");
                $("#admin_generated_userId1").focus();
                    flag1=1;
                } else{
                   $("#admin_generated_userId1").removeClass("error_cl"); 
                }
                var admin_generated_password=$('#admin_generated_password1').val();
                if(admin_generated_password==''){
                $("#admin_generated_password1").addClass("error_cl");
                $("#admin_generated_password1").focus();
                    flag1=1;
                } else{
                   $("#admin_generated_password1").removeClass("error_cl"); 
                }
                if(flag1==0){
                   $('#logInForm1').submit();
                }
            });
			
			$(".inserUid").click(function(){
				var inserUid=$(this).data("id");
				$("#uid1").val(inserUid);
			});
        });