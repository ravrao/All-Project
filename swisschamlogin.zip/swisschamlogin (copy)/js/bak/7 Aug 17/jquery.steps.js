/*! 
 * jQuery Steps v1.1.0 - 09/04/2014
 * Copyright (c) 2014 Rafael Staib (http://www.jquery-steps.com)
 * Licensed under MIT http://www.opensource.org/licenses/MIT
 */
;
(function ($, undefined) {
    $.fn.extend({
        _aria: function (name, value) {
            return this.attr("aria-" + name, value);
        },

        _removeAria: function (name) {
            return this.removeAttr("aria-" + name);
        },

        _enableAria: function (enable) {
            return (enable == null || enable) ?
                this.removeClass("disabled")._aria("disabled", "false") :
                this.addClass("disabled")._aria("disabled", "true");
        },

        _showAria: function (show) {
            return (show == null || show) ?
                this.show()._aria("hidden", "false") :
                this.hide()._aria("hidden", "true");
        },

        _selectAria: function (select) {
            return (select == null || select) ?
                this.addClass("current")._aria("selected", "true") :
                this.removeClass("current")._aria("selected", "false");
        },

        _id: function (id) {
            return (id) ? this.attr("id", id) : this.attr("id");
        }
    });

    if (!String.prototype.format) {
        String.prototype.format = function () {
            var args = (arguments.length === 1 && $.isArray(arguments[0])) ? arguments[0] : arguments;
            var formattedString = this;
            for (var i = 0; i < args.length; i++) {
                var pattern = new RegExp("\\{" + i + "\\}", "gm");
                formattedString = formattedString.replace(pattern, args[i]);
            }
            return formattedString;
        };
    }

    /**
     * A global unique id count.
     *
     * @static
     * @private
     * @property _uniqueId
     * @type Integer
     **/
    var _uniqueId = 0;

    /**
     * The plugin prefix for cookies.
     *
     * @final
     * @private
     * @property _cookiePrefix
     * @type String
     **/
    var _cookiePrefix = "jQu3ry_5teps_St@te_";

    /**
     * Suffix for the unique tab id.
     *
     * @final
     * @private
     * @property _tabSuffix
     * @type String
     * @since 0.9.7
     **/
    var _tabSuffix = "-t-";

    /**
     * Suffix for the unique tabpanel id.
     *
     * @final
     * @private
     * @property _tabpanelSuffix
     * @type String
     * @since 0.9.7
     **/
    var _tabpanelSuffix = "-p-";

    /**
     * Suffix for the unique title id.
     *
     * @final
     * @private
     * @property _titleSuffix
     * @type String
     * @since 0.9.7
     **/
    var _titleSuffix = "-h-";

    /**
     * An error message for an "index out of range" error.
     *
     * @final
     * @private
     * @property _indexOutOfRangeErrorMessage
     * @type String
     **/
    var _indexOutOfRangeErrorMessage = "Index out of range.";

    /**
     * An error message for an "missing corresponding element" error.
     *
     * @final
     * @private
     * @property _missingCorrespondingElementErrorMessage
     * @type String
     **/
    var _missingCorrespondingElementErrorMessage = "One or more corresponding step {0} are missing.";

    /**
     * Adds a step to the cache.
     *
     * @static
     * @private
     * @method addStepToCache
     * @param wizard {Object} A jQuery wizard object
     * @param step {Object} The step object to add
     **/
    function addStepToCache(wizard, step) {
        getSteps(wizard).push(step);
    }

    function analyzeData(wizard, options, state) {
        var stepTitles = wizard.children(options.headerTag),
            stepContents = wizard.children(options.bodyTag);

        // Validate content
        if (stepTitles.length > stepContents.length) {
            throwError(_missingCorrespondingElementErrorMessage, "contents");
        } else if (stepTitles.length < stepContents.length) {
            throwError(_missingCorrespondingElementErrorMessage, "titles");
        }

        var startIndex = options.startIndex;

        state.stepCount = stepTitles.length;

        // Tries to load the saved state (step position)
        if (options.saveState && $.cookie) {
            var savedState = $.cookie(_cookiePrefix + getUniqueId(wizard));
            // Sets the saved position to the start index if not undefined or out of range 
            var savedIndex = parseInt(savedState, 0);
            if (!isNaN(savedIndex) && savedIndex < state.stepCount) {
                startIndex = savedIndex;
            }
        }

        state.currentIndex = startIndex;

        stepTitles.each(function (index) {
            var item = $(this), // item == header
                content = stepContents.eq(index),
                modeData = content.data("mode"),
                mode = (modeData == null) ? contentMode.html : getValidEnumValue(contentMode, (/^\s*$/.test(modeData) || isNaN(modeData)) ? modeData : parseInt(modeData, 0)),
                contentUrl = (mode === contentMode.html || content.data("url") === undefined) ?
                "" : content.data("url"),
                contentLoaded = (mode !== contentMode.html && content.data("loaded") === "1"),
                step = $.extend({}, stepModel, {
                    title: item.html(),
                    content: (mode === contentMode.html) ? content.html() : "",
                    contentUrl: contentUrl,
                    contentMode: mode,
                    contentLoaded: contentLoaded
                });

            addStepToCache(wizard, step);
        });
    }

    /**
     * Triggers the onCanceled event.
     *
     * @static
     * @private
     * @method cancel
     * @param wizard {Object} The jQuery wizard object
     **/
    function cancel(wizard) {
        wizard.triggerHandler("canceled");
    }

    function decreaseCurrentIndexBy(state, decreaseBy) {
        return state.currentIndex - decreaseBy;
    }

    /**
     * Removes the control functionality completely and transforms the current state to the initial HTML structure.
     *
     * @static
     * @private
     * @method destroy
     * @param wizard {Object} A jQuery wizard object
     **/
    function destroy(wizard, options) {
        var eventNamespace = getEventNamespace(wizard);

        // Remove virtual data objects from the wizard
        wizard.unbind(eventNamespace).removeData("uid").removeData("options")
            .removeData("state").removeData("steps").removeData("eventNamespace")
            .find(".actions a").unbind(eventNamespace);

        // Remove attributes and CSS classes from the wizard
        wizard.removeClass(options.clearFixCssClass + " vertical");

        var contents = wizard.find(".content > *");

        // Remove virtual data objects from panels and their titles
        contents.removeData("loaded").removeData("mode").removeData("url");

        // Remove attributes, CSS classes and reset inline styles on all panels and their titles
        contents.removeAttr("id").removeAttr("role").removeAttr("tabindex")
            .removeAttr("class").removeAttr("style")._removeAria("labelledby")
            ._removeAria("hidden");

        // Empty panels if the mode is set to 'async' or 'iframe'
        wizard.find(".content > [data-mode='async'],.content > [data-mode='iframe']").empty();

        var wizardSubstitute = $("<{0} class=\"{1}\"></{0}>".format(wizard.get(0).tagName, wizard.attr("class")));

        var wizardId = wizard._id();
        if (wizardId != null && wizardId !== "") {
            wizardSubstitute._id(wizardId);
        }

        wizardSubstitute.html(wizard.find(".content").html());
        wizard.after(wizardSubstitute);
        wizard.remove();

        return wizardSubstitute;
    }

    /**
     * Triggers the onFinishing and onFinished event.
     *
     * @static
     * @private
     * @method finishStep
     * @param wizard {Object} The jQuery wizard object
     * @param state {Object} The state container of the current wizard
     **/
    function finishStep(wizard, state) {
        var currentStep = wizard.find(".steps li").eq(state.currentIndex);

        if (wizard.triggerHandler("finishing", [state.currentIndex])) {
            currentStep.addClass("done").removeClass("error");
            wizard.triggerHandler("finished", [state.currentIndex]);
        } else {
            currentStep.addClass("error");
        }
    }

    /**
     * Gets or creates if not exist an unique event namespace for the given wizard instance.
     *
     * @static
     * @private
     * @method getEventNamespace
     * @param wizard {Object} A jQuery wizard object
     * @return {String} Returns the unique event namespace for the given wizard
     */
    function getEventNamespace(wizard) {
        var eventNamespace = wizard.data("eventNamespace");

        if (eventNamespace == null) {
            eventNamespace = "." + getUniqueId(wizard);
            wizard.data("eventNamespace", eventNamespace);
        }

        return eventNamespace;
    }

    function getStepAnchor(wizard, index) {
        var uniqueId = getUniqueId(wizard);

        return wizard.find("#" + uniqueId + _tabSuffix + index);
    }

    function getStepPanel(wizard, index) {
        var uniqueId = getUniqueId(wizard);

        return wizard.find("#" + uniqueId + _tabpanelSuffix + index);
    }

    function getStepTitle(wizard, index) {
        var uniqueId = getUniqueId(wizard);

        return wizard.find("#" + uniqueId + _titleSuffix + index);
    }

    function getOptions(wizard) {
        return wizard.data("options");
    }

    function getState(wizard) {
        return wizard.data("state");
    }

    function getSteps(wizard) {
        return wizard.data("steps");
    }

    /**
     * Gets a specific step object by index.
     *
     * @static
     * @private
     * @method getStep
     * @param index {Integer} An integer that belongs to the position of a step
     * @return {Object} A specific step object
     **/
    function getStep(wizard, index) {
        var steps = getSteps(wizard);

        if (index < 0 || index >= steps.length) {
            throwError(_indexOutOfRangeErrorMessage);
        }

        return steps[index];
    }

    /**
     * Gets or creates if not exist an unique id from the given wizard instance.
     *
     * @static
     * @private
     * @method getUniqueId
     * @param wizard {Object} A jQuery wizard object
     * @return {String} Returns the unique id for the given wizard
     */
    function getUniqueId(wizard) {
        var uniqueId = wizard.data("uid");

        if (uniqueId == null) {
            uniqueId = wizard._id();
            if (uniqueId == null) {
                uniqueId = "steps-uid-".concat(_uniqueId);
                wizard._id(uniqueId);
            }

            _uniqueId++;
            wizard.data("uid", uniqueId);
        }

        return uniqueId;
    }

    /**
     * Gets a valid enum value by checking a specific enum key or value.
     * 
     * @static
     * @private
     * @method getValidEnumValue
     * @param enumType {Object} Type of enum
     * @param keyOrValue {Object} Key as `String` or value as `Integer` to check for
     */
    function getValidEnumValue(enumType, keyOrValue) {
        validateArgument("enumType", enumType);
        validateArgument("keyOrValue", keyOrValue);

        // Is key
        if (typeof keyOrValue === "string") {
            var value = enumType[keyOrValue];
            if (value === undefined) {
                throwError("The enum key '{0}' does not exist.", keyOrValue);
            }

            return value;
        }
        // Is value
        else if (typeof keyOrValue === "number") {
            for (var key in enumType) {
                if (enumType[key] === keyOrValue) {
                    return keyOrValue;
                }
            }

            throwError("Invalid enum value '{0}'.", keyOrValue);
        }
        // Type is not supported
        else {
            throwError("Invalid key or value type.");
        }
    }

    /**
     * Routes to the next step.
     *
     * @static
     * @private
     * @method goToNextStep
     * @param wizard {Object} The jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @return {Boolean} Indicates whether the action executed
     **/
    function goToNextStep(wizard, options, state) {
        return paginationClick(wizard, options, state, increaseCurrentIndexBy(state, 1));
    }

    /**
     * Routes to the previous step.
     *
     * @static
     * @private
     * @method goToPreviousStep
     * @param wizard {Object} The jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @return {Boolean} Indicates whether the action executed
     **/
    function goToPreviousStep(wizard, options, state) {
        return paginationClick(wizard, options, state, decreaseCurrentIndexBy(state, 1));
    }

    /**
     * Routes to a specific step by a given index.
     *
     * @static
     * @private
     * @method goToStep
     * @param wizard {Object} The jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param index {Integer} The position (zero-based) to route to
     * @return {Boolean} Indicates whether the action succeeded or failed
     **/
    function goToStep(wizard, options, state, index) {
        console.log(state);
        console.log(options);
        console.log(wizard);
        if (index < 0 || index >= state.stepCount) {
            throwError(_indexOutOfRangeErrorMessage);
        }

        if (options.forceMoveForward && index < state.currentIndex) {
            return;
        }
        var vCheck = 0;
        var dropVal = $('#stateDrop').val();
        var oldIndex = state.currentIndex;
        if (oldIndex == 0) {
            if (dropVal == "") {
                vCheck = 1;
            }


        }



        if (dropVal == 'Beijing') {
            $('.commonHongKong').show();
            var radioValue1 = $("input[name='b_view_1']:checked").val();
            var frAllChk = $("input[name='b_view_2']:checked").val();
            $('#frAllChk').val(frAllChk);
        } else if (dropVal == 'Shanghai') {
            $('.commonHongKong').show();
            var radioValue1 = $("input[name='s_view_1']:checked").val();
            var frAllChk = $("input[name='s_view_2']:checked").val();
            $('#frAllChk').val(frAllChk);
        } else if (dropVal == 'Guangzhou') {
            $('.commonHongKong').show();
            var radioValue1 = $("input[name='g_view_1']:checked").val();
            var frAllChk = $("input[name='g_view_2']:checked").val();
            $('#frAllChk').val(frAllChk);
        } else if (dropVal == 'HongKong') {
            $('.commonHongKong').hide();
            var radioValue1 = $("input[name='h_view_1']:checked").val();
            var frAllChk = $("input[name='h_view_3']:checked").val();
            $('#frAllChk').val(frAllChk);
        } else if (dropVal == 'ChinaMainland') {
            $('.commonHongKong').show();
            var radioValue1 = $("input[name='c_view_1']:checked").val();
            var frAllChk = $("input[name='c_view_1']:checked").val();
            $('#frAllChk').val(frAllChk);
        }

        if (radioValue1 == 'A_company' && index == 2) {
            $('.genCls').hide();
            $('#cmpHld').show();
        } else if (radioValue1 == 'An_individual' && index == 2) {
            $('.genCls').hide();
            $('#indvHld').show();

            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                $('#jrnlHld').show();
                $('#indvHld').hide();
            } else {
                $('#jrnlHld').hide();
            }

        } else if (radioValue1 == 'NPO_Journalist_500_RMB' && index == 2) {
            $('.genCls').hide();
            $('#npoHld').show();
            $('#jrnlHld').hide();
        } else if (radioValue1 == 'An_investment_zone' && index == 2) {
            $('.genCls').hide();
            $('#invstHld').show();
        }
        if (radioValue1 == 'A_company' && index == 2) {
            $('#frCmp').show();
            $('#frAll').hide();
        } else {
            $('#frCmp').hide();
            $('#frAll').show();
        }

        if (vCheck == 1) {
            alert("Please select one");
            return false;
        }
        if (index == 1) {
            if (dropVal == 'Beijing') {
                if ($('input[name=b_view_1]:checked').length <= 0) {
                    alert("Please select one at this label");
                    return false;
                } else {
                    var radioValue1 = $("input[name='b_view_1']:checked").val();
                    if (radioValue1 == 'A_company') {
                        if ($('input[name=b_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var b_view_2 = $("input[name='b_view_2']:checked").val();
                            if (b_view_2 == 'Swiss_invested_company') {
                                if ($('input[name=b_view_3]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    //var b_view_3 = $("input[name='b_view_3']:checked").val();
                                    if ($('input[name=b_view_4]:checked').length <= 0) {
                                        alert("Please select one at this label");
                                        return false;
                                    }
                                }
                            } else if (b_view_2 == 'Non-Swiss_invested_company') {
                                if ($('input[name=b_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            }
                        }
                    } else if (radioValue1 == 'An_individual') {
                        if ($('input[name=b_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var b_view_2 = $("input[name='b_view_2']:checked").val();
                            if (b_view_2 == 'Individual_(above_35_y/o)') {
                                if ($('input[name=b_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (b_view_2 == 'Young_Professional_(under_35_y/o)') {
                                if ($('input[name=b_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (b_view_2 == 'journalist') {
                                if ($('input[name=b_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            }
                        }

                    } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
                        if ($('input[name=b_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        }
                        //return true;
                    } else if (radioValue1 == 'An_investment_zone') {
                        if ($('input[name=b_view_5]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        }
                    }
                }

            } else if (dropVal == 'Shanghai') {
                if ($('input[name=s_view_1]:checked').length <= 0) {
                    alert("Please select one at this label");
                    return false;
                } else {
                    var radioValue1 = $("input[name='s_view_1']:checked").val();
                    if (radioValue1 == 'A_company') {
                        if ($('input[name=s_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var s_view_2 = $("input[name='s_view_2']:checked").val();
                            if (s_view_2 == 'Swiss_invested_company') {
                                if ($('input[name=s_view_3]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    //var b_view_3 = $("input[name='b_view_3']:checked").val();
                                    if ($('input[name=s_view_5]:checked').length <= 0) {
                                        alert("Please select one at this label");
                                        return false;
                                    }
                                }
                            } else if (s_view_2 == 'Non-Swiss_invested_company') {
                                if ($('input[name=s_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    var s_view_4 = $("input[name='s_view_4']:checked").val();
                                    if (s_view_4 == '100_staff_or_more_in_Mainland_China') {
                                        if ($('input[name=s_view_5]:checked').length <= 0) {
                                            alert("Please select one at this label");
                                            return false;
                                        }
                                    } else if (s_view_4 == '1-99_staff_in_Mainlan_China') {
                                        if ($('input[name=s_view_5]:checked').length <= 0) {
                                            alert("Please select one at this label");
                                            return false;
                                        }

                                    }
                                }
                            }
                        }
                    } else if (radioValue1 == 'An_individual') {
                        if ($('input[name=s_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var s_view_2 = $("input[name='s_view_2']:checked").val();
                            if (s_view_2 == 'Individual_(above_35_y/o)') {
                                if ($('input[name=s_view_5]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (s_view_2 == 'Young_Professional_(under_35_y/o)') {
                                if ($('input[name=s_view_5]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            }
                        }

                    }
                }
            } else if (dropVal == 'Guangzhou') {
                if ($('input[name=g_view_1]:checked').length <= 0) {
                    alert("Please select one at this label");
                    return false;
                } else {
                    var radioValue1 = $("input[name='g_view_1']:checked").val();
                    if (radioValue1 == 'A_company') {
                        if ($('input[name=g_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var g_view_2 = $("input[name='g_view_2']:checked").val();
                            if (g_view_2 == 'Swiss_invested_company') {
                                if ($('input[name=g_view_3]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    //var b_view_3 = $("input[name='b_view_3']:checked").val();
                                    if ($('input[name=g_view_5]:checked').length <= 0) {
                                        alert("Please select one at this label");
                                        return false;
                                    }
                                }
                            } else if (g_view_2 == 'Non-Swiss_invested_company') {
                                if ($('input[name=g_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    var g_view_4 = $("input[name='g_view_4']:checked").val();
                                    if (g_view_4 == '100_staff_or_more_in_Mainland_China') {
                                        if ($('input[name=g_view_5]:checked').length <= 0) {
                                            alert("Please select one at this label");
                                            return false;
                                        }
                                    } else if (g_view_4 == '1-99_staff_in_Mainland_China') {
                                        if ($('input[name=g_view_5]:checked').length <= 0) {
                                            alert("Please select one at this label");
                                            return false;
                                        }

                                    }
                                }
                            }
                        }
                    } else if (radioValue1 == 'An_individual') {
                        if ($('input[name=g_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var g_view_2 = $("input[name='g_view_2']:checked").val();
                            if (g_view_2 == 'Individual_(above_35_y/o)') {
                                if ($('input[name=g_view_5]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            }
                        }

                    }
                }
            } else if (dropVal == 'HongKong') {


                if ($('input[name=h_view_1]:checked').length <= 0) {
                    alert("Please select one at this label");
                    return false;
                } else {
                    var radioValue1 = $("input[name='h_view_1']:checked").val();
                    if (radioValue1 == 'A_company') {
                        if ($('input[name=h_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var h_view_2 = $("input[name='h_view_2']:checked").val();
                            if (h_view_2 == '50+_employees') {
                                if ($('input[name=h_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (h_view_2 == '25-49_employees') {
                                if ($('input[name=h_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (h_view_2 == '1-24_employees') {
                                if ($('input[name=h_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            }
                        }
                    } else if (radioValue1 == 'An_individual') {
                        if ($('input[name=h_view_3]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var h_view_3 = $("input[name='h_view_3']:checked").val();
                            if (h_view_3 == 'Individual_/_Overseas_(above_35_y/o)') {
                                if ($('input[name=h_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }
                            } else if (h_view_3 == 'Young_Professional_(under_35_y/o)') {
                                if ($('input[name=h_view_4]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                }

                            }
                        }

                    }
                }


            } else if (dropVal == 'ChinaMainland') {

                if ($('input[name=c_view_1]:checked').length <= 0) {
                    alert("Please select one at this label");
                    return false;
                } else {
                    var radioValue1 = $("input[name='c_view_1']:checked").val();
                    if (radioValue1 == 'A_company') {
                        if ($('input[name=c_view_2]:checked').length <= 0) {
                            alert("Please select one at this label");
                            return false;
                        } else {
                            var c_view_2 = $("input[name='c_view_2']:checked").val();
                            if (c_view_2 == 'Swiss_invested_company') {
                                if ($('input[name=c_view_3]:checked').length <= 0) {
                                    alert("Please select one at this label");
                                    return false;
                                } else {
                                    var c_view_3 = $("input[name='c_view_3']:checked").val();
                                    if (c_view_3 == '100_staff_or_more_in_Mainland_China') {
                                        if ($('input[name=c_view_4]:checked').length <= 0) {
                                            alert("Please select one at this label");
                                            return false;
                                        }
                                    } else if (c_view_3 == '1-99_staff_in_Mainland_China') {
                                        //return true;
                                    }

                                }
                            } else if (s_view_2 == 'Non-Swiss_invested_company') {
                                //return true;
                            }
                        }
                    } else if (radioValue1 == 'An_individual') {
                        //return true;
                    }
                }
            }
        }

        if (index == 1) {
            
            if (dropVal == 'HongKong') {
                $('#non_hong_kong').hide();
                $('#hong_kong_add').show();
                $('#nmcmpno').text('Hong Kong');
                /*$('#province_area_english').html('');
                $('#province_area_english').append('<option value=""> --Select-- </option><option value="Beijing">Beijing</option><option value="Shanghai">Shanghai</option><option value="Guangzhou">Guangzhou</option><option value="HongKong" selected >Hong Kong</option><option value="ChinaMainland">China Mainland</option>');*/

            } else if (dropVal == 'ChinaMainland') {
                $('#hong_kong_add').hide();
                $('#non_hong_kong').show();
                $('#nmcmpno').text('Mainland China');
                /* $('#province_area_english').html('');
                 $('#province_area_english').append('<option value=""> --Select-- </option><option value="Beijing">Beijing</option><option value="Shanghai">Shanghai</option><option value="Guangzhou">Guangzhou</option><option value="HongKong">Hong Kong</option><option value="ChinaMainland" selected >China Mainland</option>');*/
            } else if (dropVal == 'Shanghai') {
                $('#hong_kong_add').hide();
                $('#non_hong_kong').show();
                $('#nmcmpno').text('Mainland China');
                /*$('#province_area_english').html('');
                $('#province_area_english').append('<option value=""> --Select-- </option><option value="Beijing">Beijing</option><option value="Shanghai" selected >Shanghai</option><option value="Guangzhou">Guangzhou</option><option value="HongKong">Hong Kong</option><option value="ChinaMainland">China Mainland</option>');*/
            } else if (dropVal == 'Guangzhou') {
                $('#hong_kong_add').hide();
                $('#non_hong_kong').show();
                $('#nmcmpno').text('Mainland China');
                /* $('#province_area_english').html('');
                 $('#province_area_english').append('<option value=""> --Select-- </option><option value="Beijing">Beijing</option><option value="Shanghai">Shanghai</option><option value="Guangzhou" selected >Guangzhou</option><option value="HongKong">Hong Kong</option><option value="ChinaMainland">China Mainland</option>');*/
            } else if (dropVal == 'Beijing') {
                $('#hong_kong_add').hide();
                $('#non_hong_kong').show();
                $('#nmcmpno').text('Mainland China');
                /* $('#province_area_english').html('');
                 $('#province_area_english').append('<option value=""> --Select-- </option><option value="Beijing" selected >Beijing</option><option value="Shanghai">Shanghai</option><option value="Guangzhou">Guangzhou</option><option value="HongKong">Hong Kong</option><option value="ChinaMainland">China Mainland</option>');*/
            }


            var b_view_1 = $("input[name='b_view_1']:checked").val();
            var c_view_1 = $("input[name='c_view_1']:checked").val();
            var h_view_1 = $("input[name='h_view_1']:checked").val();
            var g_view_1 = $("input[name='g_view_1']:checked").val();
            var s_view_1 = $("input[name='s_view_1']:checked").val();
            /*alert(b_view_1);
            alert(c_view_1);
            alert(h_view_1);
            alert(g_view_1);
            alert(s_view_1);*/
            if (c_view_1 == 'An_individual' || h_view_1 == 'An_individual' || g_view_1 == 'An_individual' || s_view_1 == 'An_individual') {
                //alert('hfhffhfhffh');
                $('#cominfo').hide();
                $('#blankinfo').show();
            } else {
                $('#cominfo').show();
                $('#blankinfo').hide();
            }
            if (b_view_1 == 'An_individual') {
                var b_view_2 = $("input[name='b_view_2']:checked").val();
                //alert(b_view_2);
                if (b_view_2 == 'Individual_(above_35_y/o)' || b_view_2 == 'Young_Professional_(under_35_y/o)') {
                    $('#cominfo').hide();
                    $('#blankinfo').show();
                } else {
                    $('#cominfo').show();
                    $('#blankinfo').hide();
                }
            }
            if (b_view_1 == 'NPO_Journalist_500_RMB' || b_view_1 == 'An_investment_zone' || b_view_2 == 'journalist') {
                $('.bscop').hide();
            } else {
                $('.bscop').show();
            }





        }
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

        /* Company Info Validation Start */


        if (index == 2) {
           
            $('#appenddiv').html('');
            var vs = $('#cominfo').is(":visible");
            if (vs != false) {
                companyValidation();
            }

            if (dropVal == 'HongKong') {
                
                $('.nationForAll').hide();
                $('.nationForHongkong').show();
                $('.forAll').hide();
                $('.forHongKong').show();
            } else {
                $('.nationForHongkong').hide();
                $('.nationForAll').show();
                $('.forHongKong').hide();
                $('.forAll').show();
            }
        }

        /* Company Info Validation End */

        /* Contact Info Validation Start */

        if (index == 3) {
          
            if (radioValue1 == 'A_company') {
                companyContactValidation();
            } else if (radioValue1 == 'An_individual') {
                var journalist = $("input[name='b_view_2']:checked").val();
                if (journalist == 'journalist') {
                    journalistContactValidation();
                } else {
                    individualContactValidation();
                }
            } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
                //NPOContactvalidation();

            } else if (radioValue1 == 'An_investment_zone') {
                investmentContactValidation();
            }






            var addcnt = $('#addcnt').val();
            //alert(addcnt);
            if (addcnt == 1) {
                if (radioValue1 == 'A_company') {
                    otherContactValidationc1();
                } else {
                    otherContactValidation1();
                }

            } else if (addcnt == 2) {
                if (radioValue1 == 'A_company') {
                    otherContactValidationc1();
                    otherContactValidationc2();
                } else {
                    otherContactValidation1();
                    otherContactValidation2();
                }

            }
            var showBusinessScope = $("input[name='business_scope']:checked").val();
            if (showBusinessScope != 'Other') {
                $('#showBusinessScope').html(showBusinessScope);
            } else {
                $('#showBusinessScope').html($('#other_business_scope').val());
            }
            $('#showBusinessDescriptionEnglish').html($('#business_description_english').val());
            $('#showBusinessDescriptionChinese').html($('#business_description_chinese').val());
            $('#showCompanyNameEnglish').html($('#company_name_english').val());
            $('#showCompanyNameChinese').html($('#company_name_chinese').val());
            $('#showAddressEnglish').html($('#company_address').val());
            $('#showCityEnglish').html($('#company_city').val());
            $('#showProvinceAreaEnglish').html($('#province_area_english').val());
            $('#showAddressChinese').html($('#china_office_address').val());
            $('#showCityChinese').html($('#china_office_city').val());
            $('#showZIPcode').html($('#company_zipCode').val());
            $('#showGeneralPhone').html($('#company_generalPhone').val());
            $('#showGeneralEmail').html($('#company_email').val());
            $('#showGeneralWebsite').html($('#company_website').val());
            var legal_entity = $('#legal_entity').val();
            if (legal_entity == 'domestic') {
                $('#showLegalEntity').html('Chinese Domestic');
            } else if (legal_entity == 'joint') {
                $('#showLegalEntity').html('Joint-Venture');
            } else if (legal_entity == 'foreign') {
                $('#showLegalEntity').html('Wholly Foreign-Owned');
            } else if (legal_entity == 'represent') {
                $('#showLegalEntity').html('Representative Office');
            }
            $('#showNumberEmployees').html($('#no_of_employees').val());
            $('#showSwissRegistered').html($("input[name='is_company_swiss_registered']:checked").val());
            $('#showRegisteredPRC').html($("input[name='is_company_registered_PRC']:checked").val());
            $('#showYearEstablishment').html($('#establishment_hongkong').val());
            $('#showGeographicalResponsibility').html($('#geographical_responsibility_hongkong').val());


            $('#showHQCompanyName').html($('#headquarter_name').val());
            $('#showHQAddress').html($('#headquarter_address').val());
            $('#showHQCitEnglish').html($('#headquarter_city').val());
            $('#showHQZipCode').html($('#headquarter_zipCode').val());
            $('#showHQGeneralPhone').html($('#headquarter_phone').val());






            if (radioValue1 == 'A_company') {
                $('#onlycomp').show();
                $('#An_individual').show();
                 $('#An_individual_Position_hide').show();
                 $('#A_NPO_Posotion_Show').show();
                $('#cmptle').html($("input[name='company_first_contact_title']:checked").val());
                $('#cmpdob').html($('#company_first_contact_dob').val());
                $('#cmpfnm').html($('#company_first_contact_familyName').val());
                $('#cmpgnm').html($('#company_first_contact_givenName').val());
                $('#cmpcnm').html($('#company_first_contact_chineseName').val());
                $('#cmpnation').html($("input[name='company_first_contact_nationality']:checked").val());
                $('#cmppc').html($('#company_first_contact_position').val());
                $('#cmpadde').html($('#company_first_contact_english_address').val());
                $('#cmpcte').html($('#company_first_contact_english_city').val());
                $('#cmppa').html($('#company_first_contact_province_area').val());
                $('#cmpaddc').html($('#company_first_contact_address_chinese').val());
                $('#cmpctc').html($('#company_first_contact_city_chinese').val());
                $('#cmpzipe').html($('#company_first_contact_zip').val());
                $('#cmpdp').html($('#company_first_contact_direct_phone').val());
                $('#cmpde').html($('#company_first_contact_direct_email').val());
                $('#cmpmob').html($('#company_first_contact_mobile').val());

                $('#cmptle2').html($("input[name='company_second_contact_person_title']:checked").val());
                $('#cmpfnm2').html($('#company_second_contact_person_familyName').val());
                $('#cmpdateofbirth').html($('#company_second_contact_person_dob').val());
                $('#cmpgnm2').html($('#company_second_contact_person_givenName').val());
                $('#cmpcnm2').html($('#second_contact_person_chineseName').val());
                
                $('#cmp_nationalty').html($("input[name='company_second_contact_person_nationality']:checked").val());
                $('#cmp_position').html($('#company_second_contact_position').val());
                
                $('#cmpadde2').html($('#company_second_contact_person_address_english').val());
                $('#cmpcte2').html($('#company_second_contact_person_city_english').val());
                $('#cmppa2').html($('#company_second_contact_person_area').val());
                $('#cmpaddc2').html($('#company_second_contact_person_address_chinese').val());
                $('#cmpctc2').html($('#company_second_contact_person_city_chinese').val());
                $('#cmpzipe2').html($('#company_second_contact_person_zipCode').val());
                $('#cmpdp2').html($('#second_contact_person_directPhone').val());
                $('#cmpde2').html($('#second_contact_person_directMail').val());
                $('#cmpmob2').html($('#second_contact_person_mobile').val());
                $('#showProvinceArea').html($('#headquarter_province_area_english').val());
                
            } else if (radioValue1 == 'An_individual') {
                $('#A_NPO_Posotion_Show').show();
                $('#onlycomp').hide();
                 $('#An_individual_show').show();
                 $('#An_individual_Position_hide').hide();
                var journalist = $("input[name='b_view_2']:checked").val();
                if (journalist == 'journalist') {
                    $('#onlycomp').show();
                    $('#cmptle').html($("input[name='journalist_contact_title']:checked").val());
                    $('#cmpdob').html($('#journalist_contact_dob').val());
                    $('#cmpfnm').html($('#journalist_contact_familyName').val());
                    $('#cmpgnm').html($('#journalist_contact_givenName').val());
                    $('#cmpcnm').html($('#journalist_contact_chineseName').val());
                    $('#cmpnation').html($("input[name='journalist_contact_Nationality']:checked").val());
                    $('#cmppc').html('');
                    $('#cmpadde').html($('#journalist_contact_address_english').val());
                    $('#cmpcte').html($('#journalist_contact_city_english').val());
                    $('#cmppa').html($('#journalist_contact_province_area').val());
                    $('#cmpaddc').html($('#journalist_contact_address_chinese').val());
                    $('#cmpctc').html($('#journalist_contact_city_chinese').val());
                    $('#cmpzipe').html($('#journalist_contact_zip_chinese').val());
                    $('#cmpdp').html($('#journalist_contact_phone').val());
                    $('#cmpde').html($('#journalist_contact_email').val());
                    $('#cmpmob').html($('#journalist_contact_mobile').val());

                    $('#cmptle2').html($("input[name='journalist_second_contact_title']:checked").val());
                    $('#cmpfnm2').html($('#journalist_second_contact_familyName').val());
                    $('#cmpdateofbirth').html($('#company_second_contact_person_dob').val());
                    $('#cmpgnm2').html($('#journalist_second_contact_givenName').val());
                    $('#cmpcnm2').html($('#journalist_second_contact_chineseName').val());
                    
                    $('#cmp_nationalty').html($("input[name='company_second_contact_person_nationality']:checked").val());
                    $('#cmp_position').html($('#company_second_contact_position').val());
                    $('#cmpadde2').html($('#journalist_second_contact_address_english').val());
                    $('#cmpcte2').html($('#journalist_second_contact_city_english').val());
                    $('#cmppa2').html($('#journalist_second_contact_province_area').val());
                    $('#cmpaddc2').html($('#journalist_second_contact_address_chinese').val());
                    $('#cmpctc2').html($('#journalist_second_contact_city_chinese').val());
                    $('#cmpzipe2').html($('#journalist_second_contact_zip_code').val());
                    $('#cmpdp2').html($('#journalist_second_contact_phone').val());
                    $('#cmpde2').html($('#journalist_second_contact_email').val());
                    $('#cmpmob2').html($('#journalist_second_contact_mobile').val());
                } else {
                    $('#cmptle').html($("input[name='individual_contact_title']:checked").val());
                    $('#cmpdob').html($('#individual_contact_dob').val());
                    $('#cmpfnm').html($('#individual_contact_familyName').val());
                    $('#cmpgnm').html($('#individual_contact_givenName').val());
                    $('#cmpcnm').html($('#individual_contact_chineseName').val());
                    $('#cmpnation').html($("input[name='individual_contact_Nationality']:checked").val());
                    $('#cmppc').html('');
                    $('#cmpadde').html($('#individual_contact_address_english').val());
                    $('#cmpcte').html($('#individual_contact_city_english').val());
                    $('#cmppa').html($('#individual_contact_province_area').val());
                    $('#cmpaddc').html($('#individual_contact_address_chinese').val());
                    $('#cmpctc').html($('#individual_contact_city_chinese').val());
                    $('#cmpzipe').html($('#individual_contact_zip_chinese').val());
                    $('#cmpdp').html($('#individual_contact_directPhone').val());
                    $('#cmpde').html($('#individual_contact_email').val());
                    $('#cmpmob').html($('#individual_contact_phone').val());

                    $('#cmptle2').html($("input[name='individual_second_contact_title']:checked").val());
                    $('#cmpfnm2').html($('#individual_second_contact_familyName').val());
                    $('#cmpdateofbirth').html($('#company_second_contact_person_dob').val());
                    $('#cmpgnm2').html($('#individual_second_contact_givenName').val());
                    $('#cmpcnm2').html($('#individual_second_contact_chineseName').val());
                    $('#cmp_nationalty').html($("input[name='company_second_contact_person_nationality']:checked").val());
                    $('#cmp_position').html($('#company_second_contact_position').val());
                    $('#cmpadde2').html($('#individual_second_contact_address_english').val());
                    $('#cmpcte2').html($('#individual_second_contact_city_english').val());
                    $('#cmppa2').html($('#individual_second_contact_area').val());
                    $('#cmpaddc2').html($('#individual_second_contact_address_chinese').val());
                    $('#cmpctc2').html($('#individual_second_contact_city_chinese').val());
                    $('#cmpzipe2').html($('#individual_second_contact_zip_code').val());
                    $('#cmpdp2').html($('#individual_second_contact_phone').val());
                    $('#cmpde2').html($('#individual_second_contact_email').val());
                    $('#cmpmob2').html($('#individual_second_contact_mobile').val());
                }

            } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
                $('#onlycomp').show();
                $('#An_individual').show();
                $('#A_NPO_Field').show();
                $('#A_NPO_Field_1').show();
                
                
                //$('#An_individual_Position_hide').show();
                $('#A_NPO_Posotion_Show').hide();
                
                $('#cmptle').html($("input[name='npo_contact_title']:checked").val());
                $('#cmpdob').html($('#npo_contact_dob').val());
                $('#cmpfnm').html($('#npo_contact_familyName').val());
                $('#cmpgnm').html($('#npo_contact_givenName').val());
                $('#cmpcnm').html($('#npo_contact_chineseName').val());
                $('#cmpnation').html($("input[name='npo_contact_Nationality']:checked").val());
                $('#cmppc').html('');
                $('#cmpadde').html($('#npo_contact_address_english').val());
                $('#cmpcte').html($('#npo_contact_city_english').val());
                $('#cmppa').html($('#npo_province_area').val());
                $('#cmpaddc').html($('#npo_contact_address_chinese').val());
                $('#cmpctc').html($('#npo_contact_city_chinese').val());
                $('#cmpzipe').html($('#npo_contact_zip_chinese').val());
                $('#cmpdp').html($('#npo_contact_phone').val());
                $('#cmpde').html($('#npo_contact_email').val());
                $('#cmpmob').html($('#npo_contact_mobile').val());

                $('#cmptle2').html($("input[name='npo_second_contact_title']:checked").val());
                $('#cmpfnm2').html($('#npo_second_contact_familyName').val());
                $('#cmpdateofbirth').html($('#company_second_contact_person_dob').val());
                $('#cmpgnm2').html($('#npo_second_contact_givenName').val());
                $('#cmpcnm2').html($('#npo_second_contact_chineseName').val());
                $('#cmp_nationalty').html($("input[name='company_second_contact_person_nationality']:checked").val());
                $('#cmp_position').html($('#company_second_contact_position').val());
                $('#cmpadde2').html($('#npo_second_contact_address_english').val());
                $('#cmpcte2').html($('#npo_second_contact_city_english').val());
                $('#cmppa2').html($('#npo_second_contact_area').val());
                $('#cmpaddc2').html($('#npo_second_contact_address_chinese').val());
                $('#cmpctc2').html($('#npo_second_contact_city_chinese').val());
                $('#cmpzipe2').html($('#npo_second_contact_zip_chinese').val());
                $('#cmpdp2').html($('#npo_second_contact_phone').val());
                $('#cmpde2').html($('#npo_second_contact_email').val());
                $('#cmpmob2').html($('#npo_second_contact_mobile').val());
                $('#cmpdateofbirth').html($('#npo_second_contact_dob').val());
                $('#cmp_nationalty').html($("input[name='npo_second_contact_nationality']:checked").val());
                $('#type_org').html($('#npo_organization_type').val());
                $('#org_dec').html($('#npo_organization_description').val());
                
            } else if (radioValue1 == 'An_investment_zone') {
                $('#onlycomp').show();
                $('#A_NPO_Posotion_Show').show();
                $('#An_individual').show();
                $('#cmptle').html($("input[name='investZone_contact_title']:checked").val());
                $('#cmpdob').html($('#investZone_contact_dob').val());
                $('#cmpfnm').html($('#investZone_contact_familyName').val());
                $('#cmpgnm').html($('#investZone_contact_givenName').val());
                $('#cmpcnm').html($('#investZone_contact_chineseName').val());
                $('#cmpnation').html($("input[name='investZone_contact_nationality']:checked").val());

                $('#cmppc').html($('#investZone_contact_position').val());

                $('#cmpadde').html($('#investZone_contact_address_english').val());
                $('#cmpcte').html($('#investZone_contact_city_english').val());
                $('#cmppa').html($('#investZone_contact_province_area').val());
                $('#cmpaddc').html($('#investZone_contact_address_chinese').val());
                $('#cmpctc').html($('#investZone_contact_city_chinese').val());
                $('#cmpzipe').html($('#investZone_contact_zipCode').val());
                $('#cmpdp').html($('#investZone_contact_directPhone').val());
                $('#cmpde').html($('#investZone_contact_directEmail').val());
                $('#cmpmob').html($('#investZone_contact_mobile').val());

                $('#cmptle2').html($("input[name='investZone_second_contact_title']:checked").val());
                $('#cmpfnm2').html($('#investZone_second_contact_familyName').val());
                $('#cmpdateofbirth').html($('#company_second_contact_person_dob').val());
                $('#cmpgnm2').html($('#investZone_second_contact_givenName').val());
                $('#cmpcnm2').html($('#investZone_second_contact_chineseName').val());
                $('#cmp_nationalty').html($("input[name='company_second_contact_person_nationality']:checked").val());
                $('#cmp_position').html($('#company_second_contact_position').val());
                $('#cmpadde2').html($('#investZone_second_contact_address_english').val());
                $('#cmpcte2').html($('#investZone_second_contact_city_english').val());
                $('#cmppa2').html($('#investZone_second_contact_province_area').val());
                $('#cmpaddc2').html($('#investZone_second_contact_address_chinese').val());
                $('#cmpctc2').html($('#investZone_second_contact_city_chinese').val());
                $('#cmpzipe2').html($('#investZone_second_contact_zipCode').val());
                $('#cmpdp2').html($('#investZone_second_contact_phone').val());
                $('#cmpde2').html($('#investZone_second_contact_email').val());
                $('#cmpmob2').html($('#investZone_second_contact_mobile').val());
            }


            if (dropVal == 'HongKong') {
                 $('#Beijing_I_We').show();
                $('#location').html(dropVal);
                var val = $("input[name='h_view_1']:checked").val();
                var res = val.replace("_", " ");
                $('#am_we').html(res);
                
                  if (radioValue1 != 'An_individual') {
                      $('#hongkong_indi_we').show();
                    var val3 = $("input[name='h_view_2']:checked").val();
                    var res3 = val3.replace("_", " ");
                    $('#am_we_have').html(res3);
                }
                
                
                if (radioValue1 == 'An_individual') {
                    
                    $('#hongkong_indi').show();
                 
                var val2 = $("input[name='h_view_3']:checked").val();
                var res2 = val2.split('_').join(' ');
                $('#apply_for_hongKong').html(res2);
                }
               
               
                var val1 = $("input[name='h_view_4']:checked").val();
                
                if (val1 != '') {
                    var res1 = val1.split('_').join(' ');
                    
                    $('#apply_for').html(res1);
                } else {
                    $('#apply_for').html('No membership available.');
                }
            } else if (dropVal == 'ChinaMainland') {
                $('#location').html(dropVal);
                 $('#Beijing_I_We').show();
                if (radioValue1 != 'An_individual') {
                      $('#hongkong_indi_we').show();
                      $('#I_M_W_R').show();
                      
                  }
                
                var val = $("input[name='c_view_1']:checked").val();
                var res = val.replace("_", " ");
                $('#am_we').html(res);
                
                
                var val2 = $("input[name='c_view_2']:checked").val();
                var res2 = val2.split('_').join(' ');
                $('#am_we_we_are').html(res2);
                
                var val3 = $("input[name='c_view_3']:checked").val();
                var res3 = val3.split('_').join(' ');
                $('#am_we_have').html(res3);
                
                
                
                var val1 = $("input[name='c_view_4']:checked").val();
                if (val1 != '') {
                    var res1 = val1.split('_').join(' ');
                    $('#apply_for').html(res1);
                } else {
                    $('#apply_for').html('No membership available.');
                }
            } else if (dropVal == 'Shanghai') {
                 $('#Beijing_I_We').show();
                $('#location').html(dropVal);
                $('#I_M_W_R').show();
                if (radioValue1 != 'An_individual') {
                    $('#hongkong_indi_we').show();
                }
                
                var val = $("input[name='s_view_1']:checked").val();
                var res = val.replace("_", " ");
                $('#am_we').html(res);
                
               
                var val2 = $("input[name='s_view_2']:checked").val();
                var res2 = val2.split('_').join(' ');
                $('#am_we_we_are').html(res2);
               
                
                if (radioValue1 != 'An_individual') {
                    var val3 = $("input[name='s_view_3']:checked").val();
                    var res3 = val3.split('_').join(' ');
                    $('#am_we_have').html(res3);
                 }
                var val1 = $("input[name='s_view_5']:checked").val();
                if (val1 != '') {
                    var res1 = val1.split('_').join(' ');
                    $('#apply_for').html(res1);
                } else {
                    $('#apply_for').html('No membership available.');
                }
            } else if (dropVal == 'Guangzhou') {
                
                 $('#Beijing_I_We').show();
                $('#I_M_W_R').show();
                $('#guan_indi_we').show();
                
                $('#location').html(dropVal);
                var val = $("input[name='g_view_1']:checked").val();
                var res = val.replace("_", " ");
                $('#am_we').html(res);
                
                var val2 = $("input[name='g_view_2']:checked").val();
                var res2 = val2.split('_').join(' ');
                $('#am_we_we_are').html(res2);
                
                 if (radioValue1 != 'An_individual') {
                     
                     $('#hongkong_indi_we').show();
                    var val3 = $("input[name='g_view_3']:checked").val();
                    var res3 = val3.split('_').join(' ');
                    $('#am_we_have').html(res3);
                }
                
                var val1 = $("input[name='g_view_5']:checked").val();
                if (val1 != '') {
                    //var res1 = val1.replace("_", " ");
                    var res1 =   val1.split('_').join(' ');
                  
                    $('#apply_for').html(res1);
                } else {
                    $('#apply_for').html('No membership available.');
                }
            } else if (dropVal == 'Beijing') {
                $('#location').html(dropVal);
                var val = $("input[name='b_view_1']:checked").val();
                var res = val.replace("_", " ");
                $('#am_we').html(res);
                
                //$('#hongkong_indi_we').show();
                 $('#I_M_W_R').show();
                
                
                if (radioValue1 != 'An_investment_zone' ) {
                    var val3 = $("input[name='b_view_2']:checked").val();
                    var res3 = val3.split('_').join(' ');
                    $('#am_we_we_are').html(res3);
                }
                 if (radioValue1 != 'An_individual' && radioValue1 != 'NPO_Journalist_500_RMB' && radioValue1 != 'An_investment_zone' && frAllChk != 'Non-Swiss_invested_company' ) {
                    
                    var val4 = $("input[name='b_view_3']:checked").val();
                    var res4 = val4.split('_').join(' ');
                    $('#am_we_have').html(res4);
                 }
                
                    
                 if (radioValue1 != 'NPO_Journalist_500_RMB' && radioValue1 != 'An_investment_zone'  ) {   
                    var val1 = $("input[name='b_view_4']:checked").val();
                    if (val1 != '') {
                        var res1 = val1.split('_').join(' ');
                        $('#apply_for').html(res1);
                    } else {
                        $('#apply_for').html('No membership available.');
                    }
                }
            }

        }
        if (wizard.triggerHandler("stepChanging", [state.currentIndex, index])) {
            // Save new state
            state.currentIndex = index;
            saveCurrentStateToCookie(wizard, options, state);

            // Change visualisation
            refreshStepNavigation(wizard, options, state, oldIndex);
            refreshPagination(wizard, options, state);
            loadAsyncContent(wizard, options, state);
            startTransitionEffect(wizard, options, state, index, oldIndex, function () {
                wizard.triggerHandler("stepChanged", [index, oldIndex]);
            });
        } else {
            wizard.find(".steps li").eq(oldIndex).addClass("error");
        }

        return true;
    }

    function increaseCurrentIndexBy(state, increaseBy) {
        return state.currentIndex + increaseBy;
    }

    /**
     * Initializes the component.
     *
     * @static
     * @private
     * @method initialize
     * @param options {Object} The component settings
     **/
    function initialize(options) {
        /*jshint -W040 */
        var opts = $.extend(true, {}, defaults, options);

        return this.each(function () {
            var wizard = $(this);
            var state = {
                currentIndex: opts.startIndex,
                currentStep: null,
                stepCount: 0,
                transitionElement: null
            };

            // Create data container
            wizard.data("options", opts);
            wizard.data("state", state);
            wizard.data("steps", []);

            analyzeData(wizard, opts, state);
            render(wizard, opts, state);
            registerEvents(wizard, opts);

            // Trigger focus
            if (opts.autoFocus && _uniqueId === 0) {
                getStepAnchor(wizard, opts.startIndex).focus();
            }

            wizard.triggerHandler("init", [opts.startIndex]);
        });
    }

    /**
     * Inserts a new step to a specific position.
     *
     * @static
     * @private
     * @method insertStep
     * @param wizard {Object} The jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param index {Integer} The position (zero-based) to add
     * @param step {Object} The step object to add
     * @example
     *     $("#wizard").steps().insert(0, {
     *         title: "Title",
     *         content: "", // optional
     *         contentMode: "async", // optional
     *         contentUrl: "/Content/Step/1" // optional
     *     });
     * @chainable
     **/
    function insertStep(wizard, options, state, index, step) {
        if (index < 0 || index > state.stepCount) {
            throwError(_indexOutOfRangeErrorMessage);
        }

        // TODO: Validate step object

        // Change data
        step = $.extend({}, stepModel, step);
        insertStepToCache(wizard, index, step);
        if (state.currentIndex !== state.stepCount && state.currentIndex >= index) {
            state.currentIndex++;
            saveCurrentStateToCookie(wizard, options, state);
        }
        state.stepCount++;

        var contentContainer = wizard.find(".content"),
            header = $("<{0}>{1}</{0}>".format(options.headerTag, step.title)),
            body = $("<{0}></{0}>".format(options.bodyTag));

        if (step.contentMode == null || step.contentMode === contentMode.html) {
            body.html(step.content);
        }

        if (index === 0) {
            contentContainer.prepend(body).prepend(header);
        } else {
            getStepPanel(wizard, (index - 1)).after(body).after(header);
        }

        renderBody(wizard, state, body, index);
        renderTitle(wizard, options, state, header, index);
        refreshSteps(wizard, options, state, index);
        if (index === state.currentIndex) {
            refreshStepNavigation(wizard, options, state);
        }
        refreshPagination(wizard, options, state);

        return wizard;
    }

    /**
     * Inserts a step object to the cache at a specific position.
     *
     * @static
     * @private
     * @method insertStepToCache
     * @param wizard {Object} A jQuery wizard object
     * @param index {Integer} The position (zero-based) to add
     * @param step {Object} The step object to add
     **/
    function insertStepToCache(wizard, index, step) {
        getSteps(wizard).splice(index, 0, step);
    }

    /**
     * Handles the keyup DOM event for pagination.
     *
     * @static
     * @private
     * @event keyup
     * @param event {Object} An event object
     */
    function keyUpHandler(event) {
        var wizard = $(this),
            options = getOptions(wizard),
            state = getState(wizard);

        if (options.suppressPaginationOnFocus && wizard.find(":focus").is(":input")) {
            event.preventDefault();
            return false;
        }

        var keyCodes = {
            left: 37,
            right: 39
        };
        if (event.keyCode === keyCodes.left) {
            event.preventDefault();
            goToPreviousStep(wizard, options, state);
        } else if (event.keyCode === keyCodes.right) {
            event.preventDefault();
            goToNextStep(wizard, options, state);
        }
    }

    /**
     * Loads and includes async content.
     *
     * @static
     * @private
     * @method loadAsyncContent
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     */
    function loadAsyncContent(wizard, options, state) {
        if (state.stepCount > 0) {
            var currentIndex = state.currentIndex,
                currentStep = getStep(wizard, currentIndex);

            if (!options.enableContentCache || !currentStep.contentLoaded) {
                switch (getValidEnumValue(contentMode, currentStep.contentMode)) {
                case contentMode.iframe:
                    wizard.find(".content > .body").eq(state.currentIndex).empty()
                        .html("<iframe src=\"" + currentStep.contentUrl + "\" frameborder=\"0\" scrolling=\"no\" />")
                        .data("loaded", "1");
                    break;

                case contentMode.async:
                    var currentStepContent = getStepPanel(wizard, currentIndex)._aria("busy", "true")
                        .empty().append(renderTemplate(options.loadingTemplate, {
                            text: options.labels.loading
                        }));

                    $.ajax({
                        url: currentStep.contentUrl,
                        cache: false
                    }).done(function (data) {
                        currentStepContent.empty().html(data)._aria("busy", "false").data("loaded", "1");
                        wizard.triggerHandler("contentLoaded", [currentIndex]);
                    });
                    break;
                }
            }
        }
    }

    /**
     * Fires the action next or previous click event.
     *
     * @static
     * @private
     * @method paginationClick
     * @param wizard {Object} The jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param index {Integer} The position (zero-based) to route to
     * @return {Boolean} Indicates whether the event fired successfully or not
     **/
    function paginationClick(wizard, options, state, index) {
        var oldIndex = state.currentIndex;

        if (index >= 0 && index < state.stepCount && !(options.forceMoveForward && index < state.currentIndex)) {
            var anchor = getStepAnchor(wizard, index),
                parent = anchor.parent(),
                isDisabled = parent.hasClass("disabled");

            // Enable the step to make the anchor clickable!
            parent._enableAria();
            anchor.click();

            // An error occured
            if (oldIndex === state.currentIndex && isDisabled) {
                // Disable the step again if current index has not changed; prevents click action.
                parent._enableAria(false);
                return false;
            }

            return true;
        }

        return false;
    }

    /**
     * Fires when a pagination click happens.
     *
     * @static
     * @private
     * @event click
     * @param event {Object} An event object
     */
    function paginationClickHandler(event) {
        event.preventDefault();

        var anchor = $(this),
            wizard = anchor.parent().parent().parent().parent(),
            options = getOptions(wizard),
            state = getState(wizard),
            href = anchor.attr("href");

        switch (href.substring(href.lastIndexOf("#") + 1)) {
        case "cancel":
            cancel(wizard);
            break;

        case "finish":
            finishStep(wizard, state);
            break;

        case "next":
            goToNextStep(wizard, options, state);
            break;

        case "previous":
            goToPreviousStep(wizard, options, state);
            break;
        }
    }

    /**
     * Refreshs the visualization state for the entire pagination.
     *
     * @static
     * @private
     * @method refreshPagination
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     */
    function refreshPagination(wizard, options, state) {
        if (options.enablePagination) {
            var finish = wizard.find(".actions a[href$='#finish']").parent(),
                next = wizard.find(".actions a[href$='#next']").parent();

            if (!options.forceMoveForward) {
                var previous = wizard.find(".actions a[href$='#previous']").parent();
                previous._enableAria(state.currentIndex > 0);
            }

            if (options.enableFinishButton && options.showFinishButtonAlways) {
                finish._enableAria(state.stepCount > 0);
                next._enableAria(state.stepCount > 1 && state.stepCount > (state.currentIndex + 1));
            } else {
                finish._showAria(options.enableFinishButton && state.stepCount === (state.currentIndex + 1));
                next._showAria(state.stepCount === 0 || state.stepCount > (state.currentIndex + 1)).
                _enableAria(state.stepCount > (state.currentIndex + 1) || !options.enableFinishButton);
            }
        }
    }

    /**
     * Refreshs the visualization state for the step navigation (tabs).
     *
     * @static
     * @private
     * @method refreshStepNavigation
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param [oldIndex] {Integer} The index of the prior step
     */
    function refreshStepNavigation(wizard, options, state, oldIndex) {
        var currentOrNewStepAnchor = getStepAnchor(wizard, state.currentIndex),
            currentInfo = $("<span class=\"current-info audible\">" + options.labels.current + " </span>"),
            stepTitles = wizard.find(".content > .title");

        if (oldIndex != null) {
            var oldStepAnchor = getStepAnchor(wizard, oldIndex);
            oldStepAnchor.parent().addClass("done").removeClass("error")._selectAria(false);
            stepTitles.eq(oldIndex).removeClass("current").next(".body").removeClass("current");
            currentInfo = oldStepAnchor.find(".current-info");
            currentOrNewStepAnchor.focus();
        }

        currentOrNewStepAnchor.prepend(currentInfo).parent()._selectAria().removeClass("done")._enableAria();
        stepTitles.eq(state.currentIndex).addClass("current").next(".body").addClass("current");
    }

    /**
     * Refreshes step buttons and their related titles beyond a certain position.
     *
     * @static
     * @private
     * @method refreshSteps
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param index {Integer} The start point for refreshing ids
     */
    function refreshSteps(wizard, options, state, index) {
        var uniqueId = getUniqueId(wizard);

        for (var i = index; i < state.stepCount; i++) {
            var uniqueStepId = uniqueId + _tabSuffix + i,
                uniqueBodyId = uniqueId + _tabpanelSuffix + i,
                uniqueHeaderId = uniqueId + _titleSuffix + i,
                title = wizard.find(".title").eq(i)._id(uniqueHeaderId);

            wizard.find(".steps a").eq(i)._id(uniqueStepId)
                ._aria("controls", uniqueBodyId).attr("href", "#" + uniqueHeaderId)
                .html(renderTemplate(options.titleTemplate, {
                    index: i + 1,
                    title: title.html()
                }));
            wizard.find(".body").eq(i)._id(uniqueBodyId)
                ._aria("labelledby", uniqueHeaderId);
        }
    }

    function registerEvents(wizard, options) {
        var eventNamespace = getEventNamespace(wizard);

        wizard.bind("canceled" + eventNamespace, options.onCanceled);
        wizard.bind("contentLoaded" + eventNamespace, options.onContentLoaded);
        wizard.bind("finishing" + eventNamespace, options.onFinishing);
        wizard.bind("finished" + eventNamespace, options.onFinished);
        wizard.bind("init" + eventNamespace, options.onInit);
        wizard.bind("stepChanging" + eventNamespace, options.onStepChanging);
        wizard.bind("stepChanged" + eventNamespace, options.onStepChanged);

        if (options.enableKeyNavigation) {
            wizard.bind("keyup" + eventNamespace, keyUpHandler);
        }

        wizard.find(".actions a").bind("click" + eventNamespace, paginationClickHandler);
    }

    /**
     * Removes a specific step by an given index.
     *
     * @static
     * @private
     * @method removeStep
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param index {Integer} The position (zero-based) of the step to remove
     * @return Indecates whether the item is removed.
     **/
    function removeStep(wizard, options, state, index) {
        // Index out of range and try deleting current item will return false.
        if (index < 0 || index >= state.stepCount || state.currentIndex === index) {
            return false;
        }

        // Change data
        removeStepFromCache(wizard, index);
        if (state.currentIndex > index) {
            state.currentIndex--;
            saveCurrentStateToCookie(wizard, options, state);
        }
        state.stepCount--;

        getStepTitle(wizard, index).remove();
        getStepPanel(wizard, index).remove();
        getStepAnchor(wizard, index).parent().remove();

        // Set the "first" class to the new first step button 
        if (index === 0) {
            wizard.find(".steps li").first().addClass("first");
        }

        // Set the "last" class to the new last step button 
        if (index === state.stepCount) {
            wizard.find(".steps li").eq(index).addClass("last");
        }

        refreshSteps(wizard, options, state, index);
        refreshPagination(wizard, options, state);

        return true;
    }

    function removeStepFromCache(wizard, index) {
        getSteps(wizard).splice(index, 1);
    }

    /**
     * Transforms the base html structure to a more sensible html structure.
     *
     * @static
     * @private
     * @method render
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     **/
    function render(wizard, options, state) {
        // Create a content wrapper and copy HTML from the intial wizard structure
        var wrapperTemplate = "<{0} class=\"{1}\">{2}</{0}>",
            orientation = getValidEnumValue(stepsOrientation, options.stepsOrientation),
            verticalCssClass = (orientation === stepsOrientation.vertical) ? " vertical" : "",
            contentWrapper = $(wrapperTemplate.format(options.contentContainerTag, "content " + options.clearFixCssClass, wizard.html())),
            stepsWrapper = $(wrapperTemplate.format(options.stepsContainerTag, "steps " + options.clearFixCssClass, "<ul id=\"primaryNav\" role=\"tablist\"></ul>")),
            stepTitles = contentWrapper.children(options.headerTag),
            stepContents = contentWrapper.children(options.bodyTag);

        // Transform the wizard wrapper and remove the inner HTML
        wizard.attr("role", "application").empty().append(stepsWrapper).append(contentWrapper)
            .addClass(options.cssClass + " " + options.clearFixCssClass + verticalCssClass);

        // Add WIA-ARIA support
        stepContents.each(function (index) {
            renderBody(wizard, state, $(this), index);
        });

        stepTitles.each(function (index) {
            renderTitle(wizard, options, state, $(this), index);
        });

        refreshStepNavigation(wizard, options, state);
        renderPagination(wizard, options, state);
    }

    /**
     * Transforms the body to a proper tabpanel.
     *
     * @static
     * @private
     * @method renderBody
     * @param wizard {Object} A jQuery wizard object
     * @param body {Object} A jQuery body object
     * @param index {Integer} The position of the body
     */
    function renderBody(wizard, state, body, index) {
        var uniqueId = getUniqueId(wizard),
            uniqueBodyId = uniqueId + _tabpanelSuffix + index,
            uniqueHeaderId = uniqueId + _titleSuffix + index;

        body._id(uniqueBodyId).attr("role", "tabpanel")._aria("labelledby", uniqueHeaderId)
            .addClass("body")._showAria(state.currentIndex === index);
    }

    /**
     * Renders a pagination if enabled.
     *
     * @static
     * @private
     * @method renderPagination
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     */
    function renderPagination(wizard, options, state) {
        console.log(wizard);
        console.log(options);
        console.log(state);
        if (options.enablePagination) {
            var pagination = "<{0} class=\"actions {1}\"><ul role=\"menu\" aria-label=\"{2}\">{3}</ul></{0}>",
                buttonTemplate = "<li id=\"{0}\" class=\"hideclass\"><a href=\"#{0}\" role=\"menuitem\">{1}</a></li>",
                buttons = "";

            if (!options.forceMoveForward) {
                buttons += buttonTemplate.format("previous", options.labels.previous);
            }

            buttons += buttonTemplate.format("next", options.labels.next);

            if (options.enableFinishButton) {
                buttons += buttonTemplate.format("finish", options.labels.finish);
            }

            if (options.enableCancelButton) {
                buttons += buttonTemplate.format("cancel", options.labels.cancel);
            }

            wizard.append(pagination.format(options.actionContainerTag, options.clearFixCssClass,
                options.labels.pagination, buttons));

            refreshPagination(wizard, options, state);
            loadAsyncContent(wizard, options, state);
        }
    }

    /**
     * Renders a template and replaces all placeholder.
     *
     * @static
     * @private
     * @method renderTemplate
     * @param template {String} A template
     * @param substitutes {Object} A list of substitute
     * @return {String} The rendered template
     */
    function renderTemplate(template, substitutes) {
        var matches = template.match(/#([a-z]*)#/gi);

        for (var i = 0; i < matches.length; i++) {
            var match = matches[i],
                key = match.substring(1, match.length - 1);

            if (substitutes[key] === undefined) {
                throwError("The key '{0}' does not exist in the substitute collection!", key);
            }

            template = template.replace(match, substitutes[key]);
        }

        return template;
    }

    /**
     * Transforms the title to a step item button.
     *
     * @static
     * @private
     * @method renderTitle
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     * @param header {Object} A jQuery header object
     * @param index {Integer} The position of the header
     */
    function renderTitle(wizard, options, state, header, index) {
        var uniqueId = getUniqueId(wizard),
            uniqueStepId = uniqueId + _tabSuffix + index,
            uniqueBodyId = uniqueId + _tabpanelSuffix + index,
            uniqueHeaderId = uniqueId + _titleSuffix + index,
            stepCollection = wizard.find(".steps > ul"),
            title = renderTemplate(options.titleTemplate, {
                index: index + 1,
                title: header.html()
            }),
            stepItem = $("<li role=\"tab\"><a id=\"" + uniqueStepId + "\" href=\"#" + uniqueHeaderId +
                "\" aria-controls=\"" + uniqueBodyId + "\">" + title + "</a></li>");

        stepItem._enableAria(options.enableAllSteps || state.currentIndex > index);

        if (state.currentIndex > index) {
            stepItem.addClass("done");
        }

        header._id(uniqueHeaderId).attr("tabindex", "-1").addClass("title");

        if (index === 0) {
            stepCollection.prepend(stepItem);
        } else {
            stepCollection.find("li").eq(index - 1).after(stepItem);
        }

        // Set the "first" class to the new first step button
        if (index === 0) {
            stepCollection.find("li").removeClass("first").eq(index).addClass("first");
        }

        // Set the "last" class to the new last step button
        if (index === (state.stepCount - 1)) {
            stepCollection.find("li").removeClass("last").eq(index).addClass("last");
        }

        // Register click event
        stepItem.children("a").bind("click" + getEventNamespace(wizard), stepClickHandler);
    }

    /**
     * Saves the current state to a cookie.
     *
     * @static
     * @private
     * @method saveCurrentStateToCookie
     * @param wizard {Object} A jQuery wizard object
     * @param options {Object} Settings of the current wizard
     * @param state {Object} The state container of the current wizard
     */
    function saveCurrentStateToCookie(wizard, options, state) {
        if (options.saveState && $.cookie) {
            $.cookie(_cookiePrefix + getUniqueId(wizard), state.currentIndex);
        }
    }

    function startTransitionEffect(wizard, options, state, index, oldIndex, doneCallback) {
        var stepContents = wizard.find(".content > .body"),
            effect = getValidEnumValue(transitionEffect, options.transitionEffect),
            effectSpeed = options.transitionEffectSpeed,
            newStep = stepContents.eq(index),
            currentStep = stepContents.eq(oldIndex);

        switch (effect) {
        case transitionEffect.fade:
        case transitionEffect.slide:
            var hide = (effect === transitionEffect.fade) ? "fadeOut" : "slideUp",
                show = (effect === transitionEffect.fade) ? "fadeIn" : "slideDown";

            state.transitionElement = newStep;
            currentStep[hide](effectSpeed, function () {
                var wizard = $(this)._showAria(false).parent().parent(),
                    state = getState(wizard);

                if (state.transitionElement) {
                    state.transitionElement[show](effectSpeed, function () {
                        $(this)._showAria();
                    }).promise().done(doneCallback);
                    state.transitionElement = null;
                }
            });
            break;

        case transitionEffect.slideLeft:
            var outerWidth = currentStep.outerWidth(true),
                posFadeOut = (index > oldIndex) ? -(outerWidth) : outerWidth,
                posFadeIn = (index > oldIndex) ? outerWidth : -(outerWidth);

            $.when(currentStep.animate({
                        left: posFadeOut
                    }, effectSpeed,
                    function () {
                        $(this)._showAria(false);
                    }),
                newStep.css("left", posFadeIn + "px")._showAria()
                .animate({
                    left: 0
                }, effectSpeed)).done(doneCallback);
            break;

        default:
            $.when(currentStep._showAria(false), newStep._showAria())
                .done(doneCallback);
            break;
        }
    }

    /**
     * Fires when a step click happens.
     *
     * @static
     * @private
     * @event click
     * @param event {Object} An event object
     */
    function stepClickHandler(event) {
        event.preventDefault();

        var anchor = $(this),
            wizard = anchor.parent().parent().parent().parent(),
            options = getOptions(wizard),
            state = getState(wizard),
            oldIndex = state.currentIndex;

        if (anchor.parent().is(":not(.disabled):not(.current)")) {
            var href = anchor.attr("href"),
                position = parseInt(href.substring(href.lastIndexOf("-") + 1), 0);


            goToStep(wizard, options, state, position);
        }

        // If nothing has changed
        if (oldIndex === state.currentIndex) {
            getStepAnchor(wizard, oldIndex).focus();
            return false;
        }
    }

    function throwError(message) {
        if (arguments.length > 1) {
            message = message.format(Array.prototype.slice.call(arguments, 1));
        }

        throw new Error(message);
    }

    /**
     * Checks an argument for null or undefined and throws an error if one check applies.
     *
     * @static
     * @private
     * @method validateArgument
     * @param argumentName {String} The name of the given argument
     * @param argumentValue {Object} The argument itself
     */
    function validateArgument(argumentName, argumentValue) {
        if (argumentValue == null) {
            throwError("The argument '{0}' is null or undefined.", argumentName);
        }
    }

    /**
     * Represents a jQuery wizard plugin.
     *
     * @class steps
     * @constructor
     * @param [method={}] The name of the method as `String` or an JSON object for initialization
     * @param [params=]* {Array} Additional arguments for a method call
     * @chainable
     **/
    $.fn.steps = function (method) {
        if ($.fn.steps[method]) {
            return $.fn.steps[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === "object" || !method) {
            return initialize.apply(this, arguments);
        } else {
            $.error("Method " + method + " does not exist on jQuery.steps");
        }
    };

    /**
     * Adds a new step.
     *
     * @method add
     * @param step {Object} The step object to add
     * @chainable
     **/
    $.fn.steps.add = function (step) {
        var state = getState(this);
        return insertStep(this, getOptions(this), state, state.stepCount, step);
    };

    /**
     * Removes the control functionality completely and transforms the current state to the initial HTML structure.
     *
     * @method destroy
     * @chainable
     **/
    $.fn.steps.destroy = function () {
        return destroy(this, getOptions(this));
    };

    /**
     * Triggers the onFinishing and onFinished event.
     *
     * @method finish
     **/
    $.fn.steps.finish = function () {
        finishStep(this, getState(this));
    };

    /**
     * Gets the current step index.
     *
     * @method getCurrentIndex
     * @return {Integer} The actual step index (zero-based)
     * @for steps
     **/
    $.fn.steps.getCurrentIndex = function () {
        return getState(this).currentIndex;
    };

    /**
     * Gets the current step object.
     *
     * @method getCurrentStep
     * @return {Object} The actual step object
     **/
    $.fn.steps.getCurrentStep = function () {
        return getStep(this, getState(this).currentIndex);
    };

    /**
     * Gets a specific step object by index.
     *
     * @method getStep
     * @param index {Integer} An integer that belongs to the position of a step
     * @return {Object} A specific step object
     **/
    $.fn.steps.getStep = function (index) {
        return getStep(this, index);
    };

    /**
     * Inserts a new step to a specific position.
     *
     * @method insert
     * @param index {Integer} The position (zero-based) to add
     * @param step {Object} The step object to add
     * @example
     *     $("#wizard").steps().insert(0, {
     *         title: "Title",
     *         content: "", // optional
     *         contentMode: "async", // optional
     *         contentUrl: "/Content/Step/1" // optional
     *     });
     * @chainable
     **/
    $.fn.steps.insert = function (index, step) {
        return insertStep(this, getOptions(this), getState(this), index, step);
    };

    /**
     * Routes to the next step.
     *
     * @method next
     * @return {Boolean} Indicates whether the action executed
     **/
    $.fn.steps.next = function () {
        return goToNextStep(this, getOptions(this), getState(this));
    };

    /**
     * Routes to the previous step.
     *
     * @method previous
     * @return {Boolean} Indicates whether the action executed
     **/
    $.fn.steps.previous = function () {
        return goToPreviousStep(this, getOptions(this), getState(this));
    };

    /**
     * Removes a specific step by an given index.
     *
     * @method remove
     * @param index {Integer} The position (zero-based) of the step to remove
     * @return Indecates whether the item is removed.
     **/
    $.fn.steps.remove = function (index) {
        return removeStep(this, getOptions(this), getState(this), index);
    };

    /**
     * Sets a specific step object by index.
     *
     * @method setStep
     * @param index {Integer} An integer that belongs to the position of a step
     * @param step {Object} The step object to change
     **/
    $.fn.steps.setStep = function (index, step) {
        throw new Error("Not yet implemented!");
    };

    /**
     * Skips an certain amount of steps.
     *
     * @method skip
     * @param count {Integer} The amount of steps that should be skipped
     * @return {Boolean} Indicates whether the action executed
     **/
    $.fn.steps.skip = function (count) {
        throw new Error("Not yet implemented!");
    };

    /**
     * An enum represents the different content types of a step and their loading mechanisms.
     *
     * @class contentMode
     * @for steps
     **/
    var contentMode = $.fn.steps.contentMode = {
        /**
         * HTML embedded content
         *
         * @readOnly
         * @property html
         * @type Integer
         * @for contentMode
         **/
        html: 0,

        /**
         * IFrame embedded content
         *
         * @readOnly
         * @property iframe
         * @type Integer
         * @for contentMode
         **/
        iframe: 1,

        /**
         * Async embedded content
         *
         * @readOnly
         * @property async
         * @type Integer
         * @for contentMode
         **/
        async: 2
    };

    /**
     * An enum represents the orientation of the steps navigation.
     *
     * @class stepsOrientation
     * @for steps
     **/
    var stepsOrientation = $.fn.steps.stepsOrientation = {
        /**
         * Horizontal orientation
         *
         * @readOnly
         * @property horizontal
         * @type Integer
         * @for stepsOrientation
         **/
        horizontal: 0,

        /**
         * Vertical orientation
         *
         * @readOnly
         * @property vertical
         * @type Integer
         * @for stepsOrientation
         **/
        vertical: 1
    };

    /**
     * An enum that represents the various transition animations.
     *
     * @class transitionEffect
     * @for steps
     **/
    var transitionEffect = $.fn.steps.transitionEffect = {
        /**
         * No transition animation
         *
         * @readOnly
         * @property none
         * @type Integer
         * @for transitionEffect
         **/
        none: 0,

        /**
         * Fade in transition
         *
         * @readOnly
         * @property fade
         * @type Integer
         * @for transitionEffect
         **/
        fade: 1,

        /**
         * Slide up transition
         *
         * @readOnly
         * @property slide
         * @type Integer
         * @for transitionEffect
         **/
        slide: 2,

        /**
         * Slide left transition
         *
         * @readOnly
         * @property slideLeft
         * @type Integer
         * @for transitionEffect
         **/
        slideLeft: 3
    };

    var stepModel = $.fn.steps.stepModel = {
        title: "",
        content: "",
        contentUrl: "",
        contentMode: contentMode.html,
        contentLoaded: false
    };

    /**
     * An object that represents the default settings.
     * There are two possibities to override the sub-properties.
     * Either by doing it generally (global) or on initialization.
     *
     * @static
     * @class defaults
     * @for steps
     * @example
     *   // Global approach
     *   $.steps.defaults.headerTag = "h3";
     * @example
     *   // Initialization approach
     *   $("#wizard").steps({ headerTag: "h3" });
     **/
    var defaults = $.fn.steps.defaults = {
        /**
         * The header tag is used to find the step button text within the declared wizard area.
         *
         * @property headerTag
         * @type String
         * @default "h1"
         * @for defaults
         **/
        headerTag: "h1",

        /**
         * The body tag is used to find the step content within the declared wizard area.
         *
         * @property bodyTag
         * @type String
         * @default "div"
         * @for defaults
         **/
        bodyTag: "div",

        /**
         * The content container tag which will be used to wrap all step contents.
         *
         * @property contentContainerTag
         * @type String
         * @default "div"
         * @for defaults
         **/
        contentContainerTag: "div",

        /**
         * The action container tag which will be used to wrap the pagination navigation.
         *
         * @property actionContainerTag
         * @type String
         * @default "div"
         * @for defaults
         **/
        actionContainerTag: "div",

        /**
         * The steps container tag which will be used to wrap the steps navigation.
         *
         * @property stepsContainerTag
         * @type String
         * @default "div"
         * @for defaults
         **/
        stepsContainerTag: "div",

        /**
         * The css class which will be added to the outer component wrapper.
         *
         * @property cssClass
         * @type String
         * @default "wizard"
         * @for defaults
         * @example
         *     <div class="wizard">
         *         ...
         *     </div>
         **/
        cssClass: "wizard",

        /**
         * The css class which will be used for floating scenarios.
         *
         * @property clearFixCssClass
         * @type String
         * @default "clearfix"
         * @for defaults
         **/
        clearFixCssClass: "clearfix",

        /**
         * Determines whether the steps are vertically or horizontally oriented.
         *
         * @property stepsOrientation
         * @type stepsOrientation
         * @default horizontal
         * @for defaults
         * @since 1.0.0
         **/
        stepsOrientation: stepsOrientation.horizontal,

        /*
         * Tempplates
         */

        /**
         * The title template which will be used to create a step button.
         *
         * @property titleTemplate
         * @type String
         * @default "<span class=\"number\">#index#.</span> #title#"
         * @for defaults
         **/
        titleTemplate: "<span class=\"number\">#index#.</span> #title#",

        /**
         * The loading template which will be used to create the loading animation.
         *
         * @property loadingTemplate
         * @type String
         * @default "<span class=\"spinner\"></span> #text#"
         * @for defaults
         **/
        loadingTemplate: "<span class=\"spinner\"></span> #text#",

        /*
         * Behaviour
         */

        /**
         * Sets the focus to the first wizard instance in order to enable the key navigation from the begining if `true`. 
         *
         * @property autoFocus
         * @type Boolean
         * @default false
         * @for defaults
         * @since 0.9.4
         **/
        autoFocus: false,

        /**
         * Enables all steps from the begining if `true` (all steps are clickable).
         *
         * @property enableAllSteps
         * @type Boolean
         * @default false
         * @for defaults
         **/
        enableAllSteps: false,

        /**
         * Enables keyboard navigation if `true` (arrow left and arrow right).
         *
         * @property enableKeyNavigation
         * @type Boolean
         * @default true
         * @for defaults
         **/
        enableKeyNavigation: true,

        /**
         * Enables pagination if `true`.
         *
         * @property enablePagination
         * @type Boolean
         * @default true
         * @for defaults
         **/
        enablePagination: true,

        /**
         * Suppresses pagination if a form field is focused.
         *
         * @property suppressPaginationOnFocus
         * @type Boolean
         * @default true
         * @for defaults
         **/
        suppressPaginationOnFocus: true,

        /**
         * Enables cache for async loaded or iframe embedded content.
         *
         * @property enableContentCache
         * @type Boolean
         * @default true
         * @for defaults
         **/
        enableContentCache: true,

        /**
         * Shows the cancel button if enabled.
         *
         * @property enableCancelButton
         * @type Boolean
         * @default false
         * @for defaults
         **/
        enableCancelButton: false,

        /**
         * Shows the finish button if enabled.
         *
         * @property enableFinishButton
         * @type Boolean
         * @default true
         * @for defaults
         **/
        enableFinishButton: true,

        /**
         * Not yet implemented.
         *
         * @property preloadContent
         * @type Boolean
         * @default false
         * @for defaults
         **/
        preloadContent: false,

        /**
         * Shows the finish button always (on each step; right beside the next button) if `true`. 
         * Otherwise the next button will be replaced by the finish button if the last step becomes active.
         *
         * @property showFinishButtonAlways
         * @type Boolean
         * @default false
         * @for defaults
         **/
        showFinishButtonAlways: false,

        /**
         * Prevents jumping to a previous step.
         *
         * @property forceMoveForward
         * @type Boolean
         * @default false
         * @for defaults
         **/
        forceMoveForward: false,

        /**
         * Saves the current state (step position) to a cookie.
         * By coming next time the last active step becomes activated.
         *
         * @property saveState
         * @type Boolean
         * @default false
         * @for defaults
         **/
        saveState: false,

        /**
         * The position to start on (zero-based).
         *
         * @property startIndex
         * @type Integer
         * @default 0
         * @for defaults
         **/
        startIndex: 0,

        /*
         * Animation Effect Configuration
         */

        /**
         * The animation effect which will be used for step transitions.
         *
         * @property transitionEffect
         * @type transitionEffect
         * @default none
         * @for defaults
         **/
        transitionEffect: transitionEffect.none,

        /**
         * Animation speed for step transitions (in milliseconds).
         *
         * @property transitionEffectSpeed
         * @type Integer
         * @default 200
         * @for defaults
         **/
        transitionEffectSpeed: 200,

        /*
         * Events
         */

        /**
         * Fires before the step changes and can be used to prevent step changing by returning `false`. 
         * Very useful for form validation. 
         *
         * @property onStepChanging
         * @type Event
         * @default function (event, currentIndex, newIndex) { return true; }
         * @for defaults
         **/
        onStepChanging: function (event, currentIndex, newIndex) {
            return true;
        },

        /**
         * Fires after the step has change. 
         *
         * @property onStepChanged
         * @type Event
         * @default function (event, currentIndex, priorIndex) { }
         * @for defaults
         **/
        onStepChanged: function (event, currentIndex, priorIndex) {},

        /**
         * Fires after cancelation. 
         *
         * @property onCanceled
         * @type Event
         * @default function (event) { }
         * @for defaults
         **/
        onCanceled: function (event) {},

        /**
         * Fires before finishing and can be used to prevent completion by returning `false`. 
         * Very useful for form validation. 
         *
         * @property onFinishing
         * @type Event
         * @default function (event, currentIndex) { return true; }
         * @for defaults
         **/
        onFinishing: function (event, currentIndex) {
            return true;
        },

        /**
         * Fires after completion. 
         *
         * @property onFinished
         * @type Event
         * @default function (event, currentIndex) { }
         * @for defaults
         **/
        onFinished: function (event, currentIndex) {},

        /**
         * Fires after async content is loaded. 
         *
         * @property onContentLoaded
         * @type Event
         * @default function (event, index) { }
         * @for defaults
         **/
        onContentLoaded: function (event, currentIndex) {},

        /**
         * Fires when the wizard is initialized. 
         *
         * @property onInit
         * @type Event
         * @default function (event) { }
         * @for defaults
         **/
        onInit: function (event, currentIndex) {},

        /**
         * Contains all labels. 
         *
         * @property labels
         * @type Object
         * @for defaults
         **/
        labels: {
            /**
             * Label for the cancel button.
             *
             * @property cancel
             * @type String
             * @default "Cancel"
             * @for defaults
             **/
            cancel: "Cancel",

            /**
             * This label is important for accessability reasons.
             * Indicates which step is activated.
             *
             * @property current
             * @type String
             * @default "current step:"
             * @for defaults
             **/
            current: "current step:",

            /**
             * This label is important for accessability reasons and describes the kind of navigation.
             *
             * @property pagination
             * @type String
             * @default "Pagination"
             * @for defaults
             * @since 0.9.7
             **/
            pagination: "Pagination",

            /**
             * Label for the finish button.
             *
             * @property finish
             * @type String
             * @default "Finish"
             * @for defaults
             **/
            finish: "Confirm and submit",

            /**
             * Label for the next button.
             *
             * @property next
             * @type String
             * @default "Next"
             * @for defaults
             **/
            next: "Next step",

            /**
             * Label for the previous button.
             *
             * @property previous
             * @type String
             * @default "Previous"
             * @for defaults
             **/
            previous: "Previous step",

            /**
             * Label for the loading animation.
             *
             * @property loading
             * @type String
             * @default "Loading ..."
             * @for defaults
             **/
            loading: "Loading ..."
        }
    };
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    $(document).on('change', 'input[name="business_scope"]:radio', function () {
        var business_scope = $("input[name='business_scope']:checked").val();
        if (business_scope == 'Other') {
            $('#other_business_scope').removeAttr("disabled");
        } else {
            $('#other_business_scope').attr("disabled", "disabled");
        }
    });



    $('body').on('click', '#business_description_english', function () {
        businessScopeValidation();
    });
    $('body').on('click', '#business_description_chinese', function () {

        businessScopeValidation();
        businessDescriptionEnglishValidation();
    });
    $('body').on('click', '#company_name_english', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
    });
    $('body').on('click', '#company_name_chinese', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
    });
    $('body').on('click', '#company_address', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
    });
    $('body').on('click', '#company_city', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
    });
    $('body').on('click', '#province_area_english', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
    });
    $('body').on('click', '#china_office_address', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
    });
    $('body').on('click', '#china_office_city', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
    });
    $('body').on('click', '#company_zipCode', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
       // provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
    });
    $('body').on('click', '#company_generalPhone', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
    });
    $('body').on('click', '#company_email', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
    });

    $('body').on('click', '#company_website', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
    });
    $('body').on('click', '#legal_entity', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
    });
    $('body').on('click', '#no_of_employees', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
    });
    $('body').on('click', '.chkBox', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
    });


    $('body').on('click', '#establishment_hongkong', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
    });
    $('body').on('click', '#geographical_responsibility_hongkong', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        establishmentHongkongValidation();
    });
    $('body').on('click', '#headquarter_name', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
    });

    $('body').on('click', '#headquarter_address', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
       // companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
    });
    $('body').on('click', '#headquarter_city', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
    });
    $('body').on('click', '#headquarter_zipCode', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
       // provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
       // companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
        headquarterCityValidation();
    });
    $('body').on('click', '#headquarter_phone', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
        headquarterCityValidation();
        //headquarterZipCodeValidation();
    });
    $('body').on('click', '#headquarter_province_area_english', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
        headquarterCityValidation();
        //headquarterZipCodeValidation();
        headquarterPhoneValidation();
    });
    $('body').on('click', '#fstexampleFileUploadx', function () {
        businessScopeValidation();
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
        //provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
        //companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
        headquarterCityValidation();
        //headquarterZipCodeValidation();
        headquarterPhoneValidation();
        //headquarterProvinceAreaValidation();
    });

    function companyValidation() {
        var bscop = $('.bscop').is(":visible");
        if (bscop != false) {
            businessScopeValidation();
        }
        businessDescriptionEnglishValidation();
        businessDescriptionChineseValidation();
        companyNameEnglishValidation();
        companyNameChineseValidation();
        companyAddressValidation();
        companyCityValidation();
       // provinceAreaEnglishValidation();
        chinaOfficeAddressValidation();
        chinaOfficeCityValidation();
       // companyZipCodeValidation();
        companyGeneralPhoneValidation();
        companyEmailValidation();
        companyWebsiteValidation();
        legalEntityValidation();
        noOfEmployeesValidation();
        var non_hong_kong = $('#non_hong_kong').is(":visible");
        if (non_hong_kong != false) {
            isCompanySwissRegisteredValidation();
            isCompanyRegisteredPRCValidation();
        }
        var hong_kong_add = $('#hong_kong_add').is(":visible");
        if (hong_kong_add != false) {
            establishmentHongkongValidation();
            geographicalResponsibilityHongkongValidation();
        }
        headquarterNameValidation();
        headquarterAddressValidation();
        headquarterCityValidation();
        //headquarterZipCodeValidation();
        headquarterPhoneValidation();
        //headquarterProvinceAreaValidation();
        fstexampleFileUploadxValidation();

    }

    function businessScopeValidation(event) {
        var business_scope = $("input[name='business_scope']:checked").val();
        if (business_scope == 'Other') {
            var other_business_scope = $('#other_business_scope').val();
            if (other_business_scope == '') {
                //alert("Please Enter Other Business Scope.");
                alert("Wrong format, please correct");
                $("#other_business_scope").focus();
                $("#other_business_scope").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_business_scope").removeClass("error_cl");
            }
        } else {
            $("#other_business_scope").removeClass("error_cl");
        }
    }

    function businessDescriptionEnglishValidation(event) {
        var business_description_english = $('#business_description_english').val();
        var regex = /\s+/gi;
        var word_count = business_description_english.trim().replace(regex, ' ').split(' ').length;
        if (business_description_english == '' || word_count > 151) {
            //alert("Please Enter Business Description With In 150 Words.");
            alert("Wrong format, please correct");
            $("#business_description_english").focus();
            $("#business_description_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#business_description_english").removeClass("error_cl");
        }
    }

    function businessDescriptionChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var business_description_chinese = $('#business_description_chinese').val();
            var business_length = $("#business_description_chinese").val().replace(/ /g, '').length;
            if (business_description_chinese == '' || business_length > 101) {
                alert("Wrong format, please correct");
                //alert("Please Enter Business Description Chinese With In 100 Charecters");
                $("#business_description_chinese").focus();
                $("#business_description_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#business_description_chinese").removeClass("error_cl");
            }
        } else {
            $("#business_description_chinese").removeClass("error_cl");
        }
    }

    function companyNameEnglishValidation(event) {
        var company_name_english = $('#company_name_english').val();
        if (company_name_english == '') {
            alert("Wrong format, please correct");
            //alert("Please Enter Company Name English");
            $("#company_name_english").focus();
            $("#company_name_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_name_english").removeClass("error_cl");
        }
    }

    function companyNameChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_name_chinese = $('#company_name_chinese').val();
            if (company_name_chinese == '') {
                //alert("Please Enter Company Name English");
                alert("Wrong format, please correct");
                $("#company_name_chinese").focus();
                $("#company_name_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_name_chinese").removeClass("error_cl");
            }
        } else {
            $("#company_name_chinese").removeClass("error_cl");
        }
    }

    function companyAddressValidation(event) {
        var company_address = $('#company_address').val();
        if (company_address == '') {
            //alert("Please Enter Company Address English");
            alert("Wrong format, please correct");
            $("#company_address").focus();
            $("#company_address").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_address").removeClass("error_cl");
        }
    }

    function companyCityValidation(event) {
        var company_city = $('#company_city').val();
        if (company_city == '') {
            //alert("Please Enter Company City English");
            alert("Wrong format, please correct");
            $("#company_city").focus();
            $("#company_city").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_city").removeClass("error_cl");
        }
    }

    /*function provinceAreaEnglishValidation(event) {
        var province_area_english = $('#province_area_english').val();
        if (province_area_english == '') {
            //alert("Please Enter Province/Area in English");
            alert("Wrong format, please correct");
            $("#province_area_english").focus();
            $("#province_area_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#province_area_english").removeClass("error_cl");
        }
    }*/

    function chinaOfficeAddressValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var china_office_address = $('#china_office_address').val();
            if (china_office_address == '') {
                //alert("Please Enter Company China Office Address");
                alert("Wrong format, please correct");
                $("#china_office_address").focus();
                $("#china_office_address").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#china_office_address").removeClass("error_cl");
            }
        } else {
            $("#china_office_address").removeClass("error_cl");
        }
    }

    function chinaOfficeCityValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var china_office_city = $('#china_office_city').val();
            if (china_office_city == '') {
                //alert("Please Enter China Office City");
                alert("Wrong format, please correct");
                $("#china_office_city").focus();
                $("#china_office_city").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#china_office_city").removeClass("error_cl");
            }
        } else {
            $("#china_office_city").removeClass("error_cl");
        }
    }

    /*function companyZipCodeValidation(event) {
        var company_zipCode = $('#company_zipCode').val();
        if (company_zipCode == '') {
            //alert("Please Enter Company ZipCode");
            alert("Wrong format, please correct");
            $("#company_zipCode").focus();
            $("#company_zipCode").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_zipCode").removeClass("error_cl");
        }
    }*/

    function companyGeneralPhoneValidation(event) {
        // var res = company_website.match(/^\b\d{3}[- +]?\d{3}[- ]?\d{4}\b/g);
        //var phonePattern= / ^([0|\+[0-9 -]{1,5})?([7-9][0-9])$/;
        var phonePattern = /^[+0-9 -]/g;
        var company_generalPhone = $('#company_generalPhone').val();
        //var res = company_generalPhone.Enter(/^[+0-9 -]/g);
        //alert(phonePattern.test(company_generalPhone));
        if ((!phonePattern.test(company_generalPhone)) || (company_generalPhone == '')) {
            //alert("Please Enter Company General Phone");
            alert("Wrong format, please correct");
            $("#company_generalPhone").focus();
            $("#company_generalPhone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_generalPhone").removeClass("error_cl");
        }
    }

    function companyEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var company_email = $('#company_email').val(); 
        if( company_email == 'NA') { $("#company_email").removeClass("error_cl"); return; } 
        if ((!emailPattern.test(company_email)) || (company_email == '')) {
            //alert("Please Enter General Email");
            alert("Wrong format, please correct");
            $("#company_email").focus();
            $("#company_email").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_email").removeClass("error_cl");
        }
    }

    function companyWebsiteValidation(event) {
        var company_website = $('#company_website').val();
        if( company_website == 'NA') { $("#company_website").removeClass("error_cl"); return; } 
        var res = company_website.match(/^(http(s)?:\/\/.)(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        var res1 = company_website.match(/^(www\.)[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        if ((company_website == '') || (res == null && res1 == null)) {
            //alert("Please Enter Correct Company Website");
            alert("Wrong format, please correct");
            $("#company_website").focus();
            $("#company_website").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_website").removeClass("error_cl");
        }
    }

    function legalEntityValidation(event) {
        var legal_entity = $('#legal_entity').val();
        if (legal_entity == '') {
            //alert("Please Select Legal Entity");
            alert("Wrong format, please correct");
            $("#legal_entity").focus();
            $("#legal_entity").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#legal_entity").removeClass("error_cl");
        }
    }

    function noOfEmployeesValidation(event) {
        var no_of_employees = $('#no_of_employees').val();
        if ((no_of_employees == '') || (isNaN(no_of_employees))) {
            //alert("Please Enter No Of Employees");
            alert("Wrong format, please correct");
            $("#no_of_employees").focus();
            $("#no_of_employees").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#no_of_employees").removeClass("error_cl");
        }
    }

    function isCompanySwissRegisteredValidation(event) {
        var is_company_swiss_registered = $("input[name='is_company_swiss_registered']:checked").val();
        if (is_company_swiss_registered == '') {
            //alert("Please Select One");
            alert("Wrong format, please correct");
            $("#is_company_swiss_registered").focus();
            $("#is_company_swiss_registered").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#is_company_swiss_registered").removeClass("error_cl");
        }
    }

    function isCompanyRegisteredPRCValidation(event) {
        var is_company_registered_PRC = $("input[name='is_company_registered_PRC']:checked").val();
        if (is_company_registered_PRC == '') {
            //alert("Please Select One");
            alert("Wrong format, please correct");
            $("#is_company_registered_PRC").focus();
            $("#is_company_registered_PRC").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#is_company_registered_PRC").removeClass("error_cl");
        }
    }

    function establishmentHongkongValidation(event) {
        var establishment_hongkong = $('#establishment_hongkong').val();
        if ((establishment_hongkong == '') || (isNaN(establishment_hongkong))) {
            //alert("Please Enter Year of Establishment in Hong Kong");
            alert("Wrong format, please correct");
            $("#establishment_hongkong").focus();
            $("#establishment_hongkong").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#establishment_hongkong").removeClass("error_cl");
        }
    }

    function geographicalResponsibilityHongkongValidation(event) {
        var geographical_responsibility_hongkong = $('#geographical_responsibility_hongkong').val();
        if (geographical_responsibility_hongkong == '') {
            //alert("Please Enter Geographical Responsibility of your company in Hong Kong");
            alert("Wrong format, please correct");
            $("#geographical_responsibility_hongkong").focus();
            $("#geographical_responsibility_hongkong").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#geographical_responsibility_hongkong").removeClass("error_cl");
        }
    }

    function headquarterNameValidation(event) {
        var headquarter_name = $('#headquarter_name').val();
        if (headquarter_name == '') {
            //alert("Please Enter Headquarter Name");
            alert("Wrong format, please correct");
            $("#headquarter_name").focus();
            $("#headquarter_name").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_name").removeClass("error_cl");
        }
    }

    function headquarterAddressValidation(event) {
        var headquarter_address = $('#headquarter_address').val();
        if (headquarter_address == '') {
            //alert("Please Enter Headquarter Address");
            alert("Wrong format, please correct");
            $("#headquarter_address").focus();
            $("#headquarter_address").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_address").removeClass("error_cl");
        }
    }

    function headquarterCityValidation(event) {
        var headquarter_city = $('#headquarter_city').val();
        if (headquarter_city == '') {
            //alert("Please Enter Headquarter City");
            alert("Wrong format, please correct");
            $("#headquarter_city").focus();
            $("#headquarter_city").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_city").removeClass("error_cl");
        }
    }

   /* function headquarterZipCodeValidation(event) {
        var headquarter_zipCode = $('#headquarter_zipCode').val();
        if (headquarter_zipCode == '') {
            //alert("Please Enter Headquarter ZipCode");
            alert("Wrong format, please correct");
            $("#headquarter_zipCode").focus();
            $("#headquarter_zipCode").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_zipCode").removeClass("error_cl");
        }
    } */

    function headquarterPhoneValidation(event) {
        var headquarter_phone = $('#headquarter_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(headquarter_phone)) || (headquarter_phone == '')) {
            //alert("Please Enter Headquarter Phone ");
            alert("Wrong format, please correct");
            $("#headquarter_phone").focus();
            $("#headquarter_phone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_phone").removeClass("error_cl");
        }
    }

    /*function headquarterProvinceAreaValidation(event) {
        var headquarter_province_area_english = $('#headquarter_province_area_english').val();
        if (headquarter_province_area_english == '') {
            //alert("Please Upload Picture");
            alert("Wrong format, please correct");
            $("#headquarter_province_area_english").focus();
            $("#headquarter_province_area_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#headquarter_province_area_english").removeClass("error_cl");
        }
    }*/

    function fstexampleFileUploadxValidation(event) {
        var fstexampleFileUploadx = $('#fstexampleFileUploadx').val();
        /*if (fstexampleFileUploadx == '') {
            //alert("Please Upload Picture");
            alert("Wrong format, please correct");
            $("#fstexampleFileUploadx").focus();
            $("#fstexampleFileUploadx").addClass("error_cl");
            event.preventDefault();
        } else {*/
            $("#fstexampleFileUploadx").removeClass("error_cl");
       // }
    }


    /* Company Info validation End */
    /* company contact validation Start */

    function companyContactValidation(event) {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();



        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();
        companySecondContactPersonAreaValidation();
        companySecondContactPersonAddressChineseValidation();
        companySecondContactPersonCityChineseValidation();
        companySecondContactPersonZipCodeValidation();*/
        secondContactPersonMobileValidation();
        secondContactPersonDirectPhoneValidation();


    }
    $('body').on('click', '#company_first_contact_dob', function () {
        companyFirstContactTitleValidation();
    });
    $('body').on('click', '#company_first_contact_familyName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
    });
    $('body').on('click', '#company_first_contact_givenName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
    });
    $('body').on('click', '#company_first_contact_chineseName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
    });
    $('body').on('click', '.company_first_contact_nationality', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
    });
    $('body').on('click', '#company_first_contact_position', function () {
        companyFirstContactTitleValidation();
        /* companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
    });
    $('body').on('click', '#company_first_contact_english_address', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
    });
    $('body').on('click', '#company_first_contact_english_city', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
    });
    $('body').on('click', '#company_first_contact_province_area', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
    });
    $('body').on('click', '#company_first_contact_address_chinese', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
    });
    $('body').on('click', '#company_first_contact_city_chinese', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
    });
    $('body').on('click', '#company_first_contact_zip', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
    });
    $('body').on('click', '#company_first_contact_direct_phone', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
    });
    $('body').on('click', '#company_first_contact_direct_email', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
    });
    $('body').on('click', '#company_first_contact_mobile', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
    });
    $('body').on('click', '.company_second_contact_person_title', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
    });
    $('body').on('click', '#company_second_contact_person_dob', function () {
        companyFirstContactTitleValidation();
        /* companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
        /*companySecondContactPersonTitleValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_familyName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_givenName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();*/
    });
    $('body').on('click', '#second_contact_person_chineseName', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();*/
    });
    $('body').on('click', '.company_second_contact_person_nationality', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();
        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();*/
    });

    $('body').on('click', '#company_second_contact_position', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();*/
    });

    $('body').on('click', '#company_second_contact_person_address_english', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_city_english', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_area', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_address_chinese', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();
        companySecondContactPersonAreaValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_city_chinese', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /* companySecondContactPersonTitleValidation();
          companySecondContactPersonDobValidation();
         companySecondContactPersonFamilyNameValidation();
         companySecondContactPersonGivenNameValidation();
         secondContactPersonChineseNameValidation();
         companySecondContactPersonNationalityValidation();
         companySecondContactPositionValidation();
         companySecondContactPersonAddressEnglishValidation();
         companySecondContactPersonCityEnglishValidation();
         companySecondContactPersonAreaValidation();
         companySecondContactPersonAddressChineseValidation();*/
    });
    $('body').on('click', '#company_second_contact_person_zipCode', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /* companySecondContactPersonTitleValidation();
         companySecondContactPersonDobValidation();
         companySecondContactPersonFamilyNameValidation();
         companySecondContactPersonGivenNameValidation();
         secondContactPersonChineseNameValidation();
         companySecondContactPersonNationalityValidation();
         companySecondContactPositionValidation();
         companySecondContactPersonAddressEnglishValidation();
         companySecondContactPersonCityEnglishValidation();
         companySecondContactPersonAreaValidation();
         companySecondContactPersonAddressChineseValidation();
         companySecondContactPersonCityChineseValidation();*/
    });
    $('body').on('click', '#second_contact_person_mobile', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();
        companySecondContactPersonAreaValidation();
        companySecondContactPersonAddressChineseValidation();
        companySecondContactPersonCityChineseValidation();
        companySecondContactPersonZipCodeValidation();*/
    });
    $('body').on('click', '#second_contact_person_directPhone', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();
        companySecondContactPersonAreaValidation();
        companySecondContactPersonAddressChineseValidation();
        companySecondContactPersonCityChineseValidation();
        companySecondContactPersonZipCodeValidation();*/
        secondContactPersonMobileValidation();
    });
    $('body').on('click', '#second_contact_person_directMail', function () {
        companyFirstContactTitleValidation();
        /*companyFirstContactDobValidation();*/
        companyFirstContactFamilyNameValidation();
        companyFirstContactGivenNameValidation();
        companyFirstContactChineseNameValidation();
        companyFirstContactNationalityValidation();
        companyFirstContactPositionValidation();
        companyFirstContactEnglishAddressValidation();
        companyFirstContactEnglishCityValidation();
        companyFirstContactProvinceAreaValidation();
        companyFirstContactAddressChineseValidation();
        companyFirstContactCityChineseValidation();
        companyFirstContactZipValidation();
        companyFirstContactDirectPhoneValidation();
        companyFirstContactDirectemailValidation();
        companyFirstContactMobileValidation();

        /*companySecondContactPersonTitleValidation();
        companySecondContactPersonDobValidation();
        companySecondContactPersonFamilyNameValidation();
        companySecondContactPersonGivenNameValidation();
        secondContactPersonChineseNameValidation();
        companySecondContactPersonNationalityValidation();
        companySecondContactPositionValidation();
        companySecondContactPersonAddressEnglishValidation();
        companySecondContactPersonCityEnglishValidation();
        companySecondContactPersonAreaValidation();
        companySecondContactPersonAddressChineseValidation();
        companySecondContactPersonCityChineseValidation();
        companySecondContactPersonZipCodeValidation();*/
        secondContactPersonMobileValidation();
        secondContactPersonDirectPhoneValidation();
        secondContactPersonDirectMailValidation();
    });


    function companyFirstContactTitleValidation(event) {
        var company_first_contact_title = $("input[name='company_first_contact_title']:checked").val();
        if (company_first_contact_title == '') {
            //alert("Please Select Title.");
            alert("Wrong format, please correct");
            $("#company_first_contact_title").focus();
            $("#company_first_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_title").removeClass("error_cl");
        }
    }

    /*function companyFirstContactDobValidation(event) {
        var company_first_contact_dob = $('#company_first_contact_dob').val();
        if (company_first_contact_dob == '') {
            // alert("Please Enter Correct Date Of Birth");
            alert("Wrong format, please correct");
            $("#company_first_contact_dob").focus();
            $("#company_first_contact_dob").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_dob").removeClass("error_cl");
        }
    }*/

    function companyFirstContactFamilyNameValidation(event) {
        var company_first_contact_familyName = $('#company_first_contact_familyName').val();
        if (company_first_contact_familyName == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#company_first_contact_familyName").focus();
            $("#company_first_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_familyName").removeClass("error_cl");
        }
    }

    function companyFirstContactGivenNameValidation(event) {
        var company_first_contact_givenName = $('#company_first_contact_givenName').val();
        if (company_first_contact_givenName == '') {
            // alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#company_first_contact_givenName").focus();
            $("#company_first_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_givenName").removeClass("error_cl");
        }
    }

    function companyFirstContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_first_contact_chineseName = $('#company_first_contact_chineseName').val();
            if (company_first_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#company_first_contact_chineseName").focus();
                $("#company_first_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_first_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#company_first_contact_chineseName").removeClass("error_cl");
        }
    }

    function companyFirstContactNationalityValidation(event) {
        var company_first_contact_nationality = $("input[name='company_first_contact_nationality']:checked").val();
        if (company_first_contact_nationality == '') {
            //alert("Please Select Nationality.");
            alert("Wrong format, please correct");
            $("#company_first_contact_nationality").focus();
            $("#company_first_contact_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_nationality").removeClass("error_cl");
        }
    }

    function companyFirstContactPositionValidation(event) {
        var company_first_contact_position = $('#company_first_contact_position').val();
        if (company_first_contact_position == '') {
            //alert("Please Enter Position");
            alert("Wrong format, please correct");
            $("#company_first_contact_position").focus();
            $("#company_first_contact_position").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_position").removeClass("error_cl");
        }
    }

    function companyFirstContactEnglishAddressValidation(event) {
        var company_first_contact_english_address = $('#company_first_contact_english_address').val();
        if (company_first_contact_english_address == '') {
            //alert("Please Enter Address");
            alert("Wrong format, please correct");
            $("#company_first_contact_english_address").focus();
            $("#company_first_contact_english_address").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_english_address").removeClass("error_cl");
        }
    }

    function companyFirstContactEnglishCityValidation(event) {
        var company_first_contact_english_city = $('#company_first_contact_english_city').val();
        if (company_first_contact_english_city == '') {
            //alert("Please Enter City In English.");
            alert("Wrong format, please correct");
            $("#company_first_contact_english_city").focus();
            $("#company_first_contact_english_city").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_english_city").removeClass("error_cl");
        }
    }

    function companyFirstContactProvinceAreaValidation(event) {
        var company_first_contact_province_area = $('#company_first_contact_province_area').val();
        if (company_first_contact_province_area == '') {
            //alert("Please Select Province/Area.");
            alert("Wrong format, please correct");
            $("#company_first_contact_province_area").focus();
            $("#company_first_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_province_area").removeClass("error_cl");
        }
    }

    function companyFirstContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_first_contact_address_chinese = $('#company_first_contact_address_chinese').val();
            if (company_first_contact_address_chinese == '') {
                //alert("Please Enter Address In Chinese.");
                alert("Wrong format, please correct");
                $("#company_first_contact_address_chinese").focus();
                $("#company_first_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_first_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#company_first_contact_address_chinese").removeClass("error_cl");
        }
    }

    function companyFirstContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_first_contact_city_chinese = $('#company_first_contact_city_chinese').val();
            if (company_first_contact_city_chinese == '') {
                //alert("Please Enter City In Chinese");
                alert("Wrong format, please correct");
                $("#company_first_contact_city_chinese").focus();
                $("#company_first_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_first_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#company_first_contact_city_chinese").removeClass("error_cl");
        }
    }

    function companyFirstContactZipValidation(event) {
        var company_first_contact_zip = $('#company_first_contact_zip').val();
        if (company_first_contact_zip == '') {
            //alert("Please Enter Zip Code.");
            alert("Wrong format, please correct");
            $("#company_first_contact_zip").focus();
            $("#company_first_contact_zip").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_zip").removeClass("error_cl");
        }
    }

    function companyFirstContactDirectPhoneValidation(event) {
        var company_first_contact_direct_phone = $('#company_first_contact_direct_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(company_first_contact_direct_phone)) || (company_first_contact_direct_phone == '')) {
            //alert("Please Enter Direct Phone No.");
            alert("Wrong format, please correct");
            $("#company_first_contact_direct_phone").focus();
            $("#company_first_contact_direct_phone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_first_contact_direct_phone").removeClass("error_cl");
        }
    }

    function companyFirstContactDirectemailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var company_first_contact_direct_email = $('#company_first_contact_direct_email').val();
        if ((!emailPattern.test(company_first_contact_direct_email)) || (company_first_contact_direct_email == '')) {
            //alert("Please Enter Email Address.");
            alert("Wrong format, please correct");
            $("#company_first_contact_direct_email").focus();
            $("#company_first_contact_direct_email").addClass("error_cl");
            return false;
        } else {
            $("#company_first_contact_direct_email").removeClass("error_cl");
        }
    }

    function companyFirstContactMobileValidation(event) {
        var company_first_contact_mobile = $('#company_first_contact_mobile').val();
        var lenght1 = $('#company_first_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if ((company_first_contact_mobile == '') || (!phonePattern.test(company_first_contact_mobile)) || (lenght1 > 20)) {
            // alert("Please Enter Mobile No.");
            alert("Wrong format, please correct");
            $("#company_first_contact_mobile").focus();
            $("#company_first_contact_mobile").addClass("error_cl");
            return false;
        } else {
            $("#company_first_contact_mobile").removeClass("error_cl");
        }
    }

    function companySecondContactPersonTitleValidation(event) {
        var company_second_contact_person_title = $("input[name='company_second_contact_person_title']:checked").val();
        if (company_second_contact_person_title == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_title").focus();
            $("#company_second_contact_person_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_title").removeClass("error_cl");
        }
    }

    /*   function companySecondContactPersonDobValidation(event) {
           var company_second_contact_person_dob = $('#company_second_contact_person_dob').val();
           if (company_second_contact_person_dob == '') {
               //alert("Please Enter Other Contact Family Name.");
               alert("Wrong format, please correct");
               $("#company_second_contact_person_dob").focus();
               $("#company_second_contact_person_dob").addClass("error_cl");
               event.preventDefault();
           } else {
               $("#company_second_contact_person_dob").removeClass("error_cl");
           }
       }*/

    function companySecondContactPersonFamilyNameValidation(event) {
        var company_second_contact_person_familyName = $('#company_second_contact_person_familyName').val();
        if (company_second_contact_person_familyName == '') {
            //alert("Please Enter Other Contact Family Name.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_familyName").focus();
            $("#company_second_contact_person_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_familyName").removeClass("error_cl");
        }
    }

    function companySecondContactPersonGivenNameValidation(event) {
        var company_second_contact_person_givenName = $('#company_second_contact_person_givenName').val();
        if (company_second_contact_person_givenName == '') {
            //alert("Please Enter Other Contact Given Name.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_givenName").focus();
            $("#company_second_contact_person_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_givenName").removeClass("error_cl");
        }
    }

    function secondContactPersonChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var second_contact_person_chineseName = $('#second_contact_person_chineseName').val();
            if (second_contact_person_chineseName == '') {
                // alert("Please Enter Other Contact Chinese Name.");
                alert("Wrong format, please correct");
                $("#second_contact_person_chineseName").focus();
                $("#second_contact_person_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#second_contact_person_chineseName").removeClass("error_cl");
            }
        } else {
            $("#second_contact_person_chineseName").removeClass("error_cl");
        }
    }

    function companySecondContactPersonNationalityValidation(event) {
        var company_second_contact_person_nationality = $("input[name='company_second_contact_person_nationality']:checked").val();
        if (company_second_contact_person_nationality == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_nationality").focus();
            $("#company_second_contact_person_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_nationality").removeClass("error_cl");
        }
    }

    function companySecondContactPositionValidation(event) {
        var company_second_contact_position = $('#company_second_contact_position').val();
        if (company_second_contact_position == '') {
            //alert("Please Enter Other Contact Address In English.");
            alert("Wrong format, please correct");
            $("#company_second_contact_position").focus();
            $("#company_second_contact_position").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_position").removeClass("error_cl");
        }
    }

    function companySecondContactPersonAddressEnglishValidation(event) {
        var company_second_contact_person_address_english = $('#company_second_contact_person_address_english').val();
        if (company_second_contact_person_address_english == '') {
            //alert("Please Enter Other Contact Address In English.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_address_english").focus();
            $("#company_second_contact_person_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_address_english").removeClass("error_cl");
        }
    }

    function companySecondContactPersonCityEnglishValidation(event) {
        var company_second_contact_person_city_english = $('#company_second_contact_person_city_english').val();
        if (company_second_contact_person_city_english == '') {
            //alert("Please Enter Other Contact City In English.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_city_english").focus();
            $("#company_second_contact_person_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_city_english").removeClass("error_cl");
        }
    }

    function companySecondContactPersonAreaValidation(event) {
        var company_second_contact_person_area = $('#company_second_contact_person_area').val();
        if (company_second_contact_person_area == '') {
            //alert("Please Enter Other Contact Province/Area.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_area").focus();
            $("#company_second_contact_person_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_area").removeClass("error_cl");
        }
    }

    function companySecondContactPersonAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_second_contact_person_address_chinese = $('#company_second_contact_person_address_chinese').val();
            if (company_second_contact_person_address_chinese == '') {
                // alert("Please Enter Other Contact Address In Chinese.");
                alert("Wrong format, please correct");
                $("#company_second_contact_person_address_chinese").focus();
                $("#company_second_contact_person_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_second_contact_person_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#company_second_contact_person_address_chinese").removeClass("error_cl");
        }
    }

    function companySecondContactPersonCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var company_second_contact_person_city_chinese = $('#company_second_contact_person_city_chinese').val();
            if (company_second_contact_person_city_chinese == '') {
                //alert("Please Enter Other Contact City In Chinese.");
                alert("Wrong format, please correct");
                $("#company_second_contact_person_city_chinese").focus();
                $("#company_second_contact_person_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_second_contact_person_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#company_second_contact_person_city_chinese").removeClass("error_cl");
        }
    }

    function companySecondContactPersonZipCodeValidation(event) {
        var company_second_contact_person_zipCode = $('#company_second_contact_person_zipCode').val();
        if (company_second_contact_person_zipCode == '') {
            //alert("Please Enter Other Contact Zip Code.");
            alert("Wrong format, please correct");
            $("#company_second_contact_person_zipCode").focus();
            $("#company_second_contact_person_zipCode").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#company_second_contact_person_zipCode").removeClass("error_cl");
        }
    }

    function secondContactPersonMobileValidation(event) {
        var second_contact_person_mobile = $('#second_contact_person_mobile').val();
        var lenght1 = $('#second_contact_person_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (second_contact_person_mobile != '') {
            if ((!phonePattern.test(second_contact_person_mobile)) || (lenght1 > 20)) {
                //alert("Please Enter Other Contact Mobile No.");
                alert("Wrong format, please correct");
                $("#second_contact_person_mobile").focus();
                $("#second_contact_person_mobile").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#second_contact_person_mobile").removeClass("error_cl");
            }
        } else {
            $("#second_contact_person_mobile").removeClass("error_cl");
        }
    }

    function secondContactPersonDirectPhoneValidation(event) {
        var second_contact_person_directPhone = $('#second_contact_person_directPhone').val();
        var phonePattern = /^[+0-9 -]/g;
        if (second_contact_person_directPhone != '') {
            if (!phonePattern.test(second_contact_person_directPhone)) {
                //alert("Please Enter Other Contact Phone no.");
                alert("Wrong format, please correct");
                $("#second_contact_person_directPhone").focus();
                $("#second_contact_person_directPhone").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#second_contact_person_directPhone").removeClass("error_cl");
            }
        } else {
            $("#second_contact_person_directPhone").removeClass("error_cl");
        }
    }

    function secondContactPersonDirectMailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var second_contact_person_directMail = $('#second_contact_person_directMail').val();
        if (second_contact_person_directMail != '') {
            if (!emailPattern.test(second_contact_person_directMail)) {
                //alert("Please Enter Other Contact Email.");
                alert("Wrong format, please correct");
                $("#second_contact_person_directMail").focus();
                $("#second_contact_person_directMail").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#second_contact_person_directMail").removeClass("error_cl");
            }
        } else {
            $("#second_contact_person_directMail").removeClass("error_cl");
        }
    }

    /*Total Company validation End */



    $('body').on('click', '#npo_organization_description', function () {
        npoOrganizationTypeValidation();
    });
    $('body').on('click', '.npo_contact_title', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();

    });
    $('body').on('click', '#npo_contact_dob', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();

    });
    $('body').on('click', '#npo_contact_familyName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /* npoContactDobValidation();*/
    });
    $('body').on('click', '#npo_contact_givenName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
    });
    $('body').on('click', '#npo_contact_chineseName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
    });
    $('body').on('click', '.npo_contact_Nationality', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
    });
    $('body').on('click', '#npo_contact_address_english', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
    });
    $('body').on('click', '#npo_contact_city_english', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
    });
    $('body').on('click', '#npo_province_area', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
    });
    $('body').on('click', '#npo_contact_address_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
    });
    $('body').on('click', '#npo_contact_city_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
    });
    $('body').on('click', '#npo_contact_zip_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
    });
    $('body').on('click', '#npo_contact_phone', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
    });
    $('body').on('click', '#npo_contact_email', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
    });
    $('body').on('click', '#npo_contact_mobile', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
    });
    $('body').on('click', '.npo_second_contact_title', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /* npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();
    });
    $('body').on('click', '#npo_second_contact_dob', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();*/
    });
    $('body').on('click', '#npo_second_contact_familyName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /* npoSecondContactTitleValidation();
         npoSecondContactDobValidation();*/
    });
    $('body').on('click', '#npo_second_contact_givenName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();*/
    });
    $('body').on('click', '#npo_second_contact_chineseName', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();*/
    });
    $('body').on('click', '.npo_second_contact_nationality', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();*/
    });
    $('body').on('click', '#npo_second_contact_address_english', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();*/
    });
    $('body').on('click', '#npo_second_contact_city_english', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();*/
    });
    $('body').on('click', '#npo_second_contact_area', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();*/
    });
    $('body').on('click', '#npo_second_contact_address_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();*/
    });
    $('body').on('click', '#npo_second_contact_city_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();*/
    });
    $('body').on('click', '#npo_second_contact_zip_chinese', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
         npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();
        npoSecondContactCityChineseValidation();*/
    });
    $('body').on('click', '#npo_second_contact_mobile', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();
        npoSecondContactCityChineseValidation();
        npoSecondContactZipChineseValidation();*/
    });
    $('body').on('click', '#npo_second_contact_phone', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();
        npoSecondContactCityChineseValidation();
        npoSecondContactZipChineseValidation();*/
        npoSecondContactMobileValidation();
    });
    $('body').on('click', '#npo_second_contact_email', function () {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();
        npoSecondContactCityChineseValidation();
        npoSecondContactZipChineseValidation();*/
        npoSecondContactMobileValidation();
        npoSecondContactPhoneValidation();
    });

    function NPOContactvalidation() {
        npoOrganizationTypeValidation();
        npoOrganizationDescriptionValidation();
        npoContactTitleValidation();
        /*npoContactDobValidation();*/
        npoContactFamilyNameValidation();
        npoContactGivenNameValidation();
        npocontactChineseNameValidation();
        npoContactNationalityValidation();
        npoContactAddressenglishValidation();
        npocontactcityEnglishValidation();
        npoProvinceareaValidation();
        npoContactAddressChineseValidation();
        npocontactCityChineseValidation();
        npocontactZipChineseValidation();
        npoContactPhoneValidation();
        npoContactEmailValidation();
        npoContactMobileValidation();

        /*npoSecondContactTitleValidation();
        npoSecondContactDobValidation();
        npoSecondcontactFamilyNameValidation();
        npoSecondContactGivenNameValidation();
        nposecondContactPersonChineseNameValidation();
        npoSecondContactNationalityValidation();
        npoSecondContactAddressEnglishValidation();
        npoSecondContactCityEnglishValidation();
        npoSecondContactareaValidation();
        npoSecondContactAddressChineseValidation();
        npoSecondContactCityChineseValidation();
        npoSecondContactZipChineseValidation();*/
        npoSecondContactMobileValidation();
        npoSecondContactPhoneValidation();
        npoSecondContactEmailValidation();
    }

    function npoOrganizationTypeValidation(event) {
        var npo_organization_type = $('#npo_organization_type').val();
        if (npo_organization_type == '') {
            // alert("Please Enter Organization Type.");
            alert("Wrong format, please correct");
            $("#npo_organization_type").focus();
            $("#npo_organization_type").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_organization_type").removeClass("error_cl");
        }
    }

    function npoOrganizationDescriptionValidation(event) {
        var npo_organization_description = $('#npo_organization_description').val();
        if (npo_organization_description == '') {
            //alert("Please Enter Organization Description.");
            alert("Wrong format, please correct");
            $("#npo_organization_description").focus();
            $("#npo_organization_description").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_organization_description").removeClass("error_cl");
        }
    }

    function npoContactTitleValidation(event) {
        var npo_contact_title = $("input[name='npo_contact_title']:checked").val();
        if (npo_contact_title == '') {
            //alert("Please Select Title.");
            alert("Wrong format, please correct");
            $("#npo_contact_title").focus();
            $("#npo_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_title").removeClass("error_cl");
        }
    }

    /*    function npoContactDobValidation(event) {
            var npo_contact_dob = $('#npo_contact_dob').val();
            if (npo_contact_dob == '') {
                //alert("Please Enter Correct Date Of Birth");
                alert("Wrong format, please correct");
                $("#npo_contact_dob").focus();
                $("#npo_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_contact_dob").removeClass("error_cl");
            }
        }*/

    function npoContactFamilyNameValidation(event) {
        var npo_contact_familyName = $('#npo_contact_familyName').val();
        if (npo_contact_familyName == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#npo_contact_familyName").focus();
            $("#npo_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_familyName").removeClass("error_cl");
        }
    }

    function npoContactGivenNameValidation(event) {
        var npo_contact_givenName = $('#npo_contact_givenName').val();
        if (npo_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#npo_contact_givenName").focus();
            $("#npo_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_givenName").removeClass("error_cl");
        }
    }

    function npocontactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_contact_chineseName = $('#npo_contact_chineseName').val();
            if (npo_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#npo_contact_chineseName").focus();
                $("#npo_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#npo_contact_chineseName").removeClass("error_cl");
        }
    }

    function npoContactNationalityValidation(event) {
        var npo_contact_Nationality = $("input[name='npo_contact_Nationality']:checked").val();
        if (npo_contact_Nationality == '') {
            //alert("Please Select Nationality.");
            alert("Wrong format, please correct");
            $("#npo_contact_Nationality").focus();
            $("#npo_contact_Nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_Nationality").removeClass("error_cl");
        }
    }
    /* 	function companyFirstContactPositionValidation(event){
    		var company_first_contact_position = $('#company_first_contact_position').val();
            if (company_first_contact_position == '') {
                alert("Please Enter Position");
                $("#company_first_contact_position").focus();
                $("#company_first_contact_position").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#company_first_contact_position").removeClass("error_cl");
            }
    	} */
    function npoContactAddressenglishValidation(event) {
        var npo_contact_address_english = $('#npo_contact_address_english').val();
        if (company_first_contact_english_address == '') {
            //alert("Please Enter Address");
            alert("Wrong format, please correct");
            $("#npo_contact_address_english").focus();
            $("#npo_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_address_english").removeClass("error_cl");
        }
    }

    function npocontactcityEnglishValidation(event) {
        var npo_contact_city_english = $('#npo_contact_city_english').val();
        if (npo_contact_city_english == '') {
            //alert("Please Enter City In English.");
            alert("Wrong format, please correct");
            $("#npo_contact_city_english").focus();
            $("#npo_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_city_english").removeClass("error_cl");
        }
    }

    function npoProvinceareaValidation(event) {
        var npo_province_area = $('#npo_province_area').val();
        if (npo_province_area == '') {
            //alert("Please Select Province/Area.");
            alert("Wrong format, please correct");
            $("#npo_province_area").focus();
            $("#npo_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_province_area").removeClass("error_cl");
        }
    }

    function npoContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_contact_address_chinese = $('#npo_contact_address_chinese').val();
            if (npo_contact_address_chinese == '') {
                //alert("Please Enter Address In Chinese.");
                alert("Wrong format, please correct");
                $("#npo_contact_address_chinese").focus();
                $("#npo_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#npo_contact_address_chinese").removeClass("error_cl");
        }
    }

    function npocontactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_contact_city_chinese = $('#npo_contact_city_chinese').val();
            if (npo_contact_city_chinese == '') {
                //alert("Please Enter City In Chinese");
                alert("Wrong format, please correct");
                $("#npo_contact_city_chinese").focus();
                $("#npo_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#npo_contact_city_chinese").removeClass("error_cl");
        }
    }

    function npocontactZipChineseValidation(event) {
        var npo_contact_zip_chinese = $('#npo_contact_zip_chinese').val();
        if (npo_contact_zip_chinese == '') {
            //alert("Please Enter Zip Code.");
            alert("Wrong format, please correct");
            $("#npo_contact_zip_chinese").focus();
            $("#npo_contact_zip_chinese").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_zip_chinese").removeClass("error_cl");
        }
    }

    function npoContactPhoneValidation(event) {
        var npo_contact_phone = $('#npo_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(npo_contact_phone)) || (npo_contact_phone == '')) {
            //alert("Please Enter Direct Phone No.");
            alert("Wrong format, please correct");
            $("#npo_contact_phone").focus();
            $("#npo_contact_phone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_contact_phone").removeClass("error_cl");
        }
    }

    function npoContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var npo_contact_email = $('#npo_contact_email').val();
        if ((!emailPattern.test(npo_contact_email)) || (npo_contact_email == '')) {
            //alert("Please Enter Email Address.");
            alert("Wrong format, please correct");
            $("#npo_contact_email").focus();
            $("#npo_contact_email").addClass("error_cl");
            return false;
        } else {
            $("#npo_contact_email").removeClass("error_cl");
        }
    }

    function npoContactMobileValidation(event) {
        var npo_contact_mobile = $('#npo_contact_mobile').val();
        var lenght1 = $('#npo_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if ((npo_contact_mobile == '') || (!phonePattern.test(npo_contact_mobile)) || (lenght1 > 20)) {
            //alert("Please Enter Mobile No.");
            alert("Wrong format, please correct");
            $("#npo_contact_mobile").focus();
            $("#npo_contact_mobile").addClass("error_cl");
            return false;
        } else {
            $("#npo_contact_mobile").removeClass("error_cl");
        }
    }

    function npoSecondContactTitleValidation(event) {
        var npo_second_contact_title = $("input[name='npo_second_contact_title']:checked").val();
        if (npo_second_contact_title == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_title").focus();
            $("#npo_second_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_title").removeClass("error_cl");
        }
    }

    /*    function npoSecondContactDobValidation(event) {
            var npo_second_contact_dob = $('#npo_second_contact_dob').val();
            if (npo_second_contact_dob == '') {
                //alert("Please Enter Other Contact Family Name.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_dob").focus();
                $("#npo_second_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_dob").removeClass("error_cl");
            }
        }*/

    function npoSecondcontactFamilyNameValidation(event) {
        var npo_second_contact_familyName = $('#npo_second_contact_familyName').val();
        if (npo_second_contact_familyName == '') {
            //alert("Please Enter Other Contact Family Name.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_familyName").focus();
            $("#npo_second_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_familyName").removeClass("error_cl");
        }
    }

    function npoSecondContactGivenNameValidation(event) {
        var npo_second_contact_givenName = $('#npo_second_contact_givenName').val();
        if (npo_second_contact_givenName == '') {
            alert("Wrong format, please correct");
            //alert("Please Enter Other Contact Given Name.");
            $("#npo_second_contact_givenName").focus();
            $("#npo_second_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_givenName").removeClass("error_cl");
        }
    }

    function nposecondContactPersonChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_second_contact_chineseName = $('#npo_second_contact_chineseName').val();
            if (npo_second_contact_chineseName == '') {
                //alert("Please Enter Other Contact Chinese Name.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_chineseName").focus();
                $("#npo_second_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_chineseName").removeClass("error_cl");
        }
    }

    function npoSecondContactNationalityValidation(event) {
        var npo_second_contact_nationality = $("input[name='npo_second_contact_nationality']:checked").val();
        if (npo_second_contact_nationality == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_nationality").focus();
            $("#npo_second_contact_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_nationality").removeClass("error_cl");
        }
    }

    function npoSecondContactAddressEnglishValidation(event) {
        var npo_second_contact_address_english = $('#npo_second_contact_address_english').val();
        if (npo_second_contact_address_english == '') {
            //alert("Please Enter Other Contact Address In English.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_address_english").focus();
            $("#npo_second_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_address_english").removeClass("error_cl");
        }
    }

    function npoSecondContactCityEnglishValidation(event) {
        var npo_second_contact_city_english = $('#npo_second_contact_city_english').val();
        if (npo_second_contact_city_english == '') {
            //alert("Please Enter Other Contact City In English.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_city_english").focus();
            $("#npo_second_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_city_english").removeClass("error_cl");
        }
    }

    function npoSecondContactareaValidation(event) {
        var npo_second_contact_area = $('#npo_second_contact_area').val();
        if (npo_second_contact_area == '') {
            //alert("Please Select Other Contact Province/Area.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_area").focus();
            $("#npo_second_contact_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_area").removeClass("error_cl");
        }
    }

    function npoSecondContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_second_contact_address_chinese = $('#npo_second_contact_address_chinese').val();
            if (npo_second_contact_address_chinese == '') {
                //alert("Please Enter Other Contact Address In Chinese.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_address_chinese").focus();
                $("#npo_second_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_address_chinese").removeClass("error_cl");
        }
    }

    function npoSecondContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var npo_second_contact_city_chinese = $('#npo_second_contact_city_chinese').val();
            if (npo_second_contact_city_chinese == '') {
                //alert("Please Enter Other Contact City In Chinese.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_city_chinese").focus();
                $("#npo_second_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_city_chinese").removeClass("error_cl");
        }
    }

    function npoSecondContactZipChineseValidation(event) {
        var npo_second_contact_zip_chinese = $('#npo_second_contact_zip_chinese').val();
        if (npo_second_contact_zip_chinese == '') {
            //alert("Please Enter Other Contact Zip Code.");
            alert("Wrong format, please correct");
            $("#npo_second_contact_zip_chinese").focus();
            $("#npo_second_contact_zip_chinese").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#npo_second_contact_zip_chinese").removeClass("error_cl");
        }
    }

    function npoSecondContactMobileValidation(event) {
        var npo_second_contact_mobile = $('#npo_second_contact_mobile').val();
        var lenght1 = $('#npo_second_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (npo_second_contact_mobile != '') {
            if ((!phonePattern.test(npo_second_contact_mobile)) || (lenght1 > 20)) {
                //alert("Please Enter Other Contact Mobile No.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_mobile").focus();
                $("#npo_second_contact_mobile").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_mobile").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_mobile").removeClass("error_cl");
        }
    }

    function npoSecondContactPhoneValidation(event) {
        var npo_second_contact_phone = $('#npo_second_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if (npo_second_contact_phone != '') {
            if (!phonePattern.test(npo_second_contact_phone)) {
                //alert("Please Enter Other Contact Phone no.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_phone").focus();
                $("#npo_second_contact_phone").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_phone").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_phone").removeClass("error_cl");
        }
    }

    function npoSecondContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var npo_second_contact_email = $('#npo_second_contact_email').val();
        if (npo_second_contact_email != '') {
            if (!emailPattern.test(npo_second_contact_email)) {
                //alert("Please Select Other Contact Email.");
                alert("Wrong format, please correct");
                $("#npo_second_contact_email").focus();
                $("#npo_second_contact_email").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#npo_second_contact_email").removeClass("error_cl");
            }
        } else {
            $("#npo_second_contact_email").removeClass("error_cl");
        }
    }
    /* Npo validation End*/


    $('body').on('click', '#individual_contact_dob', function () {
        individualContactTitleValidation();
    });

    $('body').on('click', '#individual_contact_familyName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
    });
    $('body').on('click', '#individual_contact_givenName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
    });
    $('body').on('click', '#individual_contact_chineseName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
    });
    $('body').on('click', '.individual_contact_Nationality', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
    });
    $('body').on('click', '#individual_contact_address_english', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
    });
    $('body').on('click', '#individual_contact_city_english', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
    });
    $('body').on('click', '#individual_contact_province_area', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
    });
    $('body').on('click', '#individual_contact_address_chinese', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
    });
    $('body').on('click', '#individual_contact_city_chinese', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
    });
    $('body').on('click', '#individual_contact_zip_chinese', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
    });
    $('body').on('click', '#individual_contact_directPhone', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
    });
    $('body').on('click', '#individual_contact_email', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
    });
    $('body').on('click', '#individual_contact_phone', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
       // individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
    });
    $('body').on('click', '.individual_second_contact_title', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();
    });
    $('body').on('click', '#individual_second_contact_dob', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();*/
    });
    $('body').on('click', '#individual_second_contact_familyName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();*/
    });
    $('body').on('click', '#individual_second_contact_givenName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();*/
    });
    $('body').on('click', '#individual_second_contact_chineseName', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();*/
    });
    $('body').on('click', '.individual_second_contact_Nationality', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();*/
    });
    $('body').on('click', '#individual_second_contact_address_english', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();*/
    });
    $('body').on('click', '#individual_second_contact_city_english', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();*/
    });
    $('body').on('click', '#individual_second_contact_area', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();*/
    });
    $('body').on('click', '#individual_second_contact_address_chinese', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();*/
    });
    $('body').on('click', '#individual_second_contact_city_chinese', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();*/
    });
    $('body').on('click', '#individual_second_contact_zip_code', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
       // individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();
        individualSecondContactCityChineseValidation();*/
    });
    $('body').on('click', '#individual_second_contact_mobile', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();
        individualSecondContactCityChineseValidation();
        individualSecondContactZipCodeValidation();*/
    });
    $('body').on('click', '#individual_second_contact_phone', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
       // individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();
        individualSecondContactCityChineseValidation();
        individualSecondContactZipCodeValidation();*/
        //individualSecondContactMobileValidation();
    });
    $('body').on('click', '#individual_second_contact_email', function () {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();
        individualSecondContactCityChineseValidation();
        individualSecondContactZipCodeValidation();*/
        //individualSecondContactMobileValidation();
        //individualSecondContactPhoneValidation();
    });


    function individualContactValidation(event) {
        individualContactTitleValidation();
        /*individualcontactDobValidation();*/
        individualContactFamilyNameValidation();
        individualContactGivenNameValidation();
        individualContactChineseNameValidation();
        individualContactNationalityValidation();
        individualContactAddressEnglishValidation();
        individualContactCityEnglishValidation();
        //individualContactProvinceAreaValidation();
        individualContactAddressChineseValidation();
        individualContactCityChineseValidation();
        //individualContactZipChineseValidation();
        individualContactDirectPhoneValidation();
        individualContactEmailValidation();
        individualContactPhoneValidation();

        /*individualSecondContactTitleValidation();
        individualSecondContactDobValidation();
        individualSecondContactFamilyNameValidation();
        individualSecondContactGivenNameValidation();
        individualSecondContactChineseNameValidation();
        individualSecondContactNationalityValidation();
        individualSecondContactAddressEnglishValidation();
        individualSecondContactCityEnglishValidation();
        individualSecondContactAreaValidation();
        individualSecondContactAddressChineseValidation();
        individualSecondContactCityChineseValidation();
        individualSecondContactZipCodeValidation();*/
       // individualSecondContactMobileValidation();
        //individualSecondContactPhoneValidation();
        //individualSecondContactEmailValidation();
    }

    function individualContactTitleValidation(event) {
        var individual_contact_title = $("input[name='individual_contact_title']:checked").val();
        if (individual_contact_title == '') {
            //alert("Please Select Contact Title.");
            alert("Wrong format, please correct");
            $("#individual_contact_title").focus();
            $("#individual_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_title").removeClass("error_cl");
        }
    }

    /*    function individualcontactDobValidation(event) {
            var individual_contact_dob = $('#individual_contact_dob').val();
            if (individual_contact_dob == '') {
                //alert("Please Enter date Of Birth");
                alert("Wrong format, please correct");
                $("#individual_contact_dob").focus();
                $("#individual_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_contact_dob").removeClass("error_cl");
            }
        }*/

    function individualContactFamilyNameValidation(event) {
        var individual_contact_familyName = $('#individual_contact_familyName').val();
        if (individual_contact_familyName == '') {
            //alert("Please Enter family Name");
            alert("Wrong format, please correct");
            $("#individual_contact_familyName").focus();
            $("#individual_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_familyName").removeClass("error_cl");
        }
    }

    function individualContactGivenNameValidation(event) {
        var individual_contact_givenName = $('#individual_contact_givenName').val();
        if (individual_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#individual_contact_givenName").focus();
            $("#individual_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_givenName").removeClass("error_cl");
        }
    }

    function individualContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_contact_chineseName = $('#individual_contact_chineseName').val();
            if (individual_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#individual_contact_chineseName").focus();
                $("#individual_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#individual_contact_chineseName").removeClass("error_cl");
        }
    }

    function individualContactNationalityValidation(event) {
        var individual_contact_Nationality = $("input[name='individual_contact_Nationality']:checked").val();
        if (individual_contact_Nationality == '') {
            //alert("Please Select Contact Nationality.");
            alert("Wrong format, please correct");
            $("#individual_contact_Nationality").focus();
            $("#individual_contact_Nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_Nationality").removeClass("error_cl");
        }
    }

    function individualContactAddressEnglishValidation(event) {
        var individual_contact_address_english = $('#individual_contact_address_english').val();
        if (individual_contact_address_english == '') {
            //alert("Please Enter address");
            alert("Wrong format, please correct");
            $("#individual_contact_address_english").focus();
            $("#individual_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_address_english").removeClass("error_cl");
        }
    }

    function individualContactCityEnglishValidation(event) {
        var individual_contact_city_english = $('#individual_contact_city_english').val();
        if (individual_contact_city_english == '') {
            //alert("Please Enter City");
            alert("Wrong format, please correct");
            $("#individual_contact_city_english").focus();
            $("#individual_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_city_english").removeClass("error_cl");
        }
    }

    /*function individualContactProvinceAreaValidation(event) {
        var individual_contact_province_area = $('#individual_contact_province_area').val();
        if (individual_contact_province_area == '') {
            //alert("Please Select Province/Area.");
            alert("Wrong format, please correct");
            $("#individual_contact_province_area").focus();
            $("#individual_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_province_area").removeClass("error_cl");
        }
    }*/

    function individualContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_contact_address_chinese = $('#individual_contact_address_chinese').val();
            if (individual_contact_address_chinese == '') {
                //alert("Please Enter Address");
                alert("Wrong format, please correct");
                $("#individual_contact_address_chinese").focus();
                $("#individual_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#individual_contact_address_chinese").removeClass("error_cl");
        }
    }

    function individualContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_contact_city_chinese = $('#individual_contact_city_chinese').val();
            if (individual_contact_city_chinese == '') {
                //alert("Please Enter City");
                alert("Wrong format, please correct");
                $("#individual_contact_city_chinese").focus();
                $("#individual_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#individual_contact_city_chinese").removeClass("error_cl");
        }
    }

    /*function individualContactZipChineseValidation(event) {
        var individual_contact_zip_chinese = $('#individual_contact_zip_chinese').val();
        if (individual_contact_zip_chinese == '') {
            //alert("Please Enter ZipCode");
            alert("Wrong format, please correct");
            $("#individual_contact_zip_chinese").focus();
            $("#individual_contact_zip_chinese").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_zip_chinese").removeClass("error_cl");
        }
    }*/

    function individualContactDirectPhoneValidation(event) {
        var individual_contact_directPhone = $('#individual_contact_directPhone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(individual_contact_directPhone)) || (individual_contact_directPhone == '')) {
            //alert("Please Enter Direct Phone");
            alert("Wrong format, please correct");
            $("#individual_contact_directPhone").focus();
            $("#individual_contact_directPhone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_directPhone").removeClass("error_cl");
        }
    }

    function individualContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var individual_contact_email = $('#individual_contact_email').val();
        if ((!emailPattern.test(individual_contact_email)) || (individual_contact_email == '')) {
            //alert("Please Enter email");

            $("#individual_contact_email").focus();
            $("#individual_contact_email").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_email").removeClass("error_cl");
        }
    }

    function individualContactPhoneValidation(event) {
        var individual_contact_phone = $('#individual_contact_phone').val();
        var lenght1 = $('#individual_contact_phone').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if ((individual_contact_phone == '') || (!phonePattern.test(individual_contact_phone)) || (lenght1 > 20)) {
            //alert("Please Enter Phone");
            alert("Wrong format, please correct");
            $("#individual_contact_phone").focus();
            $("#individual_contact_phone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_phone").removeClass("error_cl");
        }
    }

    function individualSecondContactTitleValidation(event) {
        var individual_second_contact_title = $("input[name='individual_second_contact_title']:checked").val();
        if (individual_second_contact_title == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_title").focus();
            $("#individual_second_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_title").removeClass("error_cl");
        }
    }

    /*function individualSecondContactDobValidation(event) {
    var individual_second_contact_dob = $('#individual_second_contact_dob').val();
    if (individual_second_contact_dob == '') {
        //alert("Please Enter Other Contact Title.");
        alert("Wrong format, please correct");
        $("#individual_second_contact_dob").focus();
        $("#individual_second_contact_dob").addClass("error_cl");
        event.preventDefault();
    } else {
        $("#individual_second_contact_dob").removeClass("error_cl");
    }
}*/
    function individualSecondContactFamilyNameValidation(event) {
        var individual_second_contact_familyName = $('#individual_second_contact_familyName').val();
        if (individual_second_contact_familyName == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#individual_second_contact_familyName").focus();
            $("#individual_second_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_familyName").removeClass("error_cl");
        }
    }

    function individualSecondContactGivenNameValidation(event) {
        var individual_second_contact_givenName = $('#individual_second_contact_givenName').val();
        if (individual_second_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#individual_second_contact_givenName").focus();
            $("#individual_second_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_givenName").removeClass("error_cl");
        }
    }

    function individualSecondContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_second_contact_chineseName = $('#individual_second_contact_chineseName').val();
            if (individual_second_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#individual_second_contact_chineseName").focus();
                $("#individual_second_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_second_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#individual_second_contact_chineseName").removeClass("error_cl");
        }
    }

    function individualSecondContactNationalityValidation(event) {
        var individual_second_contact_Nationality = $("input[name='individual_second_contact_Nationality']:checked").val();
        if (individual_second_contact_Nationality == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_Nationality").focus();
            $("#individual_second_contact_Nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_Nationality").removeClass("error_cl");
        }
    }

    function individualSecondContactAddressEnglishValidation(event) {
        var individual_second_contact_address_english = $('#individual_second_contact_address_english').val();
        if (individual_second_contact_address_english == '') {
            //alert("Please Enter Other Contact Adderess In English.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_address_english").focus();
            $("#individual_second_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_address_english").removeClass("error_cl");
        }
    }

    function individualSecondContactCityEnglishValidation(event) {
        var individual_second_contact_city_english = $('#individual_second_contact_city_english').val();
        if (individual_second_contact_city_english == '') {
            //alert("Please Enter Other Contact City In English.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_city_english").focus();
            $("#individual_second_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_city_english").removeClass("error_cl");
        }
    }

    function individualSecondContactAreaValidation(event) {
        var individual_second_contact_area = $('#individual_second_contact_area').val();
        if (individual_second_contact_area == '') {
            //alert("Please Enter Other Contact Province/Area.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_area").focus();
            $("#individual_second_contact_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_area").removeClass("error_cl");
        }
    }

    function individualSecondContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_second_contact_address_chinese = $('#individual_second_contact_address_chinese').val();
            if (individual_second_contact_address_chinese == '') {
                //alert("Please Select Other Contact Province/Area.");
                alert("Wrong format, please correct");
                $("#individual_second_contact_address_chinese").focus();
                $("#individual_second_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_second_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#individual_second_contact_address_chinese").removeClass("error_cl");
        }
    }

    function individualSecondContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var individual_second_contact_city_chinese = $('#individual_second_contact_city_chinese').val();
            if (individual_second_contact_city_chinese == '') {
                //alert("Please Enter Other Contact City In Chinese.");
                alert("Wrong format, please correct");
                $("#individual_second_contact_city_chinese").focus();
                $("#individual_second_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_second_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#individual_second_contact_city_chinese").removeClass("error_cl");
        }
    }

    function individualSecondContactZipCodeValidation(event) {
        var individual_second_contact_zip_code = $('#individual_second_contact_zip_code').val();
        if (individual_second_contact_zip_code == '') {
            //alert("Please Enter Other Contact Zip Code.");
            alert("Wrong format, please correct");
            $("#individual_second_contact_zip_code").focus();
            $("#individual_second_contact_zip_code").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_second_contact_zip_code").removeClass("error_cl");
        }
    }

    /*function individualSecondContactMobileValidation(event) {
        var individual_second_contact_mobile = $('#individual_second_contact_mobile').val();
        var lenght1 = $('#individual_second_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (individual_second_contact_mobile != '') {
            if ((!phonePattern.test(individual_second_contact_mobile)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile No");
                alert("Wrong format, please correct");
                $("#individual_second_contact_mobile").focus();
                $("#individual_second_contact_mobile").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_second_contact_mobile").removeClass("error_cl");
            }
        } else {
            $("#individual_second_contact_mobile").removeClass("error_cl");
        }
    }*/

    /*function individualSecondContactPhoneValidation(event) {
        var individual_second_contact_phone = $('#individual_second_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if (individual_second_contact_phone != '') {
            if (!phonePattern.test(individual_second_contact_phone)) {
                //alert("Please Enter Phone");
                alert("Wrong format, please correct test");
                $("#individual_second_contact_phone").focus();
                $("#individual_second_contact_phone").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#individual_second_contact_phone").removeClass("error_cl");
            }
        } else {
            $("#individual_second_contact_phone").removeClass("error_cl");
        }
    } */

    /*function individualSecondContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var individual_second_contact_email = $('#individual_second_contact_email').val();
        if (individual_second_contact_email != '') {
            if (!emailPattern.test(individual_second_contact_email)) {
                //alert("Please Enter Email");
                alert("Wrong format, please correct test2");
                $("#individual_second_contact_email").focus();
                $("#individual_second_contact_email").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#second_contact_person_directMail").removeClass("error_cl");
            }
        } else {
            $("#second_contact_person_directMail").removeClass("error_cl");
        }
    }*/









    $('body').on('click', '#media_description', function () {
        mediaTypeValidation();
    });
    $('body').on('click', '.journalist_contact_title', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
    });
    $('body').on('click', '#journalist_contact_dob', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
    });
    $('body').on('click', '#journalist_contact_familyName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
    });
    $('body').on('click', '#journalist_contact_givenName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
    });
    $('body').on('click', '#journalist_contact_chineseName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
    });
    $('body').on('click', '.journalist_contact_Nationality', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
    });
    $('body').on('click', '#journalist_contact_address_english', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
    });
    $('body').on('click', '#journalist_contact_city_english', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
    });
    $('body').on('click', '#journalist_contact_province_area', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
    });
    $('body').on('click', '#journalist_contact_address_chinese', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
    });
    $('body').on('click', '#journalist_contact_city_chinese', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
    });
    $('body').on('click', '#journalist_contact_zip_chinese', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
    });
    $('body').on('click', '#journalist_contact_phone', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
    });
    $('body').on('click', '#journalist_contact_email', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
    });
    $('body').on('click', '#journalist_contact_mobile', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
    });
    $('body').on('click', '.journalist_second_contact_title', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
    });
    $('body').on('click', '#journalist_second_contact_dob', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_familyName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_givenName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_chineseName', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();*/
    });
    $('body').on('click', '.journalist_second_contact_nationality', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_address_english', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();*/
    });

    $('body').on('click', '#journalist_second_contact_city_english', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_province_area', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_address_chinese', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_city_chinese', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_zip_code', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();
        journalistSecondContactCityChineseValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_mobile', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();
        journalistSecondContactCityChineseValidation();
        journalistSecondContactZipCodeValidation();*/
    });
    $('body').on('click', '#journalist_second_contact_phone', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();
        journalistSecondContactCityChineseValidation();
        journalistSecondContactZipCodeValidation();*/
        journalistSecondContactMobileValidation();
    });
    $('body').on('click', '#journalist_second_contact_email', function () {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();
        journalistSecondContactCityChineseValidation();
        journalistSecondContactZipCodeValidation();*/
        journalistSecondContactMobileValidation();
        journalistSecondContactPhoneValidation();
    });


    function journalistContactValidation(event) {
        mediaTypeValidation();
        mediaDescriptionValidation();
        journalistContactTitleValidation();
        /*journalistContactDobValidation();*/
        journalistContactFamilyNameValidation();
        journalistContactGivenNameValidation();
        journalistContactChineseNameValidation();
        journalistContactNationalityValidation();
        journalistContactAddressEnglishValidation();
        journalistContactCityEnglishValidation();
        journalistContactProvinceAreaValidation();
        journalistContactAddressChineseValidation();
        journalistContactCityChineseValidation();
        journalistContactZipChineseValidation();
        journalistContactPhoneValidation();
        journalistContactEmailValidation();
        journalistContactMobileValidation();
        /*journalistSecondContactTitleValidation();
        journalistSecondContactDobValidation();
        journalistSecondContactFamilyNameValidation();
        journalistSecondContactGivenNameValidation();
        journalistSecondContactChineseNameValidation();
        journalistSecondContactNationalityValidation();
        journalistSecondContactAddressEnglishValidation();
        journalistSecondContactCityEnglishValidation();
        journalistSecondContactProvinceAreaValidation();
        journalistSecondContactAddressChineseValidation();
        journalistSecondContactCityChineseValidation();
        journalistSecondContactZipCodeValidation();*/
        journalistSecondContactMobileValidation();
        journalistSecondContactPhoneValidation();
        journalistSecondContactEmailValidation();
    }

    function mediaTypeValidation(event) {
        var media_type = $('#media_type').val();
        if (media_type == '') {
            //alert("Please Enter Media Type.");
            alert("Wrong format, please correct");
            $("#media_type").focus();
            $("#media_type").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#media_type").removeClass("error_cl");
        }
    }

    function mediaDescriptionValidation(event) {
        var media_description = $('#media_description').val();
        if (media_description == '') {
            //alert("Please Enter Media Description.");
            alert("Wrong format, please correct");
            $("#media_description").focus();
            $("#media_description").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#media_description").removeClass("error_cl");
        }
    }

    function journalistContactTitleValidation(event) {
        var journalist_contact_title = $("input[name='journalist_contact_title']:checked").val();
        if (journalist_contact_title == '') {
            //alert("Please Select Contact Title.");
            alert("Wrong format, please correct");
            $("#journalist_contact_title").focus();
            $("#journalist_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#individual_contact_title").removeClass("error_cl");
        }
    }

    /*    function journalistContactDobValidation(event) {
            var journalist_contact_dob = $('#journalist_contact_dob').val();
            if (journalist_contact_dob == '') {
                //alert("Please Enter date Of Birth");
                alert("Wrong format, please correct");
                $("#journalist_contact_dob").focus();
                $("#journalist_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_contact_dob").removeClass("error_cl");
            }
        }*/

    function journalistContactFamilyNameValidation(event) {
        var journalist_contact_familyName = $('#journalist_contact_familyName').val();
        if (journalist_contact_familyName == '') {
            //alert("Please Enter family Name");
            alert("Wrong format, please correct");
            $("#journalist_contact_familyName").focus();
            $("#journalist_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_familyName").removeClass("error_cl");
        }
    }

    function journalistContactGivenNameValidation(event) {
        var journalist_contact_givenName = $('#journalist_contact_givenName').val();
        if (journalist_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#journalist_contact_givenName").focus();
            $("#journalist_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_givenName").removeClass("error_cl");
        }
    }

    function journalistContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_contact_chineseName = $('#journalist_contact_chineseName').val();
            if (journalist_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#journalist_contact_chineseName").focus();
                $("#journalist_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#journalist_contact_chineseName").removeClass("error_cl");
        }
    }

    function journalistContactNationalityValidation(event) {
        var journalist_contact_Nationality = $("input[name='journalist_contact_Nationality']:checked").val();
        if (journalist_contact_Nationality == '') {
            //alert("Please Select Contact Nationality.");
            alert("Wrong format, please correct");
            $("#journalist_contact_Nationality").focus();
            $("#journalist_contact_Nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_Nationality").removeClass("error_cl");
        }
    }

    function journalistContactAddressEnglishValidation(event) {
        var journalist_contact_address_english = $('#journalist_contact_address_english').val();
        if (journalist_contact_address_english == '') {
            //alert("Please Enter address");
            alert("Wrong format, please correct");
            $("#journalist_contact_address_english").focus();
            $("#journalist_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_address_english").removeClass("error_cl");
        }
    }

    function journalistContactCityEnglishValidation(event) {
        var journalist_contact_city_english = $('#journalist_contact_city_english').val();
        if (journalist_contact_city_english == '') {
            //alert("Please Enter City");
            alert("Wrong format, please correct");
            $("#journalist_contact_city_english").focus();
            $("#journalist_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_city_english").removeClass("error_cl");
        }
    }

    function journalistContactProvinceAreaValidation(event) {
        var journalist_contact_province_area = $('#journalist_contact_province_area').val();
        if (journalist_contact_province_area == '') {
            //alert("Please Select Province/Area.");
            alert("Wrong format, please correct");
            $("#journalist_contact_province_area").focus();
            $("#journalist_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_province_area").removeClass("error_cl");
        }
    }

    function journalistContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_contact_address_chinese = $('#journalist_contact_address_chinese').val();
            if (journalist_contact_address_chinese == '') {
                //alert("Please Enter Address");
                alert("Wrong format, please correct");
                $("#journalist_contact_address_chinese").focus();
                $("#journalist_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#journalist_contact_address_chinese").removeClass("error_cl");
        }
    }

    function journalistContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_contact_city_chinese = $('#journalist_contact_city_chinese').val();
            if (journalist_contact_city_chinese == '') {
                //alert("Please Enter City");
                alert("Wrong format, please correct");
                $("#journalist_contact_city_chinese").focus();
                $("#journalist_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#journalist_contact_city_chinese").removeClass("error_cl");
        }
    }

    function journalistContactZipChineseValidation(event) {
        var journalist_contact_zip_chinese = $('#journalist_contact_zip_chinese').val();
        if (journalist_contact_zip_chinese == '') {
            //alert("Please Enter ZipCode");
            alert("Wrong format, please correct");
            $("#journalist_contact_zip_chinese").focus();
            $("#journalist_contact_zip_chinese").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_zip_chinese").removeClass("error_cl");
        }
    }

    function journalistContactPhoneValidation(event) {
        var journalist_contact_phone = $('#journalist_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(journalist_contact_phone)) || (journalist_contact_phone == '')) {
            //alert("Please Enter Direct Phone");
            alert("Wrong format, please correct");
            $("#journalist_contact_phone").focus();
            $("#journalist_contact_phone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_phone").removeClass("error_cl");
        }
    }

    function journalistContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var journalist_contact_email = $('#journalist_contact_email').val();
        if ((!emailPattern.test(journalist_contact_email)) || (journalist_contact_email == '')) {
            //alert("Please Enter email");
            alert("Wrong format, please correct");
            $("#journalist_contact_email").focus();
            $("#journalist_contact_email").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_email").removeClass("error_cl");
        }
    }

    function journalistContactMobileValidation(event) {
        var journalist_contact_mobile = $('#journalist_contact_mobile').val();
        var lenght1 = $('#journalist_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if ((journalist_contact_mobile == '') || (!phonePattern.test(journalist_contact_mobile)) || (lenght1 > 20)) {
            // alert("Please Enter Phone");
            alert("Wrong format, please correct");
            $("#journalist_contact_mobile").focus();
            $("#journalist_contact_mobile").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_contact_mobile").removeClass("error_cl");
        }
    }

    function journalistSecondContactTitleValidation(event) {
        var journalist_second_contact_title = $("input[name='journalist_second_contact_title']:checked").val();
        if (journalist_second_contact_title == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_title").focus();
            $("#journalist_second_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_title").removeClass("error_cl");
        }
    }

    /*    function journalistSecondContactDobValidation(event) {
            var journalist_second_contact_dob = $('#journalist_second_contact_dob').val();
            if (journalist_second_contact_dob == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_dob").focus();
                $("#journalist_second_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_dob").removeClass("error_cl");
            }
        }*/

    function journalistSecondContactFamilyNameValidation(event) {
        var journalist_second_contact_familyName = $('#journalist_second_contact_familyName').val();
        if (journalist_second_contact_familyName == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_familyName").focus();
            $("#journalist_second_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_familyName").removeClass("error_cl");
        }
    }

    function journalistSecondContactGivenNameValidation(event) {
        var journalist_second_contact_givenName = $('#journalist_second_contact_givenName').val();
        if (journalist_second_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_givenName").focus();
            $("#journalist_second_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_givenName").removeClass("error_cl");
        }
    }

    function journalistSecondContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_second_contact_chineseName = $('#journalist_second_contact_chineseName').val();
            if (journalist_second_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_chineseName").focus();
                $("#journalist_second_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_chineseName").removeClass("error_cl");
        }
    }

    function journalistSecondContactNationalityValidation(event) {
        var journalist_second_contact_nationality = $("input[name='journalist_second_contact_nationality']:checked").val();
        if (journalist_second_contact_nationality == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_nationality").focus();
            $("#journalist_second_contact_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_nationality").removeClass("error_cl");
        }
    }

    function journalistSecondContactAddressEnglishValidation(event) {
        var journalist_second_contact_address_english = $('#journalist_second_contact_address_english').val();
        if (journalist_second_contact_address_english == '') {
            //alert("Please Enter Other Contact Adderess In English.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_address_english").focus();
            $("#journalist_second_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_address_english").removeClass("error_cl");
        }
    }

    function journalistSecondContactCityEnglishValidation(event) {
        var journalist_second_contact_city_english = $('#journalist_second_contact_city_english').val();
        if (journalist_second_contact_city_english == '') {
            //alert("Please Enter Other Contact City In English.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_city_english").focus();
            $("#journalist_second_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_city_english").removeClass("error_cl");
        }
    }

    function journalistSecondContactProvinceAreaValidation(event) {
        var journalist_second_contact_province_area = $('#journalist_second_contact_province_area').val();
        if (journalist_second_contact_province_area == '') {
            //alert("Please Enter Other Contact Province/Area.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_province_area").focus();
            $("#journalist_second_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_province_area").removeClass("error_cl");
        }
    }

    function journalistSecondContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_second_contact_address_chinese = $('#journalist_second_contact_address_chinese').val();
            if (journalist_second_contact_address_chinese == '') {
                //alert("Please Select Other Contact Province/Area.");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_address_chinese").focus();
                $("#journalist_second_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_address_chinese").removeClass("error_cl");
        }
    }

    function journalistSecondContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var journalist_second_contact_city_chinese = $('#journalist_second_contact_city_chinese').val();
            if (journalist_second_contact_city_chinese == '') {
                //alert("Please Enter Other Contact City In Chinese.");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_city_chinese").focus();
                $("#journalist_second_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_city_chinese").removeClass("error_cl");
        }
    }

    function journalistSecondContactZipCodeValidation(event) {
        var journalist_second_contact_zip_code = $('#journalist_second_contact_zip_code').val();
        //if ((investZone_contact_zipCode == '') || (isNaN(journalist_second_contact_zip_code))) {
        if (journalist_second_contact_zip_code == '') {
            //alert("Please Enter Other Contact Zip Code.");
            alert("Wrong format, please correct");
            $("#journalist_second_contact_zip_code").focus();
            $("#journalist_second_contact_zip_code").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#journalist_second_contact_zip_code").removeClass("error_cl");
        }
    }

    function journalistSecondContactMobileValidation(event) {
        var journalist_second_contact_mobile = $('#journalist_second_contact_mobile').val();
        var lenght1 = $('#journalist_second_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (journalist_second_contact_mobile != '') {
            if ((!phonePattern.test(journalist_second_contact_mobile)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile No");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_mobile").focus();
                $("#journalist_second_contact_mobile").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_mobile").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_mobile").removeClass("error_cl");
        }
    }

    function journalistSecondContactPhoneValidation(event) {
        var journalist_second_contact_phone = $('#journalist_second_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if (journalist_second_contact_phone != '') {
            if (!phonePattern.test(journalist_second_contact_phone)) {
                //alert("Please Enter Phone");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_phone").focus();
                $("#journalist_second_contact_phone").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_phone").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_phone").removeClass("error_cl");
        }
    }

    function journalistSecondContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var journalist_second_contact_email = $('#journalist_second_contact_email').val();
        if (journalist_second_contact_email != '') {
            if (!emailPattern.test(journalist_second_contact_email)) {
                //alert("Please Enter Email");
                alert("Wrong format, please correct");
                $("#journalist_second_contact_email").focus();
                $("#journalist_second_contact_email").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#journalist_second_contact_email").removeClass("error_cl");
            }
        } else {
            $("#journalist_second_contact_email").removeClass("error_cl");
        }
    }


    /*Journalist Validation End here*/

    /* Investment Zone validation Start Here*/
    $('body').on('click', '#investZone_contact_dob', function () {
        investZoneContactTitleValidation();
    });
    $('body').on('click', '#investZone_contact_familyName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
    });
    $('body').on('click', '#investZone_contact_givenName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
    });
    $('body').on('click', '#investZone_contact_chineseName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
    });
    $('body').on('click', '.investZone_contact_nationality', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
    });
    $('body').on('click', '#investZone_contact_address_english', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
    });
    $('body').on('click', '#investZone_contact_city_english', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
    });
    $('body').on('click', '#investZone_contact_province_area', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
    });
    $('body').on('click', '#investZone_contact_address_chinese', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
    });
    $('body').on('click', '#investZone_contact_city_chinese', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
    });
    $('body').on('click', '#investZone_contact_zipCode', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
    });
    $('body').on('click', '#investZone_contact_position', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
    });
    $('body').on('click', '#investZone_contact_directPhone', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
    });
    $('body').on('click', '#investZone_contact_directEmail', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
    });
    $('body').on('click', '.investZone_contact_mobile', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
    });
    $('body').on('click', '.investZone_second_contact_title', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
    });
    $('body').on('click', '#investZone_second_contact_dob', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_familyName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_givenName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
         investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_chineseName', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();*/
    });
    $('body').on('click', '.investZone_second_contact_nationality', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_address_english', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_city_english', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_province_area', function () {
        investZoneContactTitleValidation();
        /* investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_address_chinese', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
         investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_city_chinese', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_zipCode', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();
        investZoneSecondContactCityChineseValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_mobile', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();
        investZoneSecondContactCityChineseValidation();
        investZoneSecondContactZipCodeValidation();*/
    });
    $('body').on('click', '#investZone_second_contact_phone', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();
        investZoneSecondContactCityChineseValidation();
        investZoneSecondContactZipCodeValidation();*/
        investZoneSecondContactMobileValidation();
    });
    $('body').on('click', '#investZone_second_contact_email', function () {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();
        investZoneSecondContactCityChineseValidation();
        investZoneSecondContactZipCodeValidation();*/
        investZoneSecondContactMobileValidation();
        investZoneSecondContactPhoneValidation();
    });

    function investmentContactValidation(event) {
        investZoneContactTitleValidation();
        /*investZoneContactDobValidation();*/
        investZoneContactFamilyNameValidation();
        investZoneContactGivenNameValidation();
        investZoneContactChineseNameValidation();
        investZoneContactNationalityValidation();
        investZoneContactAddressEnglishValidation();
        investZoneContactCityEnglishValidation();
        investZoneContactProvinceAreaValidation();
        investZoneContactAddressChineseValidation();
        investZoneContactCityChineseValidation();
        investZoneContactZipCodeValidation();
        investZoneContactPositionValidation();
        investZoneContactDirectPhoneValidation();
        investZoneContactDirectEmailValidation();
        investZoneContactMobileValidation();
        /*investZoneSecondContactTitleValidation();
        investZoneSecondContactDobValidation();
        investZoneSecondContactFamilyNameValidation();
        investZoneSecondContactGivenNameValidation();
        investZoneSecondContactChineseNameValidation();
        investZoneSecondContactNationalityValidation();
        investZoneSecondContactAddressEnglishValidation();
        investZoneSecondContactCityEnglishValidation();
        investZoneSecondContactProvinceAreaValidation();
        investZoneSecondContactAddressChineseValidation();
        investZoneSecondContactCityChineseValidation();
        investZoneSecondContactZipCodeValidation();*/
        investZoneSecondContactMobileValidation();
        investZoneSecondContactPhoneValidation();
        investZoneSecondContactEmailValidation();
    }


    function investZoneContactTitleValidation(event) {
        var investZone_contact_title = $("input[name='investZone_contact_title']:checked").val();
        if (investZone_contact_title == '') {
            //alert("Please Select Contact Title.");
            alert("Wrong format, please correct");
            $("#investZone_contact_title").focus();
            $("#investZone_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_title").removeClass("error_cl");
        }
    }
    /*
        function investZoneContactDobValidation(event) {
            var investZone_contact_dob = $('#investZone_contact_dob').val();
            if (investZone_contact_dob == '') {
                //alert("Please Enter date Of Birth");
                alert("Wrong format, please correct");
                $("#investZone_contact_dob").focus();
                $("#investZone_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_contact_dob").removeClass("error_cl");
            }
        }*/

    function investZoneContactFamilyNameValidation(event) {
        var investZone_contact_familyName = $('#investZone_contact_familyName').val();
        if (investZone_contact_familyName == '') {
            //alert("Please Enter family Name");
            alert("Wrong format, please correct");
            $("#investZone_contact_familyName").focus();
            $("#investZone_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_familyName").removeClass("error_cl");
        }
    }

    function investZoneContactGivenNameValidation(event) {
        var investZone_contact_givenName = $('#investZone_contact_givenName').val();
        if (investZone_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#investZone_contact_givenName").focus();
            $("#investZone_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_givenName").removeClass("error_cl");
        }
    }

    function investZoneContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_contact_chineseName = $('#investZone_contact_chineseName').val();
            if (investZone_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#investZone_contact_chineseName").focus();
                $("#investZone_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#investZone_contact_chineseName").removeClass("error_cl");
        }
    }

    function investZoneContactNationalityValidation(event) {
        var investZone_contact_nationality = $("input[name='investZone_contact_nationality']:checked").val();
        if (investZone_contact_nationality == '') {
            //alert("Please Select Contact Nationality.");
            alert("Wrong format, please correct");
            $("#investZone_contact_nationality").focus();
            $("#investZone_contact_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_nationality").removeClass("error_cl");
        }
    }

    function investZoneContactAddressEnglishValidation(event) {
        var investZone_contact_address_english = $('#investZone_contact_address_english').val();
        if (investZone_contact_address_english == '') {
            //alert("Please Enter address");
            alert("Wrong format, please correct");
            $("#investZone_contact_address_english").focus();
            $("#investZone_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_address_english").removeClass("error_cl");
        }
    }

    function investZoneContactCityEnglishValidation(event) {
        var investZone_contact_city_english = $('#investZone_contact_city_english').val();
        if (investZone_contact_city_english == '') {
            //alert("Please Enter City");
            alert("Wrong format, please correct");
            $("#investZone_contact_city_english").focus();
            $("#investZone_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_city_english").removeClass("error_cl");
        }
    }

    function investZoneContactProvinceAreaValidation(event) {
        var investZone_contact_province_area = $('#investZone_contact_province_area').val();
        if (investZone_contact_province_area == '') {
            //alert("Please Select Province/Area.");
            alert("Wrong format, please correct");
            $("#investZone_contact_province_area").focus();
            $("#investZone_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_province_area").removeClass("error_cl");
        }
    }

    function investZoneContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_contact_address_chinese = $('#investZone_contact_address_chinese').val();
            if (investZone_contact_address_chinese == '') {
                //alert("Please Enter Address");
                alert("Wrong format, please correct");
                $("#investZone_contact_address_chinese").focus();
                $("#investZone_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#investZone_contact_address_chinese").removeClass("error_cl");
        }
    }

    function investZoneContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_contact_city_chinese = $('#investZone_contact_city_chinese').val();
            if (investZone_contact_city_chinese == '') {
                //alert("Please Enter City");
                alert("Wrong format, please correct");
                $("#investZone_contact_city_chinese").focus();
                $("#investZone_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#investZone_contact_city_chinese").removeClass("error_cl");
        }
    }

    function investZoneContactZipCodeValidation(event) {
        var investZone_contact_zipCode = $('#investZone_contact_zipCode').val();
        if (investZone_contact_zipCode == '') {
            //alert("Please Enter ZipCode");
            alert("Wrong format, please correct");
            $("#investZone_contact_zipCode").focus();
            $("#investZone_contact_zipCode").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_zipCode").removeClass("error_cl");
        }
    }

    function investZoneContactPositionValidation(event) {
        var investZone_contact_position = $('#investZone_contact_position').val();
        if (investZone_contact_position == '') {
            //alert("Please Enter Position.");
            alert("Wrong format, please correct");
            $("#investZone_contact_position").focus();
            $("#investZone_contact_position").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_position").removeClass("error_cl");
        }
    }

    function investZoneContactDirectPhoneValidation(event) {
        var investZone_contact_directPhone = $('#investZone_contact_directPhone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(investZone_contact_directPhone)) || (investZone_contact_directPhone == '')) {
            //alert("Please Enter Direct Phone");
            alert("Wrong format, please correct");
            $("#investZone_contact_directPhone").focus();
            $("#investZone_contact_directPhone").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_directPhone").removeClass("error_cl");
        }
    }

    function investZoneContactDirectEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var investZone_contact_directEmail = $('#investZone_contact_directEmail').val();
        if ((!emailPattern.test(investZone_contact_directEmail)) || (investZone_contact_directEmail == '')) {
            //alert("Please Enter email");
            alert("Wrong format, please correct");
            $("#investZone_contact_directEmail").focus();
            $("#investZone_contact_directEmail").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_directEmail").removeClass("error_cl");
        }
    }

    function investZoneContactMobileValidation(event) {
        var investZone_contact_mobile = $('#investZone_contact_mobile').val();
        var lenght1 = $('#investZone_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if ((investZone_contact_mobile == '') || (!phonePattern.test(investZone_contact_mobile)) || (lenght1 > 20)) {
            //alert("Please Enter Phone");
            alert("Wrong format, please correct");
            $("#investZone_contact_mobile").focus();
            $("#investZone_contact_mobile").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_contact_mobile").removeClass("error_cl");
        }
    }

    function investZoneSecondContactTitleValidation(event) {
        var investZone_second_contact_title = $("input[name='investZone_second_contact_title']:checked").val();
        if (investZone_second_contact_title == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_title").focus();
            $("#investZone_second_contact_title").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_title").removeClass("error_cl");
        }
    }

    /*    function investZoneSecondContactDobValidation(event) {
            var investZone_second_contact_dob = $('#investZone_second_contact_dob').val();
            if (investZone_second_contact_dob == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_dob").focus();
                $("#investZone_second_contact_dob").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_dob").removeClass("error_cl");
            }
        }*/

    function investZoneSecondContactFamilyNameValidation(event) {
        var investZone_second_contact_familyName = $('#investZone_second_contact_familyName').val();
        if (investZone_second_contact_familyName == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_familyName").focus();
            $("#investZone_second_contact_familyName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_familyName").removeClass("error_cl");
        }
    }

    function investZoneSecondContactGivenNameValidation(event) {
        var investZone_second_contact_givenName = $('#investZone_second_contact_givenName').val();
        if (investZone_second_contact_givenName == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_givenName").focus();
            $("#investZone_second_contact_givenName").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_givenName").removeClass("error_cl");
        }
    }

    function investZoneSecondContactChineseNameValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_second_contact_chineseName = $('#investZone_second_contact_chineseName').val();
            if (investZone_second_contact_chineseName == '') {
                //alert("Please Enter Chinese Name");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_chineseName").focus();
                $("#investZone_second_contact_chineseName").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_chineseName").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_chineseName").removeClass("error_cl");
        }
    }

    function investZoneSecondContactNationalityValidation(event) {
        var investZone_second_contact_nationality = $("input[name='investZone_second_contact_nationality']:checked").val();
        if (investZone_second_contact_nationality == '') {
            //alert("Please Enter Other Contact Title.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_nationality").focus();
            $("#investZone_second_contact_nationality").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_nationality").removeClass("error_cl");
        }
    }

    function investZoneSecondContactAddressEnglishValidation(event) {
        var investZone_second_contact_address_english = $('#investZone_second_contact_address_english').val();
        if (investZone_second_contact_address_english == '') {
            //alert("Please Enter Other Contact Adderess In English.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_address_english").focus();
            $("#investZone_second_contact_address_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_address_english").removeClass("error_cl");
        }
    }

    function investZoneSecondContactCityEnglishValidation(event) {
        var investZone_second_contact_city_english = $('#investZone_second_contact_city_english').val();
        if (investZone_second_contact_city_english == '') {
            //alert("Please Enter Other Contact City In English.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_city_english").focus();
            $("#investZone_second_contact_city_english").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_city_english").removeClass("error_cl");
        }
    }

    function investZoneSecondContactProvinceAreaValidation(event) {
        var investZone_second_contact_province_area = $('#investZone_second_contact_province_area').val();
        if (investZone_second_contact_province_area == '') {
            //alert("Please Enter Other Contact Province/Area.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_province_area").focus();
            $("#investZone_second_contact_province_area").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_province_area").removeClass("error_cl");
        }
    }

    function investZoneSecondContactAddressChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_second_contact_address_chinese = $('#investZone_second_contact_address_chinese').val();
            if (investZone_second_contact_address_chinese == '') {
                //alert("Please Select Other Contact Province/Area.");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_address_chinese").focus();
                $("#investZone_second_contact_address_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_address_chinese").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_address_chinese").removeClass("error_cl");
        }
    }

    function investZoneSecondContactCityChineseValidation(event) {
        var dropVal = $('#stateDrop').val();
        if (dropVal != 'HongKong') {
            var investZone_second_contact_city_chinese = $('#investZone_second_contact_city_chinese').val();
            if (investZone_second_contact_city_chinese == '') {
                //alert("Please Enter Other Contact City In Chinese.");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_city_chinese").focus();
                $("#investZone_second_contact_city_chinese").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_city_chinese").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_city_chinese").removeClass("error_cl");
        }
    }

    function investZoneSecondContactZipCodeValidation(event) {
        var investZone_second_contact_zipCode = $('#investZone_second_contact_zipCode').val();
        if (investZone_second_contact_zipCode == '') {
            //alert("Please Enter Other Contact Zip Code.");
            alert("Wrong format, please correct");
            $("#investZone_second_contact_zipCode").focus();
            $("#investZone_second_contact_zipCode").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#investZone_second_contact_zipCode").removeClass("error_cl");
        }
    }

    function investZoneSecondContactMobileValidation(event) {
        var investZone_second_contact_mobile = $('#investZone_second_contact_mobile').val();
        var lenght1 = $('#investZone_second_contact_mobile').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (investZone_second_contact_mobile != '') {
            if ((!phonePattern.test(investZone_second_contact_mobile)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile No");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_mobile").focus();
                $("#investZone_second_contact_mobile").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_mobile").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_mobile").removeClass("error_cl");
        }
    }

    function investZoneSecondContactPhoneValidation(event) {
        var investZone_second_contact_phone = $('#investZone_second_contact_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if (investZone_second_contact_phone != '') {
            if (!phonePattern.test(investZone_second_contact_phone)) {
                //alert("Please Enter Phone");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_phone").focus();
                $("#investZone_second_contact_phone").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_phone").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_phone").removeClass("error_cl");
        }
    }

    function investZoneSecondContactEmailValidation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var investZone_second_contact_email = $('#investZone_second_contact_email').val();
        if (investZone_second_contact_email != '') {
            if (!emailPattern.test(investZone_second_contact_email)) {
                //alert("Please Enter Email");
                alert("Wrong format, please correct");
                $("#investZone_second_contact_email").focus();
                $("#investZone_second_contact_email").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#investZone_second_contact_email").removeClass("error_cl");
            }
        } else {
            $("#investZone_second_contact_email").removeClass("error_cl");
        }
    }









    $('body').on('click', '.other_contact_title1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
            companyContactValidation();
        } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }

    });


    $('body').on('click', '#other_contact_dob1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
            companyContactValidation();
        } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/

    });
    $('body').on('click', '#other_contact_familyName1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /* otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/

    });
    $('body').on('click', '#other_contact_givenName1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
            companyContactValidation();
        } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /* otherContactTitle1Validation();*/
        /* otherContactDob1Validation();*/
        /* otherContactFamilyName1Validation();*/

    });
    $('body').on('click', '#other_contact_chineseName1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
    companyContactValidation();
} else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /* otherContactDob1Validation();*/
        /* otherContactFamilyName1Validation();
         otherContactGivenName1Validation();*/


    });
    $('body').on('click', '.other_contact_nationality1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /* otherContactFamilyName1Validation();
         otherContactGivenName1Validation();
         otherContactChineseName1Validation();*/

    });
    $('body').on('click', '#other_contact_address_english1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();*/

    });
    $('body').on('click', '#other_contact_city_english1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
            companyContactValidation();
        } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();*/

    });
    $('body').on('click', '#other_contact_province_area1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();*/

    });
    $('body').on('click', '#other_contact_address_chinese1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*if (radioValue1 == 'A_company') {
    companyContactValidation();
} else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /* otherContactTitle1Validation();*/
        /* otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();*/

    });
    $('body').on('click', '#other_contact_city_chinese1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*  if (radioValue1 == 'A_company') {
              companyContactValidation();
          } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();
        otherContactAddressChinese1Validation();*/

    });
    $('body').on('click', '#other_contact_zipCode1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();
        otherContactAddressChinese1Validation();
        otherContactCityChinese1Validation();*/

    });
    $('body').on('click', '#other_contact_mobile1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /* otherContactFamilyName1Validation();
         otherContactGivenName1Validation();
         otherContactChineseName1Validation();
         otherContactNationality1Validation();
         otherContactAddressEnglish1Validation();
         otherContactCityEnglish1Validation();
         otherContactProvinceArea1Validation();
         otherContactAddressChinese1Validation();
         otherContactCityChinese1Validation();
         otherContactZipCode1Validation();*/

    });
    $('body').on('click', '#other_contact_directPhone1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();
        otherContactAddressChinese1Validation();
        otherContactCityChinese1Validation();
        otherContactZipCode1Validation();*/
        otherContactMobile1Validation();

    });
    $('body').on('click', '#other_contact_directEmail1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        /* otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();
        otherContactAddressChinese1Validation();
        otherContactCityChinese1Validation();
        //otherContactZipCode1Validation();*/
        otherContactMobile1Validation();
        otherContactDirectPhone1Validation();
    });

    function otherContactValidation1(event) {
        /*otherContactTitle1Validation();*/
        /*otherContactDob1Validation();*/
        /*otherContactFamilyName1Validation();
        otherContactGivenName1Validation();
        otherContactChineseName1Validation();
        otherContactNationality1Validation();
        otherContactAddressEnglish1Validation();
        otherContactCityEnglish1Validation();
        otherContactProvinceArea1Validation();
        otherContactAddressChinese1Validation();
        otherContactCityChinese1Validation();
        //otherContactZipCode1Validation();*/
        otherContactMobile1Validation();
        otherContactDirectPhone1Validation();
        otherContactDirectEmail1Validation();
    }


    $('body').on('click', '.other_contact_title2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
    });
    $('body').on('click', '#other_contact_dob2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/

    });

    $('body').on('click', '#other_contact_familyName2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /*otherContactDob2Validation();*/

    });
    $('body').on('click', '#other_contact_givenName2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /*otherContactDob2Validation();*/
        /*otherContactFamilyName2Validation();*/

    });
    $('body').on('click', '#other_contact_givenName2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*  if (radioValue1 == 'A_company') {
      companyContactValidation();
  } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /*otherContactDob2Validation();*/
        /*otherContactFamilyName2Validation();
        otherContactGivenName2Validation();*/

    });
    $('body').on('click', '#other_contact_chineseName2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /*otherContactDob2Validation();*/
        /*otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
*/
    });
    $('body').on('click', '.other_contact_nationality2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /* otherContactDob2Validation();*/
        /*otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();*/

    });
    $('body').on('click', '#other_contact_address_english2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*  if (radioValue1 == 'A_company') {
              companyContactValidation();
          } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();*/
        /*otherContactDob2Validation();*/
        /*otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();*/

    });
    $('body').on('click', '#other_contact_city_english2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*  if (radioValue1 == 'A_company') {
              companyContactValidation();
          } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();*/

    });
    $('body').on('click', '#other_contact_province_area2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();*/

    });
    $('body').on('click', '#other_contact_address_chinese2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();*/

    });
    $('body').on('click', '#other_contact_city_chinese2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();*/

    });
    $('body').on('click', '#other_contact_zipCode2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();
        otherContactCityChinese2Validation();*/

    });
    $('body').on('click', '#other_contact_mobile2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /*  if (radioValue1 == 'A_company') {
              companyContactValidation();
          } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();
        otherContactCityChinese2Validation();
        otherContactZipCode2Validation();*/

    });
    $('body').on('click', '#other_contact_directPhone2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
             companyContactValidation();
         } else */
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();
        otherContactCityChinese2Validation();
        otherContactZipCode2Validation();*/
        otherContactMobile2Validation();

    });
    $('body').on('click', '#other_contact_directEmail2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        /* if (radioValue1 == 'A_company') {
     companyContactValidation();
 } else*/
        if (radioValue1 == 'An_individual') {
            var journalist = $("input[name='b_view_2']:checked").val();
            if (journalist == 'journalist') {
                journalistContactValidation();
            } else {
                individualContactValidation();
            }
        } else if (radioValue1 == 'NPO_Journalist_500_RMB') {
            //NPOContactvalidation();
        } else if (radioValue1 == 'An_investment_zone') {
            investmentContactValidation();
        }
        otherContactValidation1();
        /*otherContactTitle2Validation();
        otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();
        otherContactCityChinese2Validation();
        otherContactZipCode2Validation();*/
        otherContactMobile2Validation();
        otherContactDirectPhone2Validation();
    });








    function otherContactValidation2(event) {
        /*otherContactTitle2Validation();
         otherContactDob2Validation();
        otherContactFamilyName2Validation();
        otherContactGivenName2Validation();
        otherContactChineseName2Validation();
        otherContactNationality2Validation();
        otherContactNationality2Validation();
        otherContactAddressEnglish2Validation();
        otherContactCityEnglish2Validation();
        otherContactProvinceArea2Validation();
        otherContactAddressChinese2Validation();
        otherContactCityChinese2Validation();
        otherContactZipCode2Validation();*/
        otherContactMobile2Validation();
        otherContactDirectPhone2Validation();
        otherContactDirectEmail2Validation();
    }

    function otherContactTitle1Validation(event) {
        var other_contact_title1 = $("input[name='other_contact_title1']:checked").val();
        if (other_contact_title1 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_title1").focus();
            $("#other_contact_title1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_title1").removeClass("error_cl");
        }
    }

    /*    function otherContactDob1Validation(event) {
            var other_contact_dob1 = $('#other_contact_dob1').val();
            if (other_contact_dob1 == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#other_contact_dob1").focus();
                $("#other_contact_dob1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_dob1").removeClass("error_cl");
            }
        }*/

    function otherContactFamilyName1Validation(event) {
        var other_contact_familyName1 = $('#other_contact_familyName1').val();
        if (other_contact_familyName1 == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#other_contact_familyName1").focus();
            $("#other_contact_familyName1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_familyName1").removeClass("error_cl");
        }
    }

    function otherContactGivenName1Validation(event) {
        var other_contact_givenName1 = $('#other_contact_givenName1').val();
        if (other_contact_givenName1 == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#other_contact_givenName1").focus();
            $("#other_contact_givenName1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_givenName1").removeClass("error_cl");
        }
    }

    function otherContactChineseName1Validation(event) {
        var other_contact_chineseName1 = $('#other_contact_chineseName1').val();
        if (other_contact_chineseName1 == '') {
            //alert("Please Enter Chinese Name");\
            alert("Wrong format, please correct");
            $("#other_contact_chineseName1").focus();
            $("#other_contact_chineseName1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_chineseName1").removeClass("error_cl");
        }
    }

    function otherContactNationality1Validation(event) {
        var other_contact_nationality1 = $("input[name='other_contact_nationality1']:checked").val();
        if (other_contact_nationality1 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_nationality1").focus();
            $("#other_contact_nationality1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_nationality1").removeClass("error_cl");
        }
    }

    function otherContactAddressEnglish1Validation(event) {
        var other_contact_address_english1 = $('#other_contact_address_english1').val();
        if (other_contact_address_english1 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_address_english1").focus();
            $("#other_contact_address_english1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_english1").removeClass("error_cl");
        }
    }

    function otherContactCityEnglish1Validation(event) {
        var other_contact_city_english1 = $('#other_contact_city_english1').val();
        if (other_contact_city_english1 == '') {
            //alert("Please Enter Other Contact City English");
            alert("Wrong format, please correct");
            $("#other_contact_city_english1").focus();
            $("#other_contact_city_english1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_english1").removeClass("error_cl");
        }
    }

    function otherContactProvinceArea1Validation(event) {
        var other_contact_province_area1 = $('#other_contact_province_area1').val();
        if (other_contact_province_area1 == '') {
            //alert("Please Select Other Contact Province/Area");
            alert("Wrong format, please correct");
            $("#other_contact_province_area1").focus();
            $("#other_contact_province_area1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_province_area1").removeClass("error_cl");
        }
    }

    function otherContactAddressChinese1Validation(event) {
        var other_contact_address_chinese1 = $('#other_contact_address_chinese1').val();
        if (other_contact_address_chinese1 == '') {
            //alert("Please Enter Other Contact Address Chinese.");
            alert("Wrong format, please correct");
            $("#other_contact_address_chinese1").focus();
            $("#other_contact_address_chinese1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_chinese1").removeClass("error_cl");
        }
    }

    function otherContactCityChinese1Validation(event) {
        var other_contact_city_chinese1 = $('#other_contact_city_chinese1').val();
        if (other_contact_city_chinese1 == '') {
            //alert("Please Enter Other Contact City Chinese");
            alert("Wrong format, please correct");
            $("#other_contact_city_chinese1").focus();
            $("#other_contact_city_chinese1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_chinese1").removeClass("error_cl");
        }
    }

    /*function otherContactZipCode1Validation(event) {
        var other_contact_zipCode1 = $('#other_contact_zipCode1').val();
        if (other_contact_zipCode1 == '') {
            //alert("Please Enter Other Contact ZipCode.");
            alert("Wrong format, please correct");
            $("#other_contact_zipCode1").focus();
            $("#other_contact_zipCode1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_zipCode1").removeClass("error_cl");
        }
    }*/

    function otherContactMobile1Validation(event) {
        var other_contact_mobile1 = $('#other_contact_mobile1').val();
        var lenght1 = $('#other_contact_mobile1').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_mobile1 != '') {
            if ((!phonePattern.test(other_contact_mobile1)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile");
                alert("Wrong format, please correct");
                $("#other_contact_mobile1").focus();
                $("#other_contact_mobile1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_mobile1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_mobile1").removeClass("error_cl");
        }

    }

    function otherContactDirectPhone1Validation(event) {
        var other_contact_directPhone1 = $('#other_contact_directPhone1').val();
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_directPhone1 != '') {
            if (!phonePattern.test(other_contact_directPhone1)) {
                // alert("Please Enter Direct Phone");
                alert("Wrong format, please correct");
                $("#other_contact_directPhone1").focus();
                $("#other_contact_directPhone1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directPhone1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directPhone1").removeClass("error_cl");
        }
    }

    function otherContactDirectEmail1Validation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var other_contact_directEmail1 = $('#other_contact_directEmail1').val();
        if (other_contact_directEmail1 != '') {
            if (!emailPattern.test(other_contact_directEmail1)) {
                //alert("Please Enter direct Email");
                alert("Wrong format, please correct");
                $("#other_contact_directEmail1").focus();
                $("#other_contact_directEmail1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directEmail1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directEmail1").removeClass("error_cl");
        }
    }



    function otherContactTitle2Validation(event) {
        var other_contact_title2 = $("input[name='other_contact_title2']:checked").val();
        if (other_contact_title2 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_title2").focus();
            $("#other_contact_title2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_title2").removeClass("error_cl");
        }
    }

    /*    function otherContactDob2Validation(event) {
            var other_contact_dob2 = $('#other_contact_dob2').val();
            if (other_contact_dob2 == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#other_contact_dob2").focus();
                $("#other_contact_dob2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_dob2").removeClass("error_cl");
            }
        }*/

    function otherContactFamilyName2Validation(event) {
        var other_contact_familyName2 = $('#other_contact_familyName1').val();
        if (other_contact_familyName2 == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#other_contact_familyName2").focus();
            $("#other_contact_familyName2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_familyName2").removeClass("error_cl");
        }
    }

    function otherContactGivenName2Validation(event) {
        var other_contact_givenName2 = $('#other_contact_givenName1').val();
        if (other_contact_givenName2 == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#other_contact_givenName2").focus();
            $("#other_contact_givenName2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_givenName2").removeClass("error_cl");
        }
    }

    function otherContactChineseName2Validation(event) {
        var other_contact_chineseName2 = $('#other_contact_chineseName2').val();
        if (other_contact_chineseName2 == '') {
            //alert("Please Enter Chinese Name");
            alert("Wrong format, please correct");
            $("#other_contact_chineseName2").focus();
            $("#other_contact_chineseName2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_chineseName2").removeClass("error_cl");
        }
    }

    function otherContactNationality2Validation(event) {
        var other_contact_nationality2 = $("input[name='other_contact_nationality2']:checked").val();
        if (other_contact_nationality2 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_nationality2").focus();
            $("#other_contact_nationality2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_nationality2").removeClass("error_cl");
        }
    }

    function otherContactAddressEnglish2Validation(event) {
        var other_contact_address_english2 = $('#other_contact_address_english2').val();
        if (other_contact_address_english2 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_address_english2").focus();
            $("#other_contact_address_english2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_english2").removeClass("error_cl");
        }
    }

    function otherContactCityEnglish2Validation(event) {
        var other_contact_city_english2 = $('#other_contact_city_english2').val();
        if (other_contact_city_english2 == '') {
            //alert("Please Enter Other Contact City English");
            alert("Wrong format, please correct");
            $("#other_contact_city_english2").focus();
            $("#other_contact_city_english2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_english2").removeClass("error_cl");
        }
    }

    function otherContactProvinceArea2Validation(event) {
        var other_contact_province_area2 = $('#other_contact_province_area2').val();
        if (other_contact_province_area2 == '') {
            //alert("Please Select Other Contact Province/Area");
            alert("Wrong format, please correct");
            $("#other_contact_province_area2").focus();
            $("#other_contact_province_area2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_province_area2").removeClass("error_cl");
        }
    }

    function otherContactAddressChinese2Validation(event) {
        var other_contact_address_chinese2 = $('#other_contact_address_chinese2').val();
        if (other_contact_address_chinese2 == '') {
            //alert("Please Enter Other Contact Address Chinese.");
            alert("Wrong format, please correct");
            $("#other_contact_address_chinese2").focus();
            $("#other_contact_address_chinese2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_chinese2").removeClass("error_cl");
        }
    }

    function otherContactCityChinese2Validation(event) {
        var other_contact_city_chinese2 = $('#other_contact_city_chinese2').val();
        if (other_contact_city_chinese2 == '') {
            //alert("Please Enter Other Contact City Chinese");
            alert("Wrong format, please correct");
            $("#other_contact_city_chinese2").focus();
            $("#other_contact_city_chinese2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_chinese2").removeClass("error_cl");
        }
    }

    function otherContactZipCode2Validation(event) {
        var other_contact_zipCode2 = $('#other_contact_zipCode2').val();
        if (other_contact_zipCode2 == '') {
            //alert("Please Enter Other Contact ZipCode.");
            alert("Wrong format, please correct");
            $("#other_contact_zipCode2").focus();
            $("#other_contact_zipCode2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_zipCode2").removeClass("error_cl");
        }
    }

    function otherContactMobile2Validation(event) {
        var other_contact_mobile2 = $('#other_contact_mobile2').val();
        var lenght1 = $('#other_contact_mobile2').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_mobile2 != '') {
            if ((!phonePattern.test(other_contact_mobile2)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile");
                alert("Wrong format, please correct");
                $("#other_contact_mobile2").focus();
                $("#other_contact_mobile2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_mobile2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_mobile2").removeClass("error_cl");
        }
    }

    function otherContactDirectPhone2Validation(event) {
        var other_contact_directPhone2 = $('#other_contact_directPhone2').val();
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_directPhone2 != '') {
            if (!phonePattern.test(other_contact_directPhone2)) {
                //alert("Please Enter Direct Phone");
                alert("Wrong format, please correct");
                $("#other_contact_directPhone2").focus();
                $("#other_contact_directPhone2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directPhone2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directPhone2").removeClass("error_cl");
        }
    }

    function otherContactDirectEmail2Validation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var other_contact_directEmail2 = $('#other_contact_directEmail2').val();
        if (other_contact_directEmail2 != '') {
            if (!emailPattern.test(other_contact_directEmail2)) {
                alert("Wrong format, please correct");
                $("#other_contact_directEmail2").focus();
                $("#other_contact_directEmail2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directEmail2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directEmail2").removeClass("error_cl");
        }
    }





    /*new company other contact validation */
    $('body').on('click', '.other_contact_titlec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();



    });


    $('body').on('click', '#other_contact_dobc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();*/

    });
    $('body').on('click', '#other_contact_familyNamec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitle1Validation();
        otherContactDobc1Validation();*/

    });
    $('body').on('click', '#other_contact_givenNamec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();*/

    });
    $('body').on('click', '#other_contact_chineseNamec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();
         otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();*/


    });
    $('body').on('click', '.other_contact_nationalityc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
*/
    });
    $('body').on('click', '#other_contact_positionc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();*/

    });
    $('body').on('click', '#other_contact_address_englishc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();*/

    });
    $('body').on('click', '#other_contact_city_englishc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();

        /*otherContactTitlec1Validation();
         otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();*/

    });
    $('body').on('click', '#other_contact_province_areac1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();*/

    });
    $('body').on('click', '#other_contact_address_chinesec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
         otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();*/

    });
    $('body').on('click', '#other_contact_city_chinesec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();*/

    });
    $('body').on('click', '#other_contact_zipCodec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();
        otherContactCityChinesec1Validation();*/

    });
    $('body').on('click', '#other_contact_mobilec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();
        otherContactCityChinesec1Validation();
        otherContactZipCodec1Validation();*/

    });
    $('body').on('click', '#other_contact_directPhonec1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();
        otherContactCityChinesec1Validation();
        otherContactZipCodec1Validation();*/
        otherContactMobilec1Validation();

    });
    $('body').on('click', '#other_contact_directEmailc1', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();

        /*otherContactTitlec1Validation();
         otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();
        otherContactCityChinesec1Validation();
        otherContactZipCodec1Validation();*/
        otherContactMobilec1Validation();
        otherContactDirectPhonec1Validation();
    });

    function otherContactValidationc1(event) {
        /*otherContactTitlec1Validation();
        otherContactDobc1Validation();
        otherContactFamilyNamec1Validation();
        otherContactGivenNamec1Validation();
        otherContactChineseNamec1Validation();
        otherContactNationalityc1Validation();
        otherContactPositionc1Validation();
        otherContactAddressEnglishc1Validation();
        otherContactCityEnglishc1Validation();
        otherContactProvinceAreac1Validation();
        otherContactAddressChinesec1Validation();
        otherContactCityChinesec1Validation();
        otherContactZipCodec1Validation();*/
        otherContactMobilec1Validation();
        otherContactDirectPhonec1Validation();
        otherContactDirectEmailc1Validation();
    }

    function otherContactTitlec1Validation(event) {
        var other_contact_titlec1 = $("input[name='other_contact_titlec1']:checked").val();
        if (other_contact_titlec1 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_titlec1").focus();
            $("#other_contact_titlec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_titlec1").removeClass("error_cl");
        }
    }

    /*    function otherContactDobc1Validation(event) {
            var other_contact_dobc1 = $('#other_contact_dobc1').val();
            if (other_contact_dobc1 == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#other_contact_dobc1").focus();
                $("#other_contact_dobc1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_dobc1").removeClass("error_cl");
            }
        }*/

    function otherContactFamilyNamec1Validation(event) {
        var other_contact_familyNamec1 = $('#other_contact_familyNamec1').val();
        if (other_contact_familyNamec1 == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#other_contact_familyNamec1").focus();
            $("#other_contact_familyNamec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_familyNamec1").removeClass("error_cl");
        }
    }

    function otherContactGivenNamec1Validation(event) {
        var other_contact_givenNamec1 = $('#other_contact_givenNamec1').val();
        if (other_contact_givenNamec1 == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#other_contact_givenNamec1").focus();
            $("#other_contact_givenNamec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_givenNamec1").removeClass("error_cl");
        }
    }

    function otherContactChineseNamec1Validation(event) {
        var other_contact_chineseNamec1 = $('#other_contact_chineseNamec1').val();
        if (other_contact_chineseNamec1 == '') {
            //alert("Please Enter Chinese Name");
            alert("Wrong format, please correct");
            $("#other_contact_chineseNamec1").focus();
            $("#other_contact_chineseNamec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_chineseNamec1").removeClass("error_cl");
        }
    }

    function otherContactNationalityc1Validation(event) {
        var other_contact_nationalityc1 = $("input[name='other_contact_nationalityc1']:checked").val();
        if (other_contact_nationalityc1 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_nationalityc1").focus();
            $("#other_contact_nationalityc1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_nationalityc1").removeClass("error_cl");
        }
    }

    function otherContactPositionc1Validation(event) {
        var other_contact_positionc1 = $('#other_contact_positionc1').val();
        if (other_contact_positionc1 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_positionc1").focus();
            $("#other_contact_positionc1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_positionc1").removeClass("error_cl");
        }
    }

    function otherContactAddressEnglishc1Validation(event) {
        var other_contact_address_englishc1 = $('#other_contact_address_englishc1').val();
        if (other_contact_address_englishc1 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_address_englishc1").focus();
            $("#other_contact_address_englishc1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_englishc1").removeClass("error_cl");
        }
    }

    function otherContactCityEnglishc1Validation(event) {
        var other_contact_city_englishc1 = $('#other_contact_city_englishc1').val();
        if (other_contact_city_englishc1 == '') {
            //alert("Please Enter Other Contact City English");
            alert("Wrong format, please correct");
            $("#other_contact_city_englishc1").focus();
            $("#other_contact_city_englishc1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_englishc1").removeClass("error_cl");
        }
    }

    function otherContactProvinceAreac1Validation(event) {
        var other_contact_province_areac1 = $('#other_contact_province_areac1').val();
        if (other_contact_province_areac1 == '') {
            //alert("Please Select Other Contact Province/Area");
            alert("Wrong format, please correct");
            $("#other_contact_province_areac1").focus();
            $("#other_contact_province_areac1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_province_areac1").removeClass("error_cl");
        }
    }

    function otherContactAddressChinesec1Validation(event) {
        var other_contact_address_chinesec1 = $('#other_contact_address_chinesec1').val();
        if (other_contact_address_chinesec1 == '') {
            //alert("Please Enter Other Contact Address Chinese.");
            alert("Wrong format, please correct");
            $("#other_contact_address_chinesec1").focus();
            $("#other_contact_address_chinesec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_chinesec1").removeClass("error_cl");
        }
    }

    function otherContactCityChinesec1Validation(event) {
        var other_contact_city_chinesec1 = $('#other_contact_city_chinesec1').val();
        if (other_contact_city_chinesec1 == '') {
            //alert("Please Enter Other Contact City Chinese");
            alert("Wrong format, please correct");
            $("#other_contact_city_chinesec1").focus();
            $("#other_contact_city_chinesec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_chinesec1").removeClass("error_cl");
        }
    }

    function otherContactZipCodec1Validation(event) {
        var other_contact_zipCodec1 = $('#other_contact_zipCodec1').val();
        if (other_contact_zipCodec1 == '') {
            //alert("Please Enter Other Contact ZipCode.");
            alert("Wrong format, please correct");
            $("#other_contact_zipCodec1").focus();
            $("#other_contact_zipCodec1").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_zipCodec1").removeClass("error_cl");
        }
    }

    function otherContactMobilec1Validation(event) {
        var other_contact_mobilec1 = $('#other_contact_mobilec1').val();
        var lenght1 = $('#other_contact_mobilec1').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_mobilec1 != '') {
            if ((!phonePattern.test(other_contact_mobilec1)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile");
                alert("Wrong format, please correct");
                $("#other_contact_mobilec1").focus();
                $("#other_contact_mobilec1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_mobilec1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_mobilec1").removeClass("error_cl");
        }
    }

    function otherContactDirectPhonec1Validation(event) {
        var other_contact_directPhonec1 = $('#other_contact_directPhonec1').val();
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_directPhonec1 != '') {
            if (!phonePattern.test(other_contact_directPhonec1)) {
                //alert("Please Enter Direct Phone");
                alert("Wrong format, please correct");
                $("#other_contact_directPhonec1").focus();
                $("#other_contact_directPhonec1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directPhonec1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directPhonec1").removeClass("error_cl");
        }
    }

    function otherContactDirectEmailc1Validation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var other_contact_directEmailc1 = $('#other_contact_directEmailc1').val();
        if (other_contact_directEmailc1 != '') {
            if (!emailPattern.test(other_contact_directEmailc1)) {
                alert("Wrong format, please correct");
                $("#other_contact_directEmailc1").focus();
                $("#other_contact_directEmailc1").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directEmailc1").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directEmailc1").removeClass("error_cl");
        }
    }




    /*second contact validation for company*/

    $('body').on('click', '.other_contact_titlec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();



    });


    $('body').on('click', '#other_contact_dobc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();*/

    });
    $('body').on('click', '#other_contact_familyNamec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();*/
        /*otherContactDobc2Validation();*/

    });
    $('body').on('click', '#other_contact_givenNamec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /* otherContactTitlec2Validation();
         otherContactDobc2Validation();
         otherContactFamilyNamec2Validation();*/

    });
    $('body').on('click', '#other_contact_chineseNamec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
         otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();*/


    });
    $('body').on('click', '.other_contact_nationalityc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();*/

    });
    $('body').on('click', '#other_contact_positionc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
         otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();*/

    });
    $('body').on('click', '#other_contact_address_englishc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
*/
    });
    $('body').on('click', '#other_contact_city_englishc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }


        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();*/

    });
    $('body').on('click', '#other_contact_province_areac2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
         otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();*/

    });
    $('body').on('click', '#other_contact_address_chinesec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();*/

    });
    $('body').on('click', '#other_contact_city_chinesec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();*/

    });
    $('body').on('click', '#other_contact_zipCodec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();
        otherContactCityChinesec2Validation();*/

    });
    $('body').on('click', '#other_contact_mobilec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
         otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();
        otherContactCityChinesec2Validation();
        otherContactZipCodec2Validation();*/

    });
    $('body').on('click', '#other_contact_directPhonec2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();
        otherContactCityChinesec2Validation();
        otherContactZipCodec2Validation();*/
        otherContactMobilec2Validation();

    });
    $('body').on('click', '#other_contact_directEmailc2', function () {
        var addcnt = $('#addcnt').val().trim();
        var dropVal = $('#stateDrop').val();
        if (dropVal == 'Beijing') {
            var radioValue1 = $("input[name='b_view_1']:checked").val();
        } else if (dropVal == 'Shanghai') {
            var radioValue1 = $("input[name='s_view_1']:checked").val();
        } else if (dropVal == 'Guangzhou') {
            var radioValue1 = $("input[name='g_view_1']:checked").val();
        } else if (dropVal == 'HongKong') {
            var radioValue1 = $("input[name='h_view_1']:checked").val();
        } else if (dropVal == 'ChinaMainland') {
            var radioValue1 = $("input[name='c_view_1']:checked").val();
        }

        companyContactValidation();
        otherContactValidationc1();

        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();
        otherContactCityChinesec2Validation();
        otherContactZipCodec2Validation();*/
        otherContactMobilec2Validation();
        otherContactDirectPhonec2Validation();
    });

    function otherContactValidationc2(event) {
        /*otherContactTitlec2Validation();
        otherContactDobc2Validation();
        otherContactFamilyNamec2Validation();
        otherContactGivenNamec2Validation();
        otherContactChineseNamec2Validation();
        otherContactNationalityc2Validation();
        otherContactPositionc2Validation();
        otherContactAddressEnglishc2Validation();
        otherContactCityEnglishc2Validation();
        otherContactProvinceAreac2Validation();
        otherContactAddressChinesec2Validation();
        otherContactCityChinesec2Validation();
        otherContactZipCodec2Validation();*/
        otherContactMobilec2Validation();
        otherContactDirectPhonec2Validation();
        otherContactDirectEmailc2Validation();
    }

    function otherContactTitlec2Validation(event) {
        var other_contact_titlec2 = $("input[name='other_contact_titlec2']:checked").val();
        if (other_contact_titlec2 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_titlec2").focus();
            $("#other_contact_titlec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_titlec2").removeClass("error_cl");
        }
    }

    /*    function otherContactDobc2Validation(event) {
            var other_contact_dobc2 = $('#other_contact_dobc2').val();
            if (other_contact_dobc2 == '') {
                //alert("Please Enter Family Name");
                alert("Wrong format, please correct");
                $("#other_contact_dobc2").focus();
                $("#other_contact_dobc2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_dobc2").removeClass("error_cl");
            }
        }
    */
    function otherContactFamilyNamec2Validation(event) {
        var other_contact_familyNamec2 = $('#other_contact_familyNamec2').val();
        if (other_contact_familyNamec2 == '') {
            //alert("Please Enter Family Name");
            alert("Wrong format, please correct");
            $("#other_contact_familyNamec2").focus();
            $("#other_contact_familyNamec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_familyNamec2").removeClass("error_cl");
        }
    }

    function otherContactGivenNamec2Validation(event) {
        var other_contact_givenNamec2 = $('#other_contact_givenNamec2').val();
        if (other_contact_givenNamec2 == '') {
            //alert("Please Enter Given Name");
            alert("Wrong format, please correct");
            $("#other_contact_givenNamec2").focus();
            $("#other_contact_givenNamec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_givenNamec2").removeClass("error_cl");
        }
    }

    function otherContactChineseNamec2Validation(event) {
        var other_contact_chineseNamec2 = $('#other_contact_chineseNamec2').val();
        if (other_contact_chineseNamec2 == '') {
            //alert("Please Enter Chinese Name");
            alert("Wrong format, please correct");
            $("#other_contact_chineseNamec2").focus();
            $("#other_contact_chineseNamec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_chineseNamec2").removeClass("error_cl");
        }
    }

    function otherContactNationalityc2Validation(event) {
        var other_contact_nationalityc2 = $("input[name='other_contact_nationalityc2']:checked").val();
        if (other_contact_nationalityc2 == '') {
            //alert("Please Select Other Contact Title.");
            alert("Wrong format, please correct");
            $("#other_contact_nationalityc2").focus();
            $("#other_contact_nationalityc2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_nationalityc2").removeClass("error_cl");
        }
    }

    function otherContactPositionc2Validation(event) {
        var other_contact_positionc2 = $('#other_contact_positionc2').val();
        if (other_contact_positionc2 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_positionc2").focus();
            $("#other_contact_positionc2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_positionc2").removeClass("error_cl");
        }
    }

    function otherContactAddressEnglishc2Validation(event) {
        var other_contact_address_englishc2 = $('#other_contact_address_englishc2').val();
        if (other_contact_address_englishc2 == '') {
            //alert("Please Enter Other Contact Address English");
            alert("Wrong format, please correct");
            $("#other_contact_address_englishc2").focus();
            $("#other_contact_address_englishc2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_englishc2").removeClass("error_cl");
        }
    }

    function otherContactCityEnglishc2Validation(event) {
        var other_contact_city_englishc2 = $('#other_contact_city_englishc2').val();
        if (other_contact_city_englishc2 == '') {
            //alert("Please Enter Other Contact City English");
            alert("Wrong format, please correct");
            $("#other_contact_city_englishc2").focus();
            $("#other_contact_city_englishc2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_englishc2").removeClass("error_cl");
        }
    }

    function otherContactProvinceAreac2Validation(event) {
        var other_contact_province_areac2 = $('#other_contact_province_areac2').val();
        if (other_contact_province_areac2 == '') {
            //alert("Please Select Other Contact Province/Area");
            alert("Wrong format, please correct");
            $("#other_contact_province_areac2").focus();
            $("#other_contact_province_areac2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_province_areac2").removeClass("error_cl");
        }
    }

    function otherContactAddressChinesec2Validation(event) {
        var other_contact_address_chinesec2 = $('#other_contact_address_chinesec2').val();
        if (other_contact_address_chinesec2 == '') {
            //alert("Please Enter Other Contact Address Chinese.");
            alert("Wrong format, please correct");
            $("#other_contact_address_chinesec2").focus();
            $("#other_contact_address_chinesec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_address_chinesec2").removeClass("error_cl");
        }
    }

    function otherContactCityChinesec2Validation(event) {
        var other_contact_city_chinesec2 = $('#other_contact_city_chinesec2').val();
        if (other_contact_city_chinesec2 == '') {
            //alert("Please Enter Other Contact City Chinese");
            alert("Wrong format, please correct");
            $("#other_contact_city_chinesec2").focus();
            $("#other_contact_city_chinesec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_city_chinesec2").removeClass("error_cl");
        }
    }

    function otherContactZipCodec2Validation(event) {
        var other_contact_zipCodec2 = $('#other_contact_zipCodec2').val();
        if (other_contact_zipCodec2 == '') {
            //alert("Please Enter Other Contact ZipCode.");
            alert("Wrong format, please correct");
            $("#other_contact_zipCodec2").focus();
            $("#other_contact_zipCodec2").addClass("error_cl");
            event.preventDefault();
        } else {
            $("#other_contact_zipCodec2").removeClass("error_cl");
        }
    }

    function otherContactMobilec2Validation(event) {
        var other_contact_mobilec2 = $('#other_contact_mobilec2').val();
        var lenght1 = $('#other_contact_mobilec2').val().length;
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_mobilec2 != '') {
            if ((!phonePattern.test(other_contact_mobilec2)) || (lenght1 > 20)) {
                //alert("Please Enter Mobile");
                alert("Wrong format, please correct");
                $("#other_contact_mobilec2").focus();
                $("#other_contact_mobilec2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_mobilec2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_mobilec2").removeClass("error_cl");
        }
    }

    function otherContactDirectPhonec2Validation(event) {
        var other_contact_directPhonec2 = $('#other_contact_directPhonec2').val();
        var phonePattern = /^[+0-9 -]/g;
        if (other_contact_directPhonec2 != '') {
            if (!phonePattern.test(other_contact_directPhonec2)) {
                //alert("Please Enter Direct Phone");
                alert("Wrong format, please correct");
                $("#other_contact_directPhonec2").focus();
                $("#other_contact_directPhonec2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directPhonec2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directPhonec2").removeClass("error_cl");
        }
    }

    function otherContactDirectEmailc2Validation(event) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var other_contact_directEmailc2 = $('#other_contact_directEmailc2').val();
        if (other_contact_directEmailc2 != '') {
            if (!emailPattern.test(other_contact_directEmailc2)) {
                alert("Wrong format, please correct");
                $("#other_contact_directEmailc2").focus();
                $("#other_contact_directEmailc2").addClass("error_cl");
                event.preventDefault();
            } else {
                $("#other_contact_directEmailc2").removeClass("error_cl");
            }
        } else {
            $("#other_contact_directEmailc2").removeClass("error_cl");
        }
    }


})(jQuery);