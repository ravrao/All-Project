$('document').ready(function () {


    /* Company Basic Information Validation With Form Submit Start And End At Line No 247*/
    $('#basicInfoSave').click(function () {
        var basicFlag = 0;
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var business_scope = $("input[name='business_scope']:checked").val();
        if (business_scope == 'Other') {
            var other_business_scope = $('#other_business_scope').val();
            if (other_business_scope == '') {
                $("#other_business_scope").focus();
                $("#other_business_scope").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#other_business_scope").removeClass("error_cl");
            }
        } else {
            $("#other_business_scope").removeClass("error_cl");
        }
        var business_description_english = $('#business_description_english').val().trim();
        var regex = /\s+/gi;
        var word_count = business_description_english.trim().replace(regex, '').split('').length;
        if (business_description_english == '' || word_count > 151) {
            //alert("Please Enter Business Description With In 150 Words");
            $("#business_description_english").focus();
            $("#business_description_english").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#business_description_english").removeClass("error_cl");
        }
        var business_description_chinese = $('#business_description_chinese').val().trim();
        var business_length = $("#business_description_chinese").val().replace(/ /g, '').length;
        if (business_description_chinese == '' || business_length > 101) {
            //alert("Please Enter Business Description Chinese With In 100 Charecters");
            $("#business_description_chinese").focus();
            $("#business_description_chinese").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#business_description_chinese").removeClass("error_cl");
        }
        var company_name_english = $('#company_name_english').val();
        if (company_name_english == '') {
            //alert("Please Enter Company Name English");
            $("#company_name_english").focus();
            $("#company_name_english").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_name_english").removeClass("error_cl");
        }
        var company_name_chinese = $('#company_name_chinese').val();
        if (company_name_chinese == '') {
            //alert("Please Enter Company Name English");
            $("#company_name_chinese").focus();
            $("#company_name_chinese").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_name_chinese").removeClass("error_cl");
        }
        var company_address = $('#company_address').val().trim();
        if (company_address == '') {
            //alert("Please Enter Company Address English");
            $("#company_address").focus();
            $("#company_address").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_address").removeClass("error_cl");
        }
        var company_city = $('#company_city').val();
        if (company_city == '') {
            //alert("Please Enter Company City English");
            $("#company_city").focus();
            $("#company_city").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_city").removeClass("error_cl");
        }
        var province_area_english = $('#province_area_english').val();
        if (province_area_english == '') {
            //alert("Please Enter Province/Area in English");
            $("#province_area_english").focus();
            $("#province_area_english").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#province_area_english").removeClass("error_cl");
        }
        var china_office_address = $('#china_office_address').val().trim();
        if (china_office_address == '') {
            //alert("Please Enter Company China Office Address");
            $("#china_office_address").focus();
            $("#china_office_address").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#china_office_address").removeClass("error_cl");
        }
        var china_office_city = $('#china_office_city').val();
        if (china_office_city == '') {
            //alert("Please Enter China Office City");
            $("#china_office_city").focus();
            $("#china_office_city").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#china_office_city").removeClass("error_cl");
        }
        var company_zipCode = $('#company_zipCode').val();
        if (company_zipCode == '') {
            //alert("Please Enter Company ZipCode");
            $("#company_zipCode").focus();
            $("#company_zipCode").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_zipCode").removeClass("error_cl");
        }
        var company_generalPhone = $('#company_generalPhone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(company_generalPhone)) || (company_generalPhone == '')) {
            //alert("Please Enter Company General Phone");
            $("#company_generalPhone").focus();
            $("#company_generalPhone").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_generalPhone").removeClass("error_cl");
        }
        var company_email = $('#company_email').val();
        if ((!emailPattern.test(company_email)) || (company_email == '')) {
            //alert("Please Enter General Email");
            $("#company_email").focus();
            $("#company_email").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_email").removeClass("error_cl");
        }
        var company_website = $('#company_website').val();
        var res = company_website.match(/^(http(s)?:\/\/.)(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        var res1 = company_website.match(/^(www\.)[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        if ((company_website == '') || (res == null && res1 == null)) {
            //alert("Please Enter Correct Company Website");
            $("#company_website").focus();
            $("#company_website").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#company_website").removeClass("error_cl");
        }
        var legal_entity = $('#legal_entity').val();
        if (legal_entity == '') {
            //alert("Please Select Legal Entity");
            $("#legal_entity").focus();
            $("#legal_entity").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#legal_entity").removeClass("error_cl");
        }
        var no_of_employees = $('#no_of_employees').val();
        if ((no_of_employees == '') || (isNaN(no_of_employees))) {
            //alert("Please Enter No Of Employees");
            $("#no_of_employees").focus();
            $("#no_of_employees").addClass("error_cl");
            basicFlag = 1;
            return false;
        } else {
            $("#no_of_employees").removeClass("error_cl");
        }
        /* For All*/
        var forAllOther = $('#forAllOther').is(":visible");
        if (forAllOther != false) {


            var is_company_swiss_registered = $("input[name='is_company_swiss_registered']:checked").val();
            if (is_company_swiss_registered == '') {
                //alert("Please Select One");
                $("#is_company_swiss_registered").focus();
                $("#is_company_swiss_registered").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#is_company_swiss_registered").removeClass("error_cl");
            }

            var is_company_registered_PRC = $("input[name='is_company_registered_PRC']:checked").val();
            if (is_company_registered_PRC == '') {
                //alert("Please Select One");
                $("#is_company_registered_PRC").focus();
                $("#is_company_registered_PRC").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#is_company_registered_PRC").removeClass("error_cl");
            }
        }
        /*For Hong Kong*/
        var forOnlyHongKong = $('#forOnlyHongKong').is(":visible");
        if (forOnlyHongKong != false) {

            var establishment_hongkong = $('#establishment_hongkong').val();
            if (establishment_hongkong == '') {
                //alert("Please Enter Year of Establishment in Hong Kong");
                $("#establishment_hongkong").focus();
                $("#establishment_hongkong").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#establishment_hongkong").removeClass("error_cl");
            }

            var geographical_responsibility_hongkong = $('#geographical_responsibility_hongkong').val();
            if (geographical_responsibility_hongkong == '') {
                //alert("Please Enter Geographical Responsibility of your company in Hong Kong");
                $("#geographical_responsibility_hongkong").focus();
                $("#geographical_responsibility_hongkong").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#geographical_responsibility_hongkong").removeClass("error_cl");
            }
        }

        var pre_logo = $('#pre_logo').is(":visible");
        if (pre_logo != false) {
            var fstexampleFileUploadx = $('#fstexampleFileUploadx').val();
            if (fstexampleFileUploadx == '') {
                //alert("Please Upload Picture");
                $("#fstexampleFileUploadx").focus();
                $("#fstexampleFileUploadx").addClass("error_cl");
                basicFlag = 1;
                return false;
            } else {
                $("#fstexampleFileUploadx").removeClass("error_cl");
            }
        }

        if (basicFlag == 0) {
            $('#companyBasicInfoForm').submit();
        }

    });
    /* Company Basic Information Validation With Form Submit End*/

    /* Company Headquarter Information Validation With Form Submit Start and End At Line No-304 */
    $('#headquarterInfoSave').click(function () {
        var headFlag = 0;
        var headquarter_name = $('#headquarter_name').val();
        if (headquarter_name == '') {
            $("#headquarter_name").focus();
            $("#headquarter_name").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_name").removeClass("error_cl");
        }
        var headquarter_address = $('#headquarter_address').val();
        if (headquarter_address == '') {
            $("#headquarter_address").focus();
            $("#headquarter_address").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_address").removeClass("error_cl");
        }
        var headquarter_city = $('#headquarter_city').val();
        if (headquarter_city == '') {
            $("#headquarter_city").focus();
            $("#headquarter_city").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_city").removeClass("error_cl");
        }
        var headquarter_zipCode = $('#headquarter_zipCode').val();
        if ((headquarter_zipCode == '') || (isNaN(headquarter_zipCode))) {
            $("#headquarter_zipCode").focus();
            $("#headquarter_zipCode").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_zipCode").removeClass("error_cl");
        }
        var headquarter_phone = $('#headquarter_phone').val();
        var phonePattern = /^[+0-9 -]/g;
        if ((!phonePattern.test(headquarter_phone)) || (headquarter_phone == '')) {
            $("#headquarter_phone").focus();
            $("#headquarter_phone").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_phone").removeClass("error_cl");
        }
        var headquarter_province_area_english = $('#headquarter_province_area_english').val();
        if (headquarter_province_area_english == '') {
            $("#headquarter_province_area_english").focus();
            $("#headquarter_province_area_english").addClass("error_cl");
            headFlag = 1;
            return false;
        } else {
            $("#headquarter_province_area_english").removeClass("error_cl");
        }

        if (headFlag == 0) {
            $('#headquarterInfoForm').submit();
        }

    });
    /* Company Headquarter Information Validation With Form Submit End*/

    /* Other Contact Information validation And From Submit Start And End At Line No- 379*/
    $('#otherContactSave').click(function () {
        var otherFlag = 0;
        var i = 1;
        var addcnt = $('#addcnt').val();
        var compsnyORnot = $('#compsnyORnot').val();
        if (compsnyORnot == 0) {
            for (i = 1; i <= addcnt; i++) {

                var other_contact_dob = $('#other_contact_dob' + i).val();

                if (other_contact_dob == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_dob' + i).focus();
                    $('#other_contact_dob' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_dob' + i).removeClass("error_cl");
                }
                var other_contact_familyName = $('#other_contact_familyName' + i).val();
                if (other_contact_familyName == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_familyName' + i).focus();
                    $('#other_contact_familyName' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_familyName' + i).removeClass("error_cl");
                }
                var other_contact_givenName = $('#other_contact_givenName' + i).val();
                if (other_contact_givenName == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_givenName' + i).focus();
                    $('#other_contact_givenName' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_givenName' + i).removeClass("error_cl");
                }
                var other_contact_chineseName = $('#other_contact_chineseName' + i).val();
                if (other_contact_chineseName == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_chineseName' + i).focus();
                    $('#other_contact_chineseName' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_chineseName' + i).removeClass("error_cl");
                }
                /*var other_contact_nationality = $("input[name='other_contact_nationality']:checked").val();
                if (other_contact_nationality == '') {
                    //alert("Please Select nationality");
                    $('#other_contact_nationality').focus();
                    $('#other_contact_nationality').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_nationality').removeClass("error_cl");
                }*/
                var other_contact_address_english = $('#other_contact_address_english' + i).val();
                if (other_contact_address_english == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_english' + i).focus();
                    $('#other_contact_address_english' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_english' + i).removeClass("error_cl");
                }
                var other_contact_city_english = $('#other_contact_city_english' + i).val();
                if (other_contact_city_english == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_english' + i).focus();
                    $('#other_contact_city_english' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_english' + i).removeClass("error_cl");
                }
                var other_contact_province_area = $('#other_contact_province_area' + i).val();
                if (other_contact_province_area == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_province_area' + i).focus();
                    $('#other_contact_province_area' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_province_area' + i).removeClass("error_cl");
                }
                var other_contact_address_chinese = $('#other_contact_address_chinese' + i).val();
                if (other_contact_address_chinese == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_chinese' + i).focus();
                    $('#other_contact_address_chinese' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_chinese' + i).removeClass("error_cl");
                }
                var other_contact_city_chinese = $('#other_contact_city_chinese' + i).val();
                if (other_contact_city_chinese == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_chinese' + i).focus();
                    $('#other_contact_city_chinese' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_chinese' + i).removeClass("error_cl");
                }
                var other_contact_zipCode = $('#other_contact_zipCode' + i).val();
                if (other_contact_zipCode == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_zipCode' + i).focus();
                    $('#other_contact_zipCode' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_zipCode' + i).removeClass("error_cl");
                }
                var other_contact_mobile = $('#other_contact_mobile' + i).val();
                var lenght1 = $('#other_contact_mobile' + i).val().length;
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_mobile)) || (other_contact_mobile == '') || (lenght1 > 20)) {
                    //alert("Please Select Business Description");
                    $('#other_contact_mobile' + i).focus();
                    $('#other_contact_mobile' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_mobile' + i).removeClass("error_cl");
                }
                var other_contact_directPhone = $('#other_contact_directPhone' + i).val();
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_directPhone)) || (other_contact_directPhone == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directPhone' + i).focus();
                    $('#other_contact_directPhone' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directPhone' + i).removeClass("error_cl");
                }
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                var other_contact_directEmail = $('#other_contact_directEmail' + i).val();
                if ((!emailPattern.test(other_contact_directEmail)) || (other_contact_directEmail == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directEmail' + i).focus();
                    $('#other_contact_directEmail' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directEmail' + i).removeClass("error_cl");
                }

            }
        } else if (compsnyORnot == 1) {
            for (i = 1; i <= addcnt; i++) {

                var other_contact_dobc = $('#other_contact_dobc' + i).val();

                if (other_contact_dobc == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_dobc' + i).focus();
                    $('#other_contact_dobc' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_dobc' + i).removeClass("error_cl");
                }
                var other_contact_familyNamec = $('#other_contact_familyNamec' + i).val();
                if (other_contact_familyNamec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_familyNamec' + i).focus();
                    $('#other_contact_familyNamec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_familyNamec' + i).removeClass("error_cl");
                }
                var other_contact_givenNamec = $('#other_contact_givenNamec' + i).val();
                if (other_contact_givenNamec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_givenNamec' + i).focus();
                    $('#other_contact_givenNamec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_givenNamec' + i).removeClass("error_cl");
                }
                var other_contact_chineseNamec = $('#other_contact_chineseNamec' + i).val();
                if (other_contact_chineseNamec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_chineseNamec' + i).focus();
                    $('#other_contact_chineseNamec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_chineseNamec' + i).removeClass("error_cl");
                }
                var other_contact_positionc = $('#other_contact_positionc' + i).val();
                if (other_contact_positionc == '') {
                    //alert("Please Select nationality");
                    $('#other_contact_positionc' + i).focus();
                    $('#other_contact_positionc' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_positionc' + i).removeClass("error_cl");
                }
                var other_contact_address_englishc = $('#other_contact_address_englishc' + i).val();
                if (other_contact_address_englishc == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_englishc' + i).focus();
                    $('#other_contact_address_englishc' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_englishc' + i).removeClass("error_cl");
                }
                var other_contact_city_englishc = $('#other_contact_city_englishc' + i).val();
                if (other_contact_city_englishc == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_englishc' + i).focus();
                    $('#other_contact_city_englishc' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_englishc' + i).removeClass("error_cl");
                }
                var other_contact_province_areac = $('#other_contact_province_areac' + i).val();
                if (other_contact_province_areac == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_province_areac' + i).focus();
                    $('#other_contact_province_areac' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_province_areac' + i).removeClass("error_cl");
                }
                var other_contact_address_chinesec = $('#other_contact_address_chinesec' + i).val();
                if (other_contact_address_chinesec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_chinesec' + i).focus();
                    $('#other_contact_address_chinesec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_chinesec' + i).removeClass("error_cl");
                }
                var other_contact_city_chinesec = $('#other_contact_city_chinesec' + i).val();
                if (other_contact_city_chinesec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_chinesec' + i).focus();
                    $('#other_contact_city_chinesec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_chinesec' + i).removeClass("error_cl");
                }
                var other_contact_zipCodec = $('#other_contact_zipCodec' + i).val();
                if (other_contact_zipCodec == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_zipCodec' + i).focus();
                    $('#other_contact_zipCodec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_zipCodec' + i).removeClass("error_cl");
                }
                var other_contact_mobilec = $('#other_contact_mobilec' + i).val();
                var lenght1 = $('#other_contact_mobilec' + i).val().length;
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_mobilec)) || (other_contact_mobilec == '') || (lenght1 > 20)) {
                    //alert("Please Select Business Description");
                    $('#other_contact_mobilec' + i).focus();
                    $('#other_contact_mobilec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_mobilec' + i).removeClass("error_cl");
                }
                var other_contact_directPhonec = $('#other_contact_directPhonec' + i).val();
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_directPhonec)) || (other_contact_directPhonec == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directPhonec' + i).focus();
                    $('#other_contact_directPhonec' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directPhonec' + i).removeClass("error_cl");
                }
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                var other_contact_directEmailc = $('#other_contact_directEmailc' + i).val();
                if ((!emailPattern.test(other_contact_directEmailc)) || (other_contact_directEmailc == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directEmailc' + i).focus();
                    $('#other_contact_directEmailc' + i).addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directEmailc' + i).removeClass("error_cl");
                }

            }

        }
        if (otherFlag == 0) {
            $('#contactotherInfoForm').submit();
        }

    });
    /* Other Contact Information Validation With Form Submit End*/


/* Company Directory validation And From Submit Start And End At Line No- 379*/

    $('#memberDirectorySave').click(function () {
        //alert('hi');
        var otherFlag = 0;
        var i = 1;
        var addcnt = $('#addcnt').val();
        var compsnyORnot = $('#compsnyORnot').val();
        var other_contact_dob_dir = $('#other_contact_dob_dir').val();
           
                if (other_contact_dob_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_dob_dir').focus();
                    $('#other_contact_dob_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_dob_dir').removeClass("error_cl");
                }
                var other_contact_familyName_dir = $('#other_contact_familyName_dir').val();
                if (other_contact_familyName_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_familyName_dir').focus();
                    $('#other_contact_familyName_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_familyName_dir').removeClass("error_cl");
                }
                var other_contact_givenName_dir = $('#other_contact_givenName_dir').val();
                if (other_contact_givenName_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_givenName_dir').focus();
                    $('#other_contact_givenName_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_givenName_dir').removeClass("error_cl");
                }
               /* var other_contact_chineseName_dir = $('#other_contact_chineseName_dir').val();
                if (other_contact_chineseName_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_chineseName_dir').focus();
                    $('#other_contact_chineseName_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_chineseName_dir').removeClass("error_cl");
                }
                
                var other_contact_position_dir = $('#other_contact_position_dir').val();
                if (other_contact_position_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_position_dir').focus();
                    $('#other_contact_position_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_position_dir').removeClass("error_cl");
                }
                
                var other_contact_address_english_dir = $('#other_contact_address_english_dir').val();
                if (other_contact_address_english_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_english_dir').focus();
                    $('#other_contact_address_english_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_english_dir').removeClass("error_cl");
                }
                var other_contact_city_english_dir = $('#other_contact_city_english_dir').val();
                if (other_contact_city_english_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_english_dir').focus();
                    $('#other_contact_city_english_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_english_dir').removeClass("error_cl");
                }
                var other_contact_province_area_dir = $('#other_contact_province_area_dir').val();
                if (other_contact_province_area_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_province_area_dir').focus();
                    $('#other_contact_province_area_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_province_area_dir').removeClass("error_cl");
                }
                var other_contact_address_chinese_dir = $('#other_contact_address_chinese_dir').val();
                if (other_contact_address_chinese_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_address_chinese_dir').focus();
                    $('#other_contact_address_chinese_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_address_chinese_dir').removeClass("error_cl");
                }
                var other_contact_city_chinese_dir = $('#other_contact_city_chinese_dir').val();
                if (other_contact_city_chinese_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_city_chinese_dir').focus();
                    $('#other_contact_city_chinese_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_city_chinese_dir').removeClass("error_cl");
                }
                var other_contact_zipCode_dir = $('#other_contact_zipCode_dir').val();
                if (other_contact_zipCode_dir == '') {
                    //alert("Please Select Business Description");
                    $('#other_contact_zipCode_dir').focus();
                    $('#other_contact_zipCode_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_zipCode_dir').removeClass("error_cl");
                }*/
                var other_contact_mobile_dir = $('#other_contact_mobile_dir').val();
                var lenght1 = $('#other_contact_mobile_dir').val().length;
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_mobile_dir)) || (other_contact_mobile_dir == '') || (lenght1 > 20)) {
                    //alert("Please Select Business Description");
                    $('#other_contact_mobile_dir').focus();
                    $('#other_contact_mobile_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_mobile_dir').removeClass("error_cl");
                }
                var other_contact_directPhone_dir = $('#other_contact_directPhone_dir').val();
                var phonePattern = /^[+0-9 -]/g;
                if ((!phonePattern.test(other_contact_directPhone_dir)) || (other_contact_directPhone_dir == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directPhone_dir').focus();
                    $('#other_contact_directPhone_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directPhone_dir').removeClass("error_cl");
                }
                var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                var other_contact_directEmail_dir = $('#other_contact_directEmail_dir').val();
                if ((!emailPattern.test(other_contact_directEmail_dir)) || (other_contact_directEmail_dir == '')) {
                    //alert("Please Select Business Description");
                    $('#other_contact_directEmail_dir').focus();
                    $('#other_contact_directEmail_dir').addClass("error_cl");
                    otherFlag = 1;
                    return false;
                } else {
                    $('#other_contact_directEmail_dir').removeClass("error_cl");
                }

          
        
        if (otherFlag == 0) {
            $('#memberdirectoryForm').submit();
        }

    });
    
    
    /* Company Directory Validation With Form Submit End*/



    $('#otherCompanyContactSave').click(function () {
        var otherFlag = 0;
        var CompanyAddcnt = $('#CompanyAddcnt').val();
        //alert(CompanyAddcnt);
        var i = CompanyAddcnt;
        
       if(CompanyAddcnt!=0)
       {
        //for (i = CompanyAddcnt; i <= CompanyAddcnt; i++) {
            var other_company_name_english = $('#other_company_name_english' + i).val();
            if (other_company_name_english == '') {
               
                //alert("Please Select Business Description");
                $('#other_company_name_english' + i).focus();
                $('#other_company_name_english' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                
                $('#other_company_name_english' + i).removeClass("error_cl");
            }
            var other_company_name_chinese = $('#other_company_name_chinese' + i).val();
            if (other_company_name_chinese == '') {
                //alert("Please Select Business Description");
                $('#other_company_name_chinese' + i).focus();
                $('#other_company_name_chinese' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_name_chinese' + i).removeClass("error_cl");
            }
            var other_company_address = $('#other_company_address' + i).val();
            if (other_company_address == '') {
                //alert("Please Select Business Description");
                $('#other_company_address' + i).focus();
                $('#other_company_address' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_address' + i).removeClass("error_cl");
            }
            var other_company_city = $('#other_company_city' + i).val();
            if (other_company_city == '') {
                //alert("Please Select Business Description");
                $('#other_company_city' + i).focus();
                $('#other_company_city' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_city' + i).removeClass("error_cl");
            }
            var other_province_area_english = $('#other_province_area_english' + i).val();
            if (other_province_area_english == '') {
                //alert("Please Select Business Description");
                $('#other_province_area_english' + i).focus();
                $('#other_province_area_english' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_province_area_english' + i).removeClass("error_cl");
            }
            var other_china_office_address = $('#other_china_office_address' + i).val();
            if (other_china_office_address == '') {
                //alert("Please Select Business Description");
                $('#other_china_office_address' + i).focus();
                $('#other_china_office_address' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_china_office_address' + i).removeClass("error_cl");
            }
            var other_china_office_city = $('#other_china_office_city' + i).val();
            if (other_china_office_city == '') {
                //alert("Please Select Business Description");
                $('#other_china_office_city' + i).focus();
                $('#other_china_office_city' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_china_office_city' + i).removeClass("error_cl");
            }
            var other_company_zipCode = $('#other_company_zipCode' + i).val();
            if ((other_company_zipCode == '') || (isNaN(other_company_zipCode))) {
                //alert("Please Select Business Description");
                $('#other_company_zipCode' + i).focus();
                $('#other_company_zipCode' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_zipCode' + i).removeClass("error_cl");
            }
            var other_company_generalPhone = $('#other_company_generalPhone' + i).val();
            var phonePattern = /^[+0-9 -]/g;
            if ((!phonePattern.test(other_company_generalPhone)) || (other_company_generalPhone == '')) {
                //alert("Please Select Business Description");
                $('#other_company_generalPhone' + i).focus();
                $('#other_company_generalPhone' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_generalPhone' + i).removeClass("error_cl");
            }

            var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
            var other_company_email = $('#other_company_email' + i).val();
            if ((!emailPattern.test(other_company_email)) || (other_company_email == '')) {
                //alert("Please Select Business Description");
                $('#other_company_email' + i).focus();
                $('#other_company_email' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_email' + i).removeClass("error_cl");
            }
            var other_company_website = $('#other_company_email' + i).val();
            if (other_company_website == '') {
                $('#other_company_website' + i).focus();
                $('#other_company_website' + i).addClass("error_cl");
                otherFlag = 1;
                return false;
            } else {
                $('#other_company_website' + i).removeClass("error_cl");
            }

       // }
    }
        if (otherFlag == 0) {
          
            $('#companyContactOtherInfoForm').submit();
        }

    });





    /* Account Information validation And From Submit Start And End At Line No- 501 */
    $('#accountInfoSave').click(function () {
        var accountFlag = 0;
        var isDisabled = $('#admin_generated_password').prop('disabled');
        var admin_generated_userId = $('#admin_generated_userId').val();
        if (admin_generated_userId == '') {
            //alert("Please Select Business Description");
            $('#admin_generated_userId').focus();
            $('#admin_generated_userId').addClass("error_cl");
            accountFlag = 1;
            return false;
        } else {
            $('#admin_generated_userId').removeClass("error_cl");
        }
        var chkUserName = $('#chkUserName').val();
        if (chkUserName != 0) {
            //alert("Please Select Business Description");
            $('#admin_generated_userId').focus();
            $('#admin_generated_userId').addClass("error_cl");
            accountFlag = 1;
            return false;
        } else {
            $('#admin_generated_userId').removeClass("error_cl");
        }
        var isDisabled = $("#admin_generated_password").is(':disabled');
        if (isDisabled == false) {
            var admin_generated_password = $('#admin_generated_password').val();
            if (admin_generated_password == '') {
                //alert("Please Select Business Description");
                $('#admin_generated_password').focus();
                $('#admin_generated_password').addClass("error_cl");
                accountFlag = 1;
                return false;
            } else {
                $('#admin_generated_password').removeClass("error_cl");
            }
            var confirm_admin_generated_password = $('#confirm_admin_generated_password').val();
            if (confirm_admin_generated_password == '') {
                //alert("Please Select Business Description");
                $('#confirm_admin_generated_password').focus();
                $('#confirm_admin_generated_password').addClass("error_cl");
                accountFlag = 1;
                return false;
            } else {
                $('#confirm_admin_generated_password').removeClass("error_cl");
            }
            if (confirm_admin_generated_password != admin_generated_password) {
                //alert("Please Select Business Description");
                $('#confirm_admin_generated_password').focus();
                $('#confirm_admin_generated_password').addClass("error_cl");
                accountFlag = 1;
                return false;
            } else {
                $('#confirm_admin_generated_password').removeClass("error_cl");
            }
        }
        if (accountFlag == 0) {
            $('#accountInfoForm').submit();
        }
    });

    /* Account Information Validation With Form Submit End*/
    /* Personal Information validation And From Submit Start And End At Line No-  */
    $('#personalInfoSave').click(function () {

        var personalFlag = 0;
        var year_of_birth = $('#year_of_birth').val();
        if (year_of_birth == '') {
            //alert("Please Select Business Description");
            $('#year_of_birth').focus();
            $('#year_of_birth').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#year_of_birth').removeClass("error_cl");
        }

        var family_name = $('#family_name').val();
        if (family_name == '') {
            //alert("Please Select Business Description");
            $('#family_name').focus();
            $('#family_name').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#family_name').removeClass("error_cl");
        }

        var given_name = $('#given_name').val();
        if (given_name == '') {
            //alert("Please Select Business Description");
            $('#given_name').focus();
            $('#given_name').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#given_name').removeClass("error_cl");
        }
        /*var chinese_name = $('#chinese_name').val();
        if (chinese_name == '') {
            //alert("Please Select Business Description");
            $('#chinese_name').focus();
            $('#chinese_name').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#chinese_name').removeClass("error_cl");
        }*/
        var nationality = $("input[name='nationality']:checked").val();
        if (nationality == '') {
            alert("Please Select nationality");
            $('#indiv_nationality_swiss').focus();
            $('#indiv_nationality_swiss').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#indiv_nationality_swiss').removeClass("error_cl");
        }
        /*var address_english = $('#address_english').val().trim();
        //alert(address_english);
        if (address_english == '') {
            alert("Please Select Business Description");
            $('#address_english').focus();
            $('#address_english').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#address_english').removeClass("error_cl");
        }
        //alert();
        var city_english = $('#city_english').val();
        if (city_english == '') {
            //alert("Please Select Business Description");
            $('#city_english').focus();
            $('#city_english').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#city_english').removeClass("error_cl");
        }
        var province_area = $('#province_area').val();
        if (province_area == '') {
            //alert("Please Select Business Description");
            $('#province_area').focus();
            $('#province_area').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#province_area').removeClass("error_cl");
        }
        var address_chinese = $('#address_chinese').val();
        if (address_chinese == '') {
            //alert("Please Select Business Description");
            $('#address_chinese').focus();
            $('#address_chinese').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#address_chinese').removeClass("error_cl");
        }
        var city_chinese = $('#city_chinese').val();
        if (city_chinese == '') {
            //alert("Please Select Business Description");
            $('#city_chinese').focus();
            $('#city_chinese').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#city_chinese').removeClass("error_cl");
        }
        var zip_code_english = $('#zip_code_english').val();
        if (zip_code_english == '') {
            //alert("Please Select Business Description");
            $('#zip_code_english').focus();
            $('#zip_code_english').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#zip_code_english').removeClass("error_cl");
        }*/
        var frcm = $('#frcm').is(":visible");
        if (frcm != false) {
            var positionIn_company = $('#positionIn_company').val();
            //alert();
            if (positionIn_company == '') {
                //alert("Please Select Business Description");
                $('#positionIn_company').focus();
                $('#positionIn_company').addClass("error_cl");
                personalFlag = 1;
                return false;
            } else {
                $('#positionIn_company').removeClass("error_cl");
            }
        }
        /* var exampleFileUpload = $('#exampleFileUpload').val();
        if (exampleFileUpload == '') {
        	//alert("Please Select Business Description");
        	$('#exampleFileUpload').focus();
        	$('#exampleFileUpload').addClass("error_cl");
        	personalFlag = 1;
        	return false;
        } else {
        	$('#exampleFileUpload').removeClass("error_cl");
        } */
        var direct_phone = $('#direct_phone').val();
        if (direct_phone == '') {
            //alert("Please Select Business Description");
            $('#direct_phone').focus();
            $('#direct_phone').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#direct_phone').removeClass("error_cl");
        }
        var mobile_phone = $('#mobile_phone').val();
        var lenght1 = $('#mobile_phone').val().length;
        if ((mobile_phone == '') || (lenght1 > 20)) {
            //alert("Please Select Business Description");
            $('#mobile_phone').focus();
            $('#mobile_phone').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#mobile_phone').removeClass("error_cl");
        }
        /* var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		var direct_email = $('#direct_email').val();
        if ((!emailPattern.test(direct_email)) || (direct_email == '')) {
            //alert("Please Enter General Email");
            $("#direct_email").focus();
            $("#direct_email").addClass("error_cl");
			personalFlag = 1;
            return false;
        } else {
            $("#direct_email").removeClass("error_cl");
        } */
        var forNpo = $('#forNpo').is(":visible");
        if (forNpo != false) {
            var npo_organization_type = $('#npo_organization_type').val();
            if (npo_organization_type == '') {
                //alert("Please Select Business Description");
                $('#npo_organization_type').focus();
                $('#npo_organization_type').addClass("error_cl");
                personalFlag = 1;
                return false;
            } else {
                $('#npo_organization_type').removeClass("error_cl");
            }
            var npo_organization_description = $('#npo_organization_description').val();
            if (npo_organization_description == '') {
                //alert("Please Select Business Description");
                $('#npo_organization_description').focus();
                $('#npo_organization_description').addClass("error_cl");
                personalFlag = 1;
                return false;
            } else {
                $('#npo_organization_description').removeClass("error_cl");
            }

        }
        var forJrnl = $('#forJrnl').is(":visible");
        if (forJrnl != false) {
            var media_type = $('#media_type').val();
            if (media_type == '') {
                //alert("Please Select Business Description");
                $('#media_type').focus();
                $('#media_type').addClass("error_cl");
                personalFlag = 1;
                return false;
            } else {
                $('#media_type').removeClass("error_cl");
            }
            var media_description = $('#media_description').val();
            if (media_description == '') {
                //alert("Please Select Business Description");
                $('#media_description').focus();
                $('#media_description').addClass("error_cl");
                personalFlag = 1;
                return false;
            } else {
                $('#media_description').removeClass("error_cl");
            }

        }
        if (personalFlag == 0) {
            $('#personalInfoForm').submit();
        }



    });
    /* Personal Information validation And From Submit End */
    /* User Name checking start*/
    $('#admin_generated_userId').keyup(function (e) {
        if (e.which === 32) {
            alert('No space are allowed in username');
            var str = $(this).val();
            str = str.replace(/\s/g, '');
            $(this).val(str);

        }
        $('#err_username').html('');
    });

    $('#admin_generated_userId').blur(function () {
        var str = $(this).val();
        str = str.replace(/\s/g, '');
        $(this).val(str);
        //alert('No space are allowed in usernames');
        var str = $(this).val();
        var str1 = str.length;
        var userId = $('#userId').val();
        if (str1 >= 6) {
            $('#admin_generated_userId').removeClass("error_cl");
            $.ajax({
                type: "POST",
                url: "usernameChk.php",
                data: {
                    admin_generated_userId: str,
                    userId: userId
                },
                async: false,
                success: function (res) {
                    if (res == 1) {
                        alert('Username is already used!');
                        $('#chkUserName').val(1);
                    } else if (res == 0) {
                        $('#chkUserName').val(0);
                    }
                }
            });

        } else {
            //alert('Minimum 6 Charecters');
            $('#admin_generated_userId').focus();
            $('#admin_generated_userId').addClass("error_cl");
            $('#chkUserName').val(1);
        }
    });
    /* User Name checking end*/

    /* For Company Logo Remove Start */
    $('#removelogo').click(function () {
        $('#pre_logo').hide();
        var company_id = $('#company_id').val();
        $.ajax({
            type: "POST",
            url: "ajax_logo.php",
            data: {
                company_id: company_id
            },
            success: function (response) {
                $('#uplogo').show();
            }
        });
    });
    /* for Company Logo Remove End */
    /* Business Scope enable disable start */
    $('body').on('change', '#business_scope', function () {
        var business_scope = $(this).val();
        if (business_scope == 'Other') {
            $('#otherDiv').show();
        } else {
            $('#otherDiv').hide();
        }
    });
    /* Business Scope enable disable End */
    /* Password Change enable disable start */
    $('body').on('click', '#changePassword', function () {
        $('#changePassword').hide();
        $('#cancelPassword').show();
        $('#admin_generated_password').removeAttr("disabled");
        $('#confirm_admin_generated_password').removeAttr("disabled");
    });
    $('body').on('click', '#cancelPassword', function () {
        $('#cancelPassword').hide();
        $('#changePassword').show();
        $('#admin_generated_password').attr("disabled", "disabled");
        $('#confirm_admin_generated_password').attr("disabled", "disabled");
    });
    /* Password Change enable disable End */
    
    
/******************************* Edit Event Registration Start  */

$('#editEventSave').click(function () {
    
    var personalFlag = 0;
        var event_title = $('#event_title').val();
        if (event_title == '') {
           
            $('#event_title').focus();
            $('#event_title').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#event_title').removeClass("error_cl");
        }

        var first_name_event = $('#first_name_event').val();
        if (first_name_event == '') {
            
            $('#first_name_event').focus();
            $('#first_name_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#first_name_event').removeClass("error_cl");
        }

        var surname_event = $('#surname_event').val();
        if (surname_event == '') {
           
            $('#surname_event').focus();
            $('#surname_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#surname_event').removeClass("error_cl");
        }
       
        var emaileventPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		var email_event = $('#email_event').val();
        if ((!emaileventPattern.test(email_event)) || (email_event == '')) {
            //alert("Please Enter General Email");
            $("#email_event").focus();
            $("#email_event").addClass("error_cl");
			personalFlag = 1;
            return false;
        } else {
            $("#direct_email").removeClass("error_cl");
        } 
        
        
        var company_name_event = $('#company_name_event').val();
      
        if (company_name_event == '') {
           
            $('#company_name_event').focus();
            $('#company_name_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#company_name_event').removeClass("error_cl");
        }
       
       var job_tile_event = $('#job_tile_event').val();
      
        if (job_tile_event == '') {
           
            $('#job_tile_event').focus();
            $('#job_tile_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#job_tile_event').removeClass("error_cl");
        }
        
        var address_event = $('#address_event').val();
      
        if (address_event == '') {
           
            $('#address_event').focus();
            $('#address_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#address_event').removeClass("error_cl");
        }
       
       var phone_event = $('#phone_event').val();
      
        if (phone_event == '') {
           
            $('#phone_event').focus();
            $('#phone_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#phone_event').removeClass("error_cl");
        }
        
        var year_birth_event = $('#year_birth_event').val();
      
        if (year_birth_event == '') {
           
            $('#year_birth_event').focus();
            $('#year_birth_event').addClass("error_cl");
            personalFlag = 1;
            return false;
        } else {
            $('#year_birth_event').removeClass("error_cl");
        }
       
       
        if (personalFlag == 0) {
            $('#editeventfrom').submit();
        }


        


    });
    
   
/****************************** Edit Event Registration End */
    
    
});
/* Company Logo Preview Start*/
function showImage(input, id) {
    var file = input.files[0];
    var filesize = file.size / 1024;
    if (filesize < 2000) {
        $('#error_msg').html('');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#preview_label_id').html('<label>Preview :</label>');
                $('#preview').show();
                $('#preview').attr('src', e.target.result).height(100);
            };
            reader.readAsDataURL(input.files[0]);
        }
    } else {
        $('#error_msg').html('File size must be less than 2Mb');
    }
}
/* Company Logo Preview End*/
/* Profile Picture Preview Start*/
function showImage1(input, id) {
    var file = input.files[0];
    var filesize = file.size / 1024;
    if (filesize < 2000) {
        $('#error_msg').html('');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#preview_label_id1').html('<label>Preview :</label>');
                $('#preview1').show();
                $('#preview1').attr('src', e.target.result).height(100);
                //	$('#preview1').attr('src', e.target.result).width(100);
            };
            reader.readAsDataURL(input.files[0]);
        }
    } else {
        $('#error_msg').html('File size must be less than 2Mb');
    }
}
/* Profile Picture Preview End*/

function showImage2(input, id) {
    var file_name = $('#exampleFileUpload1').val();
    var file = input.files[0];
    var file_name1 = file.name;
    var filesize = file.size / 1024;
    if (filesize < 2000) {
        $('#error_msg').html('');
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#expert_corner_process_file').html(file_name1);
                //$('#preview1').show();
                //$('#preview1').attr('src', e.target.result).height(100);
                //	$('#preview1').attr('src', e.target.result).width(100);
            };
            reader.readAsDataURL(input.files[0]);
        }
    } else {
        $('#error_msg').html('File size must be less than 2Mb');
    }
}

