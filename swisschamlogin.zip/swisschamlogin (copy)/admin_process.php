<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');

$userId = $_SESSION["userId"];
$type = $_REQUEST['type'];

switch($type){
	case 'account_info':
		
		$admin_generated_userId = isset($_REQUEST['admin_generated_userId'])?$_REQUEST['admin_generated_userId']:"";
		$direct_email = isset($_REQUEST['direct_email'])?$_REQUEST['direct_email']:"";
		$admin_generated_password = isset($_REQUEST['admin_generated_password'])?$_REQUEST['admin_generated_password']:"";
		$language = isset($_REQUEST['language'])?$_REQUEST['language']:"";
		$assignables_role = isset($_REQUEST['assignables_role'])?$_REQUEST['assignables_role']:"";
		
		$assignables_roles = implode(",", $assignables_role); 
		
	   $sql = "UPDATE `sc_c_userdetails`
                 SET `admin_generated_userId`='".$admin_generated_userId."',
                     `direct_email`='".$direct_email."',
                     `admin_generated_password`='".$admin_generated_password."',
                     `language`='".$language."',
                     `assignables_role`='".$assignables_roles."'
               WHERE `userId` = '".$userId."'";
			
			
		$res = mysql_query($sql);
		header('Location: admin.php');
		break;
		
	case 'personal_details':
	
		$user_title = isset($_REQUEST['user_title'])?addslashes($_REQUEST['user_title']):"";
		$year_of_birth = isset($_REQUEST['year_of_birth'])?addslashes($_REQUEST['year_of_birth']):"";
		$year_of_birth = date('Y-m-d',strtotime($year_of_birth));
		$family_name = isset($_REQUEST['family_name'])?addslashes($_REQUEST['family_name']):"";
		$given_name = isset($_REQUEST['given_name'])?addslashes($_REQUEST['given_name']):"";
		$chinese_name = isset($_REQUEST['chinese_name'])?addslashes($_REQUEST['chinese_name']):"";
		$nationality = isset($_REQUEST['nationality'])?addslashes($_REQUEST['nationality']):"";
		$address_english = isset($_REQUEST['address_english'])?addslashes($_REQUEST['address_english']):"";
		$city_english = isset($_REQUEST['city_english'])?addslashes($_REQUEST['city_english']):"";
		$province_area = isset($_REQUEST['province_area'])?addslashes($_REQUEST['province_area']):"";
		$address_chinese = isset($_REQUEST['address_chinese'])?addslashes($_REQUEST['address_chinese']):"";
		$city_chinese = isset($_REQUEST['city_chinese'])?addslashes($_REQUEST['city_chinese']):"";
		$zip_code_english = isset($_REQUEST['zip_code_english'])?addslashes($_REQUEST['zip_code_english']):"";
		$positionIn_company = isset($_REQUEST['positionIn_company'])?addslashes($_REQUEST['positionIn_company']):"";
		$direct_phone = isset($_REQUEST['direct_phone'])?addslashes($_REQUEST['direct_phone']):"";
		$mobile_phone = isset($_REQUEST['mobile_phone'])?addslashes($_REQUEST['mobile_phone']):"";
		$direct_email = isset($_REQUEST['direct_email'])?addslashes($_REQUEST['direct_email']):"";
		
		$sql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."',
		                     `direct_email`='".$direct_email."'
		               WHERE `userId` = '".$userId."'";
		
		
		$res = mysql_query($sql);
		
		$img = $_FILES['profile_picture'];
        $img_name = $img['name'];
		$img_size = $img['size'];				
		
        if($img_name != "") {        	
            $ext = end(explode('.', $img_name));
            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG");
			
			if(in_array($ext,$extArr) ){
				$new_img = "image_" . time() . "." . $ext;
            	@move_uploaded_file($img['tmp_name'], "uploads/" . $new_img);
				
				  $imgsql = "UPDATE `sc_c_userdetails`
				                SET `profile_picture`='".$new_img."'
				              WHERE `userId` = '".$userId."'";
				  $imgres = mysql_query($imgsql);
			}
		}
				
		/*$ind_del_Sql="DELETE FROM `sc_c_user_to_industry` WHERE `userId`='".$userId."'";
	    mysql_query($ind_del_Sql);
	    
	    
		if(isset($_POST['industry']) && !empty($_POST['industry'])){
			$industry = $_POST['industry'];
			foreach($industry as $key=>$val){
				$ind_insSql = "INSERT INTO `sc_c_user_to_industry` 
									 SET `userId`='".$userId."',
							             `industry_id`='".$val."'";
				mysql_query($ind_insSql);
			}
		}*/
		
		header('Location: admin.php');
		break;
		
		case 'newsletter':
		
		$newsletter = implode(",",isset($_REQUEST['newsletter'])?$_REQUEST['newsletter']:"");
		
		$sql = "UPDATE `sc_c_userdetails`
		                 SET `newsletter`='".$newsletter."'
		               WHERE `userId` = '".$userId."'";
					  
		$res = mysql_query($sql);
		header('Location: admin.php');
		break;
		
		case 'question':
		
			$question = isset($_REQUEST['question'])?$_REQUEST['question']:"";
			
			$sql = "UPDATE `sc_c_userdetails`
			                 SET `question`='".$question."'
			               WHERE `userId` = '".$userId."'";
						  
			$res = mysql_query($sql);
			header('Location: admin.php');
		break;
		
		
		case 'expert_corner_article':
		
			$corner_title = isset($_REQUEST['corner_title'])?$_REQUEST['corner_title']:"";
			$corner_body = isset($_REQUEST['corner_body'])?$_REQUEST['corner_body']:"";
			$text_format = isset($_REQUEST['text_format'])?$_REQUEST['text_format']:"";
			$tag_name = isset($_REQUEST['tag_name'])?$_REQUEST['tag_name']:"";
		
			$exp_cnt = mysql_query("SELECT * FROM `sc_c_expert_corner_article` WHERE `userId`='".$userId."'");
			$cont    = mysql_num_rows($exp_cnt); 
			
			if($cont > 0){
				$expertsql = "UPDATE `sc_c_expert_corner_article`
				                SET `corner_title`='".$corner_title."',
				                    `corner_body`='".$corner_body."',
				                    `text_format`='".$text_format."',
				                    `tag_name`='".$tag_name."'
				              WHERE `userId` = '".$userId."'";
				
				$res = mysql_query($expertsql);
				
				$expertfile = $_FILES['expert_file'];
		        $expertfile_name = $expertfile['name'];
				$expertfile_size = $expertfile['size'];				
				
		        if($expertfile_name != "") {
		        	
		            $ext = end(explode('.', $expertfile_name));
		            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG");
					
					if(in_array($ext,$extArr) ){
						$new_file = "expertfile_".time().".".$ext;
		            	@move_uploaded_file($expertfile['tmp_name'], "uploads/" . $new_file);
						
						  $expertfilesql = "UPDATE `sc_c_expert_corner_article`
								               SET `expert_file`='".$new_file."'
								             WHERE `userId` = '".$userId."'";
						  $expertfileres = mysql_query($expertfilesql);
					}
				}
				
			  }else{
			  	
				$expertsql = "INSERT INTO `sc_c_expert_corner_article`
					                SET `corner_title`='".$corner_title."',
					                    `corner_body`='".$corner_body."',
					                    `text_format`='".$text_format."',
					                    `tag_name`='".$tag_name."',
					                    `userId`='".$userId."'";
				
				$res = mysql_query($expertsql);
				
				$lastId = mysql_insert_id();
								
			    $expertfile = $_FILES['expert_file'];
				$expertfile_name = $expertfile['name'];
				$expertfile_size = $expertfile['size'];	
				
		        if($expertfile_name != "") {
		            $ext = end(explode('.', $expertfile_name));
		            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG","pdf","mp4","doc","docx","xls","xlsx");
					
					if(in_array($ext,$extArr) ){
						$new_file = "expertfile_".time().".".$ext;
		            	@move_uploaded_file($expertfile['tmp_name'], "uploads/" . $new_file);
						
						$expertfilesql = "UPDATE `sc_c_expert_corner_article`
						                     SET `expert_file`='".$new_file."'
						                   WHERE `expert_corner_article_id` = '".$lastId."'";
								             
						  $expertfileres = mysql_query($expertfilesql);
					}
				}
			}
			
			header('Location: admin.php');
		break;
		
		case 'activeUser':
			
			$ids = $_REQUEST['ids'];			
			$idArr = explode(",", $ids);
			
			foreach($idArr as $key=>$val){
				//$res = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$val."'"));
                            
                              $results = mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$val."' OR other_contect_userid='".$val."'");
                              
                           while($res = mysql_fetch_assoc($results)){
                                 
                                //$updQry = "Update `sc_c_userdetails` SET `is_active`='Y' WHERE userId = '".$val."'";
                                $updQry = "Update `sc_c_userdetails` SET `is_active`='Y' WHERE userId = '".$res['userId']."'";
				$emailId = $res['direct_email'];	
				$updQry = "Update `sc_c_userdetails` SET `is_active`='Y' WHERE userId = '".$val."'";
				
				
				$userId = $res['admin_generated_userId'];
				$Password = $res['admin_generated_password'];
				
				$to  = $emailId;
	            $subject = 'Account activation';
	
				 $message = '<!DOCTYPE HTML>
                                <html>

                                <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                    <title>Account Activation</title>
                                </head>

                                <style>
                                    @import url("https://fonts.googleapis.com/css?family=Roboto:400,500,700");
                                </style>

                                <body style="padding: 0;margin: 0;">

                                    <div style="width: 800px; margin: 0 auto; border-top: 2px solid #aa0008; border-bottom:2px solid #aa0008; border-left: 1px solid #eaeaea; border-right: 1px solid #eaeaea; overflow: hidden;">
                                       
                                        <div style="margin: 0 auto; text-align: center; width: 100%; padding: 30px 0;">
                                            <img src="'.$base_url.'/logo.png" alt="">
                                        </div>
                                       
                                        <div style="background: #aa0008; color: #fff; text-align: center; padding: 28px; font-size: 26px; text-transform: uppercase;">
                                            New User Registration 
                                        </div>
                                       
                                        <div style="background: url('.$base_url.'/grilled.png) repeat; float: left; width: 100%; padding: 30px 0; font-size: 18px; line-height: 32px; color: #605e5e; padding: 20px;">
                                            <p>
                                              Your user id and password mention below.   

                                        </div>
                                        <div style="float: left;width: 100%;padding: 50px 0;">
                                            <table cellpadding="0" cellspacing="10" style="width: 80%; margin: 0 auto;">
                                                <tr>
                                                    <td style="width: 30%; font-weight: 400; font-size: 20px;">
                                                        <p>User ID</p>
                                                    </td>
                                                    <td style="width: 30%">
                                                        <p>:</p>
                                                    </td>
                                                    <td style="width: 30% ; font-weight: 400;font-size: 20px;">
                                                        <p>'.$userId.'</p>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td style="width: 30%;  font-weight: 400; font-size: 20px;">
                                                        <p>Password </p>
                                                    </td>
                                                    <td style="width: 30%">
                                                        <p>:</p>
                                                    </td>
                                                    <td style="width: 30%; font-weight: 400; font-size: 20px;">
                                                        <p>'.$Password.'</p>
                                                    </td>
                                                </tr>


                                                <tr>
                                                    <td colspan="3" style="text-align: center; background-color: #aa0008; border: 0; color: #fff; font-size: 16px; padding: 16px 30px; margin: 15px auto; display:inline-block; text-decoration: none; width: auto;">                        
                                                        <a href="'.$base_url.'online_application.php">Click here to login</a>
                                                    </td>                    
                                                </tr>

                                            </table>
                                        </div>

                                    </div>

                                </body>


                                </html>';
                                 
                                 
                                 
                                 
                                 
				
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From: swischam.com';
				@mail($to, $subject, $message, $headers);
				
				
				$UpdRes = mysql_query($updQry);
			} 
                        }
			echo "ok";
			exit();		
		break;
                
case 'eventsucess':
			
        $ids = $_REQUEST['ids'];			
        $idArr = explode(",", $ids);

        foreach($idArr as $key=>$val){
                //$res = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$val."'"));
            
            
        
              $results = mysql_query("SELECT * FROM `sc_c_event_user` WHERE event_user_id='".$val."'");

           while($res = mysql_fetch_assoc($results)){

                
                $emailId = $res['email'];
                $fullname =  $res['first_name'] .' '. $res['sur_name'];
                $EventName = $res['event_title'];
                

                $to  = $emailId;
                
   
   
/***********      Event Mail Start From Here ************************/
   
$email_message="<p>Dear ".$fullname.",</p>";
$email_message.="<p><strong>Thanks For Event Registration. And Registration information below:</strong></p><br/>";
$email_message.="<p>Event: ".$EventName."</p><br/>";
$email_message.="<p>email: ".$emailId."</p><br/>";
$email_message.="<p>Gender: ".$res['gender']."</p><br/>";
$email_message.="<p>Company Name: ".$res['company_name']."</p><br/>";
$email_message.="<p>Job Title: ".$res['job_title']."</p><br/>";
$email_message.="<p>Address: ".$res['address']."</p><br/>";
$email_message.="<p>phone: ".$res['phone']."</p><br/>";
$email_message.="<p>year of birth: ".$res['year_of_birth']."</p><br/>";

$message='';
$email_from = 'swisscham.org'; // Who the email is from
$subject = "Event Registration Sucess";
$subject = $subject;
$email_subject =  $subject; // The Subject of the email
$email_txt = $message; // Message that the email has in it
$email_to =  $res['email'];
//$email_to = 'infoware.solutions1@gmail.com';

   $headers = "From: swisscham.org";
$msg_txt='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<div style="width:500px; border:1px solid #2D4261;">
        <div style="padding:5px;background:#fff;"></div>
        <div style="font-family:Arial, Helvetica, sans-serif;font-size:13px; color:#333; padding:10px; border-top:1px solid #2D4261;">
                '.$email_message.'</div>';        

                $msg_txt.='<p style="padding:0 10px;"><b>Thank you,<br>
                Swisschamp Team</b></p>
</div>

</body>
</html>';
$semi_rand = md5(time());
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
$headers .= "\nMIME-Version: 1.0\n" .
                "Content-Type: multipart/mixed;\n" .
                " boundary=\"{$mime_boundary}\"";
$email_txt .= $msg_txt;
$email_message .= "This is a multi-part message in MIME format.\n\n" .
                        "--{$mime_boundary}\n" .
                        "Content-Type:text/html; charset=\"iso-8859-1\"\n" .
                   "Content-Transfer-Encoding: 7bit\n\n" .
$email_txt . "\n\n";
$cont ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

        <div style="width:500px; border:1px solid #2D4261;">
                <div style="padding:5px;background:#fff;"></div>
                <div style="font-family:Arial, Helvetica, sans-serif;font-size:13px; color:#333; padding:10px; border-top:1px solid #2D4261;">
                        '.$email_message.'</div>';        

                        $cont.='
        </div>

</body>
</html>';
mail($email_to, $email_subject, $cont, $headers);
   
   
   
   
/**********      Event Mail End From Here **************************/


   $UpdRes = mysql_query($updQry);
} 
}
echo "ok";
exit();		
break;		
}

