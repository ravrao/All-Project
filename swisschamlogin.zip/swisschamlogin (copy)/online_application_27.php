<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swisscham | Online Application</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/jquery.steps.css">
    <link rel="stylesheet" href="css/membership_steps.css">
    <!-- Favicon -->
    <link rel="icon" href="favicon.png">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
    <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
	<style type="text/css">
        .error_cl{
            
            border: 1px solid;
            border-color: red !important;
        }
    </style>
</head>

<body>
    <div id="page">
	<?php 
    require_once(__ROOT__.'/includes/header.php'); 
    ?>
 
        <div class="abc"></div>
        <section class="inner_banner bg-beijing hide-for-small-only">
            <div class="inner_bredcrumb">
                <nav aria-label="You are here:" role="navigation">
                    <ul class="breadcrumbs page_bredcrunb">
                        <li><a href="index.html">Home</a></li>
                        <li>
                            <span class="show-for-sr">Current: </span> SwissCham Online Application
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section>
            <div class="row">
                <div class="large-9 medium-8 small-12 columns no_padding margin_top15">
                    <div class="large-12 columns dowedo_top">
                        <h1 class="common_heading">Online Membership Application</h1>
                    </div>
					<form name="onlineApplicationForm" id="onlineApplicationForm" action="online_application_process.php" method="POST" enctype="multipart/form-data">
                    <div class="large-12 columns dowedo_top margin_top10">
                        
                        <div id="wizard">
                            <h2>Membership type</h2>
                            <section class="firstSection">
							<h3 class="common_subheading">Find the right membership type by answering a few questions (max. 6)</h3>

                                <div class="large-12 columns application_question_container">
                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Choose your location</h3>
                                    <div class="medium-12 columns">
                                        <select id="stateDrop" name="company_chamber" id="company_chamber" class="stateDrop">
                                            <option value="">-Select-</option>
                                            <option value="Beijing" id="beijingDrop">Beijing</option>
                                            <option value="Shanghai" id="shangDrop">Shanghai</option>
                                            <option value="Guangzhou" id="guangDrop">Guangzhou</option>
                                            <option value="HongKong" id="hkDrop">Hong Kong</option>
                                            <option value="ChinaMainland" id="chDrop">China Mainland</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="beijing_drop_content all_drop_content">
                                    <div id="beQ1" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.aCompany').show(); $('#beQ2').show();$('.b_no_member').hide();" type="radio" name="b_view_1" value="A_company" id="a_comp" class="b_view_1">
                                                    <label for="a_comp" class="b_view_1">A company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.anIndividual').show(); $('#beQ2').show(); $('.b_no_member').hide();" type="radio" name="b_view_1" value="An_individual" id="an_indiv" class="b_view_1">
                                                    <label for="an_indiv" class="b_view_1">An individual</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('#beQ2').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.b_no_member').show();" type="radio" name="b_view_1" value="NPO_Journalist_500_RMB" id="npo" class="no_mem b_view_1">
                                                    <label for="npo" class="no_mem b_view_1">A NPO (organization without government affiliation)</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('#beQ2').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').show(); $('.b_no_member').hide();" type="radio" name="b_view_1" value="An_investment_zone" id="zone" class="b_view_1">
                                                    <label for="zone" class="b_view_1">An investment zone</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="beQ2" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li class="generalClass aCompany">
                                                    <input onclick="$('.b_ques3').hide(); $('#beQ4').hide(); $('#beQ3').show();" type="radio" name="b_view_2" value="Swiss_invested_company" id="sic" class="b_view_2">
                                                    <label for="sic" class="b_view_2">Swiss invested company</label>
                                                </li>
                                                <li class="generalClass aCompany">
                                                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_associate').show(); $('#beQ4').show();" type="radio" name="b_view_2" value="Non-Swiss_invested_company" id="nsic" class="b_view_2">
                                                    <label for="nsic" class="b_view_2">Non-Swiss invested company</label>
                                                </li>																						
                                                <li class="generalClass anIndividual">
                                                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_indiv').show(); $('#beQ4').show(); " type="radio" name="b_view_2" value="Individual_(above_35_y/o)" id="indv" class="b_view_2">
                                                    <label for="indv" class="b_view_2">Individual (above 35 y/o)</label>
                                                </li>
                                                <li class="generalClass anIndividual">
                                                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_yp').show(); $('#beQ4').show();" type="radio" name="b_view_2" value="Young_Professional_(under_35_y/o)" id="young" class="b_view_2">
                                                    <label for="young" class="b_view_2">Young Professional (under 35 y/o)</label>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>

                                    <div id="beQ3" class="large-12 columns application_question_container hide_steps b_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.be_gen_class').hide(); $('.be_mem_l_corp').show(); $('#beQ4').show();" type="radio" name="b_view_3" value="100_staff_or_more_in_Mainland_China" id="be_hun_staff" class="b_view_3">
                                                    <label for="be_hun_staff" class="b_view_3">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.be_gen_class').hide(); $('.be_mem_sm_corp').show(); $('#beQ4').show();" type="radio" name="b_view_3" value="1-99_staff_in_Mainland_China" id="be_nin_staff" class="b_view_3">
                                                    <label for="be_nin_staff" class="b_view_3">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="beQ4" class="large-12 columns application_question_container hide_steps b_ques4">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li class="be_gen_class be_mem_associate">
                                                    <input type="radio" name="b_view_4" value="Associate_Membership_(Beijing)_RMB_10'000_/_Year" id="member_associate" class="b_view_4">
                                                    <label for="member_associate" class="b_view_4">Associate Membership (Beijing) RMB 10'000 / Year</label>
                                                </li>
                                                <li class="be_gen_class be_mem_indiv">
                                                    <input type="radio" name="b_view_4" value="Individual_Membership_(Beijing)_RMB_2'400_/_Year" id="member_individual" class="b_view_4">
                                                    <label for="member_individual" class="b_view_4">Individual Membership (Beijing) RMB 2'400 / Year</label>
                                                </li>
                                                <li class="be_gen_class be_mem_yp">
                                                    <input type="radio" name="b_view_4" value="YP_Membership_(Beijing)_RMB_500_/_Year" id="yp_member" class="b_view_4">
                                                    <label for="yp_member" class="b_view_4">YP Membership (Beijing) RMB 500 / Year</label>
                                                </li>
                                                <li class="be_gen_class be_mem_l_corp">
                                                    <input type="radio" name="b_view_4" value="L_Corporate_Membership_(Beijing)_RMB_7'500_/_Year" id="l_corp" class="b_view_4">
                                                    <label for="l_corp" class="b_view_4">L Corporate Membership (Beijing) RMB 7'500 / Year</label>
                                                </li>
                                                <li class="be_gen_class be_mem_sm_corp">
                                                    <input type="radio" name="b_view_4" value="S/M_Corporate_Membership_(Beijing)_RMB_5'000_/_Year" id="sm_corp" class="b_view_4">
                                                    <label for="sm_corp" class="b_view_4">S/M Corporate Membership (Beijing) RMB 5'000 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="beQ5" class="large-12 columns application_question_container hide_steps b_ques5">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I Am / We Are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li class="investZone">
                                                    <input onclick="$('#beQ2').hide(); $('#beQ3').hide(); $('#beQ4').hide();" type="radio" name="b_view_5" value="Membership_fee_(Beijing)_RMB_10'000_/_Year" id="memfee" class="b_view_5">
                                                    <label for="memfee" class="b_view_5">Associate Membership (Beijing) RMB 10'000 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
									
									
                                </div>

								
								
								


                                <div class="shanghai_drop_content all_drop_content">

                                    <div id="shQ1" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('.shgeneralClass').hide(); $('#shQ4').hide(); $('#shQ3').hide(); $('#shQ3_sec').hide(); $('.sh_aCompany').show(); $('#shQ2').show();" type="radio" name="s_view_1" value="A_company" id="ques1" class="s_view_1">
                                                    <label for="ques1" class="s_view_1">A company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.shgeneralClass').hide(); $('#shQ4').hide(); $('#shQ3').hide(); $('#shQ3_sec').hide(); $('.sh_anIndividual').show(); $('#shQ2').show();" type="radio" name="s_view_1" value="An_individual" id="ques2" class="s_view_1">
                                                    <label for="ques2" class="s_view_1">An individual</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="shQ2" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li class="shgeneralClass sh_aCompany">
                                                    <input onclick="$('.sh_ques3').hide(); $('#shQ4').hide(); $('#shQ3').show();" type="radio" name="s_view_2" value="Swiss_invested_company" id="sic_sh" class="s_view_2">
                                                    <label for="sic_sh" class="s_view_2">Swiss invested company</label>
                                                </li>
                                                <li class="shgeneralClass sh_aCompany">
                                                    <input onclick="$('.sh_ques3').hide();$('#shQ4').hide(); $('#shQ3_sec').show(); " type="radio" name="s_view_2" value="Non-Swiss_invested_company" id="nsic_sh" class="s_view_2">
                                                    <label for="nsic_sh" class="s_view_2">Non-Swiss invested company</label>
                                                </li>
                                                <li class="shgeneralClass sh_anIndividual">
                                                    <input onclick="$('.shQ3').hide(); $('.shQ3_sec').hide(); $('.sh_gen_class').hide(); $('.sh_indv_mem').show(); $('#shQ4').show();" type="radio" name="s_view_2" value="Individual_(above_35_y/o)" id="indv_sh" class="s_view_2">
                                                    <label for="indv_sh" class="s_view_2">Individual (above 35 y/o)</label>
                                                </li>
                                                <li class="shgeneralClass sh_anIndividual">
                                                    <input onclick="$('.shQ3').hide(); $('.shQ3_sec').hide(); $('.sh_gen_class').hide(); $('.sh_yp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_2" value="Young_Professional_(under_35_y/o)" id="young_sh" class="s_view_2">
                                                    <label for="young_sh" class="s_view_2">Young Professional (under 35 y/o)</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="shQ3" class="large-12 columns application_question_container hide_steps sh_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.sh_gen_class').hide(); $('.sh_l_corp').show(); $('#shQ4').show();" type="radio" name="s_view_3" value="100_staff_or_more_in_Mainland_China" id="sh_hun_staff" class="s_view_3">
                                                    <label for="sh_hun_staff" class="s_view_3">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.sh_gen_class').hide(); $('.sh_sm_corp').show(); $('#shQ4').show();" type="radio" name="s_view_3" value="1-99_staff_in_Mainland_China" id="sh_nin_staff" class="s_view_3">
                                                    <label for="sh_nin_staff" class="s_view_3">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="shQ3_sec" class="large-12 columns application_question_container hide_steps sh_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.sh_gen_class').hide(); $('.sh_l_corp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_4" value="100_staff_or_more_in_Mainland_China" id="sh_hun_staff_sec" class="s_view_4">
                                                    <label for="sh_hun_staff_sec" class="s_view_4">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.sh_gen_class').hide(); $('.sh_sm_corp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_4" value="1-99_staff_in_Mainlan_China" id="sh_nin_staff_sec" class="s_view_4">
                                                    <label for="sh_nin_staff_sec" class="s_view_4">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="shQ4" class="large-12 columns application_question_container hide_steps sh_ques4">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li class="sh_gen_class sh_indv_mem">
                                                    <input type="radio" name="s_view_5" value="Individual_Membership_(Shanghai)_RMB_2'400_/_Year" id="sh_indiv_member" class="s_view_5">
                                                    <label for="sh_indiv_member" class="s_view_5">Individual Membership (Shanghai) RMB 2'400 / Year</label>
                                                </li>
                                                <li class="sh_gen_class sh_yp_mem">
                                                    <input type="radio" name="s_view_5" value="YP_Membership_(Shanghai)_RMB_600_/_Year" id="sh_yp_member" class="s_view_5">
                                                    <label for="sh_yp_member" class="s_view_5">YP Membership (Shanghai) RMB 600 / Year</label>
                                                </li>
                                                <li class="sh_gen_class sh_l_corp">
                                                    <input type="radio" name="s_view_5" value="L_Corporate_Membership_(Shanghai)_RMB_7'000_/_Year" id="sh_l_corp" class="s_view_5">
                                                    <label for="sh_l_corp" class="s_view_5">L Corporate Membership (Shanghai) RMB  7'000 / Year</label>
                                                </li>
                                                <li class="sh_gen_class sh_sm_corp">
                                                    <input type="radio" name="s_view_5" value="S/M_Corporate_Membership_(Shanghai)_RMB_4'000_/_Year" id="sh_sm_corp" class="s_view_5">
                                                    <label for="sh_sm_corp" class="s_view_5">S/M Corporate Membership (Shanghai) RMB  4'000 / Year</label>
                                                </li>
                                                <li class="sh_gen_class sh_l_corp_mem">
                                                    <input type="radio" name="s_view_5" value="L_Corporate_Associate_Membership_(Shanghai)_RMB_7'000_/_Year" id="sh_lcorp" class="s_view_5">
                                                    <label for="sh_lcorp" class="s_view_5">L Associate Membership (Shanghai) RMB  7'000 / Year</label>
                                                </li>
                                                <li class="sh_gen_class sh_sm_corp_mem">
                                                    <input type="radio" name="s_view_5" value="S/M_Corporate_Associate_Membership_(Shanghai)_RMB_4'000_/_Year" id="sh_smcorp" class="s_view_5">
                                                    <label for="sh_smcorp" class="s_view_5">S/M Associate Membership (Shanghai) RMB  4'000 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>


                                </div>

                                <div class="guangzhou_drop_content all_drop_content">

                                    <div id="guaQ1" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('#guaQ4').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').hide(); $('.gua_company').show(); $('#guaQ2').show();" type="radio" name="g_view_1" value="A_company" id="gua_a_comp" class="g_view_1">
                                                    <label for="gua_a_comp" class="g_view_1">A company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').hide(); $('.gua_individual').show(); $('#guaQ2').show();" type="radio" name="g_view_1" value="An_individual" id="gua_an_indiv" class="g_view_1">
                                                    <label for="gua_an_indiv" class="g_view_1">An individual</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="guaQ2" class="large-12 columns application_question_container hide_steps cm_ques2">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li class="generalClass gua_company">
                                                    <input onclick="$('#guaQ4').hide(); $('#guaQ3_sec').hide(); $('#guaQ3').show();" type="radio" name="g_view_2" value="Swiss_invested_company" id="gua_sic" class="g_view_2">
                                                    <label for="gua_sic" class="g_view_2">Swiss invested company</label>
                                                </li>
                                                <li class="generalClass gua_company">
                                                    <input onclick="$('#guaQ4').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').show();" type="radio" name="g_view_2" value="Non-Swiss_invested_company" id="gua_nsic" class="g_view_2">
                                                    <label for="gua_nsic" class="g_view_2">Non-Swiss invested company</label>
                                                </li>
                                                <li class="generalClass gua_individual">
                                                    <input onclick="$('.gua_gen_class').hide(); $('.indiv_memship').show(); $('#guaQ4').show(); " type="radio" name="g_view_2" value="Individual_(above_35_y/o)" id="gua_indv" class="g_view_2">
                                                    <label for="gua_indv" class="g_view_2">Individual (above 35 y/o)</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="guaQ3" class="large-12 columns application_question_container hide_steps gua_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.gua_gen_class').hide(); $('.l_corp_memship').show(); $('#guaQ4').show();" type="radio" name="g_view_3" value="100_staff_or_more_in_Mainland_China" id="gua_hun_staff" class="g_view_3">
                                                    <label for="gua_hun_staff" class="g_view_3">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.gua_gen_class').hide(); $('.sm_corp_memship').show(); $('#guaQ4').show();" type="radio" name="g_view_3" value="1-99_staff_in_Mainland_China" id="gua_nin_staff" class="g_view_3">
                                                    <label for="gua_nin_staff" class="g_view_3">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="guaQ3_sec" class="large-12 columns application_question_container hide_steps gua_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.gua_gen_class').hide(); $('.l_corp_membership').show(); $('#guaQ4').show();" type="radio" name="g_view_4" value="100_staff_or_more_in_Mainland_China" id="gu_hun_staff" class="g_view_4">
                                                    <label for="gu_hun_staff" class="g_view_4">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.gua_gen_class').hide(); $('.gu_sm_corp_membership').show(); $('#guaQ4').show();" type="radio" name="g_view_4" value="1-99_staff_in_Mainland_China" id="gu_nin_staff" class="g_view_4">
                                                    <label for="gu_nin_staff" class="g_view_4">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="guaQ4" class="large-12 columns application_question_container hide_steps gua_ques4">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li class="gua_gen_class indiv_memship">
                                                    <input onclick="$('.b_ques4').hide(); $('#beQ7').show();" type="radio" name="g_view_5" value="Individual_Membership_(Guangzhou)_RMB_1'200_/_Year" id="gua_ind_mem" class="g_view_5">
                                                    <label for="gua_ind_mem" class="g_view_5">Individual Membership (Guangzhou) RMB  1'200 / Year</label>
                                                </li>
                                                <li class="gua_gen_class l_corp_memship">
                                                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="L_Corporate_Membership_(Guangzhou)_RMB_2'500_/_Year" id="gua_l_corp" class="g_view_5">
                                                    <label for="gua_l_corp" class="g_view_5">L Corporate Membership (Guangzhou) RMB  2'500 / Year</label>
                                                </li>
                                                <li class="gua_gen_class sm_corp_memship">
                                                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="S/M_Corporate_Membership_(Guangzhou)_RMB_1'000_/_Year" id="gua_sm_corp" class="g_view_5">
                                                    <label for="gua_sm_corp" class="g_view_5">S/M Corporate Membership (Guangzhou) RMB  1'000 / Year</label>
                                                </li>
                                                <li class="gua_gen_class l_corp_membership">
                                                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="L_Corporate_Associate_Membership_(Guangzhou)_RMB_2'500_/_Year" id="gu_l_corp" class="g_view_5">
                                                    <label for="gu_l_corp" class="g_view_5">L Associate Membership (Guangzhou) RMB  2'500 / Year</label>
                                                </li>
                                                <li class="gua_gen_class gu_sm_corp_membership">
                                                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="S/M_Corporate_Associate_Membership_(Guangzhou)_RMB_2'500_/_Year" id="gu_l_corp" class="g_view_5">
                                                    <label for="gu_l_corp" class="g_view_5">S/M Associate Membership (Guangzhou) RMB  2'500 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>


                                </div>

                                <div class="hongkong_drop_content all_drop_content">
                                    <div id="hkQ1" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hk_ques4').hide(); $('.hk_ques3').hide(); $('#hkQ2').show();" type="radio" name="h_view_1" value="A_company" id="hk_a_comp" class="h_view_1">
                                                    <label for="hk_a_comp" class="h_view_1">A company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hk_ques4').hide(); $('.hk_ques2').hide(); $('#hkQ3').show();" type="radio" name="h_view_1" value="An_individual" id="hk_an_indiv" class="h_view_1">
                                                    <label for="hk_an_indiv" class="h_view_1">An individual</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="hkQ2" class="large-12 columns application_question_container hide_steps hk_ques2">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hkCorpA').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="50+_employees" id="hk_fif_plus" class="h_view_2 hg_view">
                                                    <label for="hk_fif_plus" class="h_view_2">50+ employees</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hkCorpB').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="25-49_employees" id="hk_tf_plus" class="h_view_2 hg_view">
                                                    <label for="hk_tf_plus" class="h_view_2">25-49 employees</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hkCorpC').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="1-24_employees" id="hk_tf_less" class="h_view_2 hg_view">
                                                    <label for="hk_tf_less" class="h_view_2">1-24 employees</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="hkQ3" class="large-12 columns application_question_container hide_steps hk_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hkIndvMem').show(); $('#hkQ4').show();" type="radio" name="h_view_3" value="Individual_/_Overseas_(above_35_y/o)" id="hk_hun_staff" class="h_view_3 hg_view">
                                                    <label for="hk_hun_staff" class="h_view_3">Individual / Overseas (above 35 y/o)</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.generalClass').hide(); $('.hkYpMem').show(); $('#hkQ4').show();" type="radio" name="h_view_3" value="Young_Professional_(under_35_y/o)" id="hk_nin_staff" class="h_view_3">
                                                    <label for="hk_nin_staff" class="h_view_3 hg_view">Young Professional (under 35 y/o)</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="hkQ4" class="large-12 columns application_question_container hide_steps hk_ques4">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li class="generalClass hkCorpA">
                                                    <input onclick="$('.b_ques3').hide(); $('#beQ3').show();" type="radio" name="h_view_4" value="Corporate_A_Membership_(Hong_Kong)_HKD_7'000_/_Year" id="hk_corp_a" class="h_view_4 hg_view">
                                                    <label for="hk_corp_a" class="h_view_4">Corporate A Membership (Hong Kong) HKD 7'000 / Year</label>
                                                </li>
                                                <li class="generalClass hkCorpB">
                                                    <input onclick="$('.b_ques3').hide(); $('#beQ4').show();" type="radio" name="h_view_4" value="Corporate_B_Membership_(Hong_Kong)_HKD_4'500_/_Year" id="hk_corp_b" class="h_view_4 hg_view">
                                                    <label for="hk_corp_b" class="h_view_4">Corporate B Membership (Hong Kong) HKD  4'500 / Year</label>
                                                </li>
                                                <li class="generalClass hkCorpC">
                                                    <input onclick="$('.b_ques3').hide(); $('#beQ5').show();" type="radio" name="h_view_4" value="Corporate_C_Membership_(Hong_Kong)_HKD_3'000_/_Year" id="hk_corp_c" class="h_view_4 hg_view">
                                                    <label for="hk_corp_c" class="h_view_4">Corporate C Membership (Hong Kong) HKD 3'000 / Year</label>
                                                </li>
                                                <li class="generalClass hkIndvMem">
                                                    <input onclick="$('.b_ques3').hide(); $('#beQ6').show();" type="radio" name="h_view_4" value="Individual_Membership_(Hong_Kong)_HKD_2'500_/_Year" id="hk_indv_mem" class="h_view_4 hg_view">
                                                    <label for="hk_indv_mem" class="h_view_4">Individual Membership (Hong Kong) HKD  2'500 / Year</label>
                                                </li>
                                                <li class="generalClass hkYpMem">
                                                    <input onclick="$('.b_ques3').hide();" type="radio" name="h_view_4" value="YP_Membership_(Hong_Kong)_HKD_500_/_Year" id="hk_yp_mem" class="h_view_4 hg_view">
                                                    <label for="hk_yp_mem" class="h_view_4">YP Membership (Hong Kong) HKD  500 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>

                                <div class="china_mainland_drop_content all_drop_content">

                                    <div id="cmQ1" class="large-12 columns application_question_container hide_steps">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('#cmQ2').show(); $('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').hide();" type="radio" name="c_view_1" value="A_company" id="cm_a_comp" class="c_view_1 cg_view">
                                                    <label for="cm_a_comp" class="c_view_1">A company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.cm_ques2').hide(); $('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').show();" type="radio" name="c_view_1" value="An_individual" id="cm_an_indiv" class="no_mem c_view_1 cg_view">
                                                    <label for="cm_an_indiv" class="no_mem c_view_1">An individual</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="cmQ2" class="large-12 columns application_question_container hide_steps cm_ques2">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt">
                                                <li>
                                                    <input onclick="$('#cmQ3').show(); $('#cmQ4').hide(); $('.b_no_member').hide();" type="radio" name="c_view_2" value="Swiss_invested_company" id="cm_sic" class="c_view_2 cg_view">
                                                    <label for="cm_sic" class="c_view_2">Swiss invested company</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').show();" type="radio" name="c_view_2" value="Non-Swiss_invested_company" id="cm_nsic" class="no_mem c_view_2">
                                                    <label for="cm_nsic" class="no_mem c_view_2 cg_view">Non-Swiss invested company</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="cmQ3" class="large-12 columns application_question_container hide_steps cm_ques3">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li>
                                                    <input onclick="$('.cmq4_smcorp').hide(); $('#cmQ4').show(); $('.cmq4_lcorp').show();" type="radio" name="c_view_3" value="100_staff_or_more_in_Mainland_China" id="cm_hun_staff" class="c_view_3 cg_view">
                                                    <label for="cm_hun_staff" class="c_view_3">100 staff or more in Mainland China</label>
                                                </li>
                                                <li>
                                                    <input onclick="$('.cmq4_lcorp').hide(); $('#cmQ4').show(); $('.cmq4_smcorp').show();" type="radio" name="c_view_3" value="1-99_staff_in_Mainland_China" id="cm_nin_staff" class="c_view_3 cg_view">
                                                    <label for="cm_nin_staff" class="c_view_3">1-99 staff in Mainland China</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="cmQ4" class="large-12 columns application_question_container hide_steps cm_ques4">
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
                                        <div class="medium-12 columns ">
                                            <ul class="fa-ul quest_radio_opt ">
                                                <li class="cmq4_lcorp">
                                                    <input type="radio" name="c_view_4" value="L_Corporate_Membership_(China_Mainland)_RMB_7'000_/_Year" id="cm_l_corp" class="c_view_4 cg_view">
                                                    <label for="cm_l_corp" class="c_view_4">L Corporate Membership (China Mainland) RMB 15’000 / Year</label>
                                                </li>
                                                <li  class="cmq4_smcorp">
                                                    <input type="radio" name="c_view_4" value="S/M_Corporate_Membership_(China_Mainland)_RMB_4'000_/_Year" id="cm_sm_corp" class="c_view_4 cg_view">
                                                    <label for="cm_sm_corp" class="c_view_4">S/M Corporate Membership (China Mainland) RMB 9’000 / Year</label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
									

                                </div>
								<div class="large-12 columns application_question_container no_membership_hide b_no_member margin_top10">
                                        <div class="medium-12 columns ">
                                            <p class="text-center margin_top10 margin_bottom10">No membership available. If you have any question, do not hesitate to <a href="#">contact us</a>. </p>
                                        </div>
                                </div>
                            </section>

							
							
                            <h2>Company information</h2>
                            <section>
							
                                <div class="large-12 columns application_question_container" id="cominfo">
                                    <!-- <h2 class="steps_common_heading"></h2> -->
                                    <h3 class="app_quest_head bscop"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS SCOPE</h3>
                                    <div class="medium-12 columns">
                                       <!-- <form>-->
                                            <div class="large-12 columns no_padding">
                                                <div class="row bscop">
                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns membership_from second_form_field">
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Agri" id="agri" checked>
                                                                <label for="agri"> Agriculture / Food / Beverages</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Bank" id="bank">
                                                                <label for="bank"> Banking / Insurance</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Chem" id="chem">
                                                                <label for="chem"> Chemical / Pharmaceuticals</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Construct" id="construct">
                                                                <label for="construct"> Construction / Civil Engineering</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Edu" id="edu">
                                                                <label for="edu"> Education / Training</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Govt" id="govt">
                                                                <label for="govt"> Government / NGO / NPO / Economic Zone</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Hosp" id="hosp">
                                                                <label for="hosp"> Hospitality / Hotels / Tourism Services</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="information" id="inform">
                                                                <label for="inform"> Information Technology / Telecommunications</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Jewel" id="jewel">
                                                                <label for="jewel"> Jewellery / Watches</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Legal_audit" id="legal">
                                                                <label for="legal"> Legal / Audit / Consulting</label>
                                                            </div>
                                                        </div>
                                                        <div class="medium-6 columns membership_from second_form_field">
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Machine" id="machine">
                                                                <label for="machine"> Machinery / Equipment</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Manufacture" id="manufacture">
                                                                <label for="manufacture"> Manufacturing / Electronic</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Media" id="media">
                                                                <label for="media"> Media / Publication</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Medical" id="medical">
                                                                <label for="medical"> Medical / Precision / Optical Instruments</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Quality" id="quality">
                                                                <label for="quality"> Quality Control / Standards / Testing</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Trading" id="trading">
                                                                <label for="trading"> Trading / Logistics / Transportation</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Sale" id="sale">
                                                                <label for="sale"> Sales / Marketing / Retail</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Other" id="other">
                                                                <label for="other"> Other</label>
                                                                <input type="text" placeholder="" value="" name="other_business_scope" id="other_business_scope">
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="row">

                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS DESCRIPTION (short introduction of your company and your core business) </h3>
                                                    <div class="medium-6 columns application_form">
                                                        <label> 150 words in English: <span>*</span>
                                                            <textarea rows="3" placeholder="Type your text" name="business_description_english" id="business_description_english"></textarea>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> 100 characters in Chinese: <span>*</span>
                                                            <textarea rows="3" placeholder="请填写您的信息" name=
															"business_description_chinese" id="business_description_chinese"></textarea>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company type and industry</h3>

                                                    <div class="medium-6 columns application_form">
                                                        <label>Legal entity <span>*</span>
                                                            <select name="legal_entity" id="legal_entity">
                                                                <option value=""> -Select-</option>
                                                                <option value="domestic"> Chinese Domestic</option>
                                                                <option value="joint">Joint-Venture</option>
                                                                <option value="foreign">Wholly Foreign-Owned</option>
                                                                <option value="represent"> Representative Office</option>
                                                            </select>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                    </div>
                                                </div>
												
												<div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY DETAILS</h3>
                                                    <div class="medium-12 columns application_form">
                                                        <label> Company Name:<span>*</span>
                                                            <input type="text" placeholder="Type your company name" name="company_english_name" id="company_english_name">
                                                        </label>
                                                    </div>
                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns application_form">
                                                            <label> Address:<span>*</span>
                                                                <textarea rows="3" placeholder="Type your address" name="company_address" id="company_address"></textarea>
                                                            </label>
                                                        </div>
                                                        <div class="medium-6 columns application_form">
                                                            <label> City:<span>*</span>
                                                                <input type="text" placeholder="Type your city" name="company_city" id="company_city">
                                                            </label>
                                                            <label>ZIP code:<span>*</span>
                                                                <input type="text" placeholder="Type your ZIP code" name="company_zipCode" id="company_zipCode">
                                                            </label>
                                                        </div>
                                                    </div>

                                                    <div class="medium-6 columns application_form">
                                                        <label> General phone:<span>*</span>
                                                            <input type="text" placeholder="Type your general phone" name="company_generalPhone" id="company_generalPhone">
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> General website:<span>*</span>
                                                            <input type="text" placeholder="Type your general website" name="company_website" id="company_website">
                                                        </label>
                                                    </div>                                                    
                                                </div>                                                
												
                                                <div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY STRUCTURE</h3>
                                                    <div class="medium-6 columns application_form">
                                                        <label>Number of employees in  <strong id="nmcmpno"></strong><span>*</span>
                                                            <input type="text" placeholder="Type your number of employees" name="no_of_employees" id="no_of_employees">
                                                        </label>
                                                    </div>
                                                    <!--<div class="medium-12 columns membership_from second_form_field">
                                                        <legend>Is your company Swiss-invested?</legend>
                                                        <input type="radio" name="is_company_swiss_invested" value="yes" id="si_yes" checked>
                                                        <label for="si_yes"> Yes</label>
                                                        <input type="radio" name="is_company_swiss_invested" value="no" id="si_no">
                                                        <label for="si_no"> No</label>
                                                    </div>-->
                                                    <div class="medium-12 columns membership_from second_form_field">
                                                        <legend>Is your company Swiss-registered?</legend>
                                                        <input type="radio" name="is_company_swiss_registered" value="yes" id="sr_yes" checked>
                                                        <label for="sr_yes"> Yes</label>
                                                        <input type="radio" name="is_company_swiss_registered" value="no" id="sr_no">
                                                        <label for="sr_no"> No</label>
                                                    </div>
                                                    <div class="medium-12 columns membership_from second_form_field">
                                                        <legend>Are you registered in PRC with a valid business licence?</legend>
                                                        <input type="radio" name="is_company_registered_PRC" value="yes" id="prc_reg_yes" checked>
                                                        <label for="prc_reg_yes"> Yes</label>
                                                        <input type="radio" name="is_company_registered_PRC" value="no" id="prc_reg_no">
                                                        <label for="prc_reg_no"> No</label>
                                                    </div>
                                                </div>
												<div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> HEADQUARTER’S DETAILS</h3>
                                                    <div class="medium-12 columns application_form">
                                                        <label> Company Name:<span>*</span>
                                                            <input type="text" placeholder="Type your company name" name="headquarter_name" id="headquarter_name">
                                                        </label>
                                                    </div>
                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns application_form">
                                                            <label> Address:<span>*</span>
                                                                <textarea rows="3" placeholder="Type your address" name="headquarter_address" id="headquarter_address"></textarea>
                                                            </label>
                                                        </div>
                                                        <div class="medium-6 columns application_form">
                                                            <label> City:<span>*</span>
                                                                <input type="text" placeholder="Type your city" name="headquarter_city" id="headquarter_city">
                                                            </label>
                                                            <label>ZIP code:<span>*</span>
                                                                <input type="text" placeholder="Type your ZIP code" name="headquarter_zipCode" id="headquarter_zipCode">
                                                            </label>
                                                        </div>
                                                    </div>

                                                    <div class="medium-6 columns application_form">
                                                        <label> General phone:<span>*</span>
                                                            <input type="text" placeholder="Type your general phone" name="headquarter_phone" id="headquarter_phone">
                                                        </label>
                                                    </div>
													<div class="medium-6 columns application_form">
													
													</div>
                                                    <!--<div class="medium-6 columns application_form">
                                                        <label> General website:<span>*</span>
                                                            <input type="text" placeholder="Type your general website" name="headquarter_website" id="headquarter_website">
                                                        </label>
                                                    </div>-->                                                    
                                                </div>
												<div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company’s Logo: <span style="color:red;">*</span></h3>
													<div class="medium-12 columns no_padding">												
                                                        <div class="large-12 columns margin_bottom10">														
											<div class="margin_top10">
												<label for="fstexampleFileUploadx" class="button no_margin_bottom">Upload Logo</label>
												<input type="file" id="fstexampleFileUploadx" class="show-for-sr" name="logo_name" onchange="showImage3(this,0);">
											</div>
											<div class="medium-12 columns no_padding">
											<label for="over_13" class="light no_margin_bottom" id="preview_label_id" style="display:block;"></label> 
										  <div style="float:left;position:relative;">
											<img class="thumbnail" id="preview" src="" alt="" style="display:none; margin-bottom: 5px;"/>
										  </div>
											</div>
										   <small>Files must be less than 20 MB. <br>
										   Allowed file types: jpg jpeg gif png </small>
										   
                                                        </div>
                                                    </div>
												</div>
                                            </div>

                                          




                                    </div>
                                    </div>
									<div class="large-12 columns application_question_container" id="blankinfo" style="display:none;">
									<h3 class="app_quest_head bscop"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS SCOPE</h3>
                                    <div class="medium-12 columns">
                                       <!-- <form>-->
                                            <div class="large-12 columns no_padding">
                                                <div class="row bscop">
                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns membership_from second_form_field">
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Agri" id="agri"  disabled>
                                                                <label for="agri"> Agriculture / Food / Beverages</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Bank" id="bank" disabled>
                                                                <label for="bank"> Banking / Insurance</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Chem" id="chem" disabled>
                                                                <label for="chem" disabled> Chemical / Pharmaceuticals</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Construct" id="construct" disabled>
                                                                <label for="construct"> Construction / Civil Engineering</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Edu" id="edu" disabled>
                                                                <label for="edu"> Education / Training</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Govt" id="govt" disabled>
                                                                <label for="govt"> Government / NGO / NPO / Economic Zone</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Hosp" id="hosp" disabled>
                                                                <label for="hosp"> Hospitality / Hotels / Tourism Services</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="information" id="inform" disabled>
                                                                <label for="inform"> Information Technology / Telecommunications</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Jewel" id="jewel" disabled>
                                                                <label for="jewel"> Jewellery / Watches</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Legal_audit" id="legal" disabled>
                                                                <label for="legal"> Legal / Audit / Consulting</label>
                                                            </div>
                                                        </div>
                                                        <div class="medium-6 columns membership_from second_form_field">
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Machine" id="machine" disabled>
                                                                <label for="machine"> Machinery / Equipment</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Manufacture" id="manufacture" disabled>
                                                                <label for="manufacture"> Manufacturing / Electronic</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Media" id="media" disabled>
                                                                <label for="media"> Media / Publication</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Medical" id="medical" disabled>
                                                                <label for="medical"> Medical / Precision / Optical Instruments</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Quality" id="quality" disabled>
                                                                <label for="quality"> Quality Control / Standards / Testing</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Trading" id="trading" disabled>
                                                                <label for="trading"> Trading / Logistics / Transportation</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Sale" id="sale" disabled>
                                                                <label for="sale"> Sales / Marketing / Retail</label>
                                                            </div>
                                                            <div>
                                                                <input type="radio" name="business_scope" value="Other" id="other" disabled>
                                                                <label for="other"> Other</label>
                                                                <input type="text" placeholder="" value="" name="other_business_scope" id="other_business_scope" disabled>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                    </div>
									</div>
                            </section>

                            <h2>Contact information</h2>
                            <section>							

                                <div class="large-12 columns application_question_container">
								<div class="genCls" id="cmpHld">
								<h2 class="steps_common_heading">COMPANY HOLDER INFORMATION</h2>
                                            <div class="large-12 columns">
                                                <div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Contact Information</h3>
                                                    <div class="medium-12 columns membership_from second_form_field">
                                                        <label></label>
                                                        <input type="radio" name="company_first_contact_title" value="Ms" id="chi_miss" checked>
                                                        <label for="chi_miss"> Ms.</label>
                                                        <input type="radio" name="company_first_contact_title" value="Mr" id="chi_mister">
                                                        <label for="chi_mister"> Mr.</label>
                                                        <input type="radio" name="company_first_contact_title" value="Dr" id="chi_doctor">
                                                        <label for="chi_doctor"> Dr.</label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Date of birth:<span>*</span>
                                                            <input type="date" placeholder="Type date of birth" name="company_first_contact_dob" id="company_first_contact_dob" class="datepicker">
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Family name:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your family name" name="company_first_contact_familyName" id="company_first_contact_familyName">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Given name(s): <span>*</span>
                                                            <input type="text" placeholder="Type your given name" name="company_first_contact_givenName" id="company_first_contact_givenName">
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Chinese Name:<span>*</span>
                                                            <input type="text" placeholder="Type your Chinese name" name="company_first_contact_chineseName" id="company_first_contact_chineseName">
                                                        </label>
                                                    </div>
                                                    <div class="medium-12 columns membership_from second_form_field">
                                                        <legend> Nationality: </legend>
                                                        <input type="radio" name="company_first_contact_nationality" value="swiss" id="nation_swiss" checked>
                                                        <label for="nation_swiss"> Swiss</label>
                                                        <input type="radio" name="company_first_contact_nationality" value="chinese" id="nation_chinese">
                                                        <label for="nation_chinese"> Chinese</label>
                                                        <input type="radio" name="company_first_contact_nationality" value="other" id="nation_other">
                                                        <label for="nation_other"> Other</label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Company name in English:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your company name in English" name="company_name_english" id="company_name_english">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Company name in Chinese:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your company name in Chinese"  name="company_name_chinese" id="company_name_chinese">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Position in the company:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your position in the company" name="company_first_contact_position" id="company_first_contact_position">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns application_form">
                                                            <label> Address in English:<span>*</span>
                                                                <textarea rows="3" placeholder="Type your address" name="china_office_english_address" id="china_office_english_address"></textarea>
                                                            </label>
                                                        </div>
                                                        <div class="medium-6 columns application_form">
                                                            <label> City in English:<span>*</span>
                                                                <input type="text" placeholder="Type your city" name="china_office_english_city" id="china_office_english_city">
                                                            </label>
                                                            <label>Province/Area in English:<span>*</span>
                                                                <input type="text" placeholder="Province/Area in English" name="china_office_english_zip" id="china_office_english_zip">
                                                            </label>
                                                        </div>
                                                    </div>

                                                    <div class="medium-12 columns no_padding">
                                                        <div class="medium-6 columns application_form">
                                                            <label> Address in Chinese:<span>*</span>
                                                                <textarea rows="3" placeholder="Type your address" name="china_office_address" id="china_office_address"></textarea>
                                                            </label>
                                                        </div>
                                                        <div class="medium-6 columns application_form">
                                                            <label> City in Chinese:<span>*</span>
                                                                <input type="text" placeholder="Type your city" name="china_office_city" id="china_office_city">
                                                            </label>
                                                            <label>ZIP code:<span>*</span>
                                                                <input type="text" placeholder="Type your ZIP code" name="china_office_zip" id="china_office_zip">
                                                            </label>
                                                        </div>
                                                    </div>


                                                    <div class="medium-6 columns application_form">
                                                        <label> General Phone: <span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your general phone number" name="company_general_phone" id="company_general_phone">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> General Email: <span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your general email address" name="company_general_email" id="company_general_email">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Direct Phone:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your direct phone number" name="company_direct_phone" id="company_direct_phone">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Direct E-mail:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your direct e-mail address" name="company_direct_email" id="company_direct_email">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Website:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your website" name="chinese_company_website" id="chinese_company_website">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Mobile:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your mobile number"  name="company_mobile" id="company_mobile">
                                                            </div>
                                                        </label>
                                                    </div>
                                                </div>
												<div class="row">
													<div class="medium-12 columns">
														<hr />
													</div>
												</div>
                                                <div class="row">
                                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> 2nd contact / assistant (in case you are unavailable)</h3>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Position within the company:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your position within the company" name="second_contact_person_position" id="second_contact_person_position">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-12 columns membership_from second_form_field">
                                                        <label></label>
                                                        <input type="radio" name="second_contact_person_title" value="Ms" id="sec_contact_miss" checked>
                                                        <label for="sec_contact_miss"> Ms.</label>
                                                        <input type="radio" name="second_contact_person_title" value="Mr" id="sec_contact_mister">
                                                        <label for="sec_contact_mister"> Mr.</label>
                                                        <input type="radio" name="second_contact_person_title" value="Dr" id="sec_contact_doctor">
                                                        <label for="sec_contact_doctor"> Dr.</label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Family name:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your family name" name="second_contact_person_familyName" id="second_contact_person_familyName">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Given name(s):<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your given name(s)" name="second_contact_person_givenName" id="second_contact_person_givenName">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Chinese name:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your Chinese name" name="second_contact_person_chineseName" id="second_contact_person_chineseName">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Mobile:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your mobile number" name="second_contact_person_mobile" id="second_contact_person_mobile">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Direct Phone:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your direct phone number" name="second_contact_person_directPhone" id="second_contact_person_directPhone">
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="medium-6 columns application_form">
                                                        <label> Direct E-mail:<span>*</span>
                                                            <div class="input-group">
                                                                <input type="text" placeholder="Type your direct e-mail address" name="second_contact_person_directMail" id="second_contact_person_directMail">
                                                            </div>
                                                        </label>
                                                    </div>
                                                </div>

                                       

                                        </div>
                                        </div>
								
								
								
								<!------->
								<div class="genCls" id="invstHld">
                                    <h2 class="steps_common_heading">INFORMATION FORM FOR INVESTMENT ZONE</h2>
                                    <div class="large-12 columns">
                                        <div class="row">
                                            <!--<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> DESCRIPTION (short introduction of your zone and your core services) </h3> -->
                                            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS DESCRIPTION (short introduction of your company and your core business) </h3>
                                            <div class="medium-6 columns application_form">
                                                <label> 150 words in English: <span>*</span>
                                                    <textarea rows="3" placeholder="Type your text" name="business_description_english_inv" id="business_description_english_inv"></textarea>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> 100 characters in Chinese: <span>*</span>
                                                    <textarea rows="3" placeholder="请填写您的信息" name="business_description_chinese_inv" id="business_description_chinese_inv"></textarea>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADDRESS</h3>
                                            <div class="medium-6 columns application_form">
                                                <label> Name in English:<span>*</span>
                                                    <input type="text" placeholder="Type your name in English" name="business_description_name_english" id="business_description_name_english">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Name in Chinese:<span>*</span>
                                                    <input type="text" placeholder="Type your name in Chinese" name="business_description_name_chinese" id="business_description_name_chinese">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in English:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="business_description_address_english" id="business_description_address_english"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in English:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in English)" name="business_description_city_english" id="business_description_city_english">
                                                    </label>
                                                    <label>Province/Area in English:<span>*</span>
                                                        <input type="text" placeholder="Province/Area in English" name="business_description_zipCode_english" id="business_description_zipCode_english">
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in Chinese:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in Chinese" name="business_description_address_chinese" id="business_description_address_chinese"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in Chinese <span>*</span>
                                                        <input type="text" placeholder="Type your city(in Chinese)" name="business_description_city_chinese" id="business_description_city_chinese">
                                                    </label>
                                                    <label>ZIP code:<span>*</span>
                                                        <input type="text" placeholder="Type your ZIP code(in English)" name="business_description_zipCode_chinese" id="business_description_zipCode_chinese">
                                                    </label>
                                                </div>

                                            </div>


                                            <div class="medium-6 columns application_form">
                                                <label> General phone: <span>*</span>
                                                    <input type="text" placeholder="Type your general phone number" name="business_description_phone" id="business_description_phone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> General website:<span>*</span>
                                                    <input type="text" placeholder="Type your general website" name="business_description_website" id=" business_description_website">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <div class="large-12 columns no_padding">
                                                    <div>
                                                        <label for="exampleFileUpload" class="button no_margin_bottom upload_file_btn">Upload File</label>
                                                        <input type="file" id="exampleFileUpload" class="show-for-sr" name=
														"business_description_logo">
                                                    </div>
                                                    <small>Files must be less than 20 MB. <br>
														Allowed file types: jpg jpeg gif png pdf mp4 doc docx xls xlsx.</small>
                                                </div>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Number of employees in Beijing / Mainland China<span>*</span>
                                                    <input type="text" placeholder="Type the number of employees" name="business_description_no_of_employee" id="business_description_no_of_employee">
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <h2 class="steps_common_heading">INVESTMENT ZONE MEMBERSHIP HOLDER INFORMATION</h2>
                                    <div class="large-12 columns ">
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="investZone_contact_title" value="Ms" id="invest_zone_miss" checked>
                                                <label for="invest_zone_miss"> Ms.</label>
                                                <input type="radio" name="investZone_contact_title" value="Mr" id="invest_zone_mister">
                                                <label for="invest_zone_mister"> Mr.</label>
                                                <input type="radio" name="investZone_contact_title" value="Dr" id="invest_zone_doctor">
                                                <label for="invest_zone_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Date of birth:<span>*</span>
                                                    <input type="date" placeholder="Type your date of birth" name="investZone_contact_dob" id="investZone_contact_dob">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <input type="text" placeholder="Type your family name" name="investZone_contact_familyName" id="investZone_contact_familyName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <input type="text" placeholder="Type your given name(s)" name="investZone_contact_givenName" id="investZone_contact_givenName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese Name:<span>*</span>
                                                    <input type="text" placeholder="Type your Chinese name" name="investZone_contact_chineseName" id="investZone_contact_chineseName">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <legend> Nationality:</legend>
                                                <input type="radio" name="investZone_contact_nationality" value="swiss" id="nationality_swiss" checked>
                                                <label for="nationality_swiss"> Swiss</label>
                                                <input type="radio" name="investZone_contact_nationality" value="chinese" id="nationality_chinese">
                                                <label for="nationality_chinese"> Chinese</label>
                                                <input type="radio" name="investZone_contact_nationality" value="other" id="nationality_other">
                                                <label for="nationality_other"> Other</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Position / Title:<span>*</span>
                                                    <input type="text" placeholder="Type your position/title" name="investZone_contact_position" id="investZone_contact_position">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> General Phone: <span>*</span>
                                                    <input type="text" placeholder="Type your general phone number" name="investZone_contact_generalphone" id="investZone_contact_generalphone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> General E-mail <span>*</span>
                                                    <input type="text" placeholder="Type your general e-mail address" name="investZone_contact_generalemail" id="investZone_contact_generalemail">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone: <span>*</span>
                                                    <input type="text" placeholder="Type your direct phone number" name="investZone_contact_directphone" id="investZone_contact_directphone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail: <span>*</span>
                                                    <input type="text" placeholder="Type your direct e-mail address" name="investZone_contact_directemail" id="investZone_contact_directemail">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Website: <span>*</span>
                                                    <input type="text" placeholder="Type your website" name="investZone_contact_website" id="investZone_contact_website">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile: <span>*</span>
                                                    <input type="text" placeholder="Type your mobile" name="investZone_contact_mobile" id="investZone_contact_mobile">
                                                </label>
                                            </div>
                                        </div>
										<div class="row">
													<div class="medium-12 columns">
														<hr />
													</div>
												</div>
                                        <div class="row">
                                            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> 2nd contact / assistant (in case you are unavailable)</h3>
                                            <div class="medium-6 columns application_form">
                                                <label> Position / Title:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your position/title " name="investZone_second_contact_position" id="investZone_second_contact_position">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="investZone_second_contact_" value="Ms" id="info_sec_contact_miss" checked>
                                                <label for="info_sec_contact_miss"> Ms.</label>
                                                <input type="radio" name="investZone_second_contact_" value="Mr" id="info_sec_contact_mister">
                                                <label for="info_sec_contact_mister"> Mr.</label>
                                                <input type="radio" name="investZone_second_contact_" value="Dr" id="info_sec_contact_doctor">
                                                <label for="info_sec_contact_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your family name" name="investZone_second_contact_familyName" id="investZone_second_contact_familyName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your given name(s)" name="investZone_second_contact_givenName" id="investZone_second_contact_givenName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your Chinese name" name="investZone_second_contact_chineseName" id="investZone_second_contact_chineseName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your mobile number" name="investZone_second_contact_mobile" id="investZone_second_contact_mobile">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct phone number" name="investZone_second_contact_phone" id="investZone_second_contact_phone">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct e-mail address" name="investZone_second_contact_email" id="investZone_second_contact_email">
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
									
									
									<div class="genCls" id="indvHld">
                                    <h2 class="steps_common_heading">INFORMATION FORM FOR INDIVIDUAL / YOUNG PROFESSIONAL</h2>
                                    <div class="large-12 columns ">
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="individual_contact_title" value="Ms" id="info_form_indiv_miss" checked>
                                                <label for="info_form_indiv_miss"> Ms.</label>
                                                <input type="radio" name="individual_contact_title" value="Mr" id="info_form_indiv_mister">
                                                <label for="info_form_indiv_mister"> Mr.</label>
                                                <input type="radio" name="individual_contact_title" value="Dr" id="info_form_indiv_doctor">
                                                <label for="info_form_indiv_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Date of birth:<span>*</span>
                                                    <input type="date" placeholder="Type your date of birth" name="individual_contact_dob" id="individual_contact_dob" class="datepicker">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <input type="text" placeholder="Type your family name" name="individual_contact_familyName" id="individual_contact_familyName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <input type="text" placeholder="Type your given name(s)" name="individual_contact_givenName" id="individual_contact_givenName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese Name:<span>*</span>
                                                    <input type="text" placeholder="Type your Chinese name" name="individual_contact_chineseName" id="individual_contact_chineseName">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <legend> Nationality:</legend>
                                                <input type="radio" name="individual_contact_Nationality" value="Swiss" id="indiv_nationality_swiss" checked>
                                                <label for="indiv_nationality_swiss"> Swiss</label>
                                                <input type="radio" name="individual_contact_Nationality" value="Chinese" id="indiv_nationality_chinese">
                                                <label for="indiv_nationality_chinese"> Chinese</label>
                                                <input type="radio" name="individual_contact_Nationality" value="Other" id="indiv_nationality_other">
                                                <label for="indiv_nationality_other"> Other</label>
                                            </div>

                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in English:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="individual_contact_address_english" id="individual_contact_address_english"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in English:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in English)" name="individual_contact_city_english" id="individual_contact_city_english">
                                                    </label>
                                                    <label>Province/Area in English:<span>*</span>
                                                        <input type="text" placeholder="Province/Area in English" name="individual_contact_zip_english" id="individual_contact_zip_english">
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in Chinese:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in Chinese" name="individual_contact_address_chinese" id="individual_contact_address_chinese"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in Chinese:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in Chinese)" name="individual_contact_city_chinese" id="individual_contact_city_chinese">
                                                    </label>
                                                    <label>ZIP code:<span>*</span>
                                                        <input type="text" placeholder="Type your ZIP code(in English)" name="individual_contact_zip_chinese" id="individual_contact_zip_chinese">
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone: <span>*</span>
                                                    <input type="text" placeholder="Type your direct phone number" name="individual_contact_directPhone" id="individual_contact_directPhone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail: <span>*</span>
                                                    <input type="text" placeholder="Type your direct e-mail address" name="individual_contact_email" id="individual_contact_email">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Website: <span>*</span>
                                                    <input type="text" placeholder="Type your website" name="individual_contact_website" id="individual_contact_website">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile: <span>*</span>
                                                    <input type="text" placeholder="Type your mobile" name="individual_contact_phone" id="individual_contact_phone">
                                                </label>
                                            </div>
                                        </div>
										<div class="row">
													<div class="medium-12 columns">
														<hr />
													</div>
												</div>
                                        <div class="row">
                                            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> 2nd contact / assistant (in case you are unavailable)</h3>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="individual_second_contact_title" value="Ms" id="info_sec_contact_miss" checked>
                                                <label for="info_sec_contact_miss"> Ms.</label>
                                                <input type="radio" name="individual_second_contact_title" value="Mr" id="info_sec_contact_mister">
                                                <label for="info_sec_contact_mister"> Mr.</label>
                                                <input type="radio" name="individual_second_contact_title" value="Dr" id="info_sec_contact_doctor">
                                                <label for="info_sec_contact_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your family name" name="individual_second_contact_familyName" id="individual_second_contact_familyName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your given name(s)" name="individual_second_contact_givenName" id="individual_second_contact_givenName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your Chinese name" name="individual_second_contact_chineseName" id="individual_second_contact_chineseName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your mobile number" name="individual_second_contact_mobile" id="individual_second_contact_mobile">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct phone number" name="individual_second_contact_phone" id="individual_second_contact_phone">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct e-mail address" name="individual_second_contact_email" id="individual_second_contact_email">
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
									<div class="genCls" id="npoHld">
                                    <h2 class="steps_common_heading"> INFORMATION FORM FOR NPO</h2>
                                    <div class="large-12 columns ">
                                        <div class="row">
                                            <div class="medium-6 columns application_form">
                                                <label> Type of organization:<span>*</span>
                                                    <input type="text" placeholder="Type your type of organization" name="npo_organization_type" id="npo_organization_type">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Organization description:<span>*</span>
                                                    <textarea rows="3" placeholder="Type your family name" name="npo_organization_description" id="npo_organization_description"></textarea>
                                                </label>
                                            </div>
                                        </div>

                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership holder</h3>
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="npo_contact_title" value="Ms" id="info_form_npo_miss" checked>
                                                <label for="info_form_npo_miss"> Ms.</label>
                                                <input type="radio" name="npo_contact_title" value="Mr" id="info_form_npo_mister">
                                                <label for="info_form_npo_mister"> Mr.</label>
                                                <input type="radio" name="npo_contact_title" value="Dr" id="info_form_npo_doctor">
                                                <label for="info_form_npo_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Date of birth:<span>*</span>
                                                    <input type="date" placeholder="Type your date of birth" name="npo_contact_dob" id="npo_contact_dob">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <input type="text" placeholder="Type your family name" name="npo_contact_familyName" id="npo_contact_familyName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <input type="text" placeholder="Type your given name(s)" name="npo_contact_givenName" id="npo_contact_givenName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese Name:<span>*</span>
                                                    <input type="text" placeholder="Type your Chinese name" name="npo_contact_chineseName" id="npo_contact_chineseName">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <legend> Nationality:</legend>
                                                <input type="radio" name="npo_contact_Nationality" value="Swiss" id="mem_hold_swiss" checked>
                                                <label for="nationality_swiss"> Swiss</label>
                                                <input type="radio" name="npo_contact_Nationality" value="Chinese" id="mem_hold_chinese">
                                                <label for="mem_hold_chinese"> Chinese</label>
                                                <input type="radio" name="npo_contact_Nationality" value="Other" id="mem_hold_other">
                                                <label for="mem_hold_other"> Other</label>
                                            </div>

                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in English:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="npo_contact_address_english" id="npo_contact_address_english"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in English:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in English)" name="npo_contact_city_english" id="npo_contact_city_english">
                                                    </label>
                                                    <label>Province/Area in English:<span>*</span>
                                                        <input type="text" placeholder="Province/Area in English" name="npo_contact_zip_english" id="npo_contact_zip_english">
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in Chinese:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="npo_contact_address_chinese" id="npo_contact_address_chinese"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in Chinese:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in Chinese)" name="npo_contact_city_chinese" id="npo_contact_city_chinese">
                                                    </label>
                                                    <label>ZIP code:<span>*</span>
                                                        <input type="text" placeholder="Type your ZIP code(in English)" name="npo_contact_zip_chinese" id="npo_contact_zip_chinese">
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <input type="text" placeholder="Type your direct phone number" name="npo_contact_phone" id="npo_contact_phone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <input type="text" placeholder="Type your direct e-mail address" name="npo_contact_email" id="npo_contact_email">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Website:<span>*</span>
                                                    <input type="text" placeholder="Type your website" name="npo_contact_website" id="npo_contact_website">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <input type="text" placeholder="Type your mobile" name="npo_contact_mobile" id="npo_contact_mobile">
                                                </label>
                                            </div>
                                        </div>
										<div class="row">
													<div class="medium-12 columns">
														<hr />
													</div>
												</div>
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> 2nd contact / assistant (in case you are unavailable)</h3>
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="npo_second_contact_title" value="Ms" id="info_asst_contact_miss" checked>
                                                <label for="info_asst_contact_miss"> Ms.</label>
                                                <input type="radio" name="npo_second_contact_title" value="Mr" id="info_asst_contact_mister">
                                                <label for="info_asst_contact_mister"> Mr.</label>
                                                <input type="radio" name="npo_second_contact_title" value="Dr" id="info_asst_contact_doctor">
                                                <label for="info_asst_contact_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your family name" name="npo_second_contact_familyName" id="npo_second_contact_familyName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your given name(s)" name="npo_second_contact_givenName" id="npo_second_contact_givenName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your Chinese name" name="npo_second_contact_chineseName" id="npo_second_contact_chineseName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your mobile number" name="npo_second_contact_mobile" id="npo_second_contact_mobile">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct phone number" name="npo_second_contact_phone" id="npo_second_contact_phone">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct e-mail address" name="npo_second_contact_email" id="npo_second_contact_email">
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
									<div class="genCls" id="jrnlHld">
                                    <h2 class="steps_common_heading"> INFORMATION FORM FOR JOURNALIST</h2>
                                    <div class="large-12 columns ">
                                        <div class="row">
                                            <div class="medium-6 columns application_form">
                                                <label> Type of media:<span>*</span>
                                                    <input type="text" placeholder="Type your type of media" name="media_type" id="media_type">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Publication description:<span>*</span>
                                                    <textarea rows="3" placeholder="Type your publication description" name="media_description" id="media_description"></textarea>
                                                </label>
                                            </div>
                                        </div>

                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership holder</h3>
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="journalist_contact_title" value="Ms" id="journalist_miss" checked>
                                                <label for="journalist_miss"> Ms.</label>
                                                <input type="radio" name="journalist_contact_title" value="Mr" id="journalist_mister">
                                                <label for="journalist_mister"> Mr.</label>
                                                <input type="radio" name="journalist_contact_title" value="Dr" id="journalist_doctor">
                                                <label for="journalist_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Date of birth:<span>*</span>
                                                    <input type="text" placeholder="Type your date of birth" name="journalist_contact_dob" id="journalist_contact_dob">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <input type="text" placeholder="Type your family name" name="journalist_contact_familyName" id="journalist_contact_familyName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <input type="text" placeholder="Type your given name(s)" name="journalist_contact_givenName" id="journalist_contact_givenName">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese Name:<span>*</span>
                                                    <input type="text" placeholder="Type your Chinese name" name="journalist_contact_chineseName" id="journalist_contact_chineseName">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <legend> Nationality:</legend>
                                                <input type="radio" name="journalist_contact_Nationality" value="Swiss" id="journalist_swiss" checked>
                                                <label for="journalist_swiss"> Swiss</label>
                                                <input type="radio" name="journalist_contact_Nationality" value="Chinese" id="journalist_chinese">
                                                <label for="journalist_chinese"> Chinese</label>
                                                <input type="radio" name="journalist_contact_Nationality" value="Other" id="journalist_other">
                                                <label for="journalist_other"> Other</label>
                                            </div>

                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in English:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="journalist_contact_address_english" id="journalist_contact_address_english"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in English:<span>*</span>
                                                        <input type="text" placeholder="Type your city(in English)" name="journalist_contact_city_english" id="journalist_contact_city_english">
                                                    </label>
                                                    <label>Province/Area in English:<span>*</span>
                                                        <input type="text" placeholder="Province/Area in English" name="journalist_contact_zip_english" id="journalist_contact_zip_english">
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="medium-12 columns no_padding">
                                                <div class="medium-6 columns application_form">
                                                    <label> Address in Chinese:<span>*</span>
                                                        <textarea rows="3" placeholder="Type your address in English" name="journalist_contact_address_chinese" id="journalist_contact_address_chinese"></textarea>
                                                    </label>
                                                </div>
                                                <div class="medium-6 columns application_form">
                                                    <label> City in Chinese:<span>*</span>
                                                        <input type="text" placeholder="Type your city (in English)" name="journalist_contact_city_chinese" id="journalist_contact_city_chinese">
                                                    </label>
                                                    <label>ZIP code:<span>*</span>
                                                        <input type="text" placeholder="Type your ZIP code(in English)" name="journalist_contact_zip_chinese" id="journalist_contact_zip_chinese">
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <input type="text" placeholder="Type your direct phone number" name="journalist_contact_phone" id="journalist_contact_phone">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <input type="text" placeholder="Type your direct e-mail address" name="journalist_contact_email" id="journalist_contact_email">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Website:<span>*</span>
                                                    <input type="text" placeholder="Type your website" name="journalist_contact_website" id="journalist_contact_website">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <input type="text" placeholder="Type your mobile" name="journalist_contact_mobile" id="journalist_contact_mobile">
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">

                                            </div>
                                        </div>
										<div class="row">
													<div class="medium-12 columns">
														<hr />
													</div>
												</div>
                                        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> 2nd contact / assistant (in case you are unavailable)</h3>
                                        <div class="row">
                                            <div class="medium-12 columns membership_from second_form_field">
                                                <label></label>
                                                <input type="radio" name="journalist_second_contact_title" value="Ms" id="sec_journalist_miss" checked>
                                                <label for="info_asst_contact_miss"> Ms.</label>
                                                <input type="radio" name="journalist_second_contact_title" value="Mr" id="sec_journalist_mister">
                                                <label for="info_asst_contact_mister"> Mr.</label>
                                                <input type="radio" name="journalist_second_contact_title" value="Dr" id="sec_journalist_doctor">
                                                <label for="info_asst_contact_doctor"> Dr.</label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Family name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your family name" name="journalist_second_contact_familyName" id="journalist_second_contact_familyName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Given name(s):<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your given name(s)" name="journalist_second_contact_givenName" id="journalist_second_contact_givenName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Chinese name:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your Chinese name" name="journalist_second_contact_chineseName" id="journalist_second_contact_chineseName">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Mobile:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your mobile number" name="journalist_second_contact_mobile" id="journalist_second_contact_mobile">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct Phone:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct phone number" name="journalist_second_contact_phone" id="journalist_second_contact_phone">
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="medium-6 columns application_form">
                                                <label> Direct E-mail:<span>*</span>
                                                    <div class="input-group">
                                                        <input type="text" placeholder="Type your direct e-mail address" name="journalist_second_contact_email" id="journalist_second_contact_email">
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
									
								<div class="medium-12 columns">
                                <div class="margin_bottom15 margin_top10">
									<a href="javascrip:void((0);" id="addmore" class="holo_button">
										<i class="fa fa-plus-circle" aria-hidden="true"></i> Add new contact
									</a>
								</div>
                                <div id="removediv" style="display:none;" class="margin_bottom10">
									<a href="javascrip:void((0);" class="holo_button" id="removebtn">
										<i class="fa fa-times-circle" aria-hidden="true"></i> Remove last contact
									</a>
								</div>
								<input type="hidden" name="addcnt" value="0" id="addcnt">
								</div>
						
								<div id="appenddiv"></div>
                                </div>
                            </section>

                            <h2>Confirmation</h2>
                            <section>
                                <div class="large-12 columns application_question_container">
                                    <h5 class="app_quest_disclaim">Please check all the information listed below and press submit to confirm your membership application.</h5>
                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership Type</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>LOCATION:</h5></td>
                                                        <td id="location"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5> I AM / WE ARE:</h5></td>
                                                        <td id="am_we"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>APPLY FOR:</h5></td>
                                                        <td id="apply_for"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
									<!--Business Information start-->
									<div id="onlycomp" style="display:none;">
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Business Information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>Business Description English</h5></td>
                                                        <td id="bde"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Business Description Chinese</h5></td>
                                                        <td id="bdc"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Legal entity </h5></td>
                                                        <td id="lgnt"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
									<!--Business Information end-->
                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company Information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Name</h5></td>
                                                        <td id="hdcmpnm"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Address</h5></td>
                                                        <td id="hdcmpadd"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>City</h5></td>
                                                        <td id="hdcmpct"></td>
                                                    </tr>
													<tr>
                                                        <td>
                                                            <h5>ZIP code</h5></td>
                                                        <td id="hdcmpzip"></td>
                                                    </tr>
													<tr>
                                                        <td>
                                                            <h5>General phone</h5></td>
                                                        <td id="hdcmpgp"></td>
                                                    </tr>
													<tr>
                                                        <td>
                                                            <h5>General website</h5></td>
                                                        <td id="hdcmpgw"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY STRUCTURE</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <h5>Number of employees </h5></td>
                                                        <td id="empno"></td>
                                                    </tr>
                                                   <!-- <tr>
                                                        <td>
                                                            <h5>Is your company Swiss-invested?</h5></td>
                                                         <td id="cmpssinv"></td>
                                                    </tr>-->
                                                    <tr>
                                                        <td>
                                                            <h5>Is your company Swiss-registered?</h5></td>
                                                          <td id="cmpssreg"></td>
                                                    </tr>
													<tr>
                                                        <td>
                                                            <h5>Are you registered in PRC with a valid business licence?  <td id="cmpssPRC"></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    </div>
                                    <div id="A_company" style="display:none;">
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company contact user information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>Title</h5></td>
                                                        <td id="cmptle"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Date of birth</h5></td>
                                                        <td id="cmpdob"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Family name</h5></td>
                                                        <td id="cmpfnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Given name(s)</h5></td>
                                                        <td id="cmpgnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Chinese Name</h5></td>
                                                        <td id="cmpcnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Nationality</h5></td>
                                                        <td id="cmpnation"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Company name in English</h5></td>
                                                        <td id="cmpcne"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Company name in Chinese</h5></td>
                                                        <td id="cmpcnc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Position in the company</h5></td>
                                                        <td id="cmppc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Address in English</h5></td>
                                                        <td id="cmpadde"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City(English)</h5></td>
                                                        <td id="cmpcte"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>ZIP code(English)</h5></td>
                                                        <td id="cmpzipe"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Address in Chinese</h5></td>
                                                        <td id="cmpaddc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City(Chinese)</h5></td>
                                                        <td id="cmpctc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>ZIP code(Chinese)</h5></td>
                                                        <td id="cmpzipc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General Phone</h5></td>
                                                        <td id="cmpgp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General Email</h5></td>
                                                        <td id="cmpge"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct Phone</h5></td>
                                                        <td id="cmpdp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct E-mail</h5></td>
                                                        <td id="cmpde"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Website</h5></td>
                                                        <td id="cmpweb"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Mobile</h5></td>
                                                        <td id="cmpmob"></td>
                                                    </tr>
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
                                    </div>
									<!--investment zone Start -->
									<div id="investment" style="display:none;">
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> INVESTMENT ZONE MEMBERSHIP HOLDER INFORMATION</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>Title</h5></td>
                                                        <td id="bdct"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Date of birth</h5></td>
                                                        <td id="bdcdob"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Family name</h5></td>
                                                        <td id="bdcfnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Given name(s)</h5></td>
                                                        <td id="bdcgnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Chinese Name</h5></td>
                                                        <td id="bdccnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Nationality</h5></td>
                                                        <td id="bdcnation"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Position in the company</h5></td>
                                                        <td id="bdpos"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General Phone</h5></td>
                                                        <td id="bdcgp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General E-mail</h5></td>
                                                        <td id="bdcge"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct Phone</h5></td>
                                                        <td id="bdcdp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct E-mail</h5></td>
                                                        <td id="bdcde"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Website</h5></td>
                                                        <td id="bdcweb"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Mobile</h5></td>
                                                        <td id="bdcmob"></td>
                                                    </tr>
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> INFORMATION FORM FOR INVESTMENT ZONE</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5> BUSINESS DESCRIPTION(English)</h5></td>
                                                        <td id="bde"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>BUSINESS DESCRIPTION(Chinese)</h5></td>
                                                        <td id="bdc"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Name in English</h5></td>
                                                        <td id="bdnme"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Name in Chinese</h5></td>
                                                        <td id="bdnmc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Address in English</h5></td>
                                                        <td id="bdadde"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City</h5></td>
                                                        <td id="bdcte"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>ZIP code</h5></td>
                                                        <td id="bdzip"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Address in Chinese</h5></td>
                                                        <td id="bdaddc"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City(chinese)</h5></td>
                                                        <td id="bdctc"></td>
                                                    </tr>
													
													<tr>
                                                        <td><h5>General website</h5></td>
                                                        <td id="bdgw"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General phone</h5></td>
                                                        <td id="gdgp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Number of employees in Beijing / Mainland China</h5></td>
                                                        <td id="gdno"></td>
                                                    </tr>
													
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
                                    </div>
									
									
									
									
									<!--investment zone end -->
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Second user information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>Position within the company</h5></td>
                                                        <td id="sndPos"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Title</h5></td>
                                                        <td id="sndtle"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Family name</h5></td>
                                                        <td id="sndfnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Given name(s)</h5></td>
                                                        <td id="sndgnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Chinese Name</h5></td>
                                                        <td id="sndcnm"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Mobile</h5></td>
                                                        <td id="sndmob"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct Phone</h5></td>
                                                        <td id="snddp"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct E-mail</h5></td>
                                                        <td id="sndde"></td>
                                                    </tr>
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
									<div id="jurnalist" style="display:none;">
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company contact user information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td><h5>Title</h5></td>
                                                        <td id="cmptlej"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Date of birth</h5></td>
                                                        <td id="cmpdobj"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Family name</h5></td>
                                                        <td id="cmpfnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Given name(s)</h5></td>
                                                        <td id="cmpgnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Chinese Name</h5></td>
                                                        <td id="cmpcnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Nationality</h5></td>
                                                        <td id="cmpnationj"></td>
                                                    </tr>
													<!--<tr>
                                                        <td><h5>Company name in English</h5></td>
                                                        <td id="cmpcnej"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Company name in Chinese</h5></td>
                                                        <td id="cmpcncj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Position in the company</h5></td>
                                                        <td id="cmppcj"></td>
                                                    </tr>-->
													<tr>
                                                        <td><h5>Address in English</h5></td>
                                                        <td id="cmpaddej"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City(English)</h5></td>
                                                        <td id="cmpctej"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>ZIP code(English)</h5></td>
                                                        <td id="cmpzipej"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Address in Chinese</h5></td>
                                                        <td id="cmpaddcj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>City(Chinese)</h5></td>
                                                        <td id="cmpctcj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>ZIP code(Chinese)</h5></td>
                                                        <td id="cmpzipcj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General Phone</h5></td>
                                                        <td id="cmpgpj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>General Email</h5></td>
                                                        <td id="cmpgej"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct Phone</h5></td>
                                                        <td id="cmpdpj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Website</h5></td>
                                                        <td id="cmpwebj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Mobile</h5></td>
                                                        <td id="cmpmobj"></td>
                                                    </tr>
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
									<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> JOURNALIST Second user information</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
													<tr>
                                                        <td><h5>Title</h5></td>
                                                        <td id="sndtlej"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h5>Family name</h5></td>
                                                        <td id="sndfnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Given name(s)</h5></td>
                                                        <td id="sndgnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Chinese Name</h5></td>
                                                        <td id="sndcnmj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Mobile</h5></td>
                                                        <td id="sndmobj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct Phone</h5></td>
                                                        <td id="snddpj"></td>
                                                    </tr>
													<tr>
                                                        <td><h5>Direct E-mail</h5></td>
                                                        <td id="snddej"></td>
                                                    </tr>
                                                </tbody>
													
                                            </table>
                                        </div>
                                    </div>
									</div>
									<!--
                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership contact</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Name</h5></td>
                                                        <td>Primary Membership - Corporate (More than 1,000 employees worldwide)</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Name (Chinese)</h5></td>
                                                        <td>Primary Membership - Corporate</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>Business description (English)</h5></td>
                                                        <td>Primary Membership - Corporate</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Method of Payment</h3>
                                    <div class="medium-12 columns no_padding">
                                        <div class="table-scroll">
                                            <table class="application_final_check">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Name</h5></td>
                                                        <td>Primary Membership - Corporate (More than 1,000 employees worldwide)</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>Company Name (Chinese)</h5></td>
                                                        <td>Primary Membership - Corporate</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <h5>Business description (English)</h5></td>
                                                        <td>Primary Membership - Corporate</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>-->
                                </div>
                            </section>
                            </div>

                        </div>
                    </div>
</form>
                    <div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
                        <div class="large-12 columns inner_right_panel">
                            <div class="large-12 columns right_y_join margin_top10">
                                <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
                                <p class="text-center">Because Connections Matter.</p>
                                <ul class="fa-ul join_button_group">
                                    <li><a href="#" class="button expanded ">WHY JOIN US</a></li>
                                    <li><a href="#" class="button expanded ">BECOME A  MEMBER</a></li>
                                </ul>
                            </div>
                            <div class="large-12 columns right_y_join margin_top10">
                                <div class="flex-video right_panel_video">
                                    <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <div class="large-12 columns right_y_join margin_top10">
                                <h3 class="common_subheading">Strategic Partner</h3>
                                <ul class="fa-ul inner_sponser_img">
                                    <li><img src="images/inner_sponser1.jpg" /></li>
                                    <li><img src="images/inner_sponser2.jpg" /></li>
                                    <li><img src="images/inner_sponser3.jpg" /></li>
                                </ul>
                            </div>
                            <div class="large-12 columns">
                                <hr class="right_devider" />
                            </div>
                            <div class="large-12 columns right_y_join margin_top10">
                                <h3 class="common_subheading">Upcoming events</h3>
                                <div class="tab_list_item">
                                    <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                    <h5>Venue Name</h5>
                                    <h3>Chinese authorities clear a path for HNA takeover of gategroup</h3>
                                </div>
                                <div class="tab_list_item">
                                    <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                    <h5>Venue Name</h5>
                                    <h3>Credit Suisse Plans on Raising Stake in Chinese Joint Venture</h3>
                                </div>
                                <div class="tab_list_item">
                                    <h4>11th Jul 2016 <span><i class="fa fa-map-marker" aria-hidden="true"></i> Beijing</span></h4>
                                    <h5>Venue Name</h5>
                                    <h3>Joint Chamber Cocktail Presentation - 2H 2016 Market Outlook - Trends & trade flow between China and Europe</h3>
                                </div>
                                <a class="see_more_link" href="#">read more</a>
                            </div>
                            <div class="large-12 columns">
                                <hr class="right_devider" />
                            </div>
                            <div class="large-12 columns right_y_join margin_top10">
                                <h3 class="common_subheading">NEWSLETTER</h3>
                                <p class="">Interested in trying one? Use the form below to get in touch.</p>
                                <form>
                                    <ul class="fa-ul right_newsletter_form">
                                        <li>
                                            <label>
                                                <input type="text" placeholder="Name">
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="text" placeholder="Surname">
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="text" placeholder="Company">
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="text" placeholder="Email">
                                            </label>
                                        </li>
                                        <li class="text-left newsletter_button_sec">
                                            <a href="#" class="button newsletter_button">Subscribe</a>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>

                    </div>
                </div>
            </div>
        </section>
		<?php 
		require_once(__ROOT__.'/includes/footer.php'); 
		?>
	
	
	 <!-- Login Modal Start -->
        <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
            <h1>Please fill the information to Login</h1>
            <p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>
            <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                <div class="row">
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>User ID <span class="mandatory_tag">*</span>
                            <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                        </label>
                    </div>
                    <div class="medium-12 columns margin_top10 membership_from no_padding">
                        <label>Password <span class="mandatory_tag">*</span>
                            <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from no_padding">
                        <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                    </div>
                </div>
            </form>
            <button class="close-button" data-close aria-label="Close reveal" type="button">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <!-- Login Modal End -->
	
	
	
	
	
	
	
        <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
        <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


        <nav id="log_togg">
            <ul class="logsec_sidenav">
                <li><a href="#">Login</a></li>
                <li class="side_joinnow"><a href="#">Join US</a></li>
                <li class="right_menu_heading show-for-medium-only">Select Language</li>
                <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
            </ul>
        </nav>

        <nav id="menu">
            <ul>
                <!--
                <li class="region_side_icon"></li>
                <li class="region_side_icon"><a href="beijing.html">Beijing</a></li>
                <li class="region_side_icon"><a href="shanghai.html">Shanghai</a></li>
                <li class="region_side_icon"><a href="guangzhou.html">Guangzhou</a></li>
                <li class="region_side_icon"><a href="hongkong.html">Hong Kong</a></li>
-->
                <!--                <li class="right_menu_heading show-for-small-only">Select Language</li>-->
                <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                <!--               <li class="right_menu_heading inlineblock_element">Select Location</li>-->
                <li class="region_side_icon">
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                        <option value="index.html">Home</option>
                        <option value="beijing.html">Beijing</option>
                        <option value="shanghai.html">Shanghai</option>
                        <option value="guangzhou.html">Guangzhou</option>
                        <option value="hongkong.html">Hong Kong</option>
                    </select>
                </li>

                <li><a href="#about">ABOUT US</a>
                    <ul>
                        <li><a href="#">Who are we?</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">History</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Rules</a></li>
                        <li><a href="#">Board of Directors</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Guangzhou</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Management</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </li>
                <li><a href="#about">MEMBERSHIP</a>
                    <ul>
                        <li><a href="#">Why join us?</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Online Application</a></li>
                        <li><a href="#">Members Directory</a></li>
                        <li><a href="#">Investment Zones</a></li>
                        <li><a href="#">Member Benefits Program</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#about">EVENTS</a>
                    <ul>
                        <li><a href="#">Upcoming Events</a>

                        </li>
                        <li><a href="#">Events Calendar</a></li>
                        <li><a href="#">Events Overview</a>
                            <ul>
                                <li><a href="#">Beijing</a></li>
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Guangzhou</a></li>
                                <li><a href="#">Hong Kong</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#about">PUBLICATIONS</a>
                    <ul>
                        <li><a href="#">The Bridge</a></li>
                        <li><a href="#">Sino-Swiss Business News</a></li>
                        <li><a href="#">Reader’s Digest</a></li>
                        <li><a href="#">Legal & Investment Updates</a></li>
                        <li><a href="#">Invest in Switzerland</a></li>
                        <li><a href="#">BusinessPublications</a>
                            <ul>
                                <li><a href="#">economic report</a></li>
                                <li><a href="#">business sentiment survey</a></li>
                                <li><a href="#">embassy</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Other Links</a></li>
                    </ul>
                </li>
                <li><a href="#about">SERVICES</a>
                    <ul>
                        <li><a href="#">Our services</a></li>
                        <li><a href="#">Advertise With Us</a>
                            <ul>
                                <li><a href="#">SwissCham China</a></li>
                                <li><a href="#">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li><a href="#">JobOpportunities</a></li>
                        <li><a href="#">Training</a></li>
                        <li><a href="#">Lobbying Activities(IPR complaints, Social Security) Wechat?</a></li>
                    </ul>
                </li>
            </ul>
        </nav>


        </div>

        <a href="#0" class="cd-top">Top</a>




        <script src="bower_components/jquery/dist/jquery.js"></script>
        <script src="bower_components/what-input/what-input.js"></script>
        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/easyResponsiveTabs.js"></script>
        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
        <script type="text/javascript" src="js/pace.js"></script>
        <script type="text/javascript" src="js/jquery.steps.js?v=<?php echo time(); ?>"></script>
        <script type="text/javascript" src="js/member_registration.js"></script>
		  <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
		  <script type="text/javascript" src="js/registration.js"></script>
		  <script>
		  
		  /*  jQuery ready function. Specify a function to execute when the DOM is fully loaded.  */
$(document).ready(function (){
	$( "#individual_contact_dob" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  });
		  </script>
        <script type="text/javascript">
            $(function() {
                $('nav#menu').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: true,
                    counters: false,
                    "offCanvas": {
                        "position": "left"
                    },
                    navbar: {
                        title: 'SWISSCHAM'
                    },
                    navbars: [{
                        position: 'top',
                        content: ['searchfield']
                    }, {
                        position: 'top',
                        content: [
                            'prev',
                            'title',
                            'close'
                        ]
                    }, {
                        position: 'bottom',
                        content: [
                            //                        '<a href="http://mmenu.frebsite.nl/wordpress-plugin.html" target="_blank">WordPress plugin</a>'
                        ]
                    }]
                });
                $('nav#log_togg').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: false,
                    counters: false,
                    navbar: {
                        title: 'Welcome to Swisscham'
                    },

                });

            });

        </script>
        <script src="js/app.js?v=<?php echo time(); ?>"></script>
        <script>
            $(function() {
                $("#wizard").steps({
                    headerTag: "h2",
                    bodyTag: "section",
                    transitionEffect: "slideLeft"
                });
            });

        </script>
		<script>
		
		
		$('document').ready(function(){
			$('.stateDrop').change(function(){
				$('.b_no_member').hide();
			});
			$('#removebtn').click(function(){
				var addcnt=$('#addcnt').val();
				if(addcnt>0){
					var rmvid='adddiv_'+addcnt;
					$('#'+rmvid).remove();
					$('#rm').remove();
					addcnt--;
					if(addcnt>=0){
						$('#addcnt').val(addcnt);
						if(addcnt==0){
							$('#removediv').hide();
						}
					}
					
				}
			});
			$('#addmore').click(function(){
				var addcnt=$('#addcnt').val();
				var tc=addcnt;
				if(addcnt<2){
					
					addcnt++;
					$('#addcnt').val(addcnt);
					$('#removediv').show();
					$('#appenddiv').append('<div id="adddiv_'+addcnt+'"><h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other contact / assistant (in case you are unavailable)</h3><div class=""><div class="medium-12 columns membership_from second_form_field"><label></label><input type="radio" name="other_contact_title'+tc+'" value="Ms" checked><label for="info_asst_contact_miss"> Ms.</label><input type="radio" name="other_contact_title'+tc+'" value="Mr"><label for="info_asst_contact_mister"> Mr.</label><input type="radio" name="other_contact_title'+tc+'" value="Dr"><label for="info_asst_contact_doctor"> Dr.</label></div><div class="medium-6 columns application_form"><label> Family name:<span>*</span><div class="input-group"><input type="text" placeholder="Type your family name" name="other_contact_familyName[]" id="other_contact_familyName'+addcnt+'"></div></label></div><div class="medium-6 columns application_form"><label> Given name(s):<span>*</span><div class="input-group"><input type="text" placeholder="Type your given name(s)" name="other_contact_givenName[]" id="other_contact_givenName'+addcnt+'"></div></label></div><div class="medium-6 columns application_form"><label> Chinese name:<span>*</span><div class="input-group"><input type="text" placeholder="Type your Chinese name" name="other_contact_chineseName[]" id="other_contact_chineseName'+addcnt+'"></div></label></div><div class="medium-6 columns application_form"><label> Mobile:<span>*</span><div class="input-group"><input type="text" placeholder="Type your mobile number" name="other_contact_mobile[]" id="other_contact_mobile'+addcnt+'"></div></label></div><div class="medium-6 columns application_form"><label> Direct Phone:<span>*</span><div class="input-group"><input type="text" placeholder="Type your direct phone number" name="other_contact_directPhone[]" id="other_contact_directPhone'+addcnt+'"></div></label></div><div class="medium-6 columns application_form"><label> Direct E-mail:<span>*</span><div class="input-group"><input type="text" placeholder="Type your direct e-mail address" name="other_contact_directEmail[]" id="other_contact_directEmail'+addcnt+'"></div></label></div></div></div>');	
				}
			});
		});
		function showImage3(input,id)
		{ 
			var file=input.files[0];
			var filesize=file.size/1024;
			if(filesize<2000)
			{
			     $('#error_msg').html('');
			     if (input.files && input.files[0]) {
				    var reader = new FileReader();
				    reader.onload = function (e) {
					$('#preview_label_id').html('<label>Preview :</label>');
					$('#preview').show();
					$('#preview').attr('src', e.target.result).height(100);
				};
				reader.readAsDataURL(input.files[0]);
			}
			}
			else
			{
				$('#error_msg').html('File size must be less than 2Mb');
			}
		}
		</script>

</body>

</html>
