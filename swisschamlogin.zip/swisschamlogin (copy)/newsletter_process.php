<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
if($_POST){	
//print_r($_POST); //die;
$userId=$_SESSION["userId"];
if(!empty($_POST['newsletter'])){
$newsletter1='';
$newsletter_temp=$_POST['newsletter'];
$newsletter_count=count($_POST['newsletter']);
for($j=0;$j<$newsletter_count;$j++){
	$newsletter1=$newsletter1.','.$newsletter_temp[$j];
}
$newsletter=$newsletter1;
}
$newsLetterUpdate="UPDATE `sc_c_userdetails` SET 
						`newsletter`='$newsletter'
						WHERE `userId`='$userId' ";	
mysql_query($newsLetterUpdate);
header('Location: membership.php');

}
?>