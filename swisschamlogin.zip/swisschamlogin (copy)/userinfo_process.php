<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 

mysql_query("SET character_set_client=utf8")or die(mysql_error());
mysql_query("SET character_set_connection=utf8")or die(mysql_error());
$userId=$_SESSION['userId'];
$changes = array(); 

if($_POST){
$info=trim($_GET['info']);
//var_dump($_REQUEST); die;

switch ($info) {
case "personal": 
	$user_title = isset($_REQUEST['user_title'])?addslashes(trim($_REQUEST['user_title'])):"";
	$year_of_birth = isset($_REQUEST['year_of_birth'])?addslashes(trim($_REQUEST['year_of_birth'])):"";
	$year_of_birth = date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['family_name'])?addslashes(trim($_REQUEST['family_name'])):"";
	$given_name = isset($_REQUEST['given_name'])?addslashes(trim($_REQUEST['given_name'])):"";
	$chinese_name = isset($_REQUEST['chinese_name'])?addslashes(trim($_REQUEST['chinese_name'])):"";
	$nationality = isset($_REQUEST['nationality'])?addslashes(trim($_REQUEST['nationality'])):"";
	$address_english = isset($_REQUEST['address_english'])?addslashes(trim($_REQUEST['address_english'])):"";
	$city_english = isset($_REQUEST['city_english'])?addslashes(trim($_REQUEST['city_english'])):"";
	$province_area = isset($_REQUEST['province_area'])?addslashes(trim($_REQUEST['province_area'])):"";
	$address_chinese = isset($_REQUEST['address_chinese'])?addslashes(trim($_REQUEST['address_chinese'])):"";
	$city_chinese = isset($_REQUEST['city_chinese'])?addslashes(trim($_REQUEST['city_chinese'])):"";
	$zip_code_english = isset($_REQUEST['zip_code_english'])?addslashes(trim($_REQUEST['zip_code_english'])):"";
	$positionIn_company = isset($_REQUEST['positionIn_company'])?addslashes(trim($_REQUEST['positionIn_company'])):"";
	$direct_phone = isset($_REQUEST['direct_phone'])?addslashes(trim($_REQUEST['direct_phone'])):"";
	$mobile_phone = isset($_REQUEST['mobile_phone'])?addslashes(trim($_REQUEST['mobile_phone'])):"";
	//$direct_email = isset($_REQUEST['direct_email'])?addslashes(trim($_REQUEST['direct_email'])):"";
	
	$npo_organization_type = isset($_REQUEST['npo_organization_type'])?addslashes(trim($_REQUEST['npo_organization_type'])):"";
	$npo_organization_description = isset($_REQUEST['npo_organization_description'])?addslashes(trim($_REQUEST['npo_organization_description'])):"";
	
	$media_type = isset($_REQUEST['media_type'])?addslashes(trim($_REQUEST['media_type'])):"";
	$media_description = isset($_REQUEST['media_description'])?addslashes(trim($_REQUEST['media_description'])):"";
	
	if((isset($_FILES['profile_picture']['name'])) && (!empty($_FILES['profile_picture']['name']))){
      $errors= array();
      $file_name = $_FILES['profile_picture']['name'];
      $file_size =$_FILES['profile_picture']['size'];
      $file_tmp =$_FILES['profile_picture']['tmp_name'];
      $file_type=$_FILES['profile_picture']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['profile_picture']['name'])));
      $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $file_name="profile_picture".time().$file_ext;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $profile_picture="uploads/".$file_name; 
         $profile_picture1=$file_name; 
      }else{
		 header('Location: membership.php#eventListTab2|ChildVerticalTab_12');
      }
	} else{
	   $profile_picture="";
	   $profile_picture1="";
	}

        //--get the user data from database
        $selSql = "SELECT * FROM `sc_c_userdetails` WHERE `userId` = $userId"; $selRows = mysql_query($selSql);
        if(mysql_num_rows($selRows) > 0){
          while ($row = mysql_fetch_assoc($selRows)) { 
             if($row['user_title'] != $user_title){ $changes["user_title"] = $user_title; }
             if($row['year_of_birth'] != $year_of_birth){ $changes["year_of_birth"] = $year_of_birth; }
             if($row['family_name'] != $family_name){ $changes["family_name"] = $family_name; }
             if($row['given_name'] != $given_name){ $changes["given_name"] = $given_name; }
             if($row['chinese_name'] != $chinese_name){ $changes["chinese_name"] = $chinese_name; }
             if($row['nationality'] != $nationality){ $changes["nationality"] = $nationality; }
             if($row['positionIn_company'] != $positionIn_company){ $changes["positionIn_company"] = $positionIn_company; }
             if($row['address_english'] != $address_english){ $changes["address_english"] = $address_english; }
             if($row['city_english'] != $city_english){ $changes["city_english"] = $city_english; } 
             if($row['province_area'] != $province_area){ $changes["province_area"] = $province_area; }
             if($row['address_chinese'] != $address_chinese){ $changes["address_chinese"] = $address_chinese; }
             if($row['city_chinese'] != $city_chinese){ $changes["city_chinese"] = $city_chinese; }
             if($row['zip_code_english'] != $zip_code_english){ $changes["zip_code_english"] = $zip_code_english; }
             if($row['direct_phone'] != $direct_phone){ $changes["direct_phone"] = $direct_phone; }
             if($row['mobile_phone'] != $mobile_phone){ $changes["mobile_phone"] = $mobile_phone; }
             //if($row['direct_email'] != $direct_email){ $changes["direct_email"] = $direct_email; }
             if($row['npo_organization_type'] != $npo_organization_type){ 
                                       $changes["npo_organization_type"] = $npo_organization_type; }
             if($row['npo_organization_description'] != $npo_organization_description){ 
                                       $changes["npo_organization_description"] = $npo_organization_description; }
             if($row['media_type'] != $media_type){ $changes["media_type"] = $media_type; }
             if($row['media_description'] != $media_description){ $changes["media_description"] = $media_description; }
          }
        } 

	if($profile_picture1!=''){
	   $personalSql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."',
		                     `profile_picture`='".$profile_picture."'
		               WHERE `userId` = '".$userId."'";
	} else{
	   $personalSql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."'
		               WHERE `userId` = '".$userId."'"; 
	}

	mysql_query($personalSql);

	if($npo_organization_type!=''){
	$npoPersonalSql="UPDATE `sc_c_userdetails`
		                 SET `npo_organization_type`='".$npo_organization_type."',
		                     `npo_organization_description`='".$npo_organization_description."'
		               WHERE `userId` = '".$userId."'"; 
	mysql_query($npoPersonalSql);
	}
	
	if($media_type!=''){
	$jrnlPersonalSql="UPDATE `sc_c_userdetails`
		                 SET `media_type`='".$media_type."',
		                     `media_description`='".$media_description."'
		               WHERE `userId` = '".$userId."'"; 
	mysql_query($jrnlPersonalSql);
	}
	
	$updated_date=date("Y-m-d");
	$updateCompanyQuery="UPDATE `sc_c_userdetails`
				SET `updated_by`='".$userId."',
				 `updated_date`='".$updated_date."'
				WHERE `userId`='".$userId."'";
	mysql_query($updateCompanyQuery);

        //--mail being sent to admin email. 
        if(!empty($changes)){
         $to  = 'info@bei.swisscham.org'; //$to  = $email;
	 $subject = 'Changes Made To User Profile:'.$family_name.'-'.$given_name;
	 $message = '<!DOCTYPE HTML><html>
		    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                    <title>Profile Changes</title></head>';
         $message .= '<body><table width="600" cellpadding="0" cellspacing="0" style="border-collapse:collapse" align="center">
		     <tr><td><img src="http://www.swisschamofcommerce.com/swisschamlogin/images/logo.png" style="display:block"></td></tr>';
         $message .= '<tr style="text-align:left;font-size:20px;color:#009fff">
			<td style="padding-top:30px;">Member Name:'.$family_name.'-'.$given_name.'</td></tr>
                     <tr style="text-align:left;font-size:18px;color:#009fff">
			<td style="padding-top:30px;padding-bottom:30px;"> The following changes have been made in Personal Section</td></tr>';
         $message .= '<hr/>'; 
         foreach($changes as $key => $change){ 
           $message .= '<tr style="text-align:left;font-size:16px;color:#aa8095">
			  <td style="padding-top:17px;padding-bottom:5px; font-family:arial; color:#333;">'; 
           $message .= $key.' : '. $change;
           $message .= '<hr/>';
	   $message .= '</td></tr>'; 
         }
         $message .= '<tr style="text-align:center; height:30px;"><td></td></tr>';							
         $message .= '<tr style="text-align:center;font-size:14px;">
		      <td style="height:30px; color:#fff; background:#306C9E; padding-top:20px; padding-bottom:20px;">All rights reserved,2016.Swiss Chinese Chamber of Commerce</td></tr>';
         $message .= '</table></body></html>';
						
	 $headers = "MIME-Version: 1.0" . "\r\n";
	 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";					
	 $headers .= "From: info@bei.swisscham.org\r\n";
	 @mail($to, $subject, $message, $headers);
        }
	
	header('Location: membership.php#eventListTab2|ChildVerticalTab_12');
	break;

case "account":
	$admin_generated_userId = isset($_REQUEST['admin_generated_userId'])?addslashes(trim($_REQUEST['admin_generated_userId'])):"";
	$admin_generated_password = isset($_REQUEST['admin_generated_password'])?addslashes(trim($_REQUEST['admin_generated_password'])):"";
	$language = isset($_REQUEST['language'])?addslashes(trim($_REQUEST['language'])):"";
	if($admin_generated_password == '' ){
            
		$accountSql = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."'
		               WHERE `userId` = '".$userId."'";
	} else{
            
            
		$accountSql_change = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."',
		                     `admin_generated_password`='".$admin_generated_password."'
		               WHERE `userId` = '".$userId."'";	
                $res = mysql_query($accountSql_change);
                
                require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
                
                $rs_USERID=$wpdb->get_row("SELECT  * FROM  `sc_users` where `user_login`='".$admin_generated_userId."'");
                $user_id =  $rs_USERID->ID;
                if($user_id!='') {
                wp_set_password( $admin_generated_password, $user_id );
                 }
                 
	}

        //--get the user data from database
        $selSql = "SELECT * FROM `sc_c_userdetails` WHERE `userId` = $userId"; $selRows = mysql_query($selSql);
        if(mysql_num_rows($selRows) > 0){ $family_name = ""; $given_name = "";
          while ($row = mysql_fetch_assoc($selRows)) { 
             $family_name = $row['family_name']; $given_name = $row['given_name'];
             if($row['admin_generated_userId'] != $admin_generated_userId){ $changes["admin_generated_userId"] = $admin_generated_userId; }
             if($row['admin_generated_password'] != $admin_generated_password){ $changes["admin_generated_password"] = $admin_generated_password; }
             if($row['language'] != $language){ $changes["language"] = $language; }
          }
        } 

	$res = mysql_query($accountSql);

	$updated_date=date("Y-m-d");
	$updateCompanyQuery="UPDATE `sc_c_userdetails`
				SET `updated_by`='".$userId."',
				 `updated_date`='".$updated_date."'
				WHERE `userId`='".$userId."'";
	mysql_query($updateCompanyQuery);

        //--mail being sent to admin email. 
        if(!empty($changes)){
         $to  = 'info@bei.swisscham.org'; //$to  = $email;
	 $subject = 'Changes Made To User Account Settings:'.$family_name.'-'.$given_name;
	 $message = '<!DOCTYPE HTML><html>
		    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                    <title>Profile Changes</title></head>';
         $message .= '<body><table width="600" cellpadding="0" cellspacing="0" style="border-collapse:collapse" align="center">
		     <tr><td><img src="http://www.swisschamofcommerce.com/swisschamlogin/images/logo.png" style="display:block"></td></tr>'; 
         $message .= '<tr style="text-align:left;font-size:20px;color:#009fff">
			<td style="padding-top:30px;">Member Name: '.$family_name.'-'.$given_name.'</td></tr> 
		     <tr style="text-align:left;font-size:18px;color:#009fff">
			<td style="padding-top:30px;padding-bottom:30px;"> The following changes have been made in Accounts Section</td></tr>';
         $message .= '<hr/>';
         foreach($changes as $key => $change){ 
           $message .= '<tr style="text-align:left;font-size:16px;color:#aa8095">
			  <td style="padding-top:17px; padding-bottom:5px; font-family:arial; color:#333;">'; 
           $message .= $key.' : '. $change;
           $message .= '<hr/>';
	   $message .= '</td></tr>'; 
         }
         $message .= '<tr style="text-align:center;height:30px;"><td></td></tr>';									
         $message .= '<tr style="background:#306C9E;color:#fff;text-align:center;font-size:14px;">
		      <td style="height:30px; color:#fff;">All rights reserved,2016.Swiss Chinese Chamber of Commerce </td></tr>';
         $message .= '</table></body></html>';
						
	 $headers = "MIME-Version: 1.0" . "\r\n";
	 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";					
	 $headers .= "From: info@bei.swisscham.org\r\n";
	 @mail($to, $subject, $message, $headers);
        }

	header('Location: membership.php#eventListTab2|ChildVerticalTab_11');
	break;


case "other":
	$otherDeleteQuery="DELETE FROM `sc_c_other_contact` WHERE `userId` = '".$userId."'";
	mysql_query($otherDeleteQuery);
	$compsnyORnot=$_REQUEST['compsnyORnot'];
	if($compsnyORnot==0){
	$cnt = count($_REQUEST['other_contact_familyName']);
	for($i=0;$i<$cnt;$i++){
		$j=$i+1;
		$other_contact_title = isset($_REQUEST['other_contact_title'.$j])?addslashes($_REQUEST['other_contact_title'.$j]):"";
        $other_contact_dob = isset($_REQUEST['other_contact_dob'][$i])?addslashes($_REQUEST['other_contact_dob'][$i]):"";
	    $other_contact_dob = date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName = isset($_REQUEST['other_contact_familyName'][$i])?addslashes($_REQUEST['other_contact_familyName'][$i]):"";
		$other_contact_givenName = isset($_REQUEST['other_contact_givenName'][$i])?addslashes($_REQUEST['other_contact_givenName'][$i]):"";
		$other_contact_chineseName = isset($_REQUEST['other_contact_chineseName'][$i])?addslashes($_REQUEST['other_contact_chineseName'][$i]):"";
        
		$other_contact_nationality = isset($_REQUEST['other_contact_nationality'.$j])?addslashes($_REQUEST['other_contact_nationality'.$j]):"";
		$other_contact_address_english = isset($_REQUEST['other_contact_address_english'][$i])?addslashes($_REQUEST['other_contact_address_english'][$i]):"";
		$other_contact_city_english = isset($_REQUEST['other_contact_city_english'][$i])?addslashes($_REQUEST['other_contact_city_english'][$i]):"";
		$other_contact_province_area = isset($_REQUEST['other_contact_province_area'][$i])?addslashes($_REQUEST['other_contact_province_area'][$i]):"";
		$other_contact_address_chinese = isset($_REQUEST['other_contact_address_chinese'][$i])?addslashes($_REQUEST['other_contact_address_chinese'][$i]):"";
		$other_contact_city_chinese = isset($_REQUEST['other_contact_city_chinese'][$i])?addslashes($_REQUEST['other_contact_city_chinese'][$i]):"";
		$other_contact_zipCode = isset($_REQUEST['other_contact_zipCode'][$i])?addslashes($_REQUEST['other_contact_zipCode'][$i]):"";
		$other_contact_mobile = isset($_REQUEST['other_contact_mobile'][$i])?addslashes($_REQUEST['other_contact_mobile'][$i]):"";
		$other_contact_directPhone = isset($_REQUEST['other_contact_directPhone'][$i])?addslashes($_REQUEST['other_contact_directPhone'][$i]):"";
		$other_contact_directEmail = isset($_REQUEST['other_contact_directEmail'][$i])?addslashes($_REQUEST['other_contact_directEmail'][$i]):"";
		
		$otherContactSql = "INSERT INTO `sc_c_other_contact`
					SET `userId`='".$userId."',
					 `other_contact_title`='".$other_contact_title."',
					 `other_contact_dob`='".$other_contact_dob."',
					 `other_contact_familyName`='".$other_contact_familyName."',
					 `other_contact_givenName`='".$other_contact_givenName."',
					 `other_contact_chineseName`='".$other_contact_chineseName."',
					 `other_contact_nationality`='".$other_contact_nationality."',
					 `other_contact_address_english`='".$other_contact_address_english."',
					 `other_contact_city_english`='".$other_contact_city_english."',
					 `other_contact_province_area`='".$other_contact_province_area."',
					 `other_contact_address_chinese`='".$other_contact_address_chinese."',
					 `other_contact_city_chinese`='".$other_contact_city_chinese."',
					 `other_contact_zipCode`='".$other_contact_zipCode."',
					 `other_contact_mobile`='".$other_contact_mobile."',
					 `other_contact_directPhone`='".$other_contact_directPhone."',
					 `other_contact_directEmail`='".$other_contact_directEmail."'";
		mysql_query($otherContactSql);	
	}
	} else if($compsnyORnot==1){
		$cnt = count($_REQUEST['other_contact_familyNamec']);
		for($i=0;$i<$cnt;$i++){
		$j=$i+1;
		$other_contact_title = isset($_REQUEST['other_contact_titlec'.$j])?addslashes($_REQUEST['other_contact_titlec'.$j]):"";
        $other_contact_dob = isset($_REQUEST['other_contact_dobc'][$i])?addslashes($_REQUEST['other_contact_dobc'][$i]):"";
	    $other_contact_dob = date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName = isset($_REQUEST['other_contact_familyNamec'][$i])?addslashes($_REQUEST['other_contact_familyNamec'][$i]):"";
		$other_contact_givenName = isset($_REQUEST['other_contact_givenNamec'][$i])?addslashes($_REQUEST['other_contact_givenNamec'][$i]):"";
		$other_contact_chineseName = isset($_REQUEST['other_contact_chineseNamec'][$i])?addslashes($_REQUEST['other_contact_chineseNamec'][$i]):"";
        
		$other_contact_nationality = isset($_REQUEST['other_contact_nationalityc'.$j])?addslashes($_REQUEST['other_contact_nationalityc'.$j]):"";
		$other_contact_position = isset($_REQUEST['other_contact_positionc'][$i])?addslashes($_REQUEST['other_contact_positionc'][$i]):"";
		$other_contact_address_english = isset($_REQUEST['other_contact_address_englishc'][$i])?addslashes($_REQUEST['other_contact_address_englishc'][$i]):"";
		$other_contact_city_english = isset($_REQUEST['other_contact_city_englishc'][$i])?addslashes($_REQUEST['other_contact_city_englishc'][$i]):"";
		$other_contact_province_area = isset($_REQUEST['other_contact_province_areac'][$i])?addslashes($_REQUEST['other_contact_province_areac'][$i]):"";
		$other_contact_address_chinese = isset($_REQUEST['other_contact_address_chinesec'][$i])?addslashes($_REQUEST['other_contact_address_chinesec'][$i]):"";
		$other_contact_city_chinese = isset($_REQUEST['other_contact_city_chinesec'][$i])?addslashes($_REQUEST['other_contact_city_chinesec'][$i]):"";
		$other_contact_zipCode = isset($_REQUEST['other_contact_zipCodec'][$i])?addslashes($_REQUEST['other_contact_zipCodec'][$i]):"";
		$other_contact_mobile = isset($_REQUEST['other_contact_mobilec'][$i])?addslashes($_REQUEST['other_contact_mobilec'][$i]):"";
		$other_contact_directPhone = isset($_REQUEST['other_contact_directPhonec'][$i])?addslashes($_REQUEST['other_contact_directPhonec'][$i]):"";
		$other_contact_directEmail = isset($_REQUEST['other_contact_directEmailc'][$i])?addslashes($_REQUEST['other_contact_directEmailc'][$i]):"";
		
		$otherContactSql = "INSERT INTO `sc_c_other_contact`
					SET `userId`='".$userId."',
					 `other_contact_title`='".$other_contact_title."',
					 `other_contact_dob`='".$other_contact_dob."',
					 `other_contact_familyName`='".$other_contact_familyName."',
					 `other_contact_givenName`='".$other_contact_givenName."',
					 `other_contact_chineseName`='".$other_contact_chineseName."',
					 `other_contact_nationality`='".$other_contact_nationality."',
					 `other_contact_position`='".$other_contact_position."',
					 `other_contact_address_english`='".$other_contact_address_english."',
					 `other_contact_city_english`='".$other_contact_city_english."',
					 `other_contact_province_area`='".$other_contact_province_area."',
					 `other_contact_address_chinese`='".$other_contact_address_chinese."',
					 `other_contact_city_chinese`='".$other_contact_city_chinese."',
					 `other_contact_zipCode`='".$other_contact_zipCode."',
					 `other_contact_mobile`='".$other_contact_mobile."',
					 `other_contact_directPhone`='".$other_contact_directPhone."',
					 `other_contact_directEmail`='".$other_contact_directEmail."'";
		mysql_query($otherContactSql);	
	}
		
	}
	$updated_date=date("Y-m-d");
	$updateCompanyQuery="UPDATE `sc_c_userdetails`
				SET `updated_by`='".$userId."',
				 `updated_date`='".$updated_date."'
				WHERE `userId`='".$userId."'";
	mysql_query($updateCompanyQuery);

	header('Location: membership.php#eventListTab2|ChildVerticalTab_13');
	break;

	
default:

	header('Location: membership.php');
	break;

} // end of switch-case

}
?>