<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
if($_GET){
$id=$_GET['id'];
$sql="SELECT * FROM `sc_c_userdetails`,`sc_c_company_details` 
			   WHERE `sc_c_userdetails`.`userId`=`sc_c_company_details`.`userId`
			   AND `sc_c_userdetails`.`userId`=$id";
$res=mysql_query($sql);
$Result=mysql_fetch_array($res);

?>
    <!doctype html>
    <html class="no-js" lang="en">

    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Swisscham | Member Directory</title>
        <link rel="stylesheet" href="css/app.css">
        <link rel="stylesheet" href="css/dev1.css">
        <!-- Favicon -->
		<link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
    </head>

    <body>
        <div id="page">
            <?php 
		require_once(__ROOT__.'/includes/header.php'); 
		?>
                <div class="abc"></div>
                <section class="inner_banner bg-beijing hide-for-small-only">
                    <div class="inner_bredcrumb">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs page_bredcrunb">
                                <li><a href="<?=$site_url?>">Home</a></li>
                                <li><a href="#">Membership</a></li>
                                <li><a href="<?=$base_url?>member_directory_general_page.php"><span class="show-for-sr">Current: </span> Members Directory</a></li>
                            </ul>
                        </nav>
                    </div>
                </section>
                <section>
                    <div class="row" data-equalizer data-equalize-on="medium">
                        <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                            <div class="large-12 columns dowedo_top">
                                <h1 class="common_heading">Members Directory</h1>
                            </div>
                            <div class="large-12 columns dowedo_top">
                                <h1 class="common_heading2"><?php if(!empty($Result['company_name_english'])){ echo $Result['company_name_english'];}?></h1>
                            </div>
                            <div class="large-12 columns dowedo_top">
                                <div class="large-12 columns directory_large">
                                    <div class="large-3 columns small_padding">
                                        <p class="text-center directory_logo">
                                            <?php if(!empty($Result['logo_name'])){?><img src="<?=$Result['logo_name']?>" />
                                                <?php } else{?><img src="images/imgpsh_fullsize.jpg" />
                                                    <?php } ?>
                                        </p>
                                    </div>
                                    <div class="large-9 columns directory_item_details small_padding">
                                        <h2><?php if(!empty($Result['company_name_english'])){ echo $Result['company_name_english'];}?></h2>
                                        <h4><?php if(!empty($Result['company_name_chinese'])){ echo $Result['company_name_chinese'];}?></h4>
                                        <h3 class="common_subheading"><?php if(!empty($Result['business_scope'])){ 
                                            if($Result['business_scope']=='Other'){ echo $Result['other_business_scope'];} else{ echo $Result['business_scope'];}
                                            }?></h3>
                                        <!--<h3 class="">农业/食�?/饮料</h3>-->
                                        <h4>Member in: <span><?php if(!empty($Result['company_chamber'])){ echo $Result['company_chamber'];}?></span></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="large-12 columns dowedo_top">
                                <h3 class="common_subheading ">business activity</h3>
                                <p>
                                    <?php if(!empty($Result['business_description_english'])){ echo $Result['business_description_english'];}else{ echo 'NA'; }?>
                                </p>
                                <p class="">
                                    <?php if(!empty($Result['business_description_chinese'])){ echo $Result['business_description_chinese'];} else {echo 'NA';}?>
                                </p>
                            </div>
<div class="large-12 columns dowedo_top no_padding margin_top10">



    <div class="large-6 columns dowedo_top">
        <h3 class="common_subheading ">Company Information</h3>
        <?php 
        $otherCompanyContactSqlSingle = mysql_query("SELECT * FROM `sc_c_company_other_contact_details` WHERE `company_id`='".$Result['company_id']."'");

        $number_of_rows = mysql_num_rows($otherCompanyContactSqlSingle);
        ?>
        <?php if($number_of_rows==0) { ?>
        <div class="contact_container">
        <div class="large-12 columns no_padding">
                        <div class="large-6 columns small_padding">
                            <ul class="directory_address">
                                <li id="comp_name">
                                    <h2><span><i aria-hidden="true" class="fa fa-building-o"></i></span> 
                                        <?php if(!empty($Result['company_name_english'])){ echo $Result['company_name_english'];} 
                                        else { echo 'NA'; }?></h2></li>
                                <li>
                                    <p id="comp_add">
                                        <span><i aria-hidden="true" class="fa fa-home"></i></span>
                                            <?php if(!empty($Result['company_address'])){ echo $Result['company_address'];} 
                                            else {?><?php echo 'NA';}?>
                                    </p>
                                </li>
                                <li>
                                    <h4><i class="fa fa-phone-square" aria-hidden="true"></i> 
                                        <?php if(!empty($Result['company_generalPhone'])){ echo $Result['company_generalPhone'];}  
                                        else { ?> &nbsp;&nbsp;<?php echo 'NA'; }?></h4></li>
                                <li>
                                    <h4><i class="fa fa-globe" aria-hidden="true"></i> <?php if(!empty($Result['company_website'])){ ?><a href="<?php if(!empty($Result['company_website'])){ echo 'http://'.$Result['company_website'];}?>" target="blank"><?php  echo $Result['company_website'];?></a><?php } 
                                    else {?> &nbsp; <a href="#"> <?php echo 'NA'; } ?></a></h4></li>
                            </ul>
                        </div>
                        <div class="large-6 columns small_padding">
                            <ul class="directory_address">
                                <li>
                                    <h2><?php if(!empty($Result['company_name_chinese'])){ echo $Result['company_name_chinese'];} ?></h2></li>
                                <li>
                                    <p id="china_off_add">
                                        <?php if(!empty($Result['china_office_address'])){ echo $Result['china_office_address'];}  ?>
                                    </p>
                                </li>
                                <!--<li>
                                    <h4><i class="fa fa-phone-square" aria-hidden="true"></i> <?php if(!empty($Result['company_generalPhone'])){ echo $Result['company_generalPhone'];}?></h4></li>
                                <li>
                                    <h4><i class="fa fa-globe" aria-hidden="true"></i><?php if(!empty($Result['company_website'])){ echo $Result['company_website'];}?></h4></li>-->
                            </ul>
                        </div>
                    </div>
        </div>
        <?php } else { ?>
        <div id="accordion-container">
            <!-- ITEM 1 -->
            <div class="accordion-header Company<?=$i?>" onclick="myFunction()">Company 1</div>

            <div class="accordion-content">
                <div class="accordion_content">
                    <div class="large-12 columns no_padding">
                        <div class="large-6 columns small_padding">
                            <ul class="directory_address">
                                <li id="comp_name">
                                    <h2><span><i aria-hidden="true" class="fa fa-building-o"></i></span> <?php if(!empty($Result['company_name_english'])){ echo $Result['company_name_english'];}?></h2></li>
                                <li id="comp_add">
                                    <p >
                                        <span><i aria-hidden="true" class="fa fa-home"></i></span><?php if(!empty($Result['company_address'])){ echo $Result['company_address'];}?>
                                    </p>
                                </li>
                                <li>
                                    <h4><i class="fa fa-phone-square" aria-hidden="true"></i> <?php if(!empty($Result['company_generalPhone'])){ echo $Result['company_generalPhone'];}?></h4></li>
                                <li>
                                    <h4><i class="fa fa-globe" aria-hidden="true"></i> <?php if(!empty($Result['company_website'])){ echo $Result['company_website'];}?></h4></li>
                            </ul>
                        </div>
                        <div class="large-6 columns small_padding">
                            <ul class="directory_address">
                                <li>
                                    <h2><?php if(!empty($Result['company_name_chinese'])){ echo $Result['company_name_chinese'];}?></h2></li>
                                <li id="china_off_add">
                                    <p >
                                        <?php if(!empty($Result['china_office_address'])){ echo $Result['china_office_address'];}?>
                                    </p>
                                </li>
                                <li>
                                    <h4><i class="fa fa-phone-square" aria-hidden="true"></i> <?php if(!empty($Result['company_generalPhone'])){ echo $Result['company_generalPhone'];}?></h4></li>
                                <li>
                                    <h4><i class="fa fa-globe" aria-hidden="true"></i> <?php if(!empty($Result['company_website'])){ echo $Result['company_website'];}?></h4></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $i=2;
             $otherCompanyContactSql = "SELECT * FROM `sc_c_company_other_contact_details` WHERE `company_id`='".$Result['company_id']."'";
            $resOther=mysql_query($otherCompanyContactSql);
            while($otherResult=mysql_fetch_array($resOther)){
            ?>
<!-- ITEM 2 -->
<div class="accordion-header Company<?=$i?>">Company <?=$i?></div>
<div class="accordion-content">
    <div class="accordion_content">
        <div class="large-12 columns no_padding">
            <div class="large-6 columns small_padding">
                <ul class="directory_address">
                    <li id="other_comp_name_<?=$i?>">
                        <span style="float: left;"><i aria-hidden="true" class="fa fa-building-o"></i></span><h2><?php if(!empty($otherResult['other_company_name_english'])){ echo $otherResult['other_company_name_english'];}?></h2></li>
                    <li id="other_comp_add_<?=$i?>">
                        <p>
                           <span><i aria-hidden="true" class="fa fa-home"></i></span> <?php if(!empty($otherResult['other_company_address'])){ echo $otherResult['other_company_address'];}?>
                        </p>
                    </li>
                    <li>
                        <h4><i class="fa fa-phone-square" aria-hidden="true"></i> <?php if(!empty($otherResult['other_company_generalPhone'])){ echo $otherResult['other_company_generalPhone'];}?></h4></li>
                    <li>
                        <h4><i class="fa fa-globe" aria-hidden="true"></i> <?php if(!empty($otherResult['other_company_website'])){ echo $otherResult['other_company_website'];}?></h4></li>
                </ul>
            </div>
            <div class="large-6 columns small_padding">
                <ul class="directory_address">
                    <li>
                        <h2><?php if(!empty($otherResult['other_company_name_chinese'])){ echo $otherResult['other_company_name_chinese'];}?></h2></li>
                    <li id="other_china_add_<?=$i?>">
                        <p>
                            <?php if(!empty($otherResult['other_china_office_address'])){ echo $otherResult['other_china_office_address'];}?>
                        </p>
                    </li>
                    <li>
                        <h4><i class="fa fa-phone-square" aria-hidden="true"></i> <?php if(!empty($otherResult['other_company_generalPhone'])){ echo $otherResult['other_company_generalPhone'];}?></h4></li>
                    <li>
                        <h4><i class="fa fa-globe" aria-hidden="true"></i> <?php if(!empty($otherResult['other_company_website'])){ echo $otherResult['other_company_website'];}?></h4></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php 
                    $i++;
                    } ?>
    <!-- ITEM 3 -->


        </div>

        <?php } ?>
    </div>
    <div class="large-6 columns dowedo_top">
        <div class="contact_add_tag">Headquarter Information</div>
        <div class="contact_container">
            <div class="contact_details">
                <h2><span><i class="fa fa-building-o" aria-hidden="true"></i></span><?php if(!empty($Result['headquarter_name'])){ echo $Result['headquarter_name'];} else { echo ' '.'NA'; }?></h2>
                <!--<h2><span><i class="fa fa-user" aria-hidden="true"></i></span> 中国瑞士商会 - 上海</h2>-->
                <h3><span><i class="fa fa-home" aria-hidden="true"></i></span> <?php if(!empty($Result['headquarter_address'])){ echo $Result['headquarter_address'];} else { echo 'NA'; }?></h3>
                <!-- <h3><span><i class="fa fa-home" aria-hidden="true"></i></span> 中国上海市黄浦区黄河路21�?� <br />鸿祥大厦1133室 <br />邮编：200003</h3>-->
            </div>
            <div class="contact_link">
                <ul class="fa-ul no-bullet">
                    <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span>
                        <?php if(!empty($Result['headquarter_phone'])){ echo $Result['headquarter_phone'];} else { echo 'NA'; }?>
                    </li>
                    <!--<li><span><i class="fa fa-envelope" aria-hidden="true"></i></span> Email / 邮件: <?php //if(!empty($Result['headquarter_address'])){ echo $Result['headquarter_address'];}?></li>-->
                </ul>
            </div>

        </div>
    </div>

</div>
<div class="large-12 columns dowedo_top">
    <!--<h3 class="common_subheading border_subheading">Head Office</h3>--><br/>
    <input type="hidden" name="addressInChinese" id="addressInChinese" value="<?php echo $Result['china_office_address'];?>" />
    <input type="hidden" name="addressInEnglish" id="addressInEnglish" value="<?=$Result['company_address']?>" />
    <input type="hidden" name="nameInEnglish" id="nameInEnglish" value="<?=$Result['company_name_english']?>" />
    <div class="large-12 columns map_container">
        <!-- <div >-->
        <div class="map_div" style="width:100%;height:250px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>

        <!--<img src="images/map.jpg" />-->
    </div>
    <!--</div>--> <br/><br/>
</div>

<div class="large-12 columns dowedo_top margin_top10">
    <div class="large-6 columns">
        <h3 class="common_subheading border_subheading">Main Contact</h3>
        <ul class="member_bottom_contact">
            <li>
                <div>
                    <h3><i class="fa fa-building-o" aria-hidden="true"></i><?php if(!empty($Result['given_name'])){ echo $Result['given_name']." ".$Result['family_name'];} else { echo 'NA';}?></h3>
                    <p><i class="fa fa-user" aria-hidden="true"></i><?php if(!empty($Result['positionIn_company'])){ echo $Result['positionIn_company'];} else { echo 'NA';}?></p>
                    <p><i class="fa fa-phone-square" aria-hidden="true"></i><?php if(!empty($Result['direct_phone'])){ echo $Result['direct_phone'];} else { echo 'NA';}?></p>
                    <p><i class="fa fa-envelope" aria-hidden="true"></i>
                         <?php if(!empty($Result['direct_email'])){ ?>
                        <a href="mailto:<?php if(!empty($Result['direct_email'])){ echo $Result['direct_email'];}?>">
                       <?php echo $Result['direct_email'];?>
                        </a><?php } else { ?> <a href="#"> <?php echo 'NA';?></a> <?php } ?></p>

                </div>
            </li>
            <!-- <li>
        <div>
            <h3><i class="fa fa-angle-right" aria-hidden="true"></i> Name 1</h3>
            <p><i class="fa fa-user" aria-hidden="true"></i> Position</p>
            <p><i class="fa fa-phone-square" aria-hidden="true"></i> 123456789</p>
            <p><i class="fa fa-envelope" aria-hidden="true"></i> Email@email.com</p>

        </div>
    </li>
    <li>
        <div>
            <h3><i class="fa fa-angle-right" aria-hidden="true"></i> Name 1</h3>
            <p><i class="fa fa-user" aria-hidden="true"></i> Position</p>
            <p><i class="fa fa-phone-square" aria-hidden="true"></i> 123456789</p>
            <p><i class="fa fa-envelope" aria-hidden="true"></i> Email@email.com</p>

        </div>
    </li>-->
        </ul>
    </div>
    <div class="large-6 columns">
        <h3 class="common_subheading border_subheading">Other Contact</h3>
        <ul class="member_bottom_contact">
            <?php
                            $otherContactSql="SELECT * FROM `sc_c_other_contact` WHERE `userId`='".$Result['userId']."'";
                            $resOtherContact=mysql_query($otherContactSql);
                            $numvalue=mysql_num_rows($resOtherContact);
                            if($numvalue>0)
                            {
                            while($otherContactResult=mysql_fetch_array($resOtherContact)){
                            ?>

                <li>
                    <div>
                        <h3><i class="fa fa-building-o" aria-hidden="true"></i><?php if(!empty($otherContactResult['other_contact_givenName'])){ echo $otherContactResult['other_contact_givenName']." ".$otherContactResult['other_contact_familyName'];} else { echo 'NA'; }?></h3>
                        <p><i class="fa fa-user" aria-hidden="true"></i><?php if(!empty($otherContactResult['other_contact_position'])){ echo $otherContactResult['other_contact_position'];} else { echo 'NA'; }?></p>
                        <p><i class="fa fa-phone-square" aria-hidden="true"></i><?php if(!empty($otherContactResult['other_contact_directPhone'])){ echo $otherContactResult['other_contact_directPhone'];} else { echo 'NA'; }?></p>
                        <p><i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php if(!empty($otherContactResult['other_contact_directEmail'])){?>
                            <a href="mailto:<?php if(!empty($otherContactResult['other_contact_directEmail'])){ echo $otherContactResult['other_contact_directEmail'];}?>">
                                <?php echo $otherContactResult['other_contact_directEmail'];
                            ?></a><?php } else { ?>
                            <a href="#"><?php echo 'NA'; }?> </a></p>

                    </div>
                </li>

                 <?php } }
                else { ?>
                 <li>
                    <div>
                        <h3><i class="fa fa-building-o" aria-hidden="true"></i> &nbsp;<?php echo 'NA';?></h3>
                        <p><i class="fa fa-user" aria-hidden="true"></i> <?php echo 'NA';?></p>
                        <p><i class="fa fa-phone-square" aria-hidden="true"></i> <?php echo 'NA';?></p>
                        <p><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo 'NA';?></p>

                    </div>
                </li>   
               <?php }
                ?>

        </ul>
    </div>
</div>





</div>

                        <?php 
				require_once(__ROOT__.'/includes/rightPanel.php'); 
				?>
                    </div>
                </section>

                <?php 
    require_once(__ROOT__.'/includes/footer.php'); 
    ?>


                    <!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please enter the details to login</h1>
                        <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                    </label>
                                </div>
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
                    <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->

                    <?php 
            require_once(__ROOT__.'/includes/footerbuttom.php'); 
            ?>


        </div>

        <a href="#0" class="cd-top">Top</a>




        <script src="bower_components/jquery/dist/jquery.js"></script>
        <script src="bower_components/what-input/what-input.js"></script>
        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/easyResponsiveTabs.js"></script>
        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
        <script type="text/javascript" src="js/pace.js"></script>

        <script type="text/javascript">
            $(function() {
                $('nav#menu').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: true,
                    counters: false,
                    "offCanvas": {
                        "position": "left"
                    },
                    navbar: {
                        title: 'SWISSCHAM'
                    },
                    navbars: [{
                        position: 'top',
                        content: ['searchfield']
                    }, {
                        position: 'top',
                        content: [
                            'prev',
                            'title',
                            'close'
                        ]
                    }, {
                        position: 'bottom',
                        content: [
                            //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                        ]
                    }]
                });
                $('nav#log_togg').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: false,
                    counters: false,
                    navbar: {
                        title: 'Welcome to Swisscham'
                    },
                    navbars: [{
                        position: 'bottom',
                        content: [
                            '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /> Wechat</a></span>',
                            '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /> LinkedIn</a></span>'
                        ]
                    }]

                });

            });

        </script>

        <script src="js/app.js"></script>
        <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
        <div id="1st">
        <script type="text/javascript">
            $(document).ready(function() {
                var addressInChinese = $('#addressInChinese').val();
                var addressInEnglish = $('#addressInEnglish').val();
                var nameInEnglish = $('#nameInEnglish').val();
                var sContent =
                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>" + addressInEnglish + "</p>" +
                    "</div>";
                var map = new BMap.Map("dituContent1");
                geocoder = new BMap.Geocoder();
                geocoder.getPoint(addressInChinese, function(res) {
                    console.log(res.lng)
                    console.log(res.lat)
                    var lng = res.lng;
                    var lat = res.lat;

                    var point = new BMap.Point(lng, lat);
                    var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                        anchor: new BMap.Size(10, 30),
                        infoWindowAnchor: new BMap.Size(10, 0)
                    });
                    var marker = new BMap.Marker(point, {
                        icon: icon,
                        title: nameInEnglish
                    });

                    <!--AXIUS: opts variable has been included and the same has been set below -->
                    var opts = {
                        //width : 500,
                        //height: 70,
                        title: nameInEnglish,
                        enableMessage: true,
                        message: addressInEnglish
                    }

                    <!--AXIUS: opts variable set here below -->


                    var infoWindow = new BMap.InfoWindow(sContent);
                    map.centerAndZoom(point, 15);
                    map.enableScrollWheelZoom();
                    map.addOverlay(marker);
                    marker.addEventListener("click", function() {
                        this.openInfoWindow(infoWindow);
                        document.getElementById('imgDemo').onload = function() {
                            infoWindow.redraw();
                        }
                    });
                });
            });

            //company1
            $(document).ready(function() {
                $(".Company").click(function(){
                var addressInChinese = $('#addressInChinese').val();
                var addressInEnglish = $('#addressInEnglish').val();
                var nameInEnglish = $('#nameInEnglish').val();
                var sContent =
                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>" + addressInEnglish + "</p>" +
                    "</div>";
                var map = new BMap.Map("dituContent1");
                geocoder = new BMap.Geocoder();
                geocoder.getPoint(addressInChinese, function(res) {
                    console.log(res.lng)
                    console.log(res.lat)
                    var lng = res.lng;
                    var lat = res.lat;

                    var point = new BMap.Point(lng, lat);
                    var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                        anchor: new BMap.Size(10, 30),
                        infoWindowAnchor: new BMap.Size(10, 0)
                    });
                    var marker = new BMap.Marker(point, {
                        icon: icon,
                        title: nameInEnglish
                    });

                    <!--AXIUS: opts variable has been included and the same has been set below -->
                    var opts = {
                        //width : 500,
                        //height: 70,
                        title: nameInEnglish,
                        enableMessage: true,
                        message: addressInEnglish
                    }

                    <!--AXIUS: opts variable set here below -->


                    var infoWindow = new BMap.InfoWindow(sContent);
                    map.centerAndZoom(point, 15);
                    map.enableScrollWheelZoom();
                    map.addOverlay(marker);
                    marker.addEventListener("click", function() {
                        this.openInfoWindow(infoWindow);
                        document.getElementById('imgDemo').onload = function() {
                            infoWindow.redraw();
                        }
                    });
                });
            });
});


            //company2
            $(document).ready(function() {
            $(".Company2").click(function(){
                var addressInChinese = $('#other_china_add_2').html();
                var addressInEnglish = $('#other_comp_add_2 p').html();
                var nameInEnglish = $('#other_comp_name_2 h2').html();
                var sContent =
                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>" + addressInEnglish + "</p>" +
                    "</div>";
                var map = new BMap.Map("dituContent1");
                geocoder = new BMap.Geocoder();
                geocoder.getPoint(addressInChinese, function(res) {
                    console.log(res.lng)
                    console.log(res.lat)
                    var lng = res.lng;
                    var lat = res.lat;

                    var point = new BMap.Point(lng, lat);
                    var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                        anchor: new BMap.Size(10, 30),
                        infoWindowAnchor: new BMap.Size(10, 0)
                    });
                    var marker = new BMap.Marker(point, {
                        icon: icon,
                        title: nameInEnglish
                    });

                    <!--AXIUS: opts variable has been included and the same has been set below -->
                    var opts = {
                        //width : 500,
                        //height: 70,
                        title: nameInEnglish,
                        enableMessage: true,
                        message: addressInEnglish
                    }

                    <!--AXIUS: opts variable set here below -->


                    var infoWindow = new BMap.InfoWindow(sContent);
                    map.centerAndZoom(point, 15);
                    map.enableScrollWheelZoom();
                    map.addOverlay(marker);
                    marker.addEventListener("click", function() {
                        this.openInfoWindow(infoWindow);
                        document.getElementById('imgDemo').onload = function() {
                            infoWindow.redraw();
                        }
                    });
                });
            });
});

            //company3
            $(document).ready(function() {
            $(".Company3").click(function(){
                var addressInChinese = $('#other_china_add_3').html();
                var addressInEnglish = $('#other_comp_add_3 p').html();
                var nameInEnglish = $('#other_comp_name_3 h2').html();
                var sContent =
                    "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                    "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>" + addressInEnglish + "</p>" +
                    "</div>";
                var map = new BMap.Map("dituContent1");
                geocoder = new BMap.Geocoder();
                geocoder.getPoint(addressInChinese, function(res) {
                    console.log(res.lng)
                    console.log(res.lat)
                    var lng = res.lng;
                    var lat = res.lat;

                    var point = new BMap.Point(lng, lat);
                    var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(20, 32), {
                        anchor: new BMap.Size(10, 30),
                        infoWindowAnchor: new BMap.Size(10, 0)
                    });
                    var marker = new BMap.Marker(point, {
                        icon: icon,
                        title: nameInEnglish
                    });

                    <!--AXIUS: opts variable has been included and the same has been set below -->
                    var opts = {
                        //width : 500,
                        //height: 70,
                        title: nameInEnglish,
                        enableMessage: true,
                        message: addressInEnglish
                    }

                    <!--AXIUS: opts variable set here below -->


                    var infoWindow = new BMap.InfoWindow(sContent);
                    map.centerAndZoom(point, 15);
                    map.enableScrollWheelZoom();
                    map.addOverlay(marker);
                    marker.addEventListener("click", function() {
                        this.openInfoWindow(infoWindow);
                        document.getElementById('imgDemo').onload = function() {
                            infoWindow.redraw();
                        }
                    });
                });
            });
});

        </script>
        </div>
        
        

        
    </body>

    </html>
    <?php } ?>
