<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');

$userId = $_SESSION["userId"];
$type = $_REQUEST['type'];

switch($type){
	case 'account_info':
		
		$admin_generated_userId = isset($_REQUEST['admin_generated_userId'])?$_REQUEST['admin_generated_userId']:"";
		$direct_email = isset($_REQUEST['direct_email'])?$_REQUEST['direct_email']:"";
		$admin_generated_password = isset($_REQUEST['admin_generated_password'])?$_REQUEST['admin_generated_password']:"";
		$language = isset($_REQUEST['language'])?$_REQUEST['language']:"";
		$assignables_role = isset($_REQUEST['assignables_role'])?$_REQUEST['assignables_role']:"";
		
		$assignables_roles = implode(",", $assignables_role); 
		
	   $sql = "UPDATE `sc_c_userdetails`
                 SET `admin_generated_userId`='".$admin_generated_userId."',
                     `direct_email`='".$direct_email."',
                     `admin_generated_password`='".$admin_generated_password."',
                     `language`='".$language."',
                     `assignables_role`='".$assignables_roles."'
               WHERE `userId` = '".$userId."'";
			
			
		$res = mysql_query($sql);
		header('Location: admin.php');
		break;
		
	case 'personal_details':
	
		$user_title = isset($_REQUEST['user_title'])?addslashes($_REQUEST['user_title']):"";
		$year_of_birth = isset($_REQUEST['year_of_birth'])?addslashes($_REQUEST['year_of_birth']):"";
		$year_of_birth = date('Y-m-d',strtotime($year_of_birth));
		$family_name = isset($_REQUEST['family_name'])?addslashes($_REQUEST['family_name']):"";
		$given_name = isset($_REQUEST['given_name'])?addslashes($_REQUEST['given_name']):"";
		$chinese_name = isset($_REQUEST['chinese_name'])?addslashes($_REQUEST['chinese_name']):"";
		$nationality = isset($_REQUEST['nationality'])?addslashes($_REQUEST['nationality']):"";
		$address_english = isset($_REQUEST['address_english'])?addslashes($_REQUEST['address_english']):"";
		$city_english = isset($_REQUEST['city_english'])?addslashes($_REQUEST['city_english']):"";
		$province_area = isset($_REQUEST['province_area'])?addslashes($_REQUEST['province_area']):"";
		$address_chinese = isset($_REQUEST['address_chinese'])?addslashes($_REQUEST['address_chinese']):"";
		$city_chinese = isset($_REQUEST['city_chinese'])?addslashes($_REQUEST['city_chinese']):"";
		$zip_code_english = isset($_REQUEST['zip_code_english'])?addslashes($_REQUEST['zip_code_english']):"";
		$positionIn_company = isset($_REQUEST['positionIn_company'])?addslashes($_REQUEST['positionIn_company']):"";
		$direct_phone = isset($_REQUEST['direct_phone'])?addslashes($_REQUEST['direct_phone']):"";
		$mobile_phone = isset($_REQUEST['mobile_phone'])?addslashes($_REQUEST['mobile_phone']):"";
		$direct_email = isset($_REQUEST['direct_email'])?addslashes($_REQUEST['direct_email']):"";
		
		echo $sql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."',
		                     `direct_email`='".$direct_email."'
		               WHERE `userId` = '".$userId."'";
		
		
		$res = mysql_query($sql);
		
		$img = $_FILES['profile_picture'];
        $img_name = $img['name'];
		$img_size = $img['size'];				
		
        if($img_name != "") {        	
            $ext = end(explode('.', $img_name));
            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG");
			
			if(in_array($ext,$extArr) ){
				$new_img = "image_" . time() . "." . $ext;
            	@move_uploaded_file($img['tmp_name'], "uploads/" . $new_img);
				
				  $imgsql = "UPDATE `sc_c_userdetails`
				                SET `profile_picture`='".$new_img."'
				              WHERE `userId` = '".$userId."'";
				  $imgres = mysql_query($imgsql);
			}
		}
				
		/*$ind_del_Sql="DELETE FROM `sc_c_user_to_industry` WHERE `userId`='".$userId."'";
	    mysql_query($ind_del_Sql);
	    
	    
		if(isset($_POST['industry']) && !empty($_POST['industry'])){
			$industry = $_POST['industry'];
			foreach($industry as $key=>$val){
				$ind_insSql = "INSERT INTO `sc_c_user_to_industry` 
									 SET `userId`='".$userId."',
							             `industry_id`='".$val."'";
				mysql_query($ind_insSql);
			}
		}*/
		
		header('Location: admin.php');
		break;
		
		case 'newsletter':
		
		$newsletter = implode(",",isset($_REQUEST['newsletter'])?$_REQUEST['newsletter']:"");
		
		$sql = "UPDATE `sc_c_userdetails`
		                 SET `newsletter`='".$newsletter."'
		               WHERE `userId` = '".$userId."'";
					  
		$res = mysql_query($sql);
		header('Location: admin.php');
		break;
		
		case 'question':
		
			$question = isset($_REQUEST['question'])?$_REQUEST['question']:"";
			
			$sql = "UPDATE `sc_c_userdetails`
			                 SET `question`='".$question."'
			               WHERE `userId` = '".$userId."'";
						  
			$res = mysql_query($sql);
			header('Location: admin.php');
		break;
		
		
		case 'expert_corner_article':
		
			$corner_title = isset($_REQUEST['corner_title'])?$_REQUEST['corner_title']:"";
			$corner_body = isset($_REQUEST['corner_body'])?$_REQUEST['corner_body']:"";
			$text_format = isset($_REQUEST['text_format'])?$_REQUEST['text_format']:"";
			$tag_name = isset($_REQUEST['tag_name'])?$_REQUEST['tag_name']:"";
		
			$exp_cnt = mysql_query("SELECT * FROM `sc_c_expert_corner_article` WHERE `userId`='".$userId."'");
			$cont    = mysql_num_rows($exp_cnt); 
			
			if($cont > 0){
				$expertsql = "UPDATE `sc_c_expert_corner_article`
				                SET `corner_title`='".$corner_title."',
				                    `corner_body`='".$corner_body."',
				                    `text_format`='".$text_format."',
				                    `tag_name`='".$tag_name."'
				              WHERE `userId` = '".$userId."'";
				
				$res = mysql_query($expertsql);
				
				$expertfile = $_FILES['expert_file'];
		        $expertfile_name = $expertfile['name'];
				$expertfile_size = $expertfile['size'];				
				
		        if($expertfile_name != "") {
		        	
		            $ext = end(explode('.', $expertfile_name));
		            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG");
					
					if(in_array($ext,$extArr) ){
						$new_file = "expertfile_".time().".".$ext;
		            	@move_uploaded_file($expertfile['tmp_name'], "uploads/" . $new_file);
						
						  $expertfilesql = "UPDATE `sc_c_expert_corner_article`
								               SET `expert_file`='".$new_file."'
								             WHERE `userId` = '".$userId."'";
						  $expertfileres = mysql_query($expertfilesql);
					}
				}
				
			  }else{
			  	
				$expertsql = "INSERT INTO `sc_c_expert_corner_article`
					                SET `corner_title`='".$corner_title."',
					                    `corner_body`='".$corner_body."',
					                    `text_format`='".$text_format."',
					                    `tag_name`='".$tag_name."',
					                    `userId`='".$userId."'";
				
				$res = mysql_query($expertsql);
				
				$lastId = mysql_insert_id();
								
			    $expertfile = $_FILES['expert_file'];
				$expertfile_name = $expertfile['name'];
				$expertfile_size = $expertfile['size'];	
				
		        if($expertfile_name != "") {
		            $ext = end(explode('.', $expertfile_name));
		            $extArr = array("jpeg","jpg","png","JPEG","JPG","PNG","pdf","mp4","doc","docx","xls","xlsx");
					
					if(in_array($ext,$extArr) ){
						$new_file = "expertfile_".time().".".$ext;
		            	@move_uploaded_file($expertfile['tmp_name'], "uploads/" . $new_file);
						
						$expertfilesql = "UPDATE `sc_c_expert_corner_article`
						                     SET `expert_file`='".$new_file."'
						                   WHERE `expert_corner_article_id` = '".$lastId."'";
								             
						  $expertfileres = mysql_query($expertfilesql);
					}
				}
			}
			
			header('Location: admin.php');
		break;
		
		case 'activeUser':
			
			$ids = $_REQUEST['ids'];			
			$idArr = explode(",", $ids);
			
			foreach($idArr as $key=>$val){
				$res = mysql_fetch_array(mysql_query("SELECT * FROM `sc_c_userdetails` WHERE userId='".$val."'"));
				$emailId = $res['direct_email'];	
				$updQry = "Update `sc_c_userdetails` SET `is_active`='Y' WHERE userId = '".$val."'";
				$UpdRes = mysql_query($updQry);
			} 	
			echo "ok";
			exit();		
		break;
		
}

