<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
        <div class="large-12 columns right_y_join margin_top10">
            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
            <p class="text-center">Because Connections Matter.</p>
            <ul class="fa-ul join_button_group">
                <li><a href="<?php echo $site_url ;?>why-join-us/" class="button expanded ">WHY JOIN US</a></li>
                <li><a href="<?php echo $site_url ;?>why-join-us/" class="button expanded ">BECOME A  MEMBER</a></li>
            </ul>
        </div>
        <!--<div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>-->
        <div class="large-12 columns right_y_join margin_top10">
            <!--<h3 class="common_subheading">Strategic Partner</h3>-->
            <ul class="fa-ul inner_sponser_img">
                <li>
                    <a target="_blank" href="https://www.nestle.com.cn/"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser1.jpg"></a>
                </li>
                <li>
                    <a target="_blank" href="https://www.vischer.com/en/home/"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser2.jpg"></a>
                </li>
                <li>
                    <a href="javascript:void(0)"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser3.jpg"></a>
                </li>
            </ul>
        </div>
        <div class="large-12 columns">
            <hr class="right_devider" />
        </div>
        <div class="large-12 columns right_y_join margin_top10">
            <h3 class="common_subheading">Upcoming Events</h3>
            <div class="tab_list_item">
                <?php 
				$selectedTime=date("Y-m-d H:i:s",time());
				//$selectedTime="2016-12-31 23:00:00";
				$endTime = strtotime("+480 minutes", strtotime($selectedTime));
				//echo date('Y-m-d h:i:s', $endTime);
								$dt=date("Y-m-d",$endTime);
								$tm=date("H:i",$endTime);
								//$eventDetailsQuery = "SELECT * FROM `sc_em_events`,`sc_em_locations` WHERE `sc_em_events`.`post_id`=`sc_em_locations`.`post_id` AND `sc_em_events`.`event_start_time`>='$dt' ORDER BY `sc_em_events`.`event_start_time`";
								//$eventDetailsQuery = "SELECT * FROM `sc_em_events`,`sc_em_locations` WHERE `sc_em_events`.`location_id`=`sc_em_locations`.`location_id`  AND `sc_em_events`.`event_start_time`>='$dt' ORDER BY `sc_em_events`.`event_start_time` Desc LIMIT 0,2";
								$eventDetailsQuery="SELECT * 
													FROM  `sc_em_events` 
													WHERE  (`event_start_date` >=  '$dt' Or `event_start_time` > '$tm') AND `event_status` =1 ORDER BY `event_start_date` LIMIT 0,3";
								$eventResult = mysql_query($eventDetailsQuery); 
								while($eventDetails = mysql_fetch_array($eventResult)){
									$loc_id=$eventDetails['location_id'];
									$sq="SELECT * 
										FROM  `sc_em_locations`
										WHERE `location_id`='$loc_id'";
									$Result = mysql_query($sq); 
									while($event = mysql_fetch_array($Result)){
								?>
                    <div class="tab_list_item">
                        <h4><?php if(!empty($eventDetails['event_start_date'])){ echo date('d F Y',strtotime($eventDetails['event_start_date']));}?> - <?php if(!empty($eventDetails['event_start_time'])){ echo date('H:i',strtotime($eventDetails['event_start_time']));}?>  to 
								<?php if(!empty($eventDetails['event_end_date'])){ echo date('d F Y',strtotime($eventDetails['event_end_date']));}?> - <?php if(!empty($eventDetails['event_end_time'])){ echo date('H:i',strtotime($eventDetails['event_end_time']));}?> 
								<span><i class="fa fa-map-marker" aria-hidden="true"></i><?php if(!empty($event['location_town'])){ echo $event['location_town']; }?></span></h4>
                        <h5><?php if(!empty($event['location_address'])){ echo $event['location_address']; }?></h5>
                        <a href="<?php echo $site_url ;?>events/<?php if(!empty($eventDetails['event_slug'])){ echo $eventDetails['event_slug']; }?>/"><h3><?php if(!empty($eventDetails['event_name'])){ echo $eventDetails['event_name']; }?></h3></a>
                    </div>
                    <?php } } ?>


            </div>
            <a class="see_more_link" href="<?php echo $site_url ;?>upcoming-events/">read more</a>
        </div>
        <script type="text/javascript">
            (function() {
                if (!window.mc4wp) {
                    window.mc4wp = {
                        listeners: [],
                        forms: {
                            on: function(event, callback) {
                                window.mc4wp.listeners.push({
                                    event: event,
                                    callback: callback
                                });
                            }
                        }
                    }
                }
            })();

        </script>
        <div class="large-12 columns">
            <hr class="right_devider" />
        </div>
        <div class="large-12 columns right_y_join no_padding">
            <form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-773" method="post" data-id="773" data-name="name">
                <div class="mc4wp-form-fields">
                    <div class="large-12 columns right_y_join margin_top10">
                        <h3 class="common_subheading">MAILING LIST</h3>
                        <p class=""></p>
                        <ul class="fa-ul right_newsletter_form">
                            <li>
                                <label>
                                    <input type="text" placeholder="FIRST NAME">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="LAST NAME">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="POSITION">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="COMPANY">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="EMAIL">
                                </label>
                            </li>
                            <li class="text-left newsletter_button_sec">
                                <a href="#" class="button newsletter_button">Subscribe</a>
                            </li>
                        </ul>

                    </div>
                    <div style="display: none;">
                        <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" />
                    </div>
                    <input type="hidden" name="_mc4wp_timestamp" value="1480483833" />
                    <input type="hidden" name="_mc4wp_form_id" value="773" />
                    <input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" />
                </div>
                <div class="mc4wp-response"></div>
            </form>
        </div>
    </div>
</div>
