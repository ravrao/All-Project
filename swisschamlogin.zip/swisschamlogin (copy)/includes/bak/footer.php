<section class="main_sponsor_sec">
    <div class="row">
        <div class="large-12 columns">
            <div class="mainSponsor">
               <?php
               
               require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
               //require_once(__SITEROOT__."/swisschamlogin/includes/wp-config.php");
               
                $spDetailsQuery = "SELECT * FROM `sc_posts`,`sc_postmeta` WHERE `sc_posts`.`ID`=`sc_postmeta`.`post_id` AND `sc_posts`.`post_type`='sponsorbottom' AND `sc_postmeta`.`meta_key`='_thumbnail_id' AND `sc_posts`.`post_status`='publish'";
                $spResult = mysql_query($spDetailsQuery);
                while ($spDetails = mysql_fetch_array($spResult)) {
                    $postId = $spDetails['meta_value'];
                    $sql = "SELECT * FROM `sc_posts` WHERE `ID`='$postId'";
                    $Result = mysql_query($sql);
                    while ($Details = mysql_fetch_array($Result)) {
                        ?>

                    <div class="">
                        <p class="main_sponsor_item"><img src="<?=$Details['guid']?>" /></p>
                    </div>

                    <?php } } ?>
            </div>
        </div>
    </div>
</section>
<!--<footer>
            <div class="row">
                <div class="large-12 columns">
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>About us</h4>
                        <p>SwissCham is a networking and information platform for Swiss companies in Greater China and Chinese/foreign companies interested in Switzerland.</p>
                        <p><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i> Learn more about our services</a></p>
                    </div>
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>Contact us</h4>
                        <div class="large-12 columns no_padding">
                            <ul class="fa-ul no-bullet footer_content">
                                <li><a href="#">SwissCham Beijing</a></li>
                                <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i> +86 10 8468 3982</a></li>
                                <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> info@bei.swisscham.org</a></li>
                                <li>
                                    <p><a href="#">Find us</a> | <a href="#">Contact form</a> | <a href="#">Follow us on wechat</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="large-4 medium-4 columns footer_about">
                        <h4>Quick links</h4>
                        <div class="large-12 columns no_padding">
                            <ul class="fa-ul no-bullet footer_list">
                                <li><a href="#">Upcoming Events</a></li>
                                <li><a href="#">Exposure</a></li>
                                <li><a href="#">Member Directory</a></li>
                                <li><a href="#">Job Opportunities</a></li>
                                <li><a href="#">Membership Application</a></li>
                                <li><a href="#">Site Map</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="large-12 columns">
                        <hr class="common_separetor" />
                    </div>
                    <div class="large-12 columns">
                        <div class="menu-centered">
                            <ul class="menu simple copyright_text">
                                <li>Copyright © 2016 Swiss Chinese Chamber of Commerce</li>
                                <li><a href="#">Terms of use</a></li>
                                <li><a href="#">Privacy policy</a></li>
                                <li>Website design by Axiussoft</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </footer>-->
<footer>
    <div class="row">
        <div class="large-12 columns">
            <div class="large-4 medium-4 columns footer_about">
                <h4>About us</h4>
                <p>SwissCham is a networking and information platform for Swiss companies in Greater China and Chinese/foreign companies interested in Switzerland.</p>
                <p><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i> Learn more about our services</a></p>
            </div>
            <div class="large-4 medium-4 columns footer_about">
                <h4>Contact us</h4>
                <div class="large-12 columns no_padding">
                    <ul class="fa-ul no-bullet footer_list">
                        <li><a href="<?=$site_url?>contact-us/">Beijing</a></li>
                        <li><a href="<?=$site_url?>contact-us/">Shanghai</a></li>
                        <li><a href="<?=$site_url?>contact-us/">Guangzhou</a></li>
                        <li><a href="<?=$site_url?>contact-us/">Hong kong</a></li>
                        <li><a href="online_application.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Online contact form</a></li>
                    </ul>
                </div>
                <!--
                        <div class="large-6 columns ">
                            <ul class="fa-ul no-bullet footer_list">
                                <li><a href="#">Shanghai</a></li>
                                <li><a href="#">Hong kong</a></li>

                            </ul>
                        </div>
-->
            </div>
            <div class="large-4 medium-4 columns footer_about">
                <h4>Quick links</h4>
                <div class="large-12 columns no_padding">
                    <ul class="fa-ul no-bullet footer_list">
                        <li><a href="<?=$site_url?>upcoming-events/">Upcoming Events</a></li>
                        <li><a href="#">Exposure</a></li>
                        <li><a href="member_directory_general_page.php">Member Directory</a></li>
                        <li><a href="<?=$site_url?>jobs/">Job Opportunities</a></li>
                        <li><a href="online_application.php">Membership Application</a></li>
                        <li><a href="#">Site Map</a></li>

                    </ul>
                </div>
            </div>
            <div class="large-12 columns">
                <hr class="common_separetor" />
            </div>
            <div class="large-12 columns">
                <div class="menu-centered">
                    <ul class="menu simple copyright_text">
                        <li>Copyright © 2016 Swiss Chinese Chamber of Commerce</li>
                        <li><a href="#">Terms of use</a></li>
                        <li><a href="#">Privacy policy</a></li>
                        <li>Website design by Axiussoft</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
