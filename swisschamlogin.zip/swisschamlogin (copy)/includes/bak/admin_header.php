<link rel="stylesheet" href="css/swiss.css">
<section class="top_strip">
            <div class="row">
                <div class="large-7 medium-7 columns">
                    <ul class="menu simple top_site_buttom">
                        <li class="active"><a href="<?=$site_url?>">Home</a></li>
                        <li><a href="<?=$site_url?>bei/">Beijing</a></li>
                        <li><a href="<?=$site_url?>sha/">Shanghai</a></li>
                        <li><a href="<?=$site_url?>gz/">Guangzhou</a></li>
                        <li><a href="<?=$site_url?>hk/">Hong Kong</a></li>
                        <li><a href="<?=$site_url?>">Switzerland</a></li>
                    </ul>
                </div>
                <div class="large-5 medium-5 columns top_log_sec">
                    <ul class="menu simple top_log_buttom ">
                        <?php
                        if(!isset($_SESSION["userId"])){?>
                        <li class="top_fix_btn"><a href="#" data-toggle="loginModal">Login</a></li>
                        <li class="top_fix_btn"><a href="#" class="join_active">Join Us</a></li>
                        <?php } else{?>
                        <li class="top_fix_btn"><a href="logout.php" class="join_active">Logout</a></li>
                        <!--<li class="language_selector top_fix_btn"><a href="#">EN</a> | <a href="#">中文</a></li>-->
                        <?php } ?>
                        
                    </ul>
                </div>
            </div>
        </section>
        <section class="small_top_strip">
            <div class="row show-for-small-only">
                <div class="large-12 columns text-right no_padding">
                    <ul class="menu simple small_login_field">
                        <li class=""><a href="#">Login</a></li>
                        <li class="small_join_btn"><a href="#" class="button">Join Us</a></li>

                        <li class="small_social_button">
                            <a class=""><img src="images/wechat.png" /></a>
                        </li>
                        <li class="small_social_button">
                            <a class=""><img src="images/linkdin.png" /></a>
                        </li>

                    </ul>
                </div>
            </div>
        </section>
        <section class="top_fixed_strip">
            <header>
                <a class="menu_toogler " href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>
                <div class="row">
                    <div class="large-7 medium-6 columns">
                        <p class="main_logo">
                            <a href="<?=$site_url?>"><img src="images/logo.png" /></a>
                        </p>
                    </div>
                    <div class="large-5 medium-6 columns no_padding">
                        <div class="large-6 medium-6 columns">
                            <div class="input-group search_group">
                                <input class="input-group-field search_field" type="text" placeholder="Search...">
                                <div class="input-group-button">
                                    <a href="#" class="button search_button"><i class="fa fa-search" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="large-6 medium-6 columns">
                            <!--
                            <ul class="menu simple ad_sponsor_item">
                                <li class=""><img src="images/sponser1.jpg" /></li>
                                <li class=""><img src="images/sponser2.png" /></li>
                            </ul>
-->
                            <div class="large-12 medium-12 small-6 columns small_support_text show-for-small-only">
                                <h3 class="text-right">supported by</h3>
                            </div>
                            <div class="large-12 medium-12 small-6 columns no_padding">
                                <div class="adSponsorItem">
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.nestle.com.cn/" target="_blank"><img src="images/slider_sponsor1.jpg" /></a>
                                        </p>
                                    </div>
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.vischer.com/en/home/" target="_blank"><img src="images/slider_sponsor2.jpg" /></a>
                                        </p>
                                    </div>
                                    <div class="">
                                        <p class="ad_sponsor_item">
                                            <a href="https://www.swiss.com/web/EN/Pages/index.aspx?WT.mc_id=SwissCham" target="_blank"><img src="images/slider_sponsor3.jpg" /></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section class="relative_sec">
                <div class="row">
                    <div class="large-12 columns main_navbar">
                        <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
                            <button class="menu-icon" type="button" data-toggle></button>
                            <div class="title-bar-title">Menu</div>
                        </div>

                        <div class="top-bar main_nav" id="main-menu">
                            <div class="top-bar-left">
                                <!--
                        <ul class="dropdown menu" data-dropdown-menu>
    <li class="menu-text">Site Title</li>
</ul>
-->
                            </div>
                            <div class="top-bar-left main_nav_list">
                                <ul class="menu main_nav_list_item" data-responsive-menu="drilldown medium-dropdown">
                                    <li class="has-submenu">
                                        <a href="#" class="">About Us</a>
                                        <ul class="submenu menu vertical main_nav_subitem" data-submenu>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Who are we?</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>swisscham-china-who-are-we/">SwissCham China</a></li>
                                                    <li><a href="<?=$site_url?>swisscham-hong-kong-who-are-we/">SwissCham Hong Kong</a></li>
                                                </ul>
                                            </li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">History</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>history-china/">SwissCham China</a></li>
                                                    <li><a href="<?=$site_url?>history-hong-kong/">SwissCham Hong Kong</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="<?=$site_url?>swisscham-china-rules/">Rules</a></li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Board of Directors</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>swisscham-board-beijing/">Beijing</a></li>
                                                    <li><a href="<?=$site_url?>swisscham-board-shanghai/">Shanghai</a></li>
                                                    <li><a href="<?=$site_url?>swisscham-board-guangzhou/">Guangzhou</a></li>
                                                    <li><a href="<?=$site_url?>swisscham-board-hong-kong/">Hong Kong</a></li>
                                                </ul>
                                            </li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Management</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>management-beijing/">Beijing</a></li>
                                                    <li><a href="<?=$site_url?>management-shanghai/">Shanghai</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="<?=$site_url?>contact-us/">Contact Us</a></li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="javascript:void(0);" class="" >Membership</a>
                                        <ul class="submenu menu vertical main_nav_subitem" data-submenu>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Why join us?</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>why-join-us-swisscham-china/">SwissCham China</a></li>
                                                    <li><a href="<?=$site_url?>why-join-us-swisscham-hong-kong/">SwissCham Hong Kong</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="online_application.php">Online Application</a></li>
                                            <li><a href="member_directory_general_page.php">Members Directory</a></li>
                                            <li><a href="<?=$site_url?>investment-zone/">Investment Zones</a></li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Member Benefits Program</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>member-benefits-program-mbp-beijing/">Beijing</a></li>
                                                    <li><a href="<?=$site_url?>member-benefits-program-mbp-shanghai/">Shanghai</a></li>
                                                    <li><a href="<?=$site_url?>member-benefits-program-mbp-hong-kong/">Hong Kong</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="javascript:void(0);" class="">Events</a>
                                        <ul class="submenu menu vertical main_nav_subitem" data-submenu>
                                            <li><a href="<?=$site_url?>upcoming-events/">Upcoming Events</a></li>
                                            <li><a href="<?=$site_url?>event-calender/">Events Calendar</a></li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Events Overview</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>beijing-events-overview/">Beijing</a></li>
                                                    <li><a href="<?=$site_url?>shanghai-events-overview/">Shanghai</a></li>
                                                    <li><a href="<?=$site_url?>guangzhou-events-overview/">Guangzhou</a></li>
                                                    <li><a href="<?=$site_url?>hongkong-events-overview/">Hong Kong</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="javascript:void(0);">Publications</a>
                                        <ul class="submenu menu vertical main_nav_subitem" data-submenu>
                                            <li><a href="<?=$site_url?>the-bridge-magazine/">The Bridge</a></li>
                                            <li><a href="<?=$site_url?>readers-digest/">Sino-Swiss Business News</a></li>
                                            <!--<li><a href="http://54.152.108.131/SwissCham/legal-and-investment-updates/">Reader’s Digest</a></li>-->
                                            <li><a href="<?=$site_url?>legal-and-investment-updates/">Legal & Investment Updates</a></li>
                                            <li><a href="<?=$site_url?>invest-in-switzerland/">Invest in Switzerland</a></li>
                                            <li><a href="<?=$site_url?>business-publications/">BusinessPublications</a></li>
                                            <li><a href="<?=$site_url?>other-links/">Other Links</a></li>

                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="javascript:void(0);" class="">Services</a>
                                        <ul class="submenu menu vertical main_nav_subitem" data-submenu>
                                            <li><a href="<?=$site_url?>our-services/">Our services</a></li>
                                            <li class="click_sub_trigger">
                                                <a href="javascript:void(0);">Advertise With Us</a>
                                                <ul class="click_sub_nav">
                                                    <li><a href="<?=$site_url?>advertise-with-us/">SwissCham China</a></li>
                                                    <li><a href="<?=$site_url?>advertise-with-us/">SwissCham Hong Kong</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="<?=$site_url?>jobs/">Job Opportunities</a></li>
                                            <li><a href="javascript:void(0);">Training</a></li>
                                            <li><a href="javascript:void(0);">Lobbying Activities</a></li>
                                            <li><a href="<?=$site_url?>wechat/"><a href="#">Wechat?</a></li>

                                        </ul>
                                    </li>
                                    <!--
                                <li><a href="#">Membership</a></li>
                                <li><a href="#">Events</a></li>
                                <li><a href="#">Publications</a></li>
                                <li><a href="#">Services</a></li>
-->
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        </section>
        
        