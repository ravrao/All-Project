<?php
/////////////////Local//////////////////////

/*$host = "localhost";
$username = "root";
$password = "";
$db = "";*/

/////////////////Live///////////////////////

$host     = "localhost";
$username = "swisschamtest";
$password = ";Asas36^Gt^F";
//$db       = "swisscham";
$db       = "swisschamtest";

$con = mysql_connect($host, $username, $password) or die("connection failed");
mysql_select_db($db, $con) or die("could not connect with database");
$dbLink = mysql_connect($host, $username, $password)or die(mysql_error());
    mysql_query("SET character_set_results=utf8", $dbLink)or die(mysql_error());
    mb_language('uni'); 
    mb_internal_encoding('UTF-8');
    mysql_select_db($db, $dbLink)or die(mysql_error());
    mysql_query("set names 'utf8'",$dbLink)or die(mysql_error());
?>