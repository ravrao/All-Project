<div class="large-3 medium-4 columns margin_top15 hide-for-small-only">
    <div class="large-12 columns inner_right_panel" data-equalizer-watch>
        <div class="large-12 columns right_y_join margin_top10">
            <h1 class="common_heading text-center">YOUR SWISS BUSINESS PLATFORM IN CHINA</h1>
            <p class="text-center">Because Connections Matter.</p>
            <ul class="fa-ul join_button_group">
                <li><a href="<?php echo $base_url?>online_application.php" class="button expanded ">WHY JOIN US</a></li>
                <li><a href="<?php echo $base_url?>online_application.php" class="button expanded ">BECOME A  MEMBER</a></li>
            </ul>
        </div>
        <!--<div class="large-12 columns right_y_join margin_top10">
                            <div class="flex-video right_panel_video">
                                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/V9gkYw35Vws" frameborder="0" allowfullscreen></iframe>
                            </div>
                        </div>-->
        <div class="large-12 columns right_y_join margin_top10">
            <!--<h3 class="common_subheading">Strategic Partner</h3>-->
            <ul class="fa-ul inner_sponser_img">
                <li>
                    <a target="_blank" href="https://www.nestle.com.cn/"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser1.jpg"></a>
                </li>
                <li>
                    <a target="_blank" href="https://www.vischer.com/en/home/"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser2.jpg"></a>
                </li>
                <li>
                    <a href="javascript:void(0)"><img src="<?php echo $site_url ;?>wp-content/uploads/2016/11/inner_sponser3.jpg"></a>
                </li>
            </ul>
        </div>
        <div class="large-12 columns">
            <hr class="right_devider" />
        </div>
        <div class="large-12 columns right_y_join margin_top10">
            <h3 class="common_subheading">Upcoming Events</h3>
            <div class="tab_list_item">
                
              <?php
               require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
               //require_once(__SITEROOT__."/swisschamlogin/includes/wp-config.php");

 $events_all_count_home = EM_Events::get(array('scope'=>'future'));
 $home_count=count($events_all_count_home);
    $args=array(
        'blog'=>'1',
        'bookings'=>'0',
        'category'=>"51,52,53,54",
        'scope'=>'future',
        'limit'=>"3",
        'format'=>'<div class="tab_list_item"><h4>#d #F #Y - #_24HSTARTTIME to #@d #@F #@Y - #_24HENDTIME<span><i class="fa fa-map-marker" aria-hidden="true"></i>#_CATEGORYNAME</h4></span></h4><h5>#_LOCATIONADDRESS</h5><a href="/#_CATEGORYSLUG/event-details/?id=#_EVENTPOSTID"><h3>#_EVENTNAME</h3></a></div>',

    );
     em_events($args); 
      

     ?>
        </div>
 <?php
if($home_count>3) { ?>
    <a class="see_more_link" href="<?php echo web_url(); ?>upcoming-events/">See Upcoming Events</a>
    <?php }  ?>          
        </div>
        <script type="text/javascript">
            (function() {
                if (!window.mc4wp) {
                    window.mc4wp = {
                        listeners: [],
                        forms: {
                            on: function(event, callback) {
                                window.mc4wp.listeners.push({
                                    event: event,
                                    callback: callback
                                });
                            }
                        }
                    }
                }
            })();

        </script>
        <div class="large-12 columns">
            <hr class="right_devider" />
        </div>
        <div class="large-12 columns right_y_join no_padding">
            <!--<form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-773" method="post" data-id="773" data-name="name">
                <div class="mc4wp-form-fields">
                    <div class="large-12 columns right_y_join margin_top10">
                        <h3 class="common_subheading">MAILING LIST</h3>
                        <p class=""></p>
                        <ul class="fa-ul right_newsletter_form">
                            <li>
                                <label>
                                    <input type="text" placeholder="FIRST NAME">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="LAST NAME">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="POSITION">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="COMPANY">
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="text" placeholder="EMAIL">
                                </label>
                            </li>
                            <li class="text-left newsletter_button_sec">
                                <a href="#" class="button newsletter_button">Subscribe</a>
                            </li>
                        </ul>

                    </div>
                    <div style="display: none;">
                        <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" />
                    </div>
                    <input type="hidden" name="_mc4wp_timestamp" value="1480483833" />
                    <input type="hidden" name="_mc4wp_form_id" value="773" />
                    <input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" />
                </div>
                <div class="mc4wp-response"></div>
            </form>-->
            
            <!-- Begin MailChimp Signup Form -->
<link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
<style type="text/css">
	#mc_embed_signup{border-radius: 10px;background: url(../images/grilled.png) repeat;padding: 0px;clear:left; font:14px Helvetica,Arial,sans-serif; }
	#mc_embed_signup .mc-field-group input{border: #000 1px solid;border-radius: 5px;-webkit-border-radius: 5px;-moz-border-radius: 5px;color: #000;margin-bottom: 0;}
        #mc_embed_signup .mc-field-group p{margin-bottom: 10px;}
        #mc_embed_signup .mc-field-group{padding-bottom: 0;min-height: auto;}
        #mc_embed_signup .button{border-radius: 5px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
background-color: rgb(170, 0, 8);
color: rgb(255, 255, 255);
text-transform: uppercase;
font-size: 13px;
font-family: "robotolight",Helvetica,Roboto,Arial,sans-serif;
margin-bottom: 0px;
padding-left: 25px;
padding-right: 25px;width: 120px;
height: 37px;}
       .common_subheading {color: #aa0008;font-size: 14px;font-family: "robotobold",Helvetica,Roboto,Arial,sans-serif;text-transform: uppercase;}
        .inner_right_panel{height: 100% !important;}
        /* Add your own MailChimp form style overrides in your site stylesheet or in this style block.
	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
</style>
<div id="mc_embed_signup">
<form action="//swisscham.us5.list-manage.com/subscribe/post?u=9efdfb3439fd20e2fdfddc6bc&amp;id=6a020d6bc3" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll">
	<h3 class="common_subheading">NEWSLETTER</h3>

<div class="mc-field-group">
	
    <p> <input type="text" value="" placeholder="FIRST NAME" name="FNAME" class="required" id="mce-FNAME"></p>
</div>
<div class="mc-field-group">
	
    <p> <input type="text" value="" placeholder="LAST NAME" name="LNAME" class="required" id="mce-LNAME"></p>
</div>
<!--<div class="mc-field-group">
	
    <input type="text" placeholder="POSITION" value="" name="MMERGE4" class="required" id="mce-MMERGE4">
</div>
<div class="mc-field-group">
	
    <input type="text" value="" placeholder="COMPANY" name="MMERGE3" class="required" id="mce-MMERGE3">
</div>-->

<div class="mc-field-group">
	
    <p><input type="email" value="" placeholder="EMAIL" name="EMAIL" class="required email" id="mce-EMAIL"></p>
</div>
	<div id="mce-responses" class="clear">
		<div class="response" id="mce-error-response" style="display:none"></div>
		<div class="response" id="mce-success-response" style="display:none"></div>
	</div>
    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_9efdfb3439fd20e2fdfddc6bc_6a020d6bc3" tabindex="-1" value=""></div>
    <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button button newsletter_button"></div>
    </div>
</form>
</div>
<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';fnames[0]='EMAIL';ftypes[0]='email';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
<!--End mc_embed_signup-->
        </div>
    </div>
</div>
