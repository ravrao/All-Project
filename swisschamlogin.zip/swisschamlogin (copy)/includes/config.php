<?php
session_start();
include('connection.php');

//////////////local////////////
//$base_url = "localhost/swischamplogin/";

//////////////live////////////
$base_url = "http://www.swisschamofcommerce.com/swisschamlogin/";
//$site_url="http://54.152.108.131/SwissCham/";
$site_url="http://www.swisschamofcommerce.com/";
?>
