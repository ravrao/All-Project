<nav id="log_togg">
            <ul class="logsec_sidenav">
                <li><a href="#">Login</a></li>
                <li class="side_joinnow"><a href="#">Join US</a></li>
                <li class="right_menu_heading show-for-medium-only">Select Language</li>
                <li class="side_lang show-for-medium-only"><a href="#">EN</a> <a href="#">中文</a></li>
            </ul>
        </nav>

        <nav id="menu">
            <ul>
                <li class="side_lang show-for-small-only"><a href="#">EN</a> <a href="#">中文</a></li>
                <li class="region_side_icon">
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                        <option value="#">Home</option>
                        <option value="<?php echo $site_url ;?>bei/">Beijing</option>
                        <option value="<?php echo $site_url ;?>sha/">Shanghai</option>
                        <option value="<?php echo $site_url ;?>gz/">Guangzhou</option>
                        <option value="<?php echo $site_url ;?>hk/">Hong Kong</option>
                    </select>
                </li>
                <li><a href="#about">ABOUT US</a>
                    <ul>
                        <li><a href="javascript:void(0);">Who are we?</a>
                            <ul>
                                <li><a href="<?php echo $site_url ;?>swisscham-china-who-are-we/">SwissCham China</a></li>
                                <li><a href="<?php echo $site_url ;?>swisscham-hong-kong-who-are-we/">SwissCham Hong Kong</a></li>
                                
                            </ul>
                        </li>
                        <li><a href="javascript:void(0);">History</a>
                        <ul>
                            <li><a href="<?php echo $site_url ;?>history-china/">SwissCham China</a></li>
                            <li><a href="<?php echo $site_url ;?>history-hong-kong/">SwissCham Hong Kong</a></li>
                        </ul>
                        </li>
                        <li><a href="<?php echo $site_url ;?>swisscham-china-rules/">Rules</a></li>
                        <li><a href="javascript:void(0);">Board of Directors</a>
                        <ul>
                            <li><a href="<?php echo $site_url ;?>swisscham-board-beijing/">Beijing</a></li>
                            <li><a href="<?php echo $site_url ;?>swisscham-board-shanghai/">Shanghai</a></li>
                            <li><a href="<?php echo $site_url ;?>swisscham-board-guangzhou/">Guangzhou</a></li>
                            <li><a href="<?php echo $site_url ;?>swisscham-board-hong-kong/">Hong Kong</a></li>
                        </ul>
                        </li>
                        <li><a href="javascript:void(0);">Management</a>
                        <ul>
                            <li><a href="<?php echo $site_url ;?>management-beijing/">Beijing</a></li>
                            <li><a href="<?php echo $site_url ;?>management-shanghai/">Shanghai</a></li>
                        </ul>
                        </li>
                        <li><a href="<?php echo $site_url ;?>contact-us/">Contact Us</a></li>
                    </ul>
                </li>
                <li><a href="javascript:void(0);">MEMBERSHIP</a>
                    <ul>
                        <li>
                            <a href="javascript:void(0);">Why join us?</a>
                            <ul>
                                <li><a href="<?php echo $site_url ;?>why-join-us-swisscham-china/">SwissCham China</a></li>
                                <li><a href="<?php echo $site_url ;?>why-join-us-swisscham-hong-kong/">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="online_application.php">Online Application</a>
                        </li>
                        <li>
                            <a href="member_directory_general_page.php">Members Directory</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>investment-zone/">Investment Zones</a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">Member Benefits Program</a>
                            <ul>
                                <li ><a href="<?php echo $site_url ;?>member-benefits-program-mbp-beijing/">Beijing</a></li>
                                <li><a href="<?php echo $site_url ;?>member-benefits-program-mbp-shanghai/">Shanghai</a></li>
                                <li ><a href="<?php echo $site_url ;?>member-benefits-program-mbp-hong-kong/">Hong Kong</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="javascript:void(0);" class="">EVENTS</a>
                    <ul>
                        <li>
                            <a href="<?php echo $site_url ;?>upcoming-events/">Upcoming Events</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>event-calender/">Events Calendar</a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">Events Overview</a>
                            <ul>
                                <li><a href="<?php echo $site_url ;?>beijing-events-overview/">Beijing</a></li>
                                <li><a href="<?php echo $site_url ;?>shanghai-events-overview/">Shanghai</a></li>
                                <li><a href="<?php echo $site_url ;?>guangzhou-events-overview/">Guangzhou</a></li>
                                <li><a href="<?php echo $site_url ;?>hongkong-events-overview/">Hong Kong</a></li>
                            </ul>
                        </li>
                        <!--<li>
                            <a href="#">Company Visits</a>
                        </li>-->
                    </ul>
                </li>


                <li><a href="#about">PUBLICATIONS</a>
                    <ul>
                        <li>
                            <a href="<?php echo $site_url ;?>the-bridge-magazine/">The Bridge</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>news/">News</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>readers-digest/">Sino-Swiss Business News</a>
                        </li>
                        
                        <li>
                            <a href="<?php echo $site_url ;?>legal-and-investment-updates/">Legal & Investment Updates</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>invest-in-switzerland/">Invest in Switzerland</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>business-publications/">Business Publications</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>other-links/">Other Links</a>
                        </li>
                    </ul>
                </li>

                <li><a href="#about">SERVICES</a>
                    <ul>
                        <li>
                            <a href="<?php echo $site_url ;?>our-services/">Our services</a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">Advertise With Us</a>
                            <ul>
                                <li><a href="<?php echo $site_url ;?>advertise-with-us/">SwissCham China</a></li>
                                <li><a href="<?php echo $site_url ;?>advertise-with-us/">SwissCham Hong Kong</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>jobs/">Job Opportunities</a>
                        </li>
                        
                        <!--<li>
                            <a href="javascript:void(0);">Training</a>
                        </li>-->
                        <li>
                            <a href="#">Lobbying Activities</a>
                        </li>
                        <li>
                            <a href="<?php echo $site_url ;?>wechat/"><a href="#">Wechat?</a>
                        </li>
                    </ul>
                </li>
            </ul>

        </nav>