<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
if(empty($_SESSION['userId']) || $_SESSION['userId']=='44'){
?>
    <!doctype html>
    <html class="no-js" lang="en">

    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Swisscham | Online Application</title>
        <link rel="stylesheet" href="css/app.css">
        <link rel="stylesheet" href="css/jquery.steps.css">
        <link rel="stylesheet" href="css/membership_steps.css">
        <!-- Favicon -->
		<link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.css" rel="stylesheet">
        <link href="css/dev1.css" rel="stylesheet">
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }

        </style>
    </head>

    <body>
        <div id="page">
            <?php 
			require_once(__ROOT__.'/includes/header.php'); 
	    ?>

<div class="abc"></div>
<section class="inner_banner bg-beijing hide-for-small-only">
    <div class="inner_bredcrumb">
        <nav aria-label="You are here:" role="navigation">
            <ul class="breadcrumbs page_bredcrunb">
                <li><a href="<?=$site_url?>">Home</a></li>
                <li><a href="#">Membership</a></li>
                <li>
                 <span class="show-for-sr">Current: </span> Online Application</li>
            </ul>
        </nav>
    </div>
</section>
<section>
    <div class="row">
        <div class="large-9 medium-8 small-12 columns no_padding margin_top15">
            <div class="large-12 columns dowedo_top">
                <h1 class="common_heading">Online Membership Application</h1>
            </div>
           <form name="onlineApplicationForm" id="onlineApplicationForm" action="online_application_process.curr.php" method="POST" enctype="multipart/form-data">
<div class="large-12 columns dowedo_top margin_top10">

    <div id="wizard">
        <h2>Membership type</h2>
        <section class="firstSection">
            <h3 class="common_subheading">Find the right membership type by answering a few questions (max. 6)</h3>

            <div class="large-12 columns application_question_container">
                <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Choose your location</h3>
                <div class="medium-12 columns">
                    <select id="stateDrop" name="company_chamber" id="company_chamber" class="stateDrop">
                        <option value="">-Select-</option>
                        <option value="Beijing" id="beijingDrop">Beijing</option>
                        <option value="Shanghai" id="shangDrop">Shanghai</option>
                        <option value="Guangzhou" id="guangDrop">Guangzhou</option>
                        <option value="HongKong" id="hkDrop">Hong Kong</option>
                        <option value="ChinaMainland" id="chDrop">China Mainland</option>

                    </select>
                </div>
            </div>
<div class="beijing_drop_content all_drop_content">
    <div id="beQ1" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.aCompany').show(); $('#beQ2').show();$('.b_no_member').hide();" type="radio" name="b_view_1" value="A_company" id="a_comp" class="b_view_1">
                    <label for="a_comp" class="b_view_1">A company</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.anIndividual').show(); $('#beQ2').show(); $('.b_no_member').hide();" type="radio" name="b_view_1" value="An_individual" id="an_indiv" class="b_view_1">
                    <label for="an_indiv" class="b_view_1">An individual</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('#beQ2').show(); $('.generalClass').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').hide(); $('.npomembership').show();" type="radio" name="b_view_1" value="NPO_Journalist_500_RMB" id="npo" class="no_mem b_view_1">
                    <label for="npo" class="no_mem b_view_1">A NPO (organization without government affiliation)</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('#beQ2').hide(); $('#beQ3').hide(); $('#beQ4').hide(); $('#beQ5').show(); $('.b_no_member').hide();" type="radio" name="b_view_1" value="An_investment_zone" id="zone" class="b_view_1">
                    <label for="zone" class="b_view_1">An investment zone</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="beQ2" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable generalClass aCompany">
                    <input onclick="$('.b_ques3').hide(); $('#beQ4').hide(); $('#beQ3').show();" type="radio" name="b_view_2" value="Swiss_invested_company" id="sic" class="b_view_2">
                    <label for="sic" class="b_view_2">Swiss invested company</label>
                </li>
                <li class="removedisable generalClass aCompany">
                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_associate').show(); $('#beQ4').show();" type="radio" name="b_view_2" value="Non-Swiss_invested_company" id="nsic" class="b_view_2">
                    <label for="nsic" class="b_view_2">Non-Swiss invested company</label>
                </li>
                <li class="removedisable generalClass anIndividual">
                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_indiv').show(); $('#beQ4').show(); " type="radio" name="b_view_2" value="Individual_(above_35_y/o)" id="indv" class="b_view_2">
                    <label for="indv" class="b_view_2">Individual (above 35 y/o)</label>
                </li>
                <li class="removedisable generalClass anIndividual">
                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_yp').show(); $('#beQ4').show();" type="radio" name="b_view_2" value="Young_Professional_(under_35_y/o)" id="young" class="b_view_2">
                    <label for="young" class="b_view_2">Young Professional (under 35 y/o)</label>
                </li>
                <li class="removedisable generalClass anIndividual">
                    <input onclick="$('#beQ3').hide(); $('#beQ4').hide(); $('.be_gen_class').hide(); $('.be_mem_bej_jur').show(); $('#beQ4').show();" type="radio" name="b_view_2" value="journalist" id="bej_journalist" class="b_view_2">
                    <label for="bej_journalist" class="b_view_2">Journalist </label>
                </li>
                <li class="removedisable adddisable generalClass npomembership">
                    <input type="radio" name="b_view_2" value="NPO_Membership_(Beijing)_RMB_500_/_year" id="npomem" class="b_view_2">
                    <label for="npomem" class="b_view_2">NPO Membership (Beijing) RMB 500 / year </label>
                </li>

            </ul>
        </div>
    </div>

    <div id="beQ3" class="large-12 columns application_question_container hide_steps b_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.be_gen_class').hide(); $('.be_mem_l_corp').show(); $('#beQ4').show();" type="radio" name="b_view_3" value="100_staff_or_more_in_Mainland_China" id="be_hun_staff" class="b_view_3">
                    <label for="be_hun_staff" class="b_view_3">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.be_gen_class').hide(); $('.be_mem_sm_corp').show(); $('#beQ4').show();" type="radio" name="b_view_3" value="1-99_staff_in_Mainland_China" id="be_nin_staff" class="b_view_3">
                    <label for="be_nin_staff" class="b_view_3">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="beQ4" class="large-12 columns application_question_container hide_steps b_ques4">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable adddisable be_gen_class be_mem_associate">
                    <input type="radio" name="b_view_4" value="Associate_Membership_(Beijing)_RMB_10'000_/_Year" id="member_associate" class="b_view_4">
                    <label for="member_associate" class="b_view_4">Associate Membership (Beijing) RMB 10'000 / Year</label>
                </li>
                <li class="removedisable adddisable be_gen_class be_mem_indiv">
                    <input type="radio" name="b_view_4" value="Individual_Membership_(Beijing)_RMB_2'400_/_Year" id="member_individual" class="b_view_4">
                    <label for="member_individual" class="b_view_4">Individual Membership (Beijing) RMB 2'400 / Year</label>
                </li>
                <li class="removedisable adddisable be_gen_class be_mem_yp">
                    <input type="radio" name="b_view_4" value="YP_Membership_(Beijing)_RMB_500_/_Year" id="yp_member" class="b_view_4">
                    <label for="yp_member" class="b_view_4">YP Membership (Beijing) RMB 500 / Year</label>
                </li>
                <li class="removedisable adddisable be_gen_class be_mem_l_corp">
                    <input type="radio" name="b_view_4" value="L_Corporate_Membership_(Beijing)_RMB_7'500_/_Year" id="l_corp" class="b_view_4">
                    <label for="l_corp" class="b_view_4">L Corporate Membership (Beijing) RMB 7'500 / Year</label>
                </li>
                <li class="removedisable adddisable be_gen_class be_mem_sm_corp">
                    <input type="radio" name="b_view_4" value="S/M_Corporate_Membership_(Beijing)_RMB_5'000_/_Year" id="sm_corp" class="b_view_4">
                    <label for="sm_corp" class="b_view_4">S/M Corporate Membership (Beijing) RMB 5'000 / Year</label>
                </li>
                <li class="removedisable adddisable be_gen_class be_mem_bej_jur">
                    <input type="radio" name="b_view_4" value="Journalist_membership_(Beijing)_RMB_500_/_Year" id="jur_corp" class="b_view_4">
                    <label for="jur_corp" class="b_view_4">Journalist membership (Beijing) RMB 500 / Year</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="beQ5" class="large-12 columns application_question_container hide_steps b_ques5">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I Am / We Are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable adddisable investZone">
                    <input onclick="$('#beQ2').hide(); $('#beQ3').hide(); $('#beQ4').hide();" type="radio" name="b_view_5" value="Associate_Membership_(Beijing)_RMB_10'000_/_Year" id="memfee" class="b_view_5">
                    <label for="memfee" class="b_view_5">Associate Membership (Beijing) RMB 10'000 / Year</label>
                </li>
            </ul>
        </div>
    </div>


</div>

<div class="shanghai_drop_content all_drop_content">

    <div id="shQ1" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('.shgeneralClass').hide(); $('#shQ4').hide(); $('#shQ3').hide(); $('#shQ3_sec').hide(); $('.sh_aCompany').show(); $('#shQ2').show();" type="radio" name="s_view_1" value="A_company" id="ques1" class="s_view_1">
                    <label for="ques1" class="s_view_1">A company</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.shgeneralClass').hide(); $('#shQ4').hide(); $('#shQ3').hide(); $('#shQ3_sec').hide(); $('.sh_anIndividual').show(); $('#shQ2').show();" type="radio" name="s_view_1" value="An_individual" id="ques2" class="s_view_1">
                    <label for="ques2" class="s_view_1">An individual</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="shQ2" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable shgeneralClass sh_aCompany">
                    <input onclick="$('.sh_ques3').hide(); $('#shQ4').hide(); $('#shQ3').show();" type="radio" name="s_view_2" value="Swiss_invested_company" id="sic_sh" class="s_view_2">
                    <label for="sic_sh" class="s_view_2">Swiss invested company</label>
                </li>
                <li class="removedisable shgeneralClass sh_aCompany">
                    <input onclick="$('.sh_ques3').hide();$('#shQ4').hide(); $('#shQ3_sec').show(); " type="radio" name="s_view_2" value="Non-Swiss_invested_company" id="nsic_sh" class="s_view_2">
                    <label for="nsic_sh" class="s_view_2">Non-Swiss invested company</label>
                </li>
                <li class="removedisable shgeneralClass sh_anIndividual">
                    <input onclick="$('.shQ3').hide(); $('.shQ3_sec').hide(); $('.sh_gen_class').hide(); $('.sh_indv_mem').show(); $('#shQ4').show();" type="radio" name="s_view_2" value="Individual_(above_35_y/o)" id="indv_sh" class="s_view_2">
                    <label for="indv_sh" class="s_view_2">Individual (above 35 y/o)</label>
                </li>
                <li class="removedisable shgeneralClass sh_anIndividual">
                    <input onclick="$('.shQ3').hide(); $('.shQ3_sec').hide(); $('.sh_gen_class').hide(); $('.sh_yp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_2" value="Young_Professional_(under_35_y/o)" id="young_sh" class="s_view_2">
                    <label for="young_sh" class="s_view_2">Young Professional (under 35 y/o)</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="shQ3" class="large-12 columns application_question_container hide_steps sh_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.sh_gen_class').hide(); $('.sh_l_corp').show(); $('#shQ4').show();" type="radio" name="s_view_3" value="100_staff_or_more_in_Mainland_China" id="sh_hun_staff" class="s_view_3">
                    <label for="sh_hun_staff" class="s_view_3">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.sh_gen_class').hide(); $('.sh_sm_corp').show(); $('#shQ4').show();" type="radio" name="s_view_3" value="1-99_staff_in_Mainland_China" id="sh_nin_staff" class="s_view_3">
                    <label for="sh_nin_staff" class="s_view_3">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="shQ3_sec" class="large-12 columns application_question_container hide_steps sh_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.sh_gen_class').hide(); $('.sh_l_corp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_4" value="100_staff_or_more_in_Mainland_China" id="sh_hun_staff_sec" class="s_view_4">
                    <label for="sh_hun_staff_sec" class="s_view_4">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.sh_gen_class').hide(); $('.sh_sm_corp_mem').show(); $('#shQ4').show();" type="radio" name="s_view_4" value="1-99_staff_in_Mainlan_China" id="sh_nin_staff_sec" class="s_view_4">
                    <label for="sh_nin_staff_sec" class="s_view_4">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="shQ4" class="large-12 columns application_question_container hide_steps sh_ques4">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable adddisable sh_gen_class sh_indv_mem">
                    <input type="radio" name="s_view_5" value="Individual_Membership_(Shanghai)_RMB_2'400_/_Year" id="sh_indiv_member" class="s_view_5">
                    <label for="sh_indiv_member" class="s_view_5">Individual Membership (Shanghai) RMB 2'400 / Year</label>
                </li>
                <li class="removedisable adddisable sh_gen_class sh_yp_mem">
                    <input type="radio" name="s_view_5" value="YP_Membership_(Shanghai)_RMB_600_/_Year" id="sh_yp_member" class="s_view_5">
                    <label for="sh_yp_member" class="s_view_5">YP Membership (Shanghai) RMB 600 / Year</label>
                </li>
                <li class="removedisable adddisable sh_gen_class sh_l_corp">
                    <input type="radio" name="s_view_5" value="L_Corporate_Membership_(Shanghai)_RMB_7'000_/_Year" id="sh_l_corp" class="s_view_5">
                    <label for="sh_l_corp" class="s_view_5">L Corporate Membership (Shanghai) RMB 7'000 / Year</label>
                </li>
                <li class="removedisable adddisable sh_gen_class sh_sm_corp">
                    <input type="radio" name="s_view_5" value="S/M_Corporate_Membership_(Shanghai)_RMB_4'000_/_Year" id="sh_sm_corp" class="s_view_5">
                    <label for="sh_sm_corp" class="s_view_5">S/M Corporate Membership (Shanghai) RMB 4'000 / Year</label>
                </li>
                <li class="removedisable adddisable sh_gen_class sh_l_corp_mem">
                    <input type="radio" name="s_view_5" value="L_Corporate_Associate_Membership_(Shanghai)_RMB_7'000_/_Year" id="sh_lcorp" class="s_view_5">
                    <label for="sh_lcorp" class="s_view_5">L Associate Membership (Shanghai) RMB 7'000 / Year</label>
                </li>
                <li class="removedisable adddisable sh_gen_class sh_sm_corp_mem">
                    <input type="radio" name="s_view_5" value="S/M_Corporate_Associate_Membership_(Shanghai)_RMB_4'000_/_Year" id="sh_smcorp" class="s_view_5">
                    <label for="sh_smcorp" class="s_view_5">S/M Associate Membership (Shanghai) RMB 4'000 / Year</label>
                </li>
            </ul>
        </div>
    </div>


</div>

<div class="guangzhou_drop_content all_drop_content">

    <div id="guaQ1" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('#guaQ4').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').hide(); $('.gua_company').show(); $('#guaQ2').show();" type="radio" name="g_view_1" value="A_company" id="gua_a_comp" class="g_view_1">
                    <label for="gua_a_comp" class="g_view_1">A company</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').hide(); $('.gua_individual').show(); $('#guaQ2').show(); $('#guaQ4').hide();" type="radio" name="g_view_1" value="An_individual" id="gua_an_indiv" class="g_view_1">
                    <label for="gua_an_indiv" class="g_view_1">An individual</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="guaQ2" class="large-12 columns application_question_container hide_steps cm_ques2">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable generalClass gua_company">
                    <input onclick="$('#guaQ4').hide(); $('#guaQ3_sec').hide(); $('#guaQ3').show();" type="radio" name="g_view_2" value="Swiss_invested_company" id="gua_sic" class="g_view_2">
                    <label for="gua_sic" class="g_view_2">Swiss invested company</label>
                </li>
                <li class="removedisable generalClass gua_company">
                    <input onclick="$('#guaQ4').hide(); $('#guaQ3').hide(); $('#guaQ3_sec').show();" type="radio" name="g_view_2" value="Non-Swiss_invested_company" id="gua_nsic" class="g_view_2">
                    <label for="gua_nsic" class="g_view_2">Non-Swiss invested company</label>
                </li>
                <li class="removedisable generalClass gua_individual">
                    <input onclick="$('.gua_gen_class').hide(); $('.indiv_memship').show(); $('#guaQ4').show(); " type="radio" name="g_view_2" value="Individual_(above_35_y/o)" id="gua_indv" class="g_view_2">
                    <label for="gua_indv" class="g_view_2">Individual (above 35 y/o)</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="guaQ3" class="large-12 columns application_question_container hide_steps gua_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.gua_gen_class').hide(); $('.l_corp_memship').show(); $('#guaQ4').show();" type="radio" name="g_view_3" value="100_staff_or_more_in_Mainland_China" id="gua_hun_staff" class="g_view_3">
                    <label for="gua_hun_staff" class="g_view_3">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.gua_gen_class').hide(); $('.sm_corp_memship').show(); $('#guaQ4').show();" type="radio" name="g_view_3" value="1-99_staff_in_Mainland_China" id="gua_nin_staff" class="g_view_3">
                    <label for="gua_nin_staff" class="g_view_3">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="guaQ3_sec" class="large-12 columns application_question_container hide_steps gua_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.gua_gen_class').hide(); $('.l_corp_membership').show(); $('#guaQ4').show();" type="radio" name="g_view_4" value="100_staff_or_more_in_Mainland_China" id="gu_hun_staff" class="g_view_4">
                    <label for="gu_hun_staff" class="g_view_4">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.gua_gen_class').hide(); $('.gu_sm_corp_membership').show(); $('#guaQ4').show();" type="radio" name="g_view_4" value="1-99_staff_in_Mainland_China" id="gu_nin_staff" class="g_view_4">
                    <label for="gu_nin_staff" class="g_view_4">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="guaQ4" class="large-12 columns application_question_container hide_steps gua_ques4">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable adddisable gua_gen_class indiv_memship">
                    <input onclick="$('.b_ques4').hide(); $('#beQ7').show();" type="radio" name="g_view_5" value="Individual_Membership_(Guangzhou)_RMB_1'200_/_Year" id="gua_ind_mem" class="g_view_5">
                    <label for="gua_ind_mem" class="g_view_5">Individual Membership (Guangzhou) RMB 1'200 / Year</label>
                </li>
                <li class="removedisable adddisable gua_gen_class l_corp_memship">
                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="L_Corporate_Membership_(Guangzhou)_RMB_2'500_/_Year" id="gua_l_corp" class="g_view_5">
                    <label for="gua_l_corp" class="g_view_5">L Corporate Membership (Guangzhou) RMB 2'500 / Year</label>
                </li>
                <li class="removedisable adddisable gua_gen_class sm_corp_memship">
                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="S/M_Corporate_Membership_(Guangzhou)_RMB_1'000_/_Year" id="gua_sm_corp" class="g_view_5">
                    <label for="gua_sm_corp" class="g_view_5">S/M Corporate Membership (Guangzhou) RMB 1'000 / Year</label>
                </li>
                <li class="removedisable adddisable gua_gen_class l_corp_membership">
                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="L_Corporate_Associate_Membership_(Guangzhou)_RMB_2'500_/_Year" id="gu_l_corp" class="g_view_5">
                    <label for="gu_l_corp" class="g_view_5">L Associate Membership (Guangzhou) RMB 2'500 / Year</label>
                </li>
                <li class="removedisable adddisable gua_gen_class gu_sm_corp_membership">
                    <input onclick="$('.b_ques4').hide(); $('#beQ8').show();" type="radio" name="g_view_5" value="S/M_Corporate_Associate_Membership_(Guangzhou)_RMB_1'000_/_Year" id="gu_l_corp1" class="g_view_5">
                    <label for="gu_l_corp1" class="g_view_5">S/M Associate Membership (Guangzhou) RMB 1'000 / Year</label>
                </li>
            </ul>
        </div>
    </div>


</div>

<div class="hongkong_drop_content all_drop_content">
    <div id="hkQ1" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hk_ques4').hide(); $('.hk_ques3').hide(); $('#hkQ2').show();" type="radio" name="h_view_1" value="A_company" id="hk_a_comp" class="h_view_1">
                    <label for="hk_a_comp" class="h_view_1">A company</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hk_ques4').hide(); $('.hk_ques2').hide(); $('#hkQ3').show();" type="radio" name="h_view_1" value="An_individual" id="hk_an_indiv" class="h_view_1">
                    <label for="hk_an_indiv" class="h_view_1">An individual</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="hkQ2" class="large-12 columns application_question_container hide_steps hk_ques2">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hkCorpA').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="50+_employees" id="hk_fif_plus" class="h_view_2 hg_view">
                    <label for="hk_fif_plus" class="h_view_2">50+ employees</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hkCorpB').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="25-49_employees" id="hk_tf_plus" class="h_view_2 hg_view">
                    <label for="hk_tf_plus" class="h_view_2">25-49 employees</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hkCorpC').show(); $('#hkQ4').show();" type="radio" name="h_view_2" value="1-24_employees" id="hk_tf_less" class="h_view_2 hg_view">
                    <label for="hk_tf_less" class="h_view_2">1-24 employees</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="hkQ3" class="large-12 columns application_question_container hide_steps hk_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hkIndvMem').show(); $('#hkQ4').show();" type="radio" name="h_view_3" value="Individual_/_Overseas_(above_35_y/o)" id="hk_hun_staff" class="h_view_3 hg_view">
                    <label for="hk_hun_staff" class="h_view_3">Individual / Overseas (above 35 y/o)</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.generalClass').hide(); $('.hkYpMem').show(); $('#hkQ4').show();" type="radio" name="h_view_3" value="Young_Professional_(under_35_y/o)" id="hk_nin_staff" class="h_view_3">
                    <label for="hk_nin_staff" class="h_view_3 hg_view">Young Professional (under 35 y/o)</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="hkQ4" class="large-12 columns application_question_container hide_steps hk_ques4">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable adddisable generalClass hkCorpA">
                    <input onclick="$('.b_ques3').hide(); $('#beQ3').show();" type="radio" name="h_view_4" value="Corporate_A_Membership_(Hong_Kong)_HKD_7'000_/_Year" id="hk_corp_a" class="h_view_4 hg_view">
                    <label for="hk_corp_a" class="h_view_4">Corporate A Membership (Hong Kong) HKD 7'000 / Year</label>
                </li>
                <li class="removedisable adddisable generalClass hkCorpB">
                    <input onclick="$('.b_ques3').hide(); $('#beQ4').show();" type="radio" name="h_view_4" value="Corporate_B_Membership_(Hong_Kong)_HKD_4'500_/_Year" id="hk_corp_b" class="h_view_4 hg_view">
                    <label for="hk_corp_b" class="h_view_4">Corporate B Membership (Hong Kong) HKD 4'500 / Year</label>
                </li>
                <li class="removedisable adddisable generalClass hkCorpC">
                    <input onclick="$('.b_ques3').hide(); $('#beQ5').show();" type="radio" name="h_view_4" value="Corporate_C_Membership_(Hong_Kong)_HKD_3'000_/_Year" id="hk_corp_c" class="h_view_4 hg_view">
                    <label for="hk_corp_c" class="h_view_4">Corporate C Membership (Hong Kong) HKD 3'000 / Year</label>
                </li>
                <li class="removedisable adddisable generalClass hkIndvMem">
                    <input onclick="$('.b_ques3').hide(); $('#beQ6').show();" type="radio" name="h_view_4" value="Individual_Membership_(Hong_Kong)_HKD_2'500_/_Year" id="hk_indv_mem" class="h_view_4 hg_view">
                    <label for="hk_indv_mem" class="h_view_4">Individual Membership (Hong Kong) HKD 2'500 / Year</label>
                </li>
                <li class="removedisable adddisable generalClass hkYpMem">
                    <input onclick="$('.b_ques3').hide();" type="radio" name="h_view_4" value="YP_Membership_(Hong_Kong)_HKD_500_/_Year" id="hk_yp_mem" class="h_view_4 hg_view">
                    <label for="hk_yp_mem" class="h_view_4">YP Membership (Hong Kong) HKD 500 / Year</label>
                </li>
            </ul>
        </div>
    </div>

</div>

<div class="china_mainland_drop_content all_drop_content">

    <div id="cmQ1" class="large-12 columns application_question_container hide_steps">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('#cmQ2').show(); $('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').hide();" type="radio" name="c_view_1" value="A_company" id="cm_a_comp" class="c_view_1 cg_view">
                    <label for="cm_a_comp" class="c_view_1">A company</label>
                </li>
                <li class="removedisable adddisable" id="chinaindividual">
                    <input onclick="$('.cm_ques2').hide(); $('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').show();" type="radio" name="c_view_1" value="An_individual" id="cm_an_indiv" class="no_mem c_view_1 cg_view">
                    <label for="cm_an_indiv" class="no_mem c_view_1">An individual</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="cmQ2" class="large-12 columns application_question_container hide_steps cm_ques2">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I am / We are</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt">
                <li class="removedisable">
                    <input onclick="$('#cmQ3').show(); $('#cmQ4').hide(); $('.b_no_member').hide();" type="radio" name="c_view_2" value="Swiss_invested_company" id="cm_sic" class="c_view_2 cg_view">
                    <label for="cm_sic" class="c_view_2">Swiss invested company</label>
                </li>
                <li class="removedisable adddisable">
                    <input onclick="$('#cmQ3').hide(); $('#cmQ4').hide(); $('.b_no_member').show();" type="radio" name="c_view_2" value="Non-Swiss_invested_company" id="cm_nsic" class="no_mem c_view_2">
                    <label for="cm_nsic" class="no_mem c_view_2 cg_view">Non-Swiss invested company</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="cmQ3" class="large-12 columns application_question_container hide_steps cm_ques3">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> We have</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable">
                    <input onclick="$('.cmq4_smcorp').hide(); $('#cmQ4').show(); $('.cmq4_lcorp').show();" type="radio" name="c_view_3" value="100_staff_or_more_in_Mainland_China" id="cm_hun_staff" class="c_view_3 cg_view">
                    <label for="cm_hun_staff" class="c_view_3">100 staff or more in Mainland China</label>
                </li>
                <li class="removedisable">
                    <input onclick="$('.cmq4_lcorp').hide(); $('#cmQ4').show(); $('.cmq4_smcorp').show();" type="radio" name="c_view_3" value="1-99_staff_in_Mainland_China" id="cm_nin_staff" class="c_view_3 cg_view">
                    <label for="cm_nin_staff" class="c_view_3">1-99 staff in Mainland China</label>
                </li>
            </ul>
        </div>
    </div>

    <div id="cmQ4" class="large-12 columns application_question_container hide_steps cm_ques4">
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> I / We apply for</h3>
        <div class="medium-12 columns ">
            <ul class="fa-ul quest_radio_opt ">
                <li class="removedisable adddisable cmq4_lcorp">
                    <input type="radio" name="c_view_4" value="L_Corporate_Membership_(China_Mainland)_RMB_15’000_/_Year" id="cm_l_corp" class="c_view_4 cg_view">
                    <label for="cm_l_corp" class="c_view_4">L Corporate Membership (Mainland China) RMB 15’000 / Year</label>
                </li>
                <li class="removedisable adddisable cmq4_smcorp">
                    <input type="radio" name="c_view_4" value="S/M_Corporate_Membership_(China_Mainland)_RMB_9’000_/_Year" id="cm_sm_corp" class="c_view_4 cg_view">
                    <label for="cm_sm_corp" class="c_view_4">S/M Corporate Membership (China Mainland) RMB 9’000 / Year</label>
                </li>
            </ul>
        </div>
    </div>


</div>
<div class="large-12 columns application_question_container no_membership_hide b_no_member margin_top10">
    <div class="medium-12 columns ">
        <p class="text-center margin_top10 margin_bottom10">No membership available. If you have any question, do not hesitate to <a href="<?=$site_url?>contact-us/">contact us</a>. </p>
    </div>
</div>
</section>


<!--<input type="text" name="web_validation_company" id="web_validation_company" value="0">-->
<h2>Company information</h2>
<section>

    <div class="large-12 columns application_question_container" id="cominfo">
        <h3 class="app_quest_head bscop"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS SCOPE</h3>
        <div class="medium-12 columns">
            <!-- <form>-->
            <div class="large-12 columns no_padding">
                <div class="row bscop">
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <div>
                                <input type="radio" name="business_scope" value="Agriculture / Food / Beverages" id="agri" checked>
                                <label for="agri"> Agriculture / Food / Beverages</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Banking / Insurance" id="bank">
                                <label for="bank"> Banking / Insurance</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Chemical / Pharmaceuticals" id="chem">
                                <label for="chem"> Chemical / Pharmaceuticals</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Construction / Civil Engineering" id="construct">
                                <label for="construct"> Construction / Civil Engineering</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Education / Training" id="edu">
                                <label for="edu"> Education / Training</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Government / NGO / NPO / Economic Zone" id="govt">
                                <label for="govt"> Government / NGO / NPO / Economic Zone</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Hospitality / Hotels / Tourism Services" id="hosp">
                                <label for="hosp"> Hospitality / Hotels / Tourism Services</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Information Technology / Telecommunications" id="inform">
                                <label for="inform"> Information Technology / Telecommunications</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Jewellery / Watches" id="jewel">
                                <label for="jewel"> Jewellery / Watches</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Legal / Audit / Consulting" id="legal">
                                <label for="legal"> Legal / Audit / Consulting</label>
                            </div>
                        </div>
                        <div class="medium-6 columns membership_from second_form_field">
                            <div>
                                <input type="radio" name="business_scope" value="Machinery / Equipment" id="machine">
                                <label for="machine"> Machinery / Equipment</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Manufacturing / Electronic" id="manufacture">
                                <label for="manufacture"> Manufacturing / Electronic</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Media / Publication" id="media">
                                <label for="media"> Media / Publication</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Medical / Precision / Optical Instruments" id="medical">
                                <label for="medical"> Medical / Precision / Optical Instruments</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Quality Control / Standards / Testing" id="quality">
                                <label for="quality"> Quality Control / Standards / Testing</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Trading / Logistics / Transportation" id="trading">
                                <label for="trading"> Trading / Logistics / Transportation</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Sales / Marketing / Retail" id="sale">
                                <label for="sale"> Sales / Marketing / Retail</label>
                            </div>
                            <div>
                                <input type="radio" name="business_scope" value="Other" id="other">
                                <label for="other"> Other</label>
                                <input type="text" placeholder="Please Enter Other Business Scope" value="" name="other_business_scope" id="other_business_scope" disabled>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row">

                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS DESCRIPTION (short introduction of your company and your core business) </h3>
                    <div class="medium-6 columns application_form">
                        <label> 150 words in English: <span>*</span>
                            <textarea rows="3" placeholder="Please Enter Business Description In English" name="business_description_english" id="business_description_english" class="companyInfoCommonClass"></textarea>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> 100 characters in Chinese: <span class="commonHongKong">*</span>
                            <textarea rows="3" placeholder="100個漢字" name="business_description_chinese" id="business_description_chinese" class="companyInfoCommonClass"></textarea>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY DETAILS</h3>



                </div>

                <div class="row">
                    <!-- <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY DETAILS</h3> -->
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Company Name in English:<span>*</span>
                                <input type="text" placeholder="Please Enter Company Name" name="company_name_english" id="company_name_english" class="companyInfoCommonClass">
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> Company Name in Chinese:<span class="commonHongKong">*</span>
                                <input type="text" placeholder="公司名稱中文" name="company_name_chinese" id="company_name_chinese" class="companyInfoCommonClass">
                            </label>
                        </div>
                    </div>
                    
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in English:<span>*</span>
                                <textarea rows="3" placeholder="Please Enter Address In English" name="company_address" id="company_address" class="companyInfoCommonClass"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in English:<span>*</span>
                                <input type="text" placeholder="Please Enter City In English" name="company_city" id="company_city" class="companyInfoCommonClass">
                            </label>
                            <label>Province/Area in English:
                                <input type="text" placeholder="Please Enter Province/Area in English" name="province_area_english" id="province_area_english">
                                <!--  <select name="province_area_english" id="province_area_english" style="margin-top:0px !important;" class="companyInfoCommonClass">-->
                            </label>
                        </div>
                    </div>

                    <!-- Changes Done start | 2.11.2016  -->
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in Chinese:<span class="commonHongKong">*</span>
                                <textarea rows="3" placeholder="地址中文" name="china_office_address" id="china_office_address" class="companyInfoCommonClass"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in Chinese:<span class="commonHongKong">*</span>
                                <input type="text" placeholder="城市中文" name="china_office_city" id="china_office_city" class="companyInfoCommonClass">
                            </label>
                            <label>ZIP code:
                                <input type="text" placeholder="Please Enter Zip Code" name="company_zipCode" id="company_zipCode" class="companyInfoCommonClass">
                            </label>
                        </div>
                    </div>
                    <!-- Changes Done end | 2.11.2016  -->
                    
                    <div class="medium-6 columns application_form">
                        <label> General Phone:<span>*</span>
                            <input type="text" placeholder="Please Enter General Phone" name="company_generalPhone" id="company_generalPhone" class="companyInfoCommonClass">
                        </label>
                    </div>

                    <!-- Changes Done start | 2.11.2016  -->
                    <div class="medium-6 columns application_form">
                        <label> General E-mail:<span>*</span>
                            <input type="text" placeholder="Please Enter General E-mail" name="company_email" id="company_email" class="companyInfoCommonClass">
                            <p>If email is unavailable, please enter 'NA' </p>
                        </label>
                    </div>
                    <!-- Changes Done end | 2.11.2016  -->

                    <div class="medium-6 columns application_form">
                        <label> General website:<span>*</span>
                            <input type="text" placeholder="Please Enter General Website" name="company_website" id="company_website" class="companyInfoCommonClass">
                            <p>If website is unavailable, please enter 'NA' </p>
                        </label>
                    </div>

                    <!-- Changes Done start | 2.11.2016  -->
                    <div class="medium-6 columns application_form">
                        <label>Legal entity <span>*</span>
                            <select name="legal_entity" id="legal_entity" style="margin-top:0px !important;" class="companyInfoCommonClass">
                                <option value=""> -Select-</option>
                                <option value="domestic"> Chinese Domestic</option>
                                <option value="joint">Joint-Venture</option>
                                <option value="foreign">Wholly Foreign-Owned</option>
                                <option value="represent"> Representative Office</option>
                            </select>
                        </label>
                    </div>
                    <!-- Changes Done end | 2.11.2016  -->
                </div>

                <div class="row">
                    <!--<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY STRUCTURE</h3> -->
                    <div class="medium-6 columns application_form">
                        <label>Number of employees in <strong id="nmcmpno"></strong><span>*</span>
                            <input type="text" placeholder="Please Enter Number Of Employees" name="no_of_employees" id="no_of_employees" class="companyInfoCommonClass">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                    </div>
                    <!--<div class="medium-12 columns membership_from second_form_field">
                <legend>Is your company Swiss-invested?</legend>
                <input type="radio" name="is_company_swiss_invested" value="yes" id="si_yes" checked>
                <label for="si_yes"> Yes</label>
                <input type="radio" name="is_company_swiss_invested" value="no" id="si_no">
                <label for="si_no"> No</label>
            </div>-->


                    <!-- Changes Done start | 2.11.2016  -->

                    <div id="non_hong_kong">
                        <div class="medium-12 columns membership_from second_form_field">
                            <legend>Is your company Swiss-registered?</legend>
                            <input type="radio" name="is_company_swiss_registered" value="yes" id="sr_yes" class="chkBox companyInfoCommonClass" checked>
                            <label for="sr_yes" class="chkBox companyInfoCommonClass"> Yes</label>
                            <input type="radio" name="is_company_swiss_registered" value="no" id="sr_no" class="chkBox companyInfoCommonClass">
                            <label for="sr_no" class="chkBox companyInfoCommonClass"> No</label>
                        </div>
                        <div class="medium-12 columns membership_from second_form_field">
                            <legend>Are you registered in PRC with a valid business licence?</legend>
                            <input type="radio" name="is_company_registered_PRC" value="yes" id="prc_reg_yes" class="chkBox companyInfoCommonClass" checked>
                            <label for="prc_reg_yes" class="chkBox  companyInfoCommonClass"> Yes</label>
                            <input type="radio" name="is_company_registered_PRC" value="no" id="prc_reg_no" class="chkBox companyInfoCommonClass">
                            <label for="prc_reg_no" class="chkBox companyInfoCommonClass"> No</label>
                        </div>
                    </div>

                    <div id="hong_kong_add" style="display:none;">
                        <div class="medium-12 columns no_padding">
                            <div class="medium-6 columns application_form">
                                <label>Year of Establishment in Hong Kong:<span>*</span>
                                    <input type="text" placeholder="Please Enter Year Of Establishment" name="establishment_hongkong" id="establishment_hongkong" class="companyInfoCommonClass">
                                </label>
                            </div>

                            <div class="medium-6 columns application_form">
                                <label>Geographical Responsibility of your company in Hong Kong:<span>*</span>
                                    <input type="text" placeholder="Please Enter Geographical Responsibility Of Your Company" name="geographical_responsibility_hongkong" id="geographical_responsibility_hongkong" class="companyInfoCommonClass">
                                </label>
                            </div>
                        </div>
                    </div>
                    <!-- Changes Done end | 2.11.2016  -->
                </div>

                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> HEADQUARTER DETAILS</h3>
                    <div class="medium-12 columns application_form">
                        <label> Company Name:<span>*</span>
                            <input type="text" placeholder="Please Enter Company Name" name="headquarter_name" id="headquarter_name" class="companyInfoCommonClass">
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address:<span>*</span>
                                <textarea rows="3" placeholder="Please Enter Address" name="headquarter_address" id="headquarter_address" class="companyInfoCommonClass"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in English:<span>*</span>
                                <input type="text" placeholder="Please Enter City In English" name="headquarter_city" id="headquarter_city" class="companyInfoCommonClass">
                            </label>
                            <label>ZIP code:
                                <input type="text" placeholder="Please Enter Zip Code" name="headquarter_zipCode" id="headquarter_zipCode" class="companyInfoCommonClass">
                            </label>
                        </div>
                    </div>

                    <div class="medium-6 columns application_form">
                        <label> General phone:<span>*</span>
                            <input type="text" placeholder="Please Enter General Phone" name="headquarter_phone" id="headquarter_phone" class="companyInfoCommonClass">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">

                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Province/Area in English:
                            <input type="text" placeholder="Please Enter Province/Area in English" name="headquarter_province_area_english" id="headquarter_province_area_english">
                        </label>
                    </div>
                </div>
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Company’s Logo: <!--<span style="color:red;">*</span>--></h3>
                    <div class="medium-12 columns no_padding">
                        <div class="large-12 columns margin_bottom10">
                            <div class="margin_top10">
                                <label for="fstexampleFileUploadx" class="button no_margin_bottom">Upload Logo</label>
                                <input type="file" id="fstexampleFileUploadx" class="show-for-sr companyInfoCommonClass" name="logo_name" onchange="showImage3(this,0);">
                            </div>
                            <div class="medium-12 columns no_padding">
                                <label for="over_13" class="light no_margin_bottom" id="preview_label_id" style="display:block;"></label>
                                <div style="float:left;position:relative;">
                                    <img class="thumbnail" id="preview" src="" alt="" style="display:none; margin-bottom: 5px;" />
                                </div>
                            </div>
                            <small>
                                Please upload the company logo<br>
                                Files must be less than 20 MB. <br>
                                           Allowed file types: jpg jpeg png gif</small>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="large-12 columns application_question_container" id="blankinfo" style="display:none;">
        <div class="medium-12 columns">
            <div class="large-12 columns no_padding">
                <div class="row bscop">
                    <div class="medium-12 columns no_padding">
                        <div class="blank_info_details">
                            <p>No information required, please click on “Next step"</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<h2>Contact information</h2>
<section>

    <div class="large-12 columns application_question_container">
        <div class="genCls" id="cmpHld">
            <!--<h2 class="steps_common_heading">COMPANY HOLDER INFORMATION</h2> -->
            <div class="large-12 columns">
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> MEMBERSHIP HOLDER INFORMATION (main contact) </h3>
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="company_first_contact_title" value="Ms" id="chi_miss">
                        <label for="chi_miss"> Ms.</label>
                        <input type="radio" name="company_first_contact_title" value="Mr" id="chi_mister">
                        <label for="chi_mister"> Mr.</label>
                        <input type="radio" name="company_first_contact_title" value="Dr" id="chi_doctor">
                        <label for="chi_doctor"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <input type="text" placeholder="Please Enter Date Of Birth" name="company_first_contact_dob" id="company_first_contact_dob" class="datepicker">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="company_first_contact_familyName" id="company_first_contact_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s): <span>*</span>
                            <input type="text" placeholder="Please Enter Given Name" name="company_first_contact_givenName" id="company_first_contact_givenName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese Name:<span class="commonHongKong">*</span>
                            <input type="text" placeholder="中文名称" name="company_first_contact_chineseName" id="company_first_contact_chineseName">
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <legend> Nationality: </legend>


                            <input type="radio" name="company_first_contact_nationality" value="swiss" id="nation_swiss" class="company_first_contact_nationality" checked>
                            <label for="nation_swiss" class="company_first_contact_nationality"> Swiss</label>

                            <span class="nationForAll">
                            <input type="radio" name="company_first_contact_nationality" value="chinese" id="nation_chinese" class="company_first_contact_nationality">
                            <label for="nation_chinese" class="company_first_contact_nationality"> Chinese</label>
                            </span>


                            <span class="nationForHongkong" style="display:none;">
                                                                                                <input type="radio" name="company_first_contact_nationality" value="other" id="nation_other" class="company_first_contact_nationality">
                            <label for="nation_hongkong" class="company_first_contact_nationality"> Hong Kong</label>
                                                                                                </span>



                            <input type="radio" name="company_first_contact_nationality" value="other" id="nation_hongkong" class="company_first_contact_nationality">
                            <label for="nation_other" class="company_first_contact_nationality"> Other</label>

                        </div>



                        <div class="medium-6 columns application_form">
                            <label> Position in the company:<span>*</span>
                                <div class="input-group">
                                    <input type="text" placeholder="Please Enter Position In The Company" name="company_first_contact_position" id="company_first_contact_position">
                                </div>
                            </label>
                        </div>
                    </div>

                    <!-- Changes Done start | 2.11.2016  -->
                    <!--    <div class="medium-6 columns application_form">
                        <label> Company name in English:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Type your company name" name="company_name_english" id="company_name_english">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Company name in Chinese:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="请输入公�?��??称" name="company_name_chinese" id="company_name_chinese">
                            </div>
                        </label>
                    </div>
-->
                    

                    
                    <!--
                    <div class="medium-6 columns application_form">
                        <label> General Phone: <span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Type your general phone number" name="company_first_contact_general_phone" id="company_first_contact_general_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> General Email: <span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Type your general email address" name="company_first_contact_general_email" id="company_first_contact_general_email">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Website:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Type your website" name="chinese_company_website" id="chinese_company_website">
                            </div>
                        </label>
                    </div>-->

                    <!-- Changes Done end | 2.11.2016  -->

                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="company_first_contact_direct_phone" id="company_first_contact_direct_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="company_first_contact_direct_email" id="company_first_contact_direct_email">
                            </div>
                        </label>
                    </div>

                    <div class="medium-6 columns application_form">
                        <label> Mobile:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile Number" name="company_first_contact_mobile" id="company_first_contact_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>
                            <div class="input-group"> </div>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <!--
                                                                <div class="medium-12 columns">
                                                                        <hr />
                                                                </div>
-->
                </div>
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact 1</h3>
                    <!-- <div class="medium-6 columns application_form">
                        <label> Position within the company:<span>*</span>
                            <div class="input-group">
                                <input type="text" placeholder="Type your position within the company" name="second_contact_person_position" id="second_contact_person_position">
                            </div>
                        </label>
                    </div> -->
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="company_second_contact_person_title" value="Ms" id="sec_contact_miss" class="company_second_contact_person_title">
                        <label for="sec_contact_miss" class="company_second_contact_person_title"> Ms.</label>
                        <input type="radio" name="company_second_contact_person_title" value="Mr" id="sec_contact_mister" class="company_second_contact_person_title">
                        <label for="sec_contact_mister" class="company_second_contact_person_title"> Mr.</label>
                        <input type="radio" name="company_second_contact_person_title" value="Dr" id="sec_contact_doctor" class="company_second_contact_person_title">
                        <label for="sec_contact_doctor" class="company_second_contact_person_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date Of Birth" name="company_second_contact_person_dob" id="company_second_contact_person_dob" class="datepicker">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="company_second_contact_person_familyName" id="company_second_contact_person_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Given name" name="company_second_contact_person_givenName" id="company_second_contact_person_givenName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="中文名称" name="second_contact_person_chineseName" id="second_contact_person_chineseName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <legend> Nationality: </legend>


                            <input type="radio" name="company_second_contact_person_nationality" value="swiss" id="nation_swiss" class="company_second_contact_person_nationality">
                            <label for="nation_swiss" class="company_second_contact_person_nationality"> Swiss</label>

                            <span class="nationForAll">
                            <input type="radio" name="company_second_contact_person_nationality" value="chinese" id="nation_chinese" class="company_second_contact_person_nationality">
                            <label for="nation_chinese" class="company_second_contact_person_nationality"> Chinese</label>
                            </span>


                            <span class="nationForHongkong" style="display:none;">
                            <input type="radio" name="company_second_contact_person_nationality" value="hongkong" id="nation_other" class="company_second_contact_person_nationality">
                            <label for="nation_hongkong" class="company_second_contact_person_nationality"> Hong Kong</label>
                            </span>



                            <input type="radio" name="company_second_contact_person_nationality" value="other" id="nation_hongkong" class="company_second_contact_person_nationality">
                            <label for="nation_other" class="company_second_contact_person_nationality"> Other</label>

                        </div>

                        <div class="medium-6 columns application_form">
                            <label> Position in the company:
                                <!--<span>*</span>-->
                                <div class="input-group">
                                    <input type="text" placeholder="Please Enter Position In The Company" name="company_second_contact_position" id="company_second_contact_position">
                                </div>
                            </label>
                        </div>

                    </div>


                    
                     
                    <div class="medium-6 columns application_form">
                        <label> Mobile:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile Number" name="second_contact_person_mobile" id="second_contact_person_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="second_contact_person_directPhone" id="second_contact_person_directPhone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="second_contact_person_directMail" id="second_contact_person_directMail">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>
                            <div class="input-group">

                            </div>
                        </label>
                    </div>
                </div>



            </div>
        </div>



        <!------->
        <div class="genCls" id="invstHld">
            <!--     <h2 class="steps_common_heading">INFORMATION FORM FOR INVESTMENT ZONE</h2>
            <div class="large-12 columns">
                <div class="row">

                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> BUSINESS DESCRIPTION (short introduction of your company and your core business) </h3>
                    <div class="medium-6 columns application_form">
                        <label> 150 words in English: <span>*</span>
                            <textarea rows="3" placeholder="Type your text" name="business_description_english_inv" id="business_description_english_inv"></textarea>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> 100 characters in Chinese: <span>*</span>
                            <textarea rows="3" placeholder="请填写您的信�?�" name="business_description_chinese_inv" id="business_description_chinese_inv"></textarea>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADDRESS</h3>
                    <div class="medium-6 columns application_form">
                        <label> Name in English:<span>*</span>
                            <input type="text" placeholder="Type your name" name="business_description_name_english" id="business_description_name_english">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Name in Chinese:<span>*</span>
                            <input type="text" placeholder="请输入您的姓�??" name="business_description_name_chinese" id="business_description_name_chinese">
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in English:<span>*</span>
                                <textarea rows="3" placeholder="Type your address" name="business_description_address_english" id="business_description_address_english"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in English:<span>*</span>
                                <input type="text" placeholder="Type your city" name="business_description_city_english" id="business_description_city_english">
                            </label>
                            <label>Province/Area in English:<span>*</span>

                                <select name="" id="" style="margin-top:0px !important;">
                                    <option value="Beijing" id="">Beijing</option>
                                    <option value="Shanghai" id="">Shanghai</option>
                                    <option value="Guangzhou" id="">Guangzhou</option>
                                    <option value="HongKong" id="">Hong Kong</option>
                                    <option value="ChinaMainland" id="">China Mainland</option>
                                </select>
                            </label>
                        </div>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in Chinese:<span>*</span>
                                <textarea rows="3" placeholder="请输入地�?�" name="business_description_address_chinese" id="business_description_address_chinese"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in Chinese <span>*</span>
                                <input type="text" placeholder="请输入城市" name="business_description_city_chinese" id="business_description_city_chinese">
                            </label>
                            <label>ZIP code:<span>*</span>
                                <input type="text" placeholder="Type your ZIP code" name="business_description_zipCode_chinese" id="business_description_zipCode_chinese">
                            </label>
                        </div>

                    </div>


                    <div class="medium-6 columns application_form">
                        <label> General phone: <span>*</span>
                            <input type="text" placeholder="Type your general phone number" name="business_description_phone" id="business_description_phone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> General website:<span>*</span>
                            <input type="text" placeholder="Type your general website" name="business_description_website" id=" business_description_website">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <div class="large-12 columns no_padding">
                            <div>
                                <label for="exampleFileUpload" class="button no_margin_bottom upload_file_btn">Upload File</label>
                                <input type="file" id="exampleFileUpload" class="show-for-sr" name="business_description_logo">
                            </div>
                            <small>Files must be less than 20 MB. <br>
                                                                        Allowed file types: jpg jpeg gif png pdf mp4 doc docx xls xlsx.</small>
                        </div>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Number of employees in Beijing / Mainland China<span>*</span>
                            <input type="text" placeholder="Type the number of employees" name="business_description_no_of_employee" id="business_description_no_of_employee">
                        </label>
                    </div>
                </div>
            </div>-->

            <h2 class="steps_common_heading">INVESTMENT ZONE MEMBERSHIP HOLDER INFORMATION</h2>
            <div class="large-12 columns ">
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="investZone_contact_title" value="Ms" id="invest_zone_miss" class="investZone_contact_title">
                        <label for="invest_zone_miss" class="investZone_contact_title"> Ms.</label>
                        <input type="radio" name="investZone_contact_title" value="Mr" id="invest_zone_mister" class="investZone_contact_title">
                        <label for="invest_zone_mister" class="investZone_contact_title"> Mr.</label>
                        <input type="radio" name="investZone_contact_title" value="Dr" id="invest_zone_doctor" class="investZone_contact_title">
                        <label for="invest_zone_doctor" class="investZone_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date Of Birth" name="investZone_contact_dob" id="investZone_contact_dob">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:<span>*</span>
                            <input type="text" placeholder="Please Enter Family Name" name="investZone_contact_familyName" id="investZone_contact_familyName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):<span>*</span>
                            <input type="text" placeholder="Please Enter Given Name" name="investZone_contact_givenName" id="investZone_contact_givenName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese Name:<span>*</span>
                            <input type="text" placeholder="中文名稱" name="investZone_contact_chineseName" id="investZone_contact_chineseName">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <legend> Nationality:</legend>
                        <input type="radio" name="investZone_contact_nationality" value="swiss" id="nationality_swiss" class="investZone_contact_nationality" checked>
                        <label for="nationality_swiss" class="investZone_contact_nationality"> Swiss</label>
                        <input type="radio" name="investZone_contact_nationality" value="chinese" id="nationality_chinese" class="investZone_contact_nationality">
                        <label for="nationality_chinese" class="investZone_contact_nationality"> Chinese</label>
                        <input type="radio" name="investZone_contact_nationality" value="other" id="nationality_other" class="investZone_contact_nationality">
                        <label for="nationality_other" class="investZone_contact_nationality"> Other</label>
                    </div>
                    
                   
                    <div class="medium-6 columns application_form">
                        <label> Position / Title:<span>*</span>
                            <input type="text" placeholder="Please Enter Position/Title" name="investZone_contact_position" id="investZone_contact_position">
                        </label>
                    </div>
                    <!--
                    <div class="medium-6 columns application_form">
<label> General Phone: <span>*</span>
<input type="text" placeholder="Type your general phone number" name="investZone_contact_generalphone" id="investZone_contact_generalphone">
</label>
</div>
-->
                    <!--
                    <div class="medium-6 columns application_form">
                        <label> General E-mail <span>*</span>
                            <input type="text" placeholder="Type your general e-mail address" name="investZone_contact_generalemail" id="investZone_contact_generalemail">
                        </label>
                    </div>
-->
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone: <span>*</span>
                            <input type="text" placeholder="Please Enter Direct Phone" name="investZone_contact_directPhone" id="investZone_contact_directPhone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail: <span>*</span>
                            <input type="text" placeholder="Please Enter Direct E-mail" name="investZone_contact_directEmail" id="investZone_contact_directEmail">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Mobile: <span>*</span>
                            <input type="text" placeholder="Please Enter Mobile" name="investZone_contact_mobile" id="investZone_contact_mobile">
                        </label>
                    </div>
                </div>
                <div class="row">
                    <div class="medium-12 columns">
                        <hr />
                    </div>
                </div>
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact 1</h3>
                    <div class="medium-6 columns application_form">
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="investZone_second_contact_title" value="Ms" id="info_sec_contact_miss" class="investZone_second_contact_title">
                        <label for="info_sec_contact_miss" class="investZone_second_contact_title"> Ms.</label>
                        <input type="radio" name="investZone_second_contact_title" value="Mr" id="info_sec_contact_mister" class="investZone_second_contact_title">
                        <label for="info_sec_contact_mister" class="investZone_second_contact_title"> Mr.</label>
                        <input type="radio" name="investZone_second_contact_title" value="Dr" id="info_sec_contact_doctor" class="investZone_second_contact_title">
                        <label for="info_sec_contact_doctor" class="investZone_second_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date Of Birth" name="investZone_second_contact_dob" id="investZone_second_contact_dob">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="investZone_second_contact_familyName" id="investZone_second_contact_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Given name" name="investZone_second_contact_givenName" id="investZone_second_contact_givenName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="中文名稱" name="investZone_second_contact_chineseName" id="investZone_second_contact_chineseName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <legend> Nationality: </legend>


                            <input type="radio" name="investZone_second_contact_nationality" value="swiss" id="nation_swiss" class="investZone_second_contact_nationality">
                            <label for="nation_swiss" class="investZone_second_contact_nationality"> Swiss</label>

                            <span class="nationForAll">
                            <input type="radio" name="investZone_second_contact_nationality" value="chinese" id="nation_chinese" class="investZone_second_contact_nationality">
                            <label for="nation_chinese" class="investZone_second_contact_nationality"> Chinese</label>
                            </span>


                            <span class="nationForHongkong" style="display:none;">
                            <input type="radio" name="investZone_second_contact_nationality" value="hongkong" id="nation_other" class="investZone_second_contact_nationality">
                            <label for="nation_hongkong" class="investZone_second_contact_nationality"> Hong Kong</label>
                            </span>



                            <input type="radio" name="investZone_second_contact_nationality" value="other" id="nation_hongkong" class="investZone_second_contact_nationality">
                            <label for="nation_other" class="investZone_second_contact_nationality"> Other</label>

                        </div>
                    </div>


                    
                    
                    <div class="medium-6 columns application_form">
                        <label> Mobile:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile Number" name="investZone_second_contact_mobile" id="investZone_second_contact_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="investZone_second_contact_phone" id="investZone_second_contact_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="investZone_second_contact_email" id="investZone_second_contact_email">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>
                            <div class="input-group">

                            </div>
                        </label>
                    </div>
                </div>
            </div>
        </div>


        <div class="genCls" id="indvHld">
            <h2 class="steps_common_heading">INFORMATION FORM FOR INDIVIDUAL / YOUNG PROFESSIONAL </h2>
            <div class="large-12 columns ">
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="individual_contact_title" value="Ms" id="info_form_indiv_miss" class="individual_contact_title">
                        <label for="info_form_indiv_miss" class="individual_contact_title"> Ms.</label>
                        <input type="radio" name="individual_contact_title" value="Mr" id="info_form_indiv_mister" class="individual_contact_title">
                        <label for="info_form_indiv_mister" class="individual_contact_title"> Mr.</label>
                        <input type="radio" name="individual_contact_title" value="Dr" id="info_form_indiv_doctor" class="individual_contact_title">
                        <label for="info_form_indiv_doctor" class="individual_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date Of Birth" name="individual_contact_dob" id="individual_contact_dob" class="datepicker demo_ranged">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:<span>*</span>
                            <input type="text" placeholder="Please Enter Family Name" name="individual_contact_familyName" id="individual_contact_familyName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):<span>*</span>
                            <input type="text" placeholder="Please Enter Given Name" name="individual_contact_givenName" id="individual_contact_givenName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese Name:<span class="commonHongKong">*</span>
                            <input type="text" placeholder="中文名稱" name="individual_contact_chineseName" id="individual_contact_chineseName">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <legend> Nationality:</legend>
                        <input type="radio" name="individual_contact_Nationality" value="Swiss" id="indiv_nationality_swiss" class="individual_contact_Nationality" checked>
                        <label for="indiv_nationality_swiss" class="individual_contact_Nationality"> Swiss</label>
                        <span class="nationForAll">
                        <input type="radio" name="individual_contact_Nationality" value="Chinese" id="indiv_nationality_chinese" class="individual_contact_Nationality">
                        <label for="indiv_nationality_chinese" class="individual_contact_Nationality"> Chinese</label>
                        </span>
                        <span class="nationForHongkong" style="display:none;">
                         <input type="radio" name="individual_contact_Nationality" value="hongkong" id="nation_other" class="individual_contact_Nationality">
                            <label for="indiv_nationality_hongkong" class="individual_contact_Nationality"> Hong Kong</label>
                        </span>
                        <input type="radio" name="individual_contact_Nationality" value="Other" id="indiv_nationality_other" class="individual_contact_Nationality">
                        <label for="indiv_nationality_other" class="individual_contact_Nationality"> Other</label>
                   
                    </div>
                    
                    
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in English:<span>*</span>
                                <textarea rows="3" placeholder="Please Enter Address In English" name="individual_contact_address_english" id="individual_contact_address_english"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in English:<span>*</span>
                                <input type="text" placeholder="Please Enter City In English" name="individual_contact_city_english" id="individual_contact_city_english">
                            </label>
                            <label>Province/Area in English:
                                <input type="text" placeholder="Please Enter Province/Area in English" name="individual_contact_province_area" id="individual_contact_province_area">

                            </label>
                        </div>
                    </div>

                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in Chinese:<span class="commonHongKong">*</span>
                                <textarea rows="3" placeholder="地址中文" name="individual_contact_address_chinese" id="individual_contact_address_chinese"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in Chinese:<span class="commonHongKong">*</span>
                                <input type="text" placeholder="城市中文" name="individual_contact_city_chinese" id="individual_contact_city_chinese">
                            </label>
                            <label>ZIP code:
                                <input type="text" placeholder="Please Enter Zip Code" name="individual_contact_zip_chinese" id="individual_contact_zip_chinese">
                            </label>
                        </div>
                    </div>

                    
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone: <span>*</span>
                            <input type="text" placeholder="Please Enter Direct Phone" name="individual_contact_directPhone" id="individual_contact_directPhone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail: <span>*</span>
                            <input type="text" placeholder="Please Enter Direct E-mail" name="individual_contact_email" id="individual_contact_email">
                        </label>
                    </div>




                    <div class="medium-6 columns application_form">
                        <label> Mobile: <span>*</span>
                            <input type="text" placeholder="Please Enter Mobile" name="individual_contact_phone" id="individual_contact_phone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">

                        <label>
                            <!-- Website: <span>*</span>
<input type="text" placeholder="Type your website" name="individual_contact_website" id="individual_contact_website">
-->
                        </label>
                    </div>
                </div>
                <div class="row">
                    <div class="medium-12 columns">
                        <hr />
                    </div>
                </div>
                <div id="only_young_professional" style="display:none;">
                <div class="row">
                    <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact 1</h3>
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="individual_second_contact_title" value="Ms" id="info_sec_contact_miss" class="individual_second_contact_title">
                        <label for="info_sec_contact_miss" class="individual_second_contact_title"> Ms.</label>
                        <input type="radio" name="individual_second_contact_title" value="Mr" id="info_sec_contact_mister" class="individual_second_contact_title">
                        <label for="info_sec_contact_mister" class="individual_second_contact_title"> Mr.</label>
                        <input type="radio" name="individual_second_contact_title" value="Dr" id="info_sec_contact_doctor" class="individual_second_contact_title">
                        <label for="info_sec_contact_doctor" class="individual_second_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date Of Birth" name="individual_second_contact_dob" id="individual_second_contact_dob" class="datepicker demo_ranged">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="individual_second_contact_familyName" id="individual_second_contact_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Given Name" name="individual_second_contact_givenName" id="individual_second_contact_givenName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="中文名稱" name="individual_second_contact_chineseName" id="individual_second_contact_chineseName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <legend> Nationality:</legend>
                        <input type="radio" name="individual_second_contact_Nationality" value="Swiss" id="sindiv_nationality_swiss" class="individual_second_contact_Nationality">
                        <label for="sindiv_nationality_swiss" class="individual_second_contact_Nationality"> Swiss</label>
                        <span class="nationForAll">
                        <input type="radio" name="individual_second_contact_Nationality" value="Chinese" id="sindiv_nationality_chinese" class="individual_second_contact_Nationality">
                        <label for="sindiv_nationality_chinese" class="individual_second_contact_Nationality"> Chinese</label>
                        </span>
                         <span class="nationForHongkong" style="display:none;">
                         <input type="radio" name="individual_second_contact_Nationality" value="hongkong" id="nation_other" class="individual_second_contact_Nationality">
                            <label for="sindiv_nationality_hongkong" class="individual_second_contact_Nationality"> Hong Kong</label>
                        </span>
                        <input type="radio" name="individual_second_contact_Nationality" value="Other" id="sindiv_nationality_other" class="individual_second_contact_Nationality">
                        <label for="sindiv_nationality_other" class="individual_second_contact_Nationality"> Other</label>
                    </div>
                    <div class="medium-6 columns application_form"><label> Position in the company:
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Position In The Company" name="individual_second_contact_position" id="individual_second_contact_position" class="otherValidate OtherCommonClass">
                            </div></label></div>
                    <!--<div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in English:
                                <textarea rows="3" placeholder="Please Enter Address In English" name="individual_second_contact_address_english" id="individual_second_contact_address_english"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in English:
                                <input type="text" placeholder="Please Enter City In English" name="individual_second_contact_city_english" id="individual_second_contact_city_english">
                            </label>
                            <label>Province/Area in English:
                                <input type="text" placeholder="Please Enter Province/Area in English" name="individual_second_contact_area" id="individual_second_contact_area">

                            </label>
                        </div>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns application_form">
                            <label> Address in Chinese:
                                <textarea rows="3" placeholder="请输入地�?�" name="individual_second_contact_address_chinese" id="individual_second_contact_address_chinese"></textarea>
                            </label>
                        </div>
                        <div class="medium-6 columns application_form">
                            <label> City in Chinese:
                                <input type="text" placeholder="请输入城市" name="individual_second_contact_city_chinese" id="individual_second_contact_city_chinese">
                            </label>
                            <label>ZIP code:
                                <input type="text" placeholder="Please Enter Zip Code" name="individual_second_contact_zip_code" id="individual_second_contact_zip_code">
                            </label>
                        </div>
                    </div>-->
                    <div class="medium-6 columns application_form">
                        <label> Mobile:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile" name="individual_second_contact_mobile" id="individual_second_contact_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:
                           <!-- <span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="individual_second_contact_phone" id="individual_second_contact_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="individual_second_contact_email" id="individual_second_contact_email">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>
                            <div class="input-group">

                            </div>
                        </label>
                    </div>
                </div>
                </div>
            </div>
            <div class="medium-12 columns" id="frAll">
            <input type="hidden" name="frAllChk" id="frAllChk" value="" />
            <div id="appenddiv" class="row"></div>
            <div class="margin_bottom15 margin_top10">

                <a href="javascript:void(0)" id="addmore" class="holo_button">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i> Add new contact
                </a>
            </div>
            <div id="removediv" style="display:none;" class="margin_bottom10">
                <a href="javascript:void(0)" class="holo_button" id="removebtn">
                    <i class="fa fa-times-circle" aria-hidden="true"></i> Remove last contact
                </a>
            </div>
            <input type="hidden" name="addcnt" value="0" id="addcnt">
        </div>
        </div>
        <div class="genCls" id="npoHld">
            <h2 class="steps_common_heading"> INFORMATION FORM FOR NPO</h2>
            <div class="large-12 columns ">
                <div class="row">
                    <div class="medium-6 columns application_form">
                        <label> Type of organization:<span>*</span>
                            <input type="text" placeholder="Please Enter Type of Organization" name="npo_organization_type" id="npo_organization_type">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Organization description:<span>*</span>
                            <textarea rows="3" placeholder="Please Enter Organization Description" name="npo_organization_description" id="npo_organization_description"></textarea>
                        </label>
                    </div>
                </div>

                <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership holder</h3>
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="npo_contact_title" value="Ms" id="info_form_npo_miss" class="npo_contact_title">
                        <label for="info_form_npo_miss" class="npo_contact_title"> Ms.</label>
                        <input type="radio" name="npo_contact_title" value="Mr" id="info_form_npo_mister" class="npo_contact_title">
                        <label for="info_form_npo_mister" class="npo_contact_title"> Mr.</label>
                        <input type="radio" name="npo_contact_title" value="Dr" id="info_form_npo_doctor" class="npo_contact_title">
                        <label for="info_form_npo_doctor" class="npo_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date of Birth" name="npo_contact_dob" id="npo_contact_dob" class="datepicker">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:<span>*</span>
                            <input type="text" placeholder="Please Enter Family Name" name="npo_contact_familyName" id="npo_contact_familyName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):<span>*</span>
                            <input type="text" placeholder="Please Enter Given Name" name="npo_contact_givenName" id="npo_contact_givenName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese Name:<span>*</span>
                            <input type="text" placeholder="中文名稱" name="npo_contact_chineseName" id="npo_contact_chineseName">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <legend> Nationality:</legend>
                        <input type="radio" name="npo_contact_Nationality" value="Swiss" id="mem_hold_swiss" class="npo_contact_Nationality" checked>
                        <label for="nationality_swiss" class="npo_contact_Nationality"> Swiss</label>
                        <input type="radio" name="npo_contact_Nationality" value="Chinese" id="mem_hold_chinese" class="npo_contact_Nationality">
                        <label for="mem_hold_chinese" class="npo_contact_Nationality"> Chinese</label>
                        <input type="radio" name="npo_contact_Nationality" value="Other" id="mem_hold_other" class="npo_contact_Nationality">
                        <label for="mem_hold_other" class="npo_contact_Nationality"> Other</label>
                    </div>

                    
                    

                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:<span>*</span>
                            <input type="text" placeholder="Please Enter Direct Phone" name="npo_contact_phone" id="npo_contact_phone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:<span>*</span>
                            <input type="text" placeholder="Please Enter Direct E-mail" name="npo_contact_email" id="npo_contact_email">
                        </label>
                    </div>
                    <!--
                    <div class="medium-6 columns application_form">
                        <label> Website:<span>*</span>
                            <input type="text" placeholder="Type your website" name="npo_contact_website" id="npo_contact_website">
                        </label>
                    </div>
-->
                    <div class="medium-6 columns application_form">
                        <label> Mobile:<span>*</span>
                            <input type="text" placeholder="Please Enter Mobile" name="npo_contact_mobile" id="npo_contact_mobile">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>

                        </label>
                    </div>
                </div>
                <div class="row">
                    <div class="medium-12 columns">
                        <hr />
                    </div>
                </div>
                
                <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact 1</h3>
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="npo_second_contact_title" value="Ms" id="info_asst_contact_miss" class="npo_second_contact_title">
                        <label for="info_asst_contact_miss" class="npo_second_contact_title"> Ms.</label>
                        <input type="radio" name="npo_second_contact_title" value="Mr" id="info_asst_contact_mister" class="npo_second_contact_title">
                        <label for="info_asst_contact_mister" class="npo_second_contact_title"> Mr.</label>
                        <input type="radio" name="npo_second_contact_title" value="Dr" id="info_asst_contact_doctor" class="npo_second_contact_title">
                        <label for="info_asst_contact_doctor" class="npo_second_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth test:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date of Birth" name="npo_second_contact_dob" id="npo_second_contact_dob">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="npo_second_contact_familyName" id="npo_second_contact_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Given Name" name="npo_second_contact_givenName" id="npo_second_contact_givenName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="中文名稱" name="npo_second_contact_chineseName" id="npo_second_contact_chineseName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <legend> Nationality: </legend>
                            <input type="radio" name="npo_second_contact_nationality" value="swiss" id="nation_swiss" class="npo_second_contact_nationality">
                            <label for="nation_swiss" class="npo_second_contact_nationality"> Swiss</label>

                            <span class="nationForAll">
                            <input type="radio" name="npo_second_contact_nationality" value="chinese" id="nation_chinese" class="npo_second_contact_nationality">
                            <label for="nation_chinese" class="npo_second_contact_nationality"> Chinese</label>
                            </span>

                            <span class="nationForHongkong" style="display:none;">
                            <input type="radio" name="npo_second_contact_nationality" value="hongkong" id="nation_other" class="npo_second_contact_nationality">
                            <label for="nation_hongkong" class="npo_second_contact_nationality"> Hong Kong</label>
                            </span>

                            <input type="radio" name="npo_second_contact_nationality" value="other" id="nation_hongkong" class="npo_second_contact_nationality">
                            <label for="nation_other" class="npo_second_contact_nationality"> Other</label>

                        </div>
                    </div>

                    
                    
                    <div class="medium-6 columns application_form">
                        <label> Mobile:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile" name="npo_second_contact_mobile" id="npo_second_contact_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="npo_second_contact_phone" id="npo_second_contact_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="npo_second_contact_email" id="npo_second_contact_email">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">

                    </div>
                </div>
                
            </div>
        </div>
        <div class="genCls" id="jrnlHld">
            <h2 class="steps_common_heading"> INFORMATION FORM FOR JOURNALIST</h2>
            <div class="large-12 columns ">
                <div class="row">
                    <div class="medium-6 columns application_form">
                        <label> Type of media:<span>*</span>
                            <input type="text" placeholder="Please Enter Type of Media" name="media_type" id="media_type">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Publication description:<span>*</span>
                            <textarea rows="3" placeholder="Please Enter Publication Description" name="media_description" id="media_description"></textarea>
                        </label>
                    </div>
                </div>

                <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership holder</h3>
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="journalist_contact_title" value="Ms" id="journalist_miss" class="journalist_contact_title">
                        <label for="journalist_miss" class="journalist_contact_title"> Ms.</label>
                        <input type="radio" name="journalist_contact_title" value="Mr" id="journalist_mister" class="journalist_contact_title">
                        <label for="journalist_mister" class="journalist_contact_title"> Mr.</label>
                        <input type="radio" name="journalist_contact_title" value="Dr" id="journalist_doctor" class="journalist_contact_title">
                        <label for="journalist_doctor" class="journalist_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date of Birth" name="journalist_contact_dob" id="journalist_contact_dob">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:<span>*</span>
                            <input type="text" placeholder="Please Enter Family Name" name="journalist_contact_familyName" id="journalist_contact_familyName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):<span>*</span>
                            <input type="text" placeholder="Please Enter Given Name" name="journalist_contact_givenName" id="journalist_contact_givenName">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese Name:<span>*</span>
                            <input type="text" placeholder="中文名稱" name="journalist_contact_chineseName" id="journalist_contact_chineseName">
                        </label>
                    </div>
                    <div class="medium-12 columns membership_from second_form_field">
                        <legend> Nationality:</legend>
                        <input type="radio" name="journalist_contact_Nationality" value="Swiss" id="journalist_swiss" class="journalist_contact_Nationality" checked>
                        <label for="journalist_swiss" class="journalist_contact_Nationality"> Swiss</label>
                        <input type="radio" name="journalist_contact_Nationality" value="Chinese" id="journalist_chinese" class="journalist_contact_Nationality">
                        <label for="journalist_chinese" class="journalist_contact_Nationality"> Chinese</label>
                        <input type="radio" name="journalist_contact_Nationality" value="Other" id="journalist_other" class="journalist_contact_Nationality">
                        <label for="journalist_other" class="journalist_contact_Nationality"> Other</label>
                    </div>

                    
                    

                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:<span>*</span>
                            <input type="text" placeholder="Please Enter Direct Phone" name="journalist_contact_phone" id="journalist_contact_phone">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:<span>*</span>
                            <input type="text" placeholder="Please Enter Direct E-mail" name="journalist_contact_email" id="journalist_contact_email">
                        </label>
                    </div>
                    <!--
                   <div class="medium-6 columns application_form">
<label> Website:<span>*</span>
<input type="text" placeholder="Type your website" name="journalist_contact_website" id="journalist_contact_website">
</label>
</div>
-->
                    <div class="medium-6 columns application_form">
                        <label> Mobile:<span>*</span>
                            <input type="text" placeholder="Please Enter Mobile" name="journalist_contact_mobile" id="journalist_contact_mobile">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">

                    </div>
                </div>
                <div class="row">
                    <div class="medium-12 columns">
                        <hr />
                    </div>
                </div>
                <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact 1</h3>
                <div class="row">
                    <div class="medium-12 columns membership_from second_form_field">
                        <label></label>
                        <input type="radio" name="journalist_second_contact_title" value="Ms" id="sec_journalist_miss" class="journalist_second_contact_title">
                        <label for="info_asst_contact_miss" class="journalist_second_contact_title"> Ms.</label>
                        <input type="radio" name="journalist_second_contact_title" value="Mr" id="sec_journalist_mister" class="journalist_second_contact_title">
                        <label for="info_asst_contact_mister" class="journalist_second_contact_title"> Mr.</label>
                        <input type="radio" name="journalist_second_contact_title" value="Dr" id="sec_journalist_doctor" class="journalist_second_contact_title">
                        <label for="info_asst_contact_doctor" class="journalist_second_contact_title"> Dr.</label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Date of birth:
                            <!--<span>*</span>-->
                            <input type="text" placeholder="Please Enter Date of Birth" name="journalist_second_contact_dob" id="journalist_second_contact_dob">
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Family name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Family Name" name="journalist_second_contact_familyName" id="journalist_second_contact_familyName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Given name(s):
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Given Name" name="journalist_second_contact_givenName" id="journalist_second_contact_givenName">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Chinese name:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="中文名稱" name="journalist_second_contact_chineseName" id="journalist_second_contact_chineseName">
                            </div>
                        </label>
                    </div>

                    <div class="medium-12 columns no_padding">
                        <div class="medium-6 columns membership_from second_form_field">
                            <legend> Nationality: </legend>


                            <input type="radio" name="journalist_second_contact_nationality" value="swiss" id="nation_swiss" class="journalist_second_contact_nationality">
                            <label for="nation_swiss" class="journalist_second_contact_nationality"> Swiss</label>

                            <span class="nationForAll">
                        <input type="radio" name="journalist_second_contact_nationality" value="chinese" id="nation_chinese" class="journalist_second_contact_nationality">
                        <label for="nation_chinese" class="journalist_second_contact_nationality"> Chinese</label>
                        </span>


                            <span class="nationForHongkong" style="display:none;">
                        <input type="radio" name="journalist_second_contact_nationality" value="hongkong" id="nation_other" class="journalist_second_contact_nationality">
                        <label for="nation_hongkong" class="journalist_second_contact_nationality"> Hong Kong</label>
                        </span>
                            <input type="radio" name="journalist_second_contact_nationality" value="other" id="nation_hongkong" class="journalist_second_contact_nationality">
                            <label for="nation_other" class="journalist_second_contact_nationality"> Other</label>

                        </div>
                    </div>
                    
                    
                    <div class="medium-6 columns application_form">
                        <label> Mobile:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Mobile" name="journalist_second_contact_mobile" id="journalist_second_contact_mobile">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct Phone:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct Phone" name="journalist_second_contact_phone" id="journalist_second_contact_phone">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label> Direct E-mail:
                            <!--<span>*</span>-->
                            <div class="input-group">
                                <input type="text" placeholder="Please Enter Direct E-mail" name="journalist_second_contact_email" id="journalist_second_contact_email">
                            </div>
                        </label>
                    </div>
                    <div class="medium-6 columns application_form">
                        <label>
                            <div class="input-group">

                            </div>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        

        <div class="medium-12 columns" id="frCmp">
            <div id="appenddiv1" class="row"></div>
            <div class="margin_bottom15 margin_top10">

                <a href="javascript:void(0)" id="addmore1" class="holo_button">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i> Add new contact
                </a>
            </div>
            <div id="removediv1" style="display:none;" class="margin_bottom10">
                <a href="javascript:void(0)" class="holo_button" id="removebtn1">
                    <i class="fa fa-times-circle" aria-hidden="true"></i> Remove last contact
                </a>
            </div>
            <input type="hidden" name="addcnt1" value="0" id="addcnt1">
        </div>

        <!-- <div id="appenddiv"></div>-->
    </div>
</section>

        <h2>Confirmation</h2>
<section>
    <div class="large-12 columns application_question_container">
        <h5 class="app_quest_disclaim">Please check all the information listed below and press submit to confirm your membership application.</h5>
        <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Membership Type</h3>
        <div class="medium-12 columns no_padding">
            <div class="table-scroll">
                <table class="application_final_check">
                    <tbody>
                        <tr>
                            <td>
                                <h5>LOCATION:</h5></td>
                            <td id="location"></td>
                        </tr>
                        <tr>
                            <td>
                                <h5> I AM / WE ARE:</h5></td>
                            <td id="am_we"></td>
                        </tr>
                        <tr id="I_M_W_R" style="display:none;"> 
                            <td>
                                <h5> I AM / WE ARE:</h5></td>
                            <td id="am_we_we_are"></td>
                        </tr>
                        <tr id="hongkong_indi_we" style="display:none">
                            <td>
                                <h5> We have:</h5></td>
                            <td id="am_we_have"></td>
                        </tr>
                        <tr id="hongkong_indi" style="display:none;">
                            <td>
                                <h5> I / We apply for:</h5></td>
                            <td id="apply_for_hongKong"></td>
                        </tr>
                      
                        <tr>
                            <td>
                                <h5> I / We apply for:</h5></td>
                            <td id="apply_for"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <!--Business Information start-->


        <div id="onlycomp" style="display:none;">
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Business Information</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Business Scope </h5></td>
                                <td id="showBusinessScope"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Business Description English</h5></td>
                                <td id="showBusinessDescriptionEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Business Description Chinese</h5></td>
                                <td id="showBusinessDescriptionChinese"></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <!--Business Information end-->
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> COMPANY DETAILS</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Company Name in English</h5></td>
                                <td id="showCompanyNameEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Company Name in Chinese</h5></td>
                                <td id="showCompanyNameChinese"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Address in English</h5></td>
                                <td id="showAddressEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City in English</h5></td>
                                <td id="showCityEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Province/Area in English</h5></td>
                                <td id="showProvinceAreaEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Address in Chinese</h5></td>
                                <td id="showAddressChinese"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City in Chinese</h5></td>
                                <td id="showCityChinese"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>ZIP code</h5></td>
                                <td id="showZIPcode"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>General phone</h5></td>
                                <td id="showGeneralPhone"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>General E-mail</h5></td>
                                <td id="showGeneralEmail"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>General website</h5></td>
                                <td id="showGeneralWebsite"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Legal entity </h5></td>
                                <td id="showLegalEntity"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Number of employees </h5></td>
                                <td id="showNumberEmployees"></td>
                            </tr>
                            <tr class="forAll">
                                <td>
                                    <h5>Is your company Swiss-registered? </h5></td>
                                <td id="showSwissRegistered"></td>
                            </tr>
                            <tr class="forAll">
                                <td>
                                    <h5>Are you registered in PRC with a valid business licence? </h5></td>
                                <td id="showRegisteredPRC"></td>
                            </tr>
                            <tr class="forHongKong">
                                <td>
                                    <h5>Year of Establishment in Hong Kong</h5></td>
                                <td id="showYearEstablishment"></td>
                            </tr>
                            <tr class="forHongKong">
                                <td>
                                    <h5>Geographical Responsibility of your company in Hong Kong</h5></td>
                                <td id="showGeographicalResponsibility"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> HEADQUARTER’S DETAILS</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Company Name:</h5></td>
                                <td id="showHQCompanyName"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Address</td>
                                     <td id="showHQAddress"></td>
                            </tr>
                            <tr>
                                <td><h5>City in English</h5></td>
                                <td id="showHQCitEnglish"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>ZIP code</h5></td>
                                    <td id="showHQZipCode"></td>
                                    </tr>
                            <tr>
                                <td><h5>General Phone</h5></td>
                                    <td id="showHQGeneralPhone"></td>
                            </tr>
                            <tr>
                                <td><h5>Province/Area in English:</h5></td>
                                    <td id="showProvinceArea"></td>
                            </tr>
                           </tbody>
                    </table>
                    </div>
                    </div>
</div>


<h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i>User information</h3>
<div class="medium-12 columns no_padding">
<div class="table-scroll">
    <table class="application_final_check">
        <tbody>
            
            <tr id="A_NPO_Field" style="display:none;">
                <td><h5>Type of organization</h5></td>
                                <td id="type_org"></td>
            </tr>
                            
            <tr id="A_NPO_Field_1" style="display:none;">
                <td><h5>Organization description</h5></td>
                                <td id="org_dec"></td>
                </tr>
            <tr>
                <td><h5>Title</h5></td>
                                <td id="cmptle"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Date of birth</h5></td>
                                <td id="cmpdob"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Family name</h5></td>
                                <td id="cmpfnm"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Given name(s)</h5></td>
                                <td id="cmpgnm"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Chinese Name</h5></td>
                                <td id="cmpcnm"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Nationality</h5></td>
                                <td id="cmpnation"></td>
                            </tr>
                            
                            <tr id="An_individual_Position_hide" style="display:none;">
                                <td>
                                    <h5>Position in the company</h5></td>
                                <td id="cmppc"></td>
                            </tr>
                             
                        
                            <tbody id="An_individual_show" style="display:none;">
                            <tr>
                                <td>
                                    <h5>Address in English</h5></td>
                                <td id="cmpadde"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City(English)</h5></td>
                                <td id="cmpcte"></td>
                            </tr>

                            <tr>
                                <td>
                                    <h5>Province/Area</h5></td>
                                <td id="cmppa"></td>
                            </tr>

                            <tr>
                                <td>
                                    <h5>Address in Chinese</h5></td>
                                <td id="cmpaddc"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City(Chinese)</h5></td>
                                <td id="cmpctc"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>ZIP code(English)</h5></td>
                                <td id="cmpzipe"></td>
                            </tr>
                            </tbody>
                            <tr>
                                <td>
                                    <h5>Direct Phone</h5></td>
                                <td id="cmpdp"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Direct E-mail</h5></td>
                                <td id="cmpde"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Mobile</h5></td>
                                <td id="cmpmob"></td>
                            </tr>
                        </tbody>

                    </table>
                </div>
            </div>



<div id="An_individual" style="display:none;">
            <!--investment zone end -->
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Second user information</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Title</h5></td>
                                <td id="cmptle2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Date of birth</h5></td>
                                <td id="cmpdateofbirth"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Family name</h5></td>
                                <td id="cmpfnm2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Given name(s)</h5></td>
                                <td id="cmpgnm2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Chinese Name</h5></td>
                                <td id="cmpcnm2"></td>
                            </tr>
                             <tr>
                                <td>
                                    <h5>Nationality</h5></td>
                                <td id="cmp_nationalty"></td>
                            </tr>
                            <tr id="A_NPO_Posotion_Show" style="display: none;">
                                <td>
                                    <h5>Position in the company</h5></td>
                                <td id="cmp_position"></td>
                            </tr>
                            <!--<tr>
                                <td>
                                    <h5>Address in English</h5></td>
                                <td id="cmpadde2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City(English)</h5></td>
                                <td id="cmpcte2"></td>
                            </tr>

                            <tr>
                                <td>
                                    <h5>Province/Area</h5></td>
                                <td id="cmppa2"></td>
                            </tr>

                            <tr>
                                <td>
                                    <h5>Address in Chinese</h5></td>
                                <td id="cmpaddc2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>City(Chinese)</h5></td>
                                <td id="cmpctc2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>ZIP code(English)</h5></td>
                                <td id="cmpzipe2"></td>
                            </tr>-->
                            <tr>
                                <td>
                                    <h5>Direct Phone</h5></td>
                                <td id="cmpdp2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Direct E-mail</h5></td>
                                <td id="cmpde2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Mobile</h5></td>
                                <td id="cmpmob2"></td>
                            </tr>
                        </tbody>

                    </table>
                </div>
            </div>

</div>

<!------------------------------------ Add new button contact 2 ------------------------>
<div id="An_individual_Contact2" style="display:none;">
            <!--investment zone end -->
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Contact 2 User information</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Title</h5></td>
                                <td id="cmptle_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Date of birth</h5></td>
                                <td id="cmpdateofbirth_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Family name</h5></td>
                                <td id="cmpfnm2_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Given name(s)</h5></td>
                                <td id="cmpgnm2_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Chinese Name</h5></td>
                                <td id="cmpcnm2_contact2"></td>
                            </tr>
                             <tr>
                                <td>
                                    <h5>Nationality</h5></td>
                                <td id="cmp_nationalty_contact2"></td>
                            </tr>
                           
                            <tr>
                                <td>
                                    <h5>Direct Phone</h5></td>
                                <td id="cmpdp2_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Direct E-mail</h5></td>
                                <td id="cmpde2_contact2"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Mobile</h5></td>
                                <td id="cmpmob2_contact2"></td>
                            </tr>
                        </tbody>

                    </table>
                </div>
            </div>

</div>
<!------------------------------------ End Add New Button Contact 2 --------------------->

<!------------------------------------ Add new button contact 3 ------------------------>
<div id="An_individual_Contact3" style="display:none;">
            <!--investment zone end -->
            <h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Contact 3 User information</h3>
            <div class="medium-12 columns no_padding">
                <div class="table-scroll">
                    <table class="application_final_check">
                        <tbody>
                            <tr>
                                <td>
                                    <h5>Title</h5></td>
                                <td id="cmptle_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Date of birth</h5></td>
                                <td id="cmpdateofbirth_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Family name</h5></td>
                                <td id="cmpfnm2_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Given name(s)</h5></td>
                                <td id="cmpgnm2_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Chinese Name</h5></td>
                                <td id="cmpcnm2_contact3"></td>
                            </tr>
                             <tr>
                                <td>
                                    <h5>Nationality</h5></td>
                                <td id="cmp_nationalty_contact3"></td>
                            </tr>
                           
                            <tr>
                                <td>
                                    <h5>Direct Phone</h5></td>
                                <td id="cmpdp2_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Direct E-mail</h5></td>
                                <td id="cmpde2_contact3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5>Mobile</h5></td>
                                <td id="cmpmob2_contact3"></td>
                            </tr>
                        </tbody>

                    </table>
                </div>
            </div>

</div>
<!------------------------------------ End Add New Button Contact 3 --------------------->
        </div>
</section>
        </div>

    </div>
</div>
</form>
<?php 
require_once(__ROOT__.'/includes/rightPanel.php'); 
 ?>
        </div>
</section>

                <?php 
		require_once(__ROOT__.'/includes/footer.php'); 
		?>
                    <!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please enter the details to login</h1>
                        <?php if($_GET['loginerror']==1) {?>
                        <div style="font-weight: bold; color: red; text-align: center;"> Wrong User ID And Password</div> 
                        <?php } ?>
                        <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                    </label>
                                </div>
                                <!--<div class="medium-12 columns margin_top10 membership_from no_padding">
								 <h6 class="directory_register_msg">If you are not member yet Please <a href="online_application.php">Register</a></h6>
								 </div>-->
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
                    <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->


                    <?php 
					require_once(__ROOT__.'/includes/footerbuttom.php'); 
					?>


                        </div>

                        <a href="#0" class="cd-top">Top</a>




                        <script src="bower_components/jquery/dist/jquery.js"></script>
                        <script src="bower_components/what-input/what-input.js"></script>
                        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
                        <script src="js/slick.js"></script>
                        <script src="js/easyResponsiveTabs.js"></script>
                        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
                        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
                        <script type="text/javascript" src="js/pace.js"></script>
                        <script type="text/javascript" src="js/jquery.steps.js?v=<?php echo time(); ?>"></script>
                        <script type="text/javascript" src="js/member_registration.js"></script>
                        <script type="text/javascript" src="js/registration.js"></script>
                        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
                        <script>
                            setTimeout(function() {
                                $("#individual_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#company_first_contact_dob").datepicker({
                                    
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#npo_contact_dob").datepicker({
                                   changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#investZone_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#journalist_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#individual_second_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#company_second_contact_person_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#investZone_second_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#npo_second_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);
                            setTimeout(function() {
                                $("#journalist_second_contact_dob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);

                            setTimeout(function() {
                                $(".commnDob").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            }, 1000);

                            $('body').on('focus', '.commnDob', function() {
                                $(this).datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: "dd/mm/yy",
                                    yearRange: "-90:+00"
                                });
                            });

                        </script>
                        <script type="text/javascript">
                            $(function() {
                                $('nav#menu').mmenu({
                                    extensions: ['effect-slide-menu', 'pageshadow'],
                                    searchfield: true,
                                    counters: false,
                                    "offCanvas": {
                                        "position": "left"
                                    },
                                    navbar: {
                                        title: 'SWISSCHAM'
                                    },
                                    navbars: [{
                                        position: 'top',
                                        content: ['searchfield']
                                    }, {
                                        position: 'top',
                                        content: [
                                            'prev',
                                            'title',
                                            'close'
                                        ]
                                    }, {
                                        position: 'bottom',
                                        content: [
                                  //'<a href="http://mmenu.frebsite.nl/wordpress-plugin.html" target="_blank">WordPress plugin</a>'
                                        ]
                                    }]
                                });
                                $('nav#log_togg').mmenu({
                                    extensions: ['effect-slide-menu', 'pageshadow'],
                                    searchfield: false,
                                    counters: false,
                                    navbar: {
                                        title: 'Welcome to Swisscham'
                                    },

                                });

                            });

                        </script>
                        <script src="js/app.js?v=<?php echo time(); ?>"></script>
                        <script>
                            $(function () {
                                $("#wizard").steps({
                                    headerTag: "h2",
                                    bodyTag: "section",
                                    transitionEffect: "slideLeft"
                                });
                                //$(".actions li:nth-child(2)").addClass("next");
                                $(".actions li:nth-child(2)").addClass("disabled");
                                $('#cm_an_indiv').click(function () {
                                    $(".actions li:nth-child(2)").removeClass("disabled");
                                })
                                $('.removedisable').click(function () {
									$('.actions li:nth-child(2)').show();
									$('#previous').show();
                                    $(".actions li:nth-child(2)").removeClass("disabled");
                                    var cls = $(this).hasClass('adddisable');
                                    if (cls == true) {
                                        $(".actions li:nth-child(2)").removeClass("disabled");
                                    } else {
                                        $(".actions li:nth-child(2)").addClass("disabled");
                                    }

                                })
								
								$('#chinaindividual').click(function(){
									$('.actions li:nth-child(2)').hide();
									$('#previous').hide();
								})

                            });
                        </script>
                        <script>
                            $('document').ready(function() {
                                var dropVal;

                                $('.stateDrop').change(function() {
                                    $('.b_no_member').hide();
                                    dropVal = $('#stateDrop').val();
                                });
                                $('#removebtn').click(function() {
                                    var addcnt = $('#addcnt').val();
                                    if (addcnt > 0) {
                                        var rmvid = 'adddiv_' + addcnt;
                                        $('#' + rmvid).remove();
                                        $('#rm').remove();
                                        addcnt--;
                                        $('#addmore').show();
                                        if (addcnt >= 0) {
                                            $('#addcnt').val(addcnt);
                                            if (addcnt == 0) {
                                                $('#removediv').hide();
                                            }
                                        }

                                    }
                                });
                                $('#addmore').click(function() {
                                    var addcnt = $('#addcnt').val();
                                    var tc = addcnt;
                                    var tc1 = addcnt;
                                    if (addcnt < 2) {

                                        addcnt++;
                                        if (addcnt >= 2) {
                                            $('#addmore').hide();
                                        }
                                        tc1 = parseInt(addcnt) + 1;
                                        $('#addcnt').val(addcnt);
                                        $('#removediv').show();
                                        $('#appenddiv').append('<div id="adddiv_' + addcnt + '" class="medium-12 columns no_padding"><h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact ' + tc1 + '</h3><div class="medium-12 columns membership_from second_form_field"><label></label><input type="radio" name="other_contact_title' + tc + '" value="Ms" class="other_contact_title OtherCommonClass' + tc + '"><label for="info_asst_contact_miss" class="other_contact_title' + tc + ' OtherCommonClass"> Ms.</label><input type="radio" name="other_contact_title' + tc + '" value="Mr" class="other_contact_title' + tc + ' OtherCommonClass"><label for="info_asst_contact_mister" class="other_contact_title' + tc + ' OtherCommonClass"> Mr.</label><input type="radio" name="other_contact_title' + tc + '" value="Dr" class="other_contact_title' + tc + '"><label for="info_asst_contact_doctor" class="other_contact_title' + tc + ' OtherCommonClass"> Dr.</label></div><div class="medium-6 columns application_form"><label> Date of birth:<span>*</span><input type="text" placeholder="Please Enter Date of Birth" name="other_contact_dob[]" id="other_contact_dob' + addcnt + '" class="commnDob"></label></div><div class="medium-6 columns application_form"><label> Family name:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Family name" name="other_contact_familyName[]" id="other_contact_familyName' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Given name(s):<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Given name" name="other_contact_givenName[]" id="other_contact_givenName' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Chinese name:<span>*</span><div class="input-group"><input type="text" placeholder="中文名稱" name="other_contact_chineseName[]" id="other_contact_chineseName' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-12 columns no_padding"><div class="medium-6 columns membership_from second_form_field"><legend> Nationality: </legend><input type="radio" name="other_contact_nationality' + tc + '" value="swiss" id="nation_swissd" class="other_contact_nationality" checked><label> Swiss</label><span class="nationChineses_hong" style="display:none;"><input type="radio" name="other_contact_nationality' + tc + '" value="chinese" id="nation_chinese" class="other_contact_nationality"><label> Chinese</label></span><span class="nationForHongkong_hong" style="display:none;"><input type="radio" name="other_contact_nationality' + tc + '" value="hongkong" id="nation_other" class="other_contact_nationality"><label> Hong Kong</label></span><input type="radio" name="other_contact_nationality' + tc + '" value="other" id="nation_hongkong" class="other_contact_nationality"><label> Other</label></div><div class="medium-6 columns application_form"><label> Position in the company:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Position In The Company" name="other_contact_position[]" id="other_contact_position' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div></div><div class="medium-6 columns application_form"></div><div class="medium-12 columns no_padding"></div><div class="medium-12 columns no_padding"><div class="medium-6 columns application_form"><label> Mobile:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Mobile" name="other_contact_mobile[]" id="other_contact_mobile' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Direct Phone:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct Phone number" name="other_contact_directPhone[]" id="other_contact_directPhone' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Direct E-mail:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct E-mail" name="other_contact_directEmail[]" id="other_contact_directEmail' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"></div></div>');
                                    }
                                    
                                    if (dropVal == 'HongKong') {
                
                                        
                                        $('.nationForHongkong_hong').show();
                                       $('.nationChineses_hong').hide();
                                    } else {
                                        $('.nationForHongkong_hong').hide();
                                        $('.nationChineses_hong').show();
                                       
                                    }
                                });
                            });

                            /*  function showImage3(input, id) {
                                  var file = input.files[0];
                                  var filesize = file.size / 1024;
                                  if (filesize < 2000) {
                                      $('#error_msg').html('');
                                      if (input.files && input.files[0]) {
                                          var reader = new FileReader();
                                          reader.onload = function (e) {
                                              $('#preview_label_id').html('<label>Preview :</label>');
                                              $('#preview').show();
                                              $('#preview').attr('src', e.target.result).height(100);
                                          };
                                          reader.readAsDataURL(input.files[0]);
                                      }
                                  } else {
                                      $('#error_msg').html('File size must be less than 2Mb');
                                  }
                              }*/

                            function showImage3(input, id) {
                                var file = input.files[0];
                                var filesize = file.size / 1024;
                                var sFileName = file.name;
                                var sFileExtension = sFileName.split('.')[sFileName.split('.').length - 1].toLowerCase();
                                if (sFileExtension == 'png' || sFileExtension == 'PNG' || sFileExtension == 'JPEG' || sFileExtension == 'jpeg' || sFileExtension == 'jpg' || sFileExtension == 'JPG') {
                                    if (input.files && input.files[0]) {
                                        var reader = new FileReader();
                                        reader.onload = function(e) {
                                            $('#preview_label_id').html('<label>Preview :</label>');
                                            $('#preview').show();
                                            $('#preview').attr('src', e.target.result).height(100);
                                        };
                                        reader.readAsDataURL(input.files[0]);
                                    }
                                } else {
                                    $('#fstexampleFileUploadx').val('');
                                    alert("Please Upload Image Only");
                                }
                            }

                        </script>
			<script>
                            $('document').ready(function() {
                                 var dropVal;
                                $('#stateDrop').change(function(){ 
                                    dropVal = $('#stateDrop').val();
                                   
                                });
                                $('#removebtn1').click(function() {
                                    var addcnt = $('#addcnt1').val();
                                    if (addcnt > 0) {
                                        var rmvid = 'adddiv1_' + addcnt;
                                        $('#' + rmvid).remove();
                                        $('#rm1').remove();
                                        addcnt--;
                                        $('#addmore1').show();
                                        if (addcnt >= 0) {
                                            $('#addcnt1').val(addcnt);
                                            if (addcnt == 0) {
                                                $('#removediv1').hide();
                                            }
                                        }

                                    }
                                });
                                $('#addmore1').click(function() {
                                    
                                   
                                    var addcnt = $('#addcnt1').val();
                                    var tc = addcnt;
                                    var tc1 = addcnt;
                                    if (addcnt < 2) {

                                        addcnt++;
                                        if (addcnt >= 2) {
                                            $('#addmore1').hide();
                                        }
                                        tc1 = parseInt(addcnt) + 1;
                                        $('#addcnt1').val(addcnt);
                                        $('#removediv1').show();
                                        $('#appenddiv1').append('<div id="adddiv1_' + addcnt + '" class="medium-12 columns no_padding"><h3 class="app_quest_head"><i class="fa fa-plus-circle" aria-hidden="true"></i> Other Contact ' + tc1 + '</h3><div class="medium-12 columns membership_from second_form_field"><label></label><input type="radio" name="other_contact_titlec' + tc + '" value="Ms" class="other_contact_titlec' + tc + ' OtherCommonClass"><label for="info_asst_contact_miss" class="other_contact_titlec' + tc + ' OtherCommonClass"> Ms.</label><input type="radio" name="other_contact_titlec' + tc + '" value="Mr" class="other_contact_titlec' + tc + ' OtherCommonClass"><label for="info_asst_contact_mister" class="other_contact_titlec' + tc + ' OtherCommonClass"> Mr.</label><input type="radio" name="other_contact_titlec' + tc + '" value="Dr" class="other_contact_titlec' + tc + '"><label for="info_asst_contact_doctor" class="other_contact_titlec' + tc + ' OtherCommonClass"> Dr.</label></div><div class="medium-6 columns application_form"><label> Date of birth:<span>*</span><input type="text" placeholder="Please Enter Date of Birth" name="other_contact_dobc[]" id="other_contact_dobc' + addcnt + '" class="commnDob"></label></div><div class="medium-6 columns application_form"><label> Family name:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Family name" name="other_contact_familyNamec[]" id="other_contact_familyNamec' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Given name(s):<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Given name" name="other_contact_givenNamec[]" id="other_contact_givenNamec' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Chinese name:<span>*</span><div class="input-group"><input type="text" placeholder="中文名稱" name="other_contact_chineseNamec[]" id="other_contact_chineseNamec' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-12 columns no_padding"><div class="medium-6 columns membership_from second_form_field"><legend> Nationality: </legend><input type="radio" name="other_contact_nationalityc' + tc + '" value="swiss" id="nation_swissd" class="other_contact_nationalityc" checked><label> Swiss</label><span class="nationForAll" style="display: none;"><input type="radio" name="other_contact_nationalityc' + tc + '" value="chinese" id="nation_chinese" class="other_contact_nationalityc"><label> Chinese</label></span><span class="nationForHongkong" style="display:none;"><input type="radio" name="other_contact_nationalityc' + tc + '" value="hongkong" id="nation_other" class="other_contact_nationalityc"><label> Hong Kong</label></span><input type="radio" name="other_contact_nationalityc' + tc + '" value="other" id="nation_hongkong" class="other_contact_nationalityc"><label> Other</label></div><div class="medium-6 columns application_form"><label> Position in the company:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Position In The Company" name="other_contact_positionc[]" id="other_contact_positionc'+addcnt+'"></div></label></div></div><div class="medium-6 columns application_form"></div><div class="medium-6 columns application_form"><label> Mobile:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Mobile" name="other_contact_mobilec[]" id="other_contact_mobilec' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Direct Phone:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct Phone number" name="other_contact_directPhonec[]" id="other_contact_directPhonec' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"><label> Direct E-mail:<span>*</span><div class="input-group"><input type="text" placeholder="Please Enter Direct E-mail" name="other_contact_directEmailc[]" id="other_contact_directEmailc' + addcnt + '" class="otherValidate OtherCommonClass"></div></label></div><div class="medium-6 columns application_form"></div></div>');
                                    }
                                    
                                    if (dropVal == 'HongKong') {
                
                                        $('.nationForAll').hide();
                                        $('.nationForHongkong').show();
                                        $('.forAll').hide();
                                        $('.forHongKong').show();
                                    } else {
                                        $('.nationForHongkong').hide();
                                        $('.nationForAll').show();
                                        $('.forHongKong').hide();
                                        $('.forAll').show();
                                    }
                                });
                            });
					</script>
    </body>

    </html>
    <?php } else{
header('Location: membership.php');
}
?>
