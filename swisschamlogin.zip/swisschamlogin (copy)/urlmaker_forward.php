<?php
/**
* A file which can forward a user to a passed URL.
* Main purpose of the file is to set a cookie on a specific domain.
*
* @param	ENgine_domain  The domain on which the cookie should be set. The E-Ngine URL maker will pass the domain of the SOAP script (should be the domain where this script is placed)
* @param	ENgine_url     Destination URL. This script will forward the user to this URL
* @param	ENgine_cookie  The cookie which needs to be set by this script so it can be used by a SOAP script on this server.
* @author	M. van de Vis
*/

$cookieName          = 'e-ngine_campaign';                                  // Name of the cookie which might be registered below
$cookieDomain        = rawurldecode(base64_decode($_GET['ENgine_domain'])); // The domain on which the cookie should be set. The E-Ngine URL maker will pass the domain of the SOAP script (should be the domain where this script is placed) 
$invalidArgumentsUrl = 'http://www.' . $cookieDomain . '/';                 // The URL to which we'll be forwarded if any errors occur

// Url set? Must be set, only access point is through E-Ngine which automatically adds the parameter ENgine_url to the query string
if(isset($_GET['ENgine_url']))
{
	// E-Ngine rawurl and base64 encodes the passed variables to decrease readability
	$url = rawurldecode(base64_decode($_GET['ENgine_url']));
	
	// Check the URL for a valid scheme, should always be valid
	$res = parse_url($url);
	if(isset($res['scheme']) && ($res['scheme']=='http' || $res['scheme']=='https'))
	{
		// The 'ENgine_cookie' parameter isnt required, but will always be passed by E-Ngine
		$cookieValue = isset($_GET['ENgine_cookie'])?trim($_GET['ENgine_cookie']):'';
		if($cookieValue != '')
		{
			$validTill = time() + (60 * 60 * 24 * 30 * 12); // seconds * minuts * hours * days * month = valid for 1 year
			@setcookie($cookieName, rawurldecode(base64_decode($cookieValue)), $validTill, "/", "." . $cookieDomain);
		}
	}else
	{
		$url = ''; //Invalid URL (shouldnt happen)
	}
}else
{
	$url = ''; //No URL found (shouldnt happen)
}

if($url == '')
{
	$url = $invalidArgumentsUrl;
}

header("Location: " . $url);
die();
