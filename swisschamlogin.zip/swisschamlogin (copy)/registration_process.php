<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 
function check($rand1){
    $check="SELECT * FROM sc_c_userdetails
                     WHERE admin_generated_userId='$rand1'";
    $resultCheck = mysql_query($check); 
    $rowCheck = mysql_fetch_array($resultCheck);
    return $rowCheck;
}
function autoUserId(){
    $ch_seed = str_split('abcdefghijklmnopqrstuvwxyz'
                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                 .'0123456789!@#$%^&*()'); // and any other characters
    shuffle($ch_seed); // probably optional since array_is randomized; this may be redundant
    $rand1='';
    foreach (array_rand($ch_seed, 10) as $k1) $rand1 .= $ch_seed[$k1];
    $ck=check($rand1);
    if(empty($ck)){
        return $rand1;
    } else{
        autoUserId();
    }
}
if($_POST){	
if(!empty($_POST['user_title'])){
$user_title=$_POST['user_title'];
} else{
    $user_title='';
}
if(!empty($_POST['family_name'])){
$family_name=$_POST['family_name'];
} else{
    $family_name='';
}
if(!empty($_POST['given_name'])){
$given_name=$_POST['given_name'];
} else{
    $given_name='';
}
if(!empty($_POST['chinese_name'])){
$chinese_name=$_POST['chinese_name'];
} else{
    $chinese_name='';
}
if(!empty($_POST['nationality'])){
$nationality=$_POST['nationality'];
} else{
    $nationality='';
}
if(!empty($_POST['membership_location'])){
$membership_location=$_POST['membership_location'];
} else{
    $membership_location='';
}
if(!empty($_POST['membership_type'])){
$membership_type=$_POST['membership_type'];
} else{
    $membership_type='';
}   
if(!empty($_POST['company_name_english'])){
$company_name_english=$_POST['company_name_english'];
} else{
    $company_name_english='';
}
if(!empty($_POST['company_name_chinese'])){
$company_name_chinese=$_POST['company_name_chinese'];
} else{
    $company_name_chinese='';
}
if(!empty($_POST['positionIn_company'])){
$positionIn_company=$_POST['positionIn_company'];
} else{
    $positionIn_company='';
}
if(!empty($_POST['address_english'])){
$address_english=addslashes($_POST['address_english']);
} else{
    $address_english='';
}
if(!empty($_POST['address_chinese'])){
$address_chinese=addslashes($_POST['address_chinese']);
} else{
    $address_chinese='';
}
if(!empty($_POST['city'])){
$city=$_POST['city'];
} else{
    $city='';
}
if(!empty($_POST['zip_code'])){
$zip_code=$_POST['zip_code'];
} else{
    $zip_code='';
}
if(!empty($_POST['website'])){
$website=$_POST['website'];
} else{
    $website='';
}
if(!empty($_POST['general_phone'])){
$general_phone=$_POST['general_phone'];
} else{
    $general_phone='';
}
 if(!empty($_POST['general_phone'])){
$general_phone=$_POST['general_phone'];
} else{
    $general_phone='';
}
if(!empty($_POST['general_email'])){
$general_email=$_POST['general_email'];
} else{
    $general_email='';
}
 if(!empty($_POST['direct_fax'])){
$direct_fax=$_POST['direct_fax'];
} else{
    $direct_fax='';
}
if(!empty($_POST['direct_phone'])){
$direct_phone=$_POST['direct_phone'];
} else{
    $direct_phone='';
}
if(!empty($_POST['direct_email'])){
$direct_email=$_POST['direct_email'];
} else{
    $direct_email='';
}
if(!empty($_POST['mobile_phone'])){
$mobile_phone=$_POST['mobile_phone'];
} else{
    $mobile_phone='';
}
if(!empty($_POST['other_industry'])){
$other_industry=$_POST['other_industry'];
} else{
    $other_industry='';
}
if(!empty($_POST['business_scope'])){
$business_scope=addslashes($_POST['business_scope']);
} else{
    $business_scope='';
}
if(!empty($_POST['legal_entity'])){
$legal_entity=$_POST['legal_entity'];
} else{
    $legal_entity='';
}
if(!empty($_POST['employees_mainland_chinese'])){
$employees_mainland_chinese=$_POST['employees_mainland_chinese'];
} else{
    $employees_mainland_chinese='';
}
if(!empty($_POST['employees_asia'])){
$employees_asia=$_POST['employees_asia'];
} else{
    $employees_asia='';
}
if(!empty($_POST['country_swissInvested'])){
$country_swissInvested=$_POST['country_swissInvested'];
} else{
    $country_swissInvested='';
}
if(!empty($_POST['country_swiss_registered'])){
$country_swiss_registered=$_POST['country_swiss_registered'];
} else{
    $country_swiss_registered='';
}
if(!empty($_POST['registered_PRC'])){
$registered_PRC=$_POST['registered_PRC'];
} else{
    $registered_PRC='';
}
if(!empty($_POST['comments'])){
$comments=addslashes($_POST['comments']);
} else{
    $comments='';
}
if(!empty($_POST['test'])){
$test=addslashes($_POST['test']);
} else{
    $test='';
}
$created_date=date("Y-m-d H:i:s");
$seed = str_split('abcdefghijklmnopqrstuvwxyz'
                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                 .'0123456789!@#$%^&*()'); // and any other characters
shuffle($seed); // probably optional since array_is randomized; this may be redundant
$rand = '';
foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
$admin_generated_userId= autoUserId(); 
$admin_generated_userId; 
$admin_generated_password= $rand;    
 
    
$insertUser = "INSERT INTO sc_c_userdetails (user_title, family_name, given_name,chinese_name,nationality,membership_location,membership_type,company_name_english,company_name_chinese,positionIn_company,address_english,address_chinese,city,zip_code,website,general_phone,general_email,direct_fax,direct_phone,direct_email,mobile_phone,other_industry,business_scope,legal_entity,employees_mainland_chinese,employees_asia,country_swissInvested,country_swiss_registered,registered_PRC,comments,created_date,test,admin_generated_userId,admin_generated_password)
VALUES ('$user_title', '$family_name', '$given_name','$chinese_name','$nationality','$membership_location','$membership_type','$company_name_english','$company_name_chinese','$positionIn_company','$address_english','$address_chinese','$city','$zip_code','$website','$general_phone','$general_email','$direct_fax','$direct_phone','$direct_email','$mobile_phone','$other_industry','$business_scope','$legal_entity','$employees_mainland_chinese','$employees_asia','$country_swissInvested','$country_swiss_registered','$registered_PRC','$comments','$created_date','$test','$admin_generated_userId','$admin_generated_password')";
mysql_query($insertUser);
$last_id=mysql_insert_id();
mysql_query("UPDATE sc_c_userdetails SET created_by='$last_id' WHERE userId='$last_id'");  
$ct=count($_POST['industry']);
$industry=$_POST['industry'];
for($i=0;$i<$ct;$i++){
$user_id=$last_id;
$industry_id=$industry[$i];
    $inserUserIndustry = "INSERT INTO sc_c_user_to_industry (user_id, industry_id) VALUES ('$user_id', '$industry_id')";
    mysql_query($inserUserIndustry);
}

$to = $general_email; 
$subject = "Registration";
$txt = "Your Registration Is Successfully Done";
$headers = "From: shubhadipbera.delgence@gmail.com" . "\r\n" .
"CC: shubhadipbera.delgence@gmail.com";
mail($to,$subject,$txt,$headers);
echo "You have registered successfully";

}   

?>