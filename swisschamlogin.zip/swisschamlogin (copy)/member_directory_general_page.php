<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
require_once(__ROOT__."/pagination.class.php");
?>
    <!doctype html>
    <html class="no-js" lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Swisscham | Member Directory</title>
        <link rel="stylesheet" href="css/app.css">
        <link rel="stylesheet" href="css/dev1.css">
        <!-- Favicon -->
		<link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
		
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }

        </style>
    </head>

    <body>
        <div id="page">
            <?php 
		require_once(__ROOT__.'/includes/header.php'); 
		?>
                <div class="abc"></div>
                <section class="inner_banner bg-beijing hide-for-small-only">
                    <div class="inner_bredcrumb">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs page_bredcrunb">
                                <li><a href="<?=$site_url?>">Home</a></li>
                                <li><a href="#">Membership</a></li>
                                <li><a href="<?=$base_url?>member_directory_general_page.php">
                                    <span class="show-for-sr">Current: </span> Members Directory</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </section>
                <section>
                    <div class="row" data-equalizer data-equalize-on="medium">
                        <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                            <div class="large-12 columns dowedo_top">
                                <h1 class="common_heading">Members Directory</h1>
                            </div>
                            <div class="large-12 columns no_padding">
                                <div class="large-12 columns dowedo_top">
                                    <p>Welcome on our Member Directory where you will find data of more than XXX companies, institutions and individuals registered with SwissCham China and Hong Kong.</p>
                                    <p>Detailed information (address, HQ, contact person) are available exclusively for our members. To know more about the other benefits to join us, <a href="<?php echo $site_url ;?>why-join-us-swisscham-china/">click HERE (SwissCham China)</a> or <a href="<?php echo $site_url ;?>why-join-us-swisscham-hong-kong/">HERE (SwissCham Hong Kong)</a>.</p>
                                </div>
                            </div>
                            <?php if(isset($_POST)){?>
                                <div class="large-12 columns no_padding">
                                    <div class="large-12 columns margin_bottom15">
                                        <div class="large-12 columns pattern_bg">
                                            <div class="large-12 columns news_dropmenu">
                                                <label>SEARCH
                                                    <form name="searchForm" id="searchForm" action="member_directory_general_page_search.php" method="GET">
                                                        <div class="input-group">
                                                            <input class="input-group-field news_search_field" type="text" placeholder="Type any keywords" value="" name="searchKey" id="searchKey">
                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="company chamber" value="" name="company_chamber" id="company_chamber">
                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="NAME" value="" name="searchName" id="searchName">

                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="business_scope" value="" name="business_scope" id="business_scope">

                                                            <div class="input-group-button">
                                                                <a href="javascript:void(0);" class="button news_search_button" id="searchButton"><i class="fa fa-search" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="large-12 columns no_padding">
                                    <div class="large-6 columns dowedo_top">
                                        <h3 class="common_subheading border_subheading">Members by Office</h3>
                                        <ul class="fa-ul custom_directory_list">
                                            <li><a href="javascript:void(0);" class="chemberClass" data-id="Beijing">Beijing</a></li>
                                            <li><a href="javascript:void(0);" class="chemberClass" data-id="Shanghai">Shanghai</a></li>
                                            <li><a href="javascript:void(0);" class="chemberClass" data-id="Guangzhou">Guangzhou</a></li>
                                            <li><a href="javascript:void(0);" class="chemberClass" data-id="ChinaMainland">China Mainland</a></li>
                                            <li><a href="javascript:void(0);" class="chemberClass" data-id="HongKong">Hong Kong</a></li>
                                        </ul>
                                    </div>
                                    <div class="large-6 columns dowedo_top">
                                        <h3 class="common_subheading border_subheading">Members by name</h3>
                                        <ul class="fa-ul custom_directory_name_list">
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="A">A</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="B">B</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="C">C</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="D">D</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="E">E</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="F">F</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="G">G</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="H">H</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="I">I</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="J">J</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="K">K</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="L">L</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="M">M</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="N">N</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="O">O</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="P">P</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="Q">Q</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="R">R</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="S">S</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="T">T</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="U">U</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="V">V</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="W">W</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="X">X</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="Y">Y</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="Z">Z</a></li>
                                            <li><a href="javascript:void(0);" class="nameClass" data-id="#">#</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="large-12 columns no_padding">
                                    <div class="large-12 columns dowedo_top">
                                        <h3 class="common_subheading border_subheading">Members by industry</h3>
                                        <ul class="fa-ul directory_industry_list">
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Agriculture / Food / Beverages">Agriculture / Food / Beverages</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Banking / Insurance">Banking / Insurance</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Chemical / Pharmaceuticals">Chemical / Pharmaceuticals</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Construction / Civil Engineering">Construction / Civil Engineering</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Education / Training">Education / Training</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Government / NGO / NPO / Economic Zone">Government / NGO / NPO / Economic Zone</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Hospitality / Hotels / Tourism Services">Hospitality / Hotels / Tourism Services</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Information Technology / Telecommunications">Information Technology / Telecommunications</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Jewellery / Watches">Jewellery / Watches</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Legal / Audit / Consulting">Legal / Audit / Consulting</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Machinery / Equipment">Machinery / Equipment</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Manufacturing / Electronic">Manufacturing / Electronic</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Media / Publication">Media / Publication</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Medical / Precision / Optical Instruments">Medical / Precision / Optical Instruments</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Quality Control / Standards / Testing">Quality Control / Standards / Testing</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Trading / Logistics / Transportation">Trading / Logistics / Transportation</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Sales / Marketing / Retail">Sales / Marketing / Retail</a></li>
                                            <li><a href="javascript:void(0);" class="businessScopeClass" data-id="Other">Other</a></li>

                                        </ul>
                                    </div>
                                </div>




                                




                                <!-- Login Modal Start -->
                                <div class="reveal login_modal" id="loginModal1" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                                    <h1>Please enter the details to login</h1>
                                    <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                                    <form name="logInForm1" id="logInForm1" action="login_process.php" method="POST">
                                        <div class="row">
                                            <div class="medium-12 columns margin_top10 membership_from no_padding">
                                                <label>User ID <span class="mandatory_tag">*</span>
                                                    <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId1">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns margin_top10 membership_from no_padding">
                                                <label>Password <span class="mandatory_tag">*</span>
                                                    <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password1">
                                                    <input type="hidden" value="" name="uid" id="uid1">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from no_padding">
                                                <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit1">Login</a></p>
                                            </div>
                                        </div>
                                    </form>
                                    <button class="close-button" data-close aria-label="Close reveal" type="button">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <!-- Login Modal End -->
                                <?php } ?>

                        </div>

                        <?php 
			require_once(__ROOT__.'/includes/rightPanel.php'); 
			?>
                    </div>
                </section>
			<!--	<section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>-->
                <?php 
			require_once(__ROOT__.'/includes/footer.php'); 
			?>
                    <!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please enter the details to login</h1>
                        <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                        <input type="hidden" value="c" name="uid" id="uid">
                                    </label>
                                </div>
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
                    <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->

                    <?php 
            require_once(__ROOT__.'/includes/footerbuttom.php'); 
            ?>


        </div>

        <a href="#0" class="cd-top">Top</a>




        <script src="bower_components/jquery/dist/jquery.js"></script>
        <script src="bower_components/what-input/what-input.js"></script>
        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/easyResponsiveTabs.js"></script>
        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
        <script type="text/javascript" src="js/pace.js"></script>
        <script type="text/javascript">
            $(function() {
                $('nav#menu').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: true,
                    counters: false,
                    "offCanvas": {
                        "position": "left"
                    },
                    navbar: {
                        title: 'SWISSCHAM'
                    },
                    navbars: [{
                        position: 'top',
                        content: ['searchfield']
                    }, {
                        position: 'top',
                        content: [
                            'prev',
                            'title',
                            'close'
                        ]
                    }, {
                        position: 'bottom',
                        content: [
                            //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                        ]
                    }]
                });
                $('nav#log_togg').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: false,
                    counters: false,
                    navbar: {
                        title: 'Welcome to Swisscham'
                    },
                    navbars: [{
                        position: 'bottom',
                        content: [
                            '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /> Wechat</a></span>',
                            '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /> LinkedIn</a></span>'
                        ]
                    }]

                });

            });

        </script>
        <script>
            $(document).ready(function() {
                $('.pagination a').click(function() {
                    var url = $(this).attr('href');
                    $('#searchform').attr('action', url);
                    $('#searchform').submit();
                });

            });

        </script>
        <script src="js/app.js"></script>
        <script src="js/generalDirectory.js"></script>
        <script type="text/javascript" src="js/registration.js"></script>

    </body>

    </html>
