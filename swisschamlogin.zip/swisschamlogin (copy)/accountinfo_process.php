<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
if($_POST){	
if(!empty($_POST['admin_generated_userId'])){
$admin_generated_userId=$_POST['admin_generated_userId'];
} else{
    $admin_generated_userId='';
}
if(!empty($_POST['general_email'])){
$direct_email=$_POST['general_email'];
} else{
    $direct_email='';
}
if(!empty($_POST['admin_generated_password'])){
$admin_generated_password=$_POST['admin_generated_password'];
} else{
    $admin_generated_password='';
}
if(!empty($_POST['timezone_name'])){
$timezone_name=addslashes($_POST['timezone_name']);
} else{
    $timezone_name='';
}
if(!empty($_POST['language'])){
$language=$_POST['language'];
} else{
    $language='';
}
$userId=$_SESSION["userId"];
if($admin_generated_password!=''){
	$updateAccout="UPDATE sc_c_userdetails SET 
						admin_generated_userId='$admin_generated_userId',
						direct_email='$direct_email',
						admin_generated_password='$admin_generated_password',
						timezone_name='$timezone_name',
						language='$language'
						WHERE userId='$userId' ";

	} else{
	$updateAccout="UPDATE sc_c_userdetails SET 
						admin_generated_userId='$admin_generated_userId',
						general_email='$general_email',
						timezone_name='$timezone_name',
						language='$language'
						WHERE userId='$userId' "; 
	}
	mysql_query($updateAccout);
	header('Location: membership.php');

}
?>