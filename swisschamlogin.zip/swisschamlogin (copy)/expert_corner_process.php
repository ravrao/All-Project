<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
if($_POST){	
//print_r($_POST); //die;
if(!empty($_POST['corner_title'])){
$corner_title=addslashes($_POST['corner_title']);
} else{
    $corner_title='';
}
if(!empty($_POST['corner_body'])){
$corner_body=addslashes($_POST['corner_body']);
} else{
    $corner_body='';
}
if(!empty($_POST['text_format'])){
$text_format=$_POST['text_format'];
} else{
    $text_format='';
}
if(!empty($_POST['tag_name'])){
$tag_name=$_POST['tag_name'];
} else{
    $tag_name='';
}
	if((isset($_FILES['expert_file']['name'])) && (!empty($_FILES['expert_file']['name']))){
      $errors= array();
      $file_name = $_FILES['expert_file']['name'];
      $file_size =$_FILES['expert_file']['size'];
      $file_tmp =$_FILES['expert_file']['tmp_name'];
      $file_type=$_FILES['expert_file']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['expert_file']['name'])));
      
      $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
     /* 
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }*/
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      //print_r($_FILES['upload_file']);
	  $file_name="expert_corner".time().$file_ext;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $expert_file="uploads/".$file_name; 
      }else{
         print_r($errors);
		 header('Location: membership.php');
      }
   } else{
	   $expert_file="";
   }
$userId=$_SESSION["userId"];
if($expert_file==''){
	$expertCornerUpdate="UPDATE `sc_c_expert_corner_article` SET 
						`corner_title`='$corner_title',
						`corner_body`='$corner_body',
						`text_format`='$text_format',
						`tag_name`='$tag_name'
						WHERE `userId`='$userId' ";

	} else{
	$expertCornerUpdate="UPDATE `sc_c_expert_corner_article` SET 
						`corner_title`='$corner_title',
						`corner_body`='$corner_body',
						`text_format`='$text_format',
						`tag_name`='$tag_name',
						`expert_file`='$expert_file'
						WHERE `userId`='$userId' "; 
	}
	$expertCornerFetch="SELECT * FROM `sc_c_expert_corner_article` WHERE `userId`='$userId'";
	$expertCornerResult=mysql_query($expertCornerFetch);
	$expertResult=mysql_fetch_array($expertCornerResult);
	if(!empty($expertResult)){
	mysql_query($expertCornerUpdate);
	} else{
		echo "insert";
	$expertCornerInsert="INSERT INTO `sc_c_expert_corner_article` 								(corner_title,corner_body,text_format,tag_name,upload_file,userId)
							VALUES('$corner_title','$corner_body','$text_format','$tag_name','$upload_file','$userId')";
	mysql_query($expertCornerInsert);	
	}
	//echo $updateAccout; die;
	
	header('Location: membership.php');

}
?>