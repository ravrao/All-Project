<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 


$userId=$_REQUEST['userId'];
$adminId = $_SESSION["userId"];
if($_POST){ 
$info=trim($_GET['info']);

switch ($info) {
case "personal":
	$user_title = isset($_REQUEST['user_title'])?addslashes($_REQUEST['user_title']):"";
	$year_of_birth = isset($_REQUEST['year_of_birth'])?addslashes($_REQUEST['year_of_birth']):"";
	$year_of_birth = date('Y-m-d',strtotime($year_of_birth));
	$family_name = isset($_REQUEST['family_name'])?addslashes($_REQUEST['family_name']):"";
	$given_name = isset($_REQUEST['given_name'])?addslashes($_REQUEST['given_name']):"";
	$chinese_name = isset($_REQUEST['chinese_name'])?addslashes($_REQUEST['chinese_name']):"";
	$nationality = isset($_REQUEST['nationality'])?addslashes($_REQUEST['nationality']):"";
	$address_english = isset($_REQUEST['address_english'])?addslashes($_REQUEST['address_english']):"";
	$city_english = isset($_REQUEST['city_english'])?addslashes($_REQUEST['city_english']):"";
	$province_area = isset($_REQUEST['province_area'])?addslashes($_REQUEST['province_area']):"";
	$address_chinese = isset($_REQUEST['address_chinese'])?addslashes($_REQUEST['address_chinese']):"";
	$city_chinese = isset($_REQUEST['city_chinese'])?addslashes($_REQUEST['city_chinese']):"";
	$zip_code_english = isset($_REQUEST['zip_code_english'])?addslashes($_REQUEST['zip_code_english']):"";
	$positionIn_company = isset($_REQUEST['positionIn_company'])?addslashes($_REQUEST['positionIn_company']):"";
	$direct_phone = isset($_REQUEST['direct_phone'])?addslashes($_REQUEST['direct_phone']):"";
	$mobile_phone = isset($_REQUEST['mobile_phone'])?addslashes($_REQUEST['mobile_phone']):"";
	$direct_email = isset($_REQUEST['direct_email'])?addslashes($_REQUEST['direct_email']):"";
	
	$npo_organization_type = isset($_REQUEST['npo_organization_type'])?addslashes($_REQUEST['npo_organization_type']):"";
	$npo_organization_description = isset($_REQUEST['npo_organization_description'])?addslashes($_REQUEST['npo_organization_description']):"";
	
	$media_type = isset($_REQUEST['media_type'])?addslashes($_REQUEST['media_type']):"";
	$media_description = isset($_REQUEST['media_description'])?addslashes($_REQUEST['media_description']):"";
	
	if((isset($_FILES['profile_picture']['name'])) && (!empty($_FILES['profile_picture']['name']))){
      $errors= array();
      $file_name = $_FILES['profile_picture']['name'];
      $file_size =$_FILES['profile_picture']['size'];
      $file_tmp =$_FILES['profile_picture']['tmp_name'];
      $file_type=$_FILES['profile_picture']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['profile_picture']['name'])));
      $expensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $file_name="profile_picture".time().$file_ext;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $profile_picture="uploads/".$file_name; 
         $profile_picture1=$file_name; 
      }else{
		 header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab2|ChildVerticalTab_12');
      }
	} else{
	   $profile_picture="";
	   $profile_picture1="";
	}
	if($profile_picture1!=''){
	   $personalSql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."',
		                     `direct_email`='".$direct_email."',
		                     `profile_picture`='".$profile_picture."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `userId` = '".$userId."'";
	} else{
	   $personalSql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$user_title."',
		                     `year_of_birth`='".$year_of_birth."',
		                     `family_name`='".$family_name."',
		                     `given_name`='".$given_name."',
		                     `chinese_name`='".$chinese_name."',
		                     `nationality`='".$nationality."',
		                     `address_english`='".$address_english."',
		                     `city_english`='".$city_english."',
		                     `province_area`='".$province_area."',
		                     `address_chinese`='".$address_chinese."',
		                     `city_chinese`='".$city_chinese."',
		                     `zip_code_english`='".$zip_code_english."',
		                     `positionIn_company`='".$positionIn_company."',
		                     `direct_phone`='".$direct_phone."',
		                     `mobile_phone`='".$mobile_phone."',
		                     `direct_email`='".$direct_email."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `userId` = '".$userId."'"; 
	}
	
	mysql_query($personalSql);
	
	if($npo_organization_type!=''){
	$npoPersonalSql="UPDATE `sc_c_userdetails`
		                 SET `npo_organization_type`='".$npo_organization_type."',
		                     `npo_organization_description`='".$npo_organization_description."'
		               WHERE `userId` = '".$userId."'"; 
	mysql_query($npoPersonalSql);
	}
	
	if($media_type!=''){
	$jrnlPersonalSql="UPDATE `sc_c_userdetails`
		                 SET `media_type`='".$media_type."',
		                     `media_description`='".$media_description."'
		               WHERE `userId` = '".$userId."'"; 
	mysql_query($jrnlPersonalSql);
        
      
	}
	
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab2|ChildVerticalTab_12');
	break;
	
	
case "account":
        
	$admin_generated_userId = isset($_REQUEST['admin_generated_userId'])?addslashes($_REQUEST['admin_generated_userId']):"";
        $general_email = isset($_REQUEST['general_email'])?addslashes($_REQUEST['general_email']):"";
        $uemail = filter_var($general_email, FILTER_SANITIZE_EMAIL);
        if(!filter_var($uemail, FILTER_VALIDATE_EMAIL) === false){ $general_email = $uemail; } else{ $general_email = ""; } 
	$admin_generated_password = isset($_REQUEST['admin_generated_password'])?addslashes($_REQUEST['admin_generated_password']):"";
	$admin_approval = isset($_REQUEST['admin_approval'])?addslashes($_REQUEST['admin_approval']):"";
	$assignables_role = isset($_REQUEST['assignables_role'])?$_REQUEST['assignables_role']:"";
	$assignables_roles = implode(",", $assignables_role); 
	$language = isset($_REQUEST['language'])?addslashes($_REQUEST['language']):"";
	if($admin_generated_password == ''){
            
            if($general_email == ""){
		$accountSql = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."',
		                     `admin_approval`='".$admin_approval."',
		                     `assignables_role`='".$assignables_roles."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `userId` = '".$userId."'";
            }
            else{
                
       		$accountSql = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."',
		                     `admin_approval`='".$admin_approval."',
		                     `assignables_role`='".$assignables_roles."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."', 
                                     `direct_email`='".$general_email."'
		               WHERE `userId` = '".$userId."'";
            }

	} else{
            
            if($general_email == ""){
                
		$accountSql = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."',
		                     `admin_generated_password`='".$admin_generated_password."',
		                     `admin_approval`='".$admin_approval."',
		                     `assignables_role`='".$assignables_role."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `other_contect_userid` = '".$userId."'";	
            }
            else {
                
		$accountSql_pass = "UPDATE `sc_c_userdetails`
		                 SET `admin_generated_userId`='".$admin_generated_userId."',
		                     `language`='".$language."',
		                     `admin_generated_password`='".$admin_generated_password."',
		                      `admin_approval`='".$admin_approval."',
		                     `assignables_role`='".$assignables_role."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."',
                                     `direct_email`='".$general_email."'
		               WHERE `userId` = '".$userId."'";	
                $res = mysql_query($accountSql_pass); 
                require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
                
                $rs_USERID=$wpdb->get_row("SELECT  * FROM  `sc_users` where `user_login`='".$admin_generated_userId."'");
                $user_id =  $rs_USERID->ID;
                if($user_id!='') {
                wp_set_password( $admin_generated_password, $user_id );
                 }
                
           }
	}
	
        //set the approval for the company members
	$accountOtherSql = "UPDATE `sc_c_userdetails`
		                 SET `admin_approval`='".$admin_approval."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `other_contect_userid` = '".$userId."'";
	
	$res = mysql_query($accountSql); 
        $res1 = mysql_query($accountOtherSql);
        
        require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
        require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-admin/includes/ms.php' );
        global $wpdb;
        $Userid=$_REQUEST['admin_generated_userId'];
       
        $rs_USERID=$wpdb->get_row("SELECT  * FROM  `sc_users` where `user_login`='".$Userid."'");
       //echo $rs_USERID->num_rows;
        if($_REQUEST['admin_approval']=='Yes')
        {
        //echo 'Pass:'.$_REQUEST['admin_general_password_hidden'];
        //echo 'User:'.$_REQUEST['admin_generated_userId'];
        $random_password = wp_generate_password( $include_standard_special_chars=false ); 
        $user_id = wp_create_user( $_REQUEST['admin_generated_userId'], $_REQUEST['admin_general_password_hidden'], $general_email );
        if($rs_USERID->user_status==1)
        {
            $user_id =  $rs_USERID->ID; 
          
           update_user_status( $user_id, 'user_status', 0 );
        }
        }
       if($_REQUEST['admin_approval']=='No')
       {
           
           $user_id =  $rs_USERID->ID; 
          
           update_user_status( $user_id, 'user_status', 1 );
        
           }
       
      
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab2|ChildVerticalTab_11');
	break;
	
	
	
case "other":

	$otherDeleteQuery="DELETE FROM `sc_c_other_contact` WHERE `userId` = '".$userId."'";
	mysql_query($otherDeleteQuery);
	$compsnyORnot=$_REQUEST['compsnyORnot'];
	if($compsnyORnot==0){
	$cnt = count($_REQUEST['other_contact_familyName']);
	for($i=0;$i<$cnt;$i++){
		$j=$i+1;
		$other_contact_title = isset($_REQUEST['other_contact_title'.$j])?addslashes($_REQUEST['other_contact_title'.$j]):"";
        $other_contact_dob = isset($_REQUEST['other_contact_dob'][$i])?addslashes($_REQUEST['other_contact_dob'][$i]):"";
	    $other_contact_dob = date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName = isset($_REQUEST['other_contact_familyName'][$i])?addslashes($_REQUEST['other_contact_familyName'][$i]):"";
		$other_contact_givenName = isset($_REQUEST['other_contact_givenName'][$i])?addslashes($_REQUEST['other_contact_givenName'][$i]):"";
		$other_contact_chineseName = trim(isset($_REQUEST['other_contact_chineseName'][$i]))?addslashes(trim($_REQUEST['other_contact_chineseName'][$i])):"";
        
		$other_contact_nationality = isset($_REQUEST['other_contact_nationality'.$j])?addslashes($_REQUEST['other_contact_nationality'.$j]):"";
		$other_contact_address_english = trim(isset($_REQUEST['other_contact_address_english'][$i]))?addslashes(trim(($_REQUEST['other_contact_address_english'][$i]))):"";
		$other_contact_city_english = isset($_REQUEST['other_contact_city_english'][$i])?addslashes($_REQUEST['other_contact_city_english'][$i]):"";
		$other_contact_province_area = isset($_REQUEST['other_contact_province_area'][$i])?addslashes($_REQUEST['other_contact_province_area'][$i]):"";
		$other_contact_address_chinese = isset($_REQUEST['other_contact_address_chinese'][$i])?addslashes($_REQUEST['other_contact_address_chinese'][$i]):"";
		$other_contact_city_chinese = isset($_REQUEST['other_contact_city_chinese'][$i])?addslashes($_REQUEST['other_contact_city_chinese'][$i]):"";
		$other_contact_zipCode = isset($_REQUEST['other_contact_zipCode'][$i])?addslashes($_REQUEST['other_contact_zipCode'][$i]):"";
		$other_contact_mobile = isset($_REQUEST['other_contact_mobile'][$i])?addslashes($_REQUEST['other_contact_mobile'][$i]):"";
		$other_contact_directPhone = isset($_REQUEST['other_contact_directPhone'][$i])?addslashes($_REQUEST['other_contact_directPhone'][$i]):"";
		$other_contact_directEmail = isset($_REQUEST['other_contact_directEmail'][$i])?addslashes($_REQUEST['other_contact_directEmail'][$i]):"";
		
		 $otherContactSql = "INSERT INTO `sc_c_other_contact`
                        SET `userId`='".$userId."',
                                `other_contact_title`='".$other_contact_title."',
                                `other_contact_dob`='".$other_contact_dob."',
                                `other_contact_familyName`='".$other_contact_familyName."',
                                `other_contact_givenName`='".$other_contact_givenName."',
                                `other_contact_chineseName`='".$other_contact_chineseName."',
                                `other_contact_nationality`='".$other_contact_nationality."',
                                `other_contact_address_english`='".$other_contact_address_english."',
                                `other_contact_city_english`='".$other_contact_city_english."',
                                `other_contact_province_area`='".$other_contact_province_area."',
                                `other_contact_address_chinese`='".$other_contact_address_chinese."',
                                `other_contact_city_chinese`='".$other_contact_city_chinese."',
                                `other_contact_zipCode`='".$other_contact_zipCode."',
                                `other_contact_mobile`='".$other_contact_mobile."',
                                `other_contact_directPhone`='".$other_contact_directPhone."',
                                `other_contact_directEmail`='".$other_contact_directEmail."'";
                
                
		mysql_query($otherContactSql);	
	}
	} else if($compsnyORnot==1){
		$cnt = count($_REQUEST['other_contact_familyNamec']);
		for($i=0;$i<$cnt;$i++){
		$j=$i+1;
		$other_contact_title = isset($_REQUEST['other_contact_titlec'.$j])?addslashes($_REQUEST['other_contact_titlec'.$j]):"";
        $other_contact_dob = isset($_REQUEST['other_contact_dobc'][$i])?addslashes($_REQUEST['other_contact_dobc'][$i]):"";
	    $other_contact_dob = date('Y-m-d',strtotime($other_contact_dob));
		$other_contact_familyName = isset($_REQUEST['other_contact_familyNamec'][$i])?addslashes($_REQUEST['other_contact_familyNamec'][$i]):"";
		$other_contact_givenName = isset($_REQUEST['other_contact_givenNamec'][$i])?addslashes($_REQUEST['other_contact_givenNamec'][$i]):"";
		$other_contact_chineseName = trim(isset($_REQUEST['other_contact_chineseNamec'][$i]))?addslashes(trim($_REQUEST['other_contact_chineseNamec'][$i])):"";
        
		$other_contact_nationality = isset($_REQUEST['other_contact_nationalityc'.$j])?addslashes($_REQUEST['other_contact_nationalityc'.$j]):"";
		$other_contact_position = isset($_REQUEST['other_contact_positionc'][$i])?addslashes($_REQUEST['other_contact_positionc'][$i]):"";
		$other_contact_address_english = trim(isset($_REQUEST['other_contact_address_englishc'][$i]))?addslashes(trim($_REQUEST['other_contact_address_englishc'][$i])):"";
		$other_contact_city_english = isset($_REQUEST['other_contact_city_englishc'][$i])?addslashes($_REQUEST['other_contact_city_englishc'][$i]):"";
		$other_contact_province_area = isset($_REQUEST['other_contact_province_areac'][$i])?addslashes($_REQUEST['other_contact_province_areac'][$i]):"";
		$other_contact_address_chinese = isset($_REQUEST['other_contact_address_chinesec'][$i])?addslashes($_REQUEST['other_contact_address_chinesec'][$i]):"";
		$other_contact_city_chinese = isset($_REQUEST['other_contact_city_chinesec'][$i])?addslashes($_REQUEST['other_contact_city_chinesec'][$i]):"";
		$other_contact_zipCode = isset($_REQUEST['other_contact_zipCodec'][$i])?addslashes($_REQUEST['other_contact_zipCodec'][$i]):"";
		$other_contact_mobile = isset($_REQUEST['other_contact_mobilec'][$i])?addslashes($_REQUEST['other_contact_mobilec'][$i]):"";
		$other_contact_directPhone = isset($_REQUEST['other_contact_directPhonec'][$i])?addslashes($_REQUEST['other_contact_directPhonec'][$i]):"";
		$other_contact_directEmail = isset($_REQUEST['other_contact_directEmailc'][$i])?addslashes($_REQUEST['other_contact_directEmailc'][$i]):"";
		
		$otherContactSql = "INSERT INTO `sc_c_other_contact`
                SET `userId`='".$userId."',
                        `other_contact_title`='".$other_contact_title."',
                        `other_contact_dob`='".$other_contact_dob."',
                        `other_contact_familyName`='".$other_contact_familyName."',
                        `other_contact_givenName`='".$other_contact_givenName."',
                        `other_contact_chineseName`='".$other_contact_chineseName."',
                        `other_contact_nationality`='".$other_contact_nationality."',
                        `other_contact_position`='".$other_contact_position."',
                        `other_contact_address_english`='".$other_contact_address_english."',
                        `other_contact_city_english`='".$other_contact_city_english."',
                        `other_contact_province_area`='".$other_contact_province_area."',
                        `other_contact_address_chinese`='".$other_contact_address_chinese."',
                        `other_contact_city_chinese`='".$other_contact_city_chinese."',
                        `other_contact_zipCode`='".$other_contact_zipCode."',
                        `other_contact_mobile`='".$other_contact_mobile."',
                        `other_contact_directPhone`='".$other_contact_directPhone."',
                        `other_contact_directEmail`='".$other_contact_directEmail."'";

		mysql_query($otherContactSql);	
	}
		
	}
        
        
	$updated_date=date("Y-m-d");
	$updateCompanyQuery="UPDATE `sc_c_userdetails`
        SET `updated_by`='".$userId."',
                `updated_date`='".$updated_date."'
       WHERE `userId`='".$userId."'";
	mysql_query($updateCompanyQuery);
	
	header('Location: admin_edit_membership.php?id='.$userId.'#eventListTab2|ChildVerticalTab_13');
	break;
        
case "memberderectory" : 
   //var_dump($_REQUEST);
  $memberdirectoryid            = $_REQUEST['userIdForMemberdiretcory'];  
    

$other_contact_title_dir            = $_REQUEST['other_contact_title_dir'];
$other_contact_dob_dir              = $_REQUEST['other_contact_dob_dir'];
$other_contact_dob_dir              = date('Y-m-d',strtotime($other_contact_dob_dir));
$other_contact_familyName_dir       = $_REQUEST['other_contact_familyName_dir'];
$other_contact_givenName_dir        = $_REQUEST['other_contact_givenName_dir'];
$other_contact_chineseName_dir          = trim($_REQUEST['other_contact_chineseName_dir']);

$other_contact_nationality_dir      = $_REQUEST['other_contact_nationality_dir'];

$other_contact_position_dir  = trim($_REQUEST['other_contact_position_dir']);

$other_contact_address_english_dir  = trim($_REQUEST['other_contact_address_english_dir']);
$other_contact_city_english_dir     = $_REQUEST['other_contact_city_english_dir'];

$other_contact_province_area_dir    = $_REQUEST['other_contact_province_area_dir'];
$other_contact_address_chinese_dir  = trim($_REQUEST['other_contact_address_chinese_dir']);

$other_contact_city_chinese_dir     = trim($_REQUEST['other_contact_city_chinese_dir']);

$other_contact_zipCode_dir          = $_REQUEST['other_contact_zipCode_dir'];
$other_contact_mobile_dir           = $_REQUEST['other_contact_mobile_dir'];
$other_contact_directPhone_dir      = $_REQUEST['other_contact_directPhone_dir'];
$other_contact_directEmail_dir      = $_REQUEST['other_contact_directEmail_dir'];
$admin_approval                     = $_REQUEST['admin_approval'];

if($memberdirectoryid!='')
{
     $memberdirAql = "UPDATE `sc_c_userdetails`
		                 SET `user_title`='".$other_contact_title_dir."',
		                     `year_of_birth`='".$other_contact_dob_dir."',
		                     `family_name`='".$other_contact_familyName_dir."',
		                     `given_name`='".$other_contact_givenName_dir."',
		                     `chinese_name`='".$other_contact_chineseName_dir."',
		                     `nationality`='".$other_contact_nationality_dir."',
                                     `positionIn_company`='".$other_contact_position_dir."',    
		                     `address_english`='".$other_contact_address_english_dir."',
		                     `city_english`='".$other_contact_city_english_dir."',
		                     `province_area`='".$other_contact_province_area_dir."',
		                     `address_chinese`='".$other_contact_address_chinese_dir."',
		                     `city_chinese`='".$other_contact_city_chinese_dir."',
		                     `zip_code_english`='".$other_contact_zipCode_dir."',
		                     
		                     `direct_phone`='".$other_contact_directPhone_dir."',
		                     `mobile_phone`='".$other_contact_mobile_dir."',
		                     `direct_email`='".$other_contact_directEmail_dir."',
		                     `admin_approval`='".$admin_approval."',
		                     `updated_by`='".$adminId."',
		                     `updated_date`='".date('Y-m-d')."'
		               WHERE `userId` = '".$memberdirectoryid."'";
             mysql_query($memberdirAql); 
        header('Location: admin.php#eventListTab5');
	break;
}
else 
{
 
function check($rand1){
    $check="SELECT * FROM sc_c_userdetails
                     WHERE admin_generated_userId='$rand1'";
    $resultCheck = mysql_query($check); 
    $rowCheck = mysql_fetch_array($resultCheck);
    return $rowCheck;
}
        function autoUserId(){
                $ch_seed = str_split('abcdefghijklmnopqrstuvwxyz'
                             .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                             .'0123456789!@#$%^&*()'); // and any other characters
                shuffle($ch_seed); // probably optional since array_is randomized; this may be redundant
                $rand1='';
                foreach (array_rand($ch_seed, 10) as $k1) $rand1 .= $ch_seed[$k1];
                $ck=check($rand1);
                if(empty($ck)){
                    return $rand1;
                } else{
                    autoUserId();
                }
        }        
                
        $created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
					 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
					 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	$admin_generated_userId= autoUserId(); 
	$admin_generated_userId; 
	$admin_generated_password= $rand;  
                
 $userFirstContactDetailsAql = "INSERT INTO `sc_c_userdetails`
				SET `other_contect_userid`='".$userId."',
                                        `user_title`='".$other_contact_title_dir."',
					 
					 `year_of_birth`='".$other_contact_dob_dir."',
					 `family_name`='".$other_contact_familyName_dir."',
					 `given_name`='".$other_contact_givenName_dir."',
					 `chinese_name`='".$other_contact_chineseName_dir."',
					 `nationality`='".$other_contact_nationality_dir."',
					 `positionIn_company`='".$other_contact_position_dir."',
					 `address_english`='".$other_contact_address_english_dir."',
					 `city_english`='".$other_contact_city_english_dir."',
					 `province_area`='".$other_contact_province_area_dir."',
					 `address_chinese`='".$other_contact_address_chinese_dir."',
					 `city_chinese`='".$other_contact_city_chinese_dir."',
					 `zip_code_english`='".$other_contact_zipCode_dir."',
					 `direct_phone`='".$other_contact_directPhone_dir."',
					 `mobile_phone`='".$other_contact_mobile_dir."',
					 `direct_email`='".$other_contact_directEmail_dir."',
                                         `admin_approval`='".$admin_approval."',    
                                             
                                         `admin_generated_userId`='".$admin_generated_userId."',
                                         `admin_generated_password`='".$admin_generated_password."',    
                                          `created_date`='".$created_date."',   
                                         `assignables_role`='member_derectory'";

mysql_query($userFirstContactDetailsAql);  
   
$to  = $other_contact_directEmail_dir;
$subject = 'Account activation';

 $message = '<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Untitled Document</title>
</head>

<body>
    <table width="600" cellpadding="0" cellspacing="0" style="border-collapse:collapse" align="center">


        <tr style="text-align:center;font-size:24px;color:#aa8095">
            <td style="padding-top:17px;padding-bottom:30px; font-family:arial; color:#333; line-height:25px;">User Id :'.$admin_generated_userId.'</td>
        </tr> 
        <tr style="text-align:center;font-size:24px;color:#aa8095">
            <td style="padding-top:17px;padding-bottom:30px; font-family:arial; color:#333; line-height:25px;">Password :'.$admin_generated_password.'</td>
        </tr>
        <tr style="text-align:center;font-size:24px;color:#aa8095">
            <td style="padding-top:17px;padding-bottom:30px; font-family:arial; color:#333; line-height:25px;"><a href="'.$base_url.'/online_application.php">Click here to login</a></td>
        </tr>  

    </table>
</body>					
</html>';


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: swischam.com';
@mail($to, $subject, $message, $headers);

header('Location: admin.php#eventListTab5');
break;
}

case "editevent": {
    
   $EventId=$_REQUEST['eventIdForevent']; 
    
    $event_title            = isset($_REQUEST['event_title'])?addslashes($_REQUEST['event_title']):"";
    $first_name_event       = isset($_REQUEST['first_name_event'])?addslashes($_REQUEST['first_name_event']):"";
    $surname_event          = isset($_REQUEST['surname_event'])?addslashes($_REQUEST['surname_event']):"";
    $email_event            = isset($_REQUEST['email_event'])?addslashes($_REQUEST['email_event']):"";
    $gender_edit            = isset($_REQUEST['gender_edit'])?addslashes($_REQUEST['gender_edit']):"";
    $company_name_event     = isset($_REQUEST['company_name_event'])?addslashes($_REQUEST['company_name_event']):"";
    $job_tile_event         = isset($_REQUEST['job_tile_event'])?addslashes($_REQUEST['job_tile_event']):"";
    $address_event          = isset($_REQUEST['address_event'])?addslashes($_REQUEST['address_event']):"";
    $phone_event            = isset($_REQUEST['event_title'])?addslashes($_REQUEST['phone_event']):"";
    $year_birth_event       = isset($_REQUEST['year_birth_event'])?addslashes($_REQUEST['year_birth_event']):"";
    
     $editEventSql = "UPDATE `sc_c_event_user`
		                 SET `event_title`='".$event_title."',
		                     `first_name`='".$first_name_event."',
		                     `sur_name`='".$surname_event."',
		                      `email`='".$email_event."',
		                     `gender`='".$gender_edit."',
		                     `company_name`='".$company_name_event."',
		                     `job_title`='".$job_tile_event."',
                                     `address`='".$address_event."',
                                     `phone`='".$phone_event."',
                                      `year_of_birth`='".$year_birth_event."'    
		               WHERE `event_user_id` = '".$EventId."'";	 
    
   
    $res_eventedit = mysql_query($editEventSql); 
   
	header('Location: http://www.swisschamofcommerce.com/swisschamlogin/admin.php#eventListTab6');
	break;
   
}

default:
	header('Location: http://www.swisschamofcommerce.com/swisschamlogin/admin.php#eventListTab5');
    
	break;
}

  }
?>