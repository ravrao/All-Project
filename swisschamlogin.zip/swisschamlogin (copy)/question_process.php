<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
if($_POST){	
print_r($_POST); //die;
$userId=$_SESSION["userId"];
if(!empty($_POST['question'])){
$question=addslashes($_POST['question']);
} else{
	$question='';
}
$questionUpdate="UPDATE `sc_c_userdetails` SET 
						`question`='$question'
						WHERE `userId`='$userId' ";	
mysql_query($questionUpdate);
header('Location: membership.php');

}
?>