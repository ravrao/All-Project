<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php'); 

$page = $_REQUEST['page'];
$mailId = $_REQUEST['mail'];

function check($rand1){
    $check="SELECT * FROM sc_c_userdetails
                     WHERE admin_generated_userId='$rand1'";
    $resultCheck = mysql_query($check); 
    $rowCheck = mysql_num_rows($resultCheck);
    return $rowCheck;
}

function autoUserId(){
    $ch_seed = str_split('abcdefghijklmnopqrstuvwxyz'
                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                 .'0123456789!@#$%^&*()'); // and any other characters
    shuffle($ch_seed); // probably optional since array_is randomized; this may be redundant
    $rand1 = '';
    foreach (array_rand($ch_seed, 10) as $k1) $rand1 .= $ch_seed[$k1];
    $ck = check($rand1);
    if($ck == 0){
        return $rand1;
    } else{
        autoUserId();
    }
}


function autoPassword(){
	$created_date=date("Y-m-d H:i:s");
	$seed = str_split('abcdefghijklmnopqrstuvwxyz'
	                 .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	                 .'0123456789!@#$%^&*()'); // and any other characters
	shuffle($seed); // probably optional since array_is randomized; this may be redundant
	$rand = '';
	foreach (array_rand($seed, 5) as $k) $rand .= $seed[$k];
	
	return $rand;
}

$admin_generated_userId = autoUserId();
$admin_generated_password = autoPassword();

$insertUser = "INSERT INTO `sc_c_userdetails` SET								
						   `admin_generated_userId`='".$admin_generated_userId."',
						   `admin_generated_password`='".$admin_generated_password."',
						   `direct_email`='".$mailId."'";
						   
mysql_query($insertUser);
$last_id=mysql_insert_id();


$insertcUser ="INSERT INTO `sc_c_company_details` SET
						   `userId`='".$last_id."'";
mysql_query($insertcUser);

$expertUserIndustry = "INSERT INTO `sc_c_expert_corner_article` SET 
								   `userId`='".$last_id."'";
mysql_query($expertUserIndustry);

$to = $mailId; 
$subject = "Registered by admin";
$message = "Registration successful.";
$headers = "From: swischam.org" . "\r\n" .
"CC: abhijit.delgence@gmail.com";
mail($to, $subject, $message, $headers);

echo "OK";
exit();


?>