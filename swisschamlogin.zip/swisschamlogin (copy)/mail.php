<?php
/*
From http://www.html-form-guide.com 
This is the simplest emailer one can have in PHP.
If this does not work, then the PHP email configuration is bad!
*/
/*$msg="";
if(isset($_POST['submit']))
{
    /* ****Important!****
    replace name@your-web-site.com below 
    with an email address that belongs to 
    the website where the script is uploaded.
    For example, if you are uploading this script to
    www.my-web-site.com, then an email like
    form@my-web-site.com is good.
    */

/*	$from_add = "shubhadip.d2s2gmail.com"; 

	$to_add = "shubhadip.d2s@gmail.com"; //<-- put your yahoo/gmail email address here

	$subject = "Test Subject";
	$message = "Test Message";
	
	$headers = "From: $from_add \r\n";
	$headers .= "Reply-To: $from_add \r\n";
	$headers .= "Return-Path: $from_add\r\n";
	$headers .= "X-Mailer: PHP \r\n";
	
	
	if(mail($to_add,$subject,$message,$headers)) 
	{
		$msg = "Mail sent OK";
	} 
	else 
	{
		print_r(error_get_last());
 	   $msg = "Error sending email!";
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
	<title>Test form to email</title>
</head>

<body>
<?php echo $msg ?>
<p>
<form action='<?php echo htmlentities($_SERVER['PHP_SELF']); ?>' method='post'>
<input type='submit' name='submit' value='Submit'>
</form>
</p>


</body>
</html>
*/
IsSMTP(); 
 SMTP server$mail->SMTPDebug = 1; // debugging: 1 for errors and messages, 2 for messages only
 $mail->SMTPAuth = true; // authentication enabled
 $mail->SMTPSecure = 'tls'; // you can use ssl then port should be 465
 $mail->Host = "tls://smtp.gmail.com"; 
 $mail->Port = 587; // or 465
 $mail->IsHTML(true);
 $mail->Username = "chhotobhaumik@gmail.com"; // your gmail account
 $mail->Password = "-T0VJM-FFPOYJOBB0kc7ZQ"; // password
 $mail->AddReplyTo('shubhadip.d2s@gmail.com', 'dsfgdsfds');  // reply to email address
 $mail->SetFrom('shubhadip.d2s@gmail.com', 'dsfgs'); // sender email address
 $mail->Subject = "Subject of email"; // subject
 $mail->Body = "Content of the message";  // message content
 $mail->AddAddress("shubhadip.d2s@gmail.com");  // recipient email address
 if(!$mail->Send()){    echo "Mailer Error: " . $mail->ErrorInfo;
}else{    
	echo "Message sent";
}
?>