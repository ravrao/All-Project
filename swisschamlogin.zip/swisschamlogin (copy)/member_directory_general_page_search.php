<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
require_once(__ROOT__."/pagination.class.php");
?>
    <!doctype html>
    <html class="no-js" lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Swisscham | Member Directory</title>
        <link rel="stylesheet" href="css/app.css">
        <link rel="stylesheet" href="css/dev1.css">
        <!-- Favicon -->
		<link rel="icon" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="57x57">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="72x72">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="114x114">
		<link rel="shortcut icon" type="image/png" href="<?=$site_url?>wp-content/themes/swisscham/images/favicon.png" sizes="144x144">
		
        <link rel="icon" href="favicon.png">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="57x57">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="72x72">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="114x114">
        <link rel="shortcut icon" type="image/png" href="favicon.png" sizes="144x144">
        <style type="text/css">
            .error_cl {
                border: 1px solid;
                border-color: red !important;
            }

        </style>
    </head>

    <body>
        <div id="page">
            <?php 
		require_once(__ROOT__.'/includes/header.php'); 
		?>
                <div class="abc"></div>
                <section class="inner_banner bg-beijing hide-for-small-only">
                    <div class="inner_bredcrumb">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs page_bredcrunb">
                                <li><a href="<?=$site_url?>">Home</a></li>
                                <li><a href="#">Membership</a></li>
                                <li><a href="<?=$base_url?>member_directory_general_page.php">
                                    <span class="show-for-sr">Current: </span> Members Directory</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </section>
                <section>
                    <div class="row" data-equalizer data-equalize-on="medium">
                        <div class="large-9 medium-8 small-12 columns no_padding margin_top15" data-equalizer-watch>
                            <div class="large-12 columns dowedo_top">
                                <h1 class="common_heading">Members Directory</h1>
                            </div>
                            <div class="large-12 columns no_padding">
                                <div class="large-12 columns dowedo_top">
                                    <p>Welcome on our Member Directory where you will find data of more than XXX companies, institutions and individuals registered with SwissCham China and Hong Kong.</p>
                                    <p>Detailed information (address, HQ, contact person) are available exclusively for our members. To know more about the other benefits to join us, <a href="<?php echo $site_url ;?>why-join-us-swisscham-china/">click HERE (SwissCham China)</a> or <a href="<?php echo $site_url ;?>why-join-us-swisscham-hong-kong/">HERE (SwissCham Hong Kong)</a>.</p>
                                </div>
                            </div>
                            <?php if(isset($_POST)){?>
                                <!--<div class="large-12 columns no_padding">
                                    <div class="large-12 columns margin_bottom15">
                                        <div class="large-12 columns pattern_bg">
                                            <div class="large-12 columns news_dropmenu">
                                                <label>SEARCH
                                                    <form name="searchForm" id="searchForm" action="member_directory_general_page_search.php" method="GET">
                                                        <div class="input-group">
                                                            <input class="input-group-field news_search_field" type="text" placeholder="Type any keywords" value="" name="searchKey" id="searchKey">
                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="company chamber" value="" name="company_chamber" id="company_chamber">
                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="NAME" value="" name="searchName" id="searchName">

                                                            <input class="input-group-field news_search_field" type="hidden" placeholder="business_scope" value="" name="business_scope" id="business_scope">

                                                            <div class="input-group-button">
                                                                <a href="javascript:void(0);" class="button news_search_button" id="searchButton"><i class="fa fa-search" aria-hidden="true"></i></a>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    
                                                    
                                                    
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                                
                                <!-- Ravi Start From HERE-->
                                
                                <div class="large-12 columns no_padding">
                                    <div class="large-12 columns margin_bottom15">
                                        <div class="large-12 columns pattern_bg">
                                            <form name="searchForm" id="searchForm" action="member_directory_general_page_search.php" method="GET">
                                                <div class="large-3 medium-6 columns news_dropmenu member_post_search">
                                                    <select name="company_chamber" id="company_chamber" class="">
                                                        <option value=""> -- Members by Office -- </option>
                                                        <option <?php if($_GET['company_chamber']=='Beijing') { ?>if selected="selected" <?php } ?>  value="Beijing" > Beijing </option>
                                                        <option <?php if($_GET['company_chamber']=='Shanghai') { ?>if selected="selected" <?php } ?> value="Shanghai" > Shanghai </option>
                                                        <option <?php if($_GET['company_chamber']=='Guangzhou') { ?>if selected="selected" <?php } ?> value="Guangzhou" > Guangzhou </option>
                                                        <option <?php if($_GET['company_chamber']=='ChinaMainland') { ?>if selected="selected" <?php } ?> value="ChinaMainland" >Mainland China </option>
                                                        <option <?php if($_GET['company_chamber']=='HongKong') { ?>if selected="selected" <?php } ?> value="HongKong" > Hong Kong </option>
                                                    </select>
                                                </div>
                                                <div class="large-3 medium-6 columns news_dropmenu member_post_search">
                                                    <select name="searchName" id="searchName" class="">
                                                        <option value=""> -- Members by name -- </option>
                                                        <option <?php if($_GET['searchName']=='A') { ?>if selected="selected" <?php } ?>  value="A" > A </option>
                                                        <option <?php if($_GET['searchName']=='B') { ?>if selected="selected" <?php } ?> value="B" > B </option>
                                                        <option <?php if($_GET['searchName']=='C') { ?>if selected="selected" <?php } ?> value="C" > C </option>
                                                        <option <?php if($_GET['searchName']=='D') { ?>if selected="selected" <?php } ?> value="D" > D </option>
                                                        <option <?php if($_GET['searchName']=='E') { ?>if selected="selected" <?php } ?> value="E" > E </option>
                                                        <option <?php if($_GET['searchName']=='F') { ?>if selected="selected" <?php } ?> value="F" > F </option>
                                                        <option <?php if($_GET['searchName']=='G') { ?>if selected="selected" <?php } ?> value="G" > G </option>
                                                        <option <?php if($_GET['searchName']=='H') { ?>if selected="selected" <?php } ?> value="H" > H </option>
                                                        <option <?php if($_GET['searchName']=='I') { ?>if selected="selected" <?php } ?> value="I" > I </option>
                                                        <option <?php if($_GET['searchName']=='J') { ?>if selected="selected" <?php } ?> value="J" > J </option>
                                                        <option <?php if($_GET['searchName']=='K') { ?>if selected="selected" <?php } ?> value="K" > K </option>
                                                        <option <?php if($_GET['searchName']=='L') { ?>if selected="selected" <?php } ?> value="L" > L </option>
                                                        <option <?php if($_GET['searchName']=='M') { ?>if selected="selected" <?php } ?> value="M" > M </option>
                                                        <option <?php if($_GET['searchName']=='N') { ?>if selected="selected" <?php } ?> value="N" > N </option>
                                                        <option <?php if($_GET['searchName']=='O') { ?>if selected="selected" <?php } ?> value="O" > O </option>
                                                        <option <?php if($_GET['searchName']=='P') { ?>if selected="selected" <?php } ?> value="P" > P </option>
                                                        <option <?php if($_GET['searchName']=='Q') { ?>if selected="selected" <?php } ?> value="Q" > Q </option>
                                                        <option <?php if($_GET['searchName']=='R') { ?>if selected="selected" <?php } ?>value="R" > R </option>
                                                        <option <?php if($_GET['searchName']=='S') { ?>if selected="selected" <?php } ?> value="S" > S </option>
                                                        <option <?php if($_GET['searchName']=='T') { ?>if selected="selected" <?php } ?> value="T" > T </option>
                                                        <option <?php if($_GET['searchName']=='U') { ?>if selected="selected" <?php } ?> value="U" > U </option>
                                                        <option <?php if($_GET['searchName']=='V') { ?>if selected="selected" <?php } ?> value="V" > V </option>
                                                        <option <?php if($_GET['searchName']=='X') { ?>if selected="selected" <?php } ?> value="W" > W </option>
                                                        <option <?php if($_GET['searchName']=='X') { ?>if selected="selected" <?php } ?> value="X" > X </option>
                                                        <option <?php if($_GET['searchName']=='Y') { ?>if selected="selected" <?php } ?> value="Y" > Y </option>
                                                        <option <?php if($_GET['searchName']=='Z') { ?>if selected="selected" <?php } ?> value="Z" > Z </option>
                                                        <option value="#" > # </option>
                                                    </select>
                                                </div>
                                                <div class="large-3 columns news_dropmenu member_post_search">
                                                    <select name="business_scope" id="business_scope" class="">
                                                        <option value=""> -- Members by industry -- </option>
                                                        <option <?php if($_GET['business_scope']=='Agriculture / Food / Beverages') { ?>if selected="selected" <?php } ?> value="Agriculture / Food / Beverages" > Agriculture / Food / Beverages </option>
                                                        <option <?php if($_GET['business_scope']=='Banking / Insurance') { ?>if selected="selected" <?php } ?> value="Banking / Insurance" > Banking / Insurance </option>
                                                        <option <?php if($_GET['business_scope']=='Chemical / Pharmaceuticals') { ?>if selected="selected" <?php } ?> value="Chemical / Pharmaceuticals" > Chemical / Pharmaceuticals </option>
                                                        <option <?php if($_GET['business_scope']=='Construction / Civil Engineering') { ?>if selected="selected" <?php } ?> value="Construction / Civil Engineering" > Construction / Civil Engineering </option>
                                                        <option <?php if($_GET['business_scope']=='Education / Training') { ?>if selected="selected" <?php } ?> value="Education / Training" > Education / Training </option>
                                                        <option <?php if($_GET['business_scope']=='Government / NGO / NPO / Economic Zone') { ?>if selected="selected" <?php } ?> value="Government / NGO / NPO / Economic Zone" > Government / NGO / NPO / Economic Zone </option>
                                                        <option <?php if($_GET['business_scope']=='Hospitality / Hotels / Tourism Services') { ?>if selected="selected" <?php } ?> value="Hospitality / Hotels / Tourism Services" > Hospitality / Hotels / Tourism Services </option>
                                                        <option <?php if($_GET['business_scope']=='Information Technology / Telecommunications') { ?>if selected="selected" <?php } ?> value="Information Technology / Telecommunications" > Information Technology / Telecommunications </option>
                                                        <option <?php if($_GET['business_scope']=='Jewellery / Watches') { ?>if selected="selected" <?php } ?> value="Jewellery / Watches" > Jewellery / Watches </option>
                                                        <option <?php if($_GET['business_scope']=='Legal / Audit / Consulting') { ?>if selected="selected" <?php } ?> value="Legal / Audit / Consulting" > Legal / Audit / Consulting </option>
                                                        <option <?php if($_GET['business_scope']=='Machinery / Equipment') { ?>if selected="selected" <?php } ?> value="Machinery / Equipment" > Machinery / Equipment </option>
                                                        <option <?php if($_GET['business_scope']=='Manufacturing / Electronic') { ?>if selected="selected" <?php } ?> value="Manufacturing / Electronic" > Manufacturing / Electronic </option>
                                                        <option <?php if($_GET['business_scope']=='Media / Publication') { ?>if selected="selected" <?php } ?> value="Media / Publication" > Media / Publication </option>
                                                        <option <?php if($_GET['business_scope']=='Medical / Precision / Optical Instruments') { ?>if selected="selected" <?php } ?> value="Medical / Precision / Optical Instruments" > Medical / Precision / Optical Instruments </option>
                                                        <option <?php if($_GET['business_scope']=='Quality Control / Standards / Testing') { ?>if selected="selected" <?php } ?> value="Quality Control / Standards / Testing" > Quality Control / Standards / Testing </option>
                                                        <option <?php if($_GET['business_scope']=='Trading / Logistics / Transportation') { ?>if selected="selected" <?php } ?> value="Trading / Logistics / Transportation" > Trading / Logistics / Transportation </option>
                                                        <option <?php if($_GET['business_scope']=='Sales / Marketing / Retail') { ?>if selected="selected" <?php } ?> value="Sales / Marketing / Retail" > Sales / Marketing / Retail </option>
                                                        <option <?php if($_GET['business_scope']=='Other') { ?>if selected="selected" <?php } ?> value="Other" > Other </option>
                                                    </select>
                                                </div>
                                                <div class="large-3 columns news_dropmenu member_post_search">

                                                    <div class="input-group">
                                                        <input class="input-group-field news_search_field" type="text" placeholder="Type any keywords" value="<?php if(!empty($_GET['searchKey'])){echo $_GET['searchKey']; }?>" name="searchKey" id="searchKey">
                                                        <div class="input-group-button">
                                                            <a href="javascript:void(0);" class="button news_search_button" id="searchButton"><i class="fa fa-search" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Ravi End From Here -->




                                <div class="large-12 columns">
                                    <div class="large-12 columns no_padding">
                                        <hr class="common_devider" />
                                    </div>
<?php 
    $limit =3;
    $where = "`sc_c_userdetails`.`userId`=`sc_c_company_details`.`userId`";
    if(!empty($_GET['searchKey'])){
            $searchKey=$_GET['searchKey'];
            $where.= " AND `sc_c_company_details`.`company_name_english` LIKE '".$searchKey."%'";
    }
    if(!empty($_GET['company_chamber'])){
            if($_GET['company_chamber'] != 'HongKong'){
             $company_chamber=$_GET['company_chamber'];
             $where.= " AND ( `sc_c_company_details`.`company_chamber`='".$company_chamber."'"; 
             $where.= " OR `sc_c_company_details`.`company_chamber`='ChinaMainland' ) ";
            } else { 
             $company_chamber=$_GET['company_chamber'];
             $where.= " AND  `sc_c_company_details`.`company_chamber`='".$company_chamber."'";
            }
    }
    if(!empty($_GET['searchName'])){
            $searchName=$_GET['searchName'];
            if($searchName!='#'){
            $searchNameLower=strtolower($searchName);
            $where.= " AND (`sc_c_company_details`.`company_name_english` LIKE '".$searchName."%' OR `sc_c_company_details`.`company_name_english` LIKE '".$searchNameLower."%')";
            } else{
            $where.= " AND `sc_c_company_details`.`company_name_english` REGEXP  '^[0-9]+'";	
            }
    }
    if(!empty($_GET['business_scope'])){
            $business_scope=$_GET['business_scope'];
            $where.= " AND `sc_c_company_details`.`business_scope`='".$business_scope."'";
    }
    
    $searchSql="SELECT * FROM `sc_c_userdetails`,`sc_c_company_details` WHERE $where AND `admin_approval`='Yes' AND company_name_english != '' ORDER 
   By sc_c_company_details.company_name_english ASC";
    
   // echo $searchSql; 
   
    $res=mysql_query($searchSql);
    $tot_records=mysql_num_rows($res);
    ///--------------------------------//

    $target_page = $_SERVER['PHP_SELF']; //CHANGE THIS ONLY IF YOU WANT TO SET A DIFERENT TARGET PAGE
    //COPY AND PASTE THE FOLLOWING CODE. DO NOT CHANGE IN FOLLOWING CODE
    $p = new pagination; //INITIALIZING PAGING OBJECT................ 
    if(!empty($_GET['p'])){
            $p1=$_GET['p'];
    } else{
            $p1=1;
    }
    $page = mysql_real_escape_string($p1);
    //$start = ($page != '')?(($page - 1) * $limit):0;
    $page =  ($page == '')?1:$page;
    $p->items($tot_records);     
    $p->limit($limit);
    $p->target($target_page);
    $p->currentPage($page);
    $p->parameterName("p");
    $count=0;
    $searchSql.= ' LIMIT '.(($page - 1)*$limit).','.$limit;
    //echo $sql;

    ///----------------------------------//
    $searchRes=mysql_query($searchSql);
    while($Result=mysql_fetch_array($searchRes)){
            $count++;
?>

                                        <!-- Start: Loop -->
                                        <div class="large-12 columns directory_sort">


                                            <div class="large-3 columns small_padding">
                                                <p class="text-center directory_logo">
                                                    <?php if(!empty($Result['logo_name'])){?><img src="<?=$Result['logo_name']?>" />
                                                        <?php } else{?><img src="images/imgpsh_fullsize.jpg" />
                                                            <?php } ?>
                                                </p>
                                            </div>

                                            <div class="large-9 columns directory_item_details small_padding">
                                                <?php
																
                                                if(!empty($_SESSION["userId"])){
                                                    if($Result['company_membership']!='An individual') {
                                                    ?>
                                                    <a href="member_directory.php?id=<?=$Result['userId']?>"> 
                                                <?php } } else{
                                                            if($Result['company_membership']!='An individual') {
                                                            ?>
                                                            <a href="javascript:void(0);" data-toggle="loginModal1" class="inserUid" data-id="<?=$Result['userId']?>">
                                                            <?php } } ?>
                                                                    <h2><?php if(!empty($Result['company_name_english'])){ echo $Result['company_name_english'];}
                                                                    else { 
                                                                        echo $Result['family_name']. ' '. $Result['given_name'];    
                                                                         }
                                                                    ?></h2>
                                                            </a>
                                                            <h4><?php if(!empty($Result['company_name_chinese'])){ echo $Result['company_name_chinese'];}?></h4>
                                                            <h3 class="common_subheading"><?php if(!empty($Result['business_scope'])){ 
								if($Result['business_scope']=='Other'){ echo $Result['other_business_scope'];} else{ echo $Result['business_scope'];}
								}?></h3>
                                                            <!--<h3 class=""><?php 
								if($Result['business_scope']=='Agriculture / Food / Beverages'){
									echo "农业/食品/饮料";
								} else if($Result['business_scope']=='Chemical / Pharmaceuticals'){
									echo "化学/制药";
								} else if($Result['business_scope']=='Education / Training'){
									echo "教育/培训";
								} else if($Result['business_scope']=='Hospitality / Hotels / Tourism Services'){
									echo "酒店/酒店/旅游服务";
								} else if($Result['business_scope']=='Jewellery / Watches'){
									echo "珠宝/手表";
								} else if($Result['business_scope']=='Machinery / Equipment'){
									echo "机械/设备";
								} else if($Result['business_scope']=='Media / Publication'){
									echo "媒体/出版";
								} else if($Result['business_scope']=='Quality Control / Standards / Testing'){
									echo "质量控制/标准/测试";
								} else if($Result['business_scope']=='Sales / Marketing / Retail'){
									echo "销售/营销/零售";
								} else if($Result['business_scope']=='Banking / Insurance'){
									echo "银行/保险";
								} else if($Result['business_scope']=='Construction / Civil Engineering'){
									echo "建筑/土木工程";
								} else if($Result['business_scope']=='Government / NGO / NPO / Economic Zone'){
									echo "政府/非政府组织/非营利组织/经济区";
								} else if($Result['business_scope']=='Information Technology / Telecommunications'){
									echo "信息技术/电信";
								} else if($Result['business_scope']=='Legal / Audit / Consulting'){
									echo "法律/审计/咨询";
								} else if($Result['business_scope']=='Manufacturing / Electronic'){
									echo "制造/电子";
								} else if($Result['business_scope']=='Medical / Precision / Optical Instruments'){
									echo "医疗/精密/光学仪器";
								} else if($Result['business_scope']=='Trading / Logistics / Transportation'){
									echo "贸易/物流/运输";
								} else{
									echo "其他";
								}
								?></h3>-->
                                                            <h4>Member in: <span><?php if(!empty($Result['company_chamber'])){ 
                                                                if($Result['company_chamber']=='ChinaMainland')
                                                                {
                                                                   echo 'Mainland China'; 
                                                                }
                                                                else {
                                                                echo $Result['company_chamber'];
                                                                }
                                                                
                                                            }?></span></h4>
                                            </div>
                                            <div class="large-12 columns dowedo_top small_padding">
                                                <p class="wordLimit">
                                                    <?php if(!empty($Result['business_description_english'])){ echo $Result['business_description_english'];}?>
                                                </p>
                                                <p class="wordLimit">
                                                    <?php if(!empty($Result['business_description_chinese'])){ echo $Result['business_description_chinese'];}?>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="large-12 columns no_padding">
                                            <hr class="common_devider" />
                                        </div>

                                        <!-- End: Loop -->
                                        <?php } ?>
                                        
<?php 
/////////// This Query For Individual /////////////////
$searchSql="SELECT * FROM `sc_c_userdetails`,`sc_c_company_details` WHERE $where AND `admin_approval`='Yes' AND company_membership == 'An individual' ORDER 
By sc_c_company_details.company_name_english ASC";


?>
                                            <?php if($count==0){?>

                                                <div class="large-12 columns directory_sort no_record">
                                                    <p><i class="fa fa-times-circle" aria-hidden="true"></i> No Record Found...</p>
                                                </div>


                                                <div class="large-12 columns no_padding">
                                                    <hr class="common_devider" />
                                                </div>
                                                <?php } else{?>
                                                    <?php $p->show(); ?>
                                                        <?php }  ?>
                                </div>




                                <!-- Login Modal Start -->
                                <div class="reveal login_modal" id="loginModal1" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                                    <h1>Please enter the details to login</h1>
                                    <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                                    <form name="logInForm1" id="logInForm1" action="login_process.php" method="POST">
                                        <div class="row">
                                            <div class="medium-12 columns margin_top10 membership_from no_padding">
                                                <label>User ID <span class="mandatory_tag">*</span>
                                                    <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId1">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns margin_top10 membership_from no_padding">
                                                <label>Password <span class="mandatory_tag">*</span>
                                                    <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password1">
                                                    <input type="hidden" value="" name="uid" id="uid1">
                                                </label>
                                            </div>
                                            <div class="medium-12 columns membership_from no_padding">
                                                <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit1">Login</a></p>
                                            </div>
                                        </div>
                                    </form>
                                    <button class="close-button" data-close aria-label="Close reveal" type="button">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <!-- Login Modal End -->
                                <?php } ?>

                        </div>

                        <?php 
			require_once(__ROOT__.'/includes/rightPanel.php'); 
			?>
                    </div>
                </section>
			<!--	<section class="main_sponsor_sec">
            <div class="row">
                <div class="large-12 columns">
                    <div class="mainSponsor">
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor2.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor3.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor4.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor5.jpg" /></p>
                        </div>
                        <div class="">
                            <p class="main_sponsor_item"><img src="images/main_sponsor1.jpg" /></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>-->
                <?php 
			require_once(__ROOT__.'/includes/footer.php'); 
			?>
                    <!-- Login Modal Start -->
                    <div class="reveal login_modal" id="loginModal" data-reveal data-close-on-click="true" data-animation-in="slide-in-down" data-animation-out="slide-out-up">
                        <h1>Please enter the details to login</h1>
                        <!--<p class='lead'>There are many options for animating modals, check out the Motion UI library to see them all</p>-->
                        <form name="logInForm" id="logInForm" action="login_process.php" method="POST">
                            <div class="row">
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>User ID <span class="mandatory_tag">*</span>
                                        <input type="text" placeholder="" name="admin_generated_userId" id="admin_generated_userId">
                                    </label>
                                </div>
                                <div class="medium-12 columns margin_top10 membership_from no_padding">
                                    <label>Password <span class="mandatory_tag">*</span>
                                        <input type="password" placeholder="" name="admin_generated_password" id="admin_generated_password">
                                        <input type="hidden" value="c" name="uid" id="uid">
                                    </label>
                                </div>
                                <div class="medium-12 columns membership_from no_padding">
                                    <p class="text-right"><a href="javascript:void(0);" class="button regnext_btn" id="loginSubmit">Login</a></p>
                                </div>
                            </div>
                        </form>
                        <button class="close-button" data-close aria-label="Close reveal" type="button">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <!-- Login Modal End -->
                    <a class="log_toogler show-for-medium-only" href="#log_togg"><i class="fa fa-bars" aria-hidden="true"></i></a>
                    <!--        <a class="menu_toogler" href="#menu"><i class="fa fa-bars" aria-hidden="true"></i></a>-->

                    <?php 
            require_once(__ROOT__.'/includes/footerbuttom.php'); 
            ?>


        </div>

        <a href="#0" class="cd-top">Top</a>




        <script src="bower_components/jquery/dist/jquery.js"></script>
        <script src="bower_components/what-input/what-input.js"></script>
        <script src="bower_components/foundation-sites/dist/foundation.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/easyResponsiveTabs.js"></script>
        <script type="text/javascript" src="js/jquery.mmenu.all.min.js"></script>
        <script type="text/javascript" src="js/jquery.viewportchecker.js"></script>
        <script type="text/javascript" src="js/pace.js"></script>
        <script type="text/javascript">
            $(function() {
                $('nav#menu').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: true,
                    counters: false,
                    "offCanvas": {
                        "position": "left"
                    },
                    navbar: {
                        title: 'SWISSCHAM'
                    },
                    navbars: [{
                        position: 'top',
                        content: ['searchfield']
                    }, {
                        position: 'top',
                        content: [
                            'prev',
                            'title',
                            'close'
                        ]
                    }, {
                        position: 'bottom',
                        content: [
                            //                        '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /></a></span>', // '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /></a></span>'
                        ]
                    }]
                });
                $('nav#log_togg').mmenu({
                    extensions: ['effect-slide-menu', 'pageshadow'],
                    searchfield: false,
                    counters: false,
                    navbar: {
                        title: 'Welcome to Swisscham'
                    },
                    navbars: [{
                        position: 'bottom',
                        content: [
                            '<span class="side_footer_link"><a class=""><img src="images/wechat.png" /> Wechat</a></span>',
                            '<span class="side_footer_link"><a class=""><img src="images/linkdin.png" /> LinkedIn</a></span>'
                        ]
                    }]

                });

            });

        </script>
        <script>
            $(document).ready(function() {
                $('.pagination a').click(function() {
                    var url = $(this).attr('href');
                    $('#searchform').attr('action', url);
                    $('#searchform').submit();
                });

            });

        </script>
        <script src="js/app.js"></script>
        <script src="js/generalDirectory.js"></script>
        <script type="text/javascript" src="js/registration.js"></script>

    </body>

    </html>
