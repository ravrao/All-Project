<?php
define('__ROOT__', dirname(__FILE__)); 
require_once(__ROOT__.'/includes/config.php');
mysql_query("SET character_set_client=utf8")or die(mysql_error());
mysql_query("SET character_set_connection=utf8")or die(mysql_error());
if($_POST){

    $admin_generated_userId=$_POST['admin_generated_userId'];
    $admin_generated_password=$_POST['admin_generated_password']; 
	
	
	if($admin_generated_userId == "admin" && $admin_generated_password=="abcd1234"){
            
		
		 $sqladmin = "SELECT * FROM sc_c_userdetails 
		                    WHERE admin_generated_userId='".$admin_generated_userId."' 
		                      AND admin_generated_password='".$admin_generated_password."'
		                      AND admin_approval='Yes'";
		
		$result = mysql_query($sqladmin); 
		$adminrow = mysql_fetch_array($result);
		
		$_SESSION["userId"] = $adminrow['userId'];
    	$_SESSION["family_name"] = $adminrow['family_name'];
    	$_SESSION["given_name"] = $adminrow['given_name'];
		header('Location: admin.php');
	}else{
		    $sql = "SELECT * FROM sc_c_userdetails 
		                    WHERE admin_generated_userId='".$admin_generated_userId."' 
		                      AND admin_generated_password='".$admin_generated_password."'
		                      AND admin_approval='Yes'";
		
		    $result = mysql_query($sql); 
		
		    $row = mysql_fetch_array($result);
		   
		    if(($row['admin_generated_userId']==$admin_generated_userId) && 
		    	($row['admin_generated_password']==$admin_generated_password)){
		
		    	$_SESSION["userId"] = $row['userId'];
		    	$_SESSION["family_name"] = $row['family_name'];
		    	$_SESSION["given_name"] = $row['given_name'];
				if(empty($_POST['uid'])){
					header('Location: membership.php');
				} else{
					if($_POST['uid']=='c'){
						header('Location: member_directory_general_page.php?p=1');
					} else{
						$id=$_POST['uid'];
						header("Location: member_directory.php?id=$id");
					}
				}
		    }else{
				if(empty($_POST['uid'])){
					header('Location: online_application.php');
				} else{
					header('Location: member_directory_general_page.php?p=1');
				}
		    	
		    }
		}
  }
?>