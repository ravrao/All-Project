<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 
session_unset("userId"); 
session_destroy(); 
//header('Location: http://54.152.108.131/SwissCham/');
header('Location: ' . $site_url);

require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php' );
 
//function wp_logout() {
    wp_destroy_current_session();
    wp_clear_auth_cookie();
 
    /**
     * Fires after a user is logged-out.
     *
     * @since 1.5.0
     */
    //do_action( 'wp_logout' );
//}
?>