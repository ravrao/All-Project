<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 

$USER_ID = $_REQUEST['guan_id'];

$news='Yes';
 $sql = "UPDATE `sc_c_userdetails`
                SET `news_gua`='".$news."'
              WHERE `userId` = '".$USER_ID."'";
			
 $rs=mysql_query($sql);
 
 if(!$rs)
 {
    die('Invalid query: ' . mysql_error());
 }
 
 //echo "OK";
