<?php
define('__ROOT__', dirname(__FILE__));
require_once(__ROOT__.'/includes/config.php'); 


$src = $_REQUEST['excl'];
if($src=="ulist") 
	  $query = $_SESSION['qry_listing'];
        
elseif($src=="adv") 
     $query = $_SESSION['adv_qry'];
    
date_default_timezone_set('Asia/Kolkata');
require('Classes/PHPExcel.php');
$objPHPExcel = new PHPExcel;
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
$objPHPExcel->getDefaultStyle()->getFont()->setSize(10);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
$numberFormat = '#,#0.##;[Red]-#,#0.##';
$objSheet = $objPHPExcel->getActiveSheet();

$objSheet->setTitle('User report');
$objSheet->getStyle('A1:BL1')->getFont()->setBold(true)->setSize(12);

/*$objSheet->getCell('A1')->setValue('USERNAME');*/

$objSheet->getCell('A1')->setValue('Membership (City)');
$objSheet->getCell('B1')->setValue('Type Of Membership');
$objSheet->getCell('C1')->setValue('Company ENG');
$objSheet->getCell('D1')->setValue('Company CN');
$objSheet->getCell('E1')->setValue('Membership Applied For');
$objSheet->getCell('F1')->setValue('Business Scope');
$objSheet->getCell('G1')->setValue('Other Business Scope');
$objSheet->getCell('H1')->setValue('Business Description English');
$objSheet->getCell('I1')->setValue('Business Description Chinese');
$objSheet->getCell('J1')->setValue('Company Address In English');
$objSheet->getCell('K1')->setValue('Company City In English');
$objSheet->getCell('L1')->setValue('Company Province/Area In English');
$objSheet->getCell('M1')->setValue('Company Address In Chinese');
$objSheet->getCell('N1')->setValue('Company City In Chinese');
$objSheet->getCell('O1')->setValue('Company ZIP Code');
$objSheet->getCell('P1')->setValue('Company General Phone');
$objSheet->getCell('Q1')->setValue('Company General E-mail');
$objSheet->getCell('R1')->setValue('Company General Website');
$objSheet->getCell('S1')->setValue('Company Legal Entity');
$objSheet->getCell('T1')->setValue('Company N° Of Employees (China Mainland/HK)');
$objSheet->getCell('U1')->setValue('Company Swiss Registered – Yes/No');
$objSheet->getCell('V1')->setValue('Company PRC Business License – Yes/No');
$objSheet->getCell('W1')->setValue('HQ Company Name');
$objSheet->getCell('X1')->setValue('HQ Address');
$objSheet->getCell('Y1')->setValue('HQ City In English');
$objSheet->getCell('Z1')->setValue('HQ Zip Code');
$objSheet->getCell('AA1')->setValue('HQ General Phone');
$objSheet->getCell('AB1')->setValue('HQ Province/Area In English');
$objSheet->getCell('AC1')->setValue('Company Holder Date Of Birth');
$objSheet->getCell('AD1')->setValue('Company Holder Family Name');
$objSheet->getCell('AE1')->setValue('Company Holder Given Name');
$objSheet->getCell('AF1')->setValue('Company Holder Chinese Name');
$objSheet->getCell('AG1')->setValue('Company Holder Nationality');
$objSheet->getCell('AH1')->setValue('Company Holder Position In The Company');
$objSheet->getCell('AI1')->setValue('Company Holder Direct Phone');
$objSheet->getCell('AJ1')->setValue('Company Holder Direct E-mail');
$objSheet->getCell('AK1')->setValue('Company Holder Mobile');
$objSheet->getCell('AL1')->setValue('Other Contact 1 Date Of Birth');
$objSheet->getCell('AM1')->setValue('Other Contact 1 Family Name');
$objSheet->getCell('AN1')->setValue('Other Contact 1 Given Name');
$objSheet->getCell('AO1')->setValue('Other Contact 1 Chinese Name');
$objSheet->getCell('AP1')->setValue('Other Contact 1 Nationality');
$objSheet->getCell('AQ1')->setValue('Other Contact 1 Position In The Company');
$objSheet->getCell('AR1')->setValue('Other Contact 1 Mobile');
$objSheet->getCell('AS1')->setValue('Other Contact 1 Direct Phone');
$objSheet->getCell('AT1')->setValue('Other Contact 1 Direct E-mail');
$objSheet->getCell('AU1')->setValue('Other Contact 2 Date Of Birth');
$objSheet->getCell('AV1')->setValue('Other Contact 2 Family Name');
$objSheet->getCell('AW1')->setValue('Other Contact 2 Given Name');
$objSheet->getCell('AX1')->setValue('Other Contact 2 Chinese Name');
$objSheet->getCell('AY1')->setValue('Other Contact 2 Nationality');
$objSheet->getCell('AZ1')->setValue('Other Contact 2 Position In The Company');
$objSheet->getCell('BA1')->setValue('Other Contact 2 Mobile');
$objSheet->getCell('BB1')->setValue('Other Contact 2 Direct Phone');
$objSheet->getCell('BC1')->setValue('Other Contact 2 Direct E-mail');
$objSheet->getCell('BD1')->setValue('Other Contact 3 Date Of Birth');
$objSheet->getCell('BE1')->setValue('Other Contact 3 Family Name');
$objSheet->getCell('BF1')->setValue('Other Contact 3 Given Name');
$objSheet->getCell('BG1')->setValue('Other Contact 3 Chinese Name');
$objSheet->getCell('BH1')->setValue('Other Contact 3 Nationality');
$objSheet->getCell('BI1')->setValue('Other Contact 3 Position In The Company');
$objSheet->getCell('BJ1')->setValue('Other Contact 3 Mobile');
$objSheet->getCell('BK1')->setValue('Other Contact 3 Direct Phone');
$objSheet->getCell('BL1')->setValue('Other Contact 3 Direct E-mail');




$usr_details_res = mysql_query($query);	
$row = 2;							  
while($usr_details_row = mysql_fetch_array($usr_details_res)){
	/*$objSheet->getCell('A'.$row)->setValue($usr_details_row['admin_generated_userId']);*/
    
        $objSheet->getCell('A'.$row)->setValue($usr_details_row['company_chamber']);
        $objSheet->getCell('B'.$row)->setValue($usr_details_row['apply_for']);
        $objSheet->getCell('C'.$row)->setValue($usr_details_row['company_name_english']);
	$objSheet->getCell('D'.$row)->setValue($usr_details_row['company_name_chinese']);
        $objSheet->getCell('E'.$row)->setValue($usr_details_row['swiss_invested'] . ' / ' .$usr_details_row['company_have']);
        $objSheet->getCell('F'.$row)->setValue($usr_details_row['business_scope']);
        $objSheet->getCell('G'.$row)->setValue($usr_details_row['other_business_scope']);
        $objSheet->getCell('H'.$row)->setValue($usr_details_row['business_description_english']);
        $objSheet->getCell('I'.$row)->setValue($usr_details_row['business_description_chinese']);
        $objSheet->getCell('J'.$row)->setValue($usr_details_row['company_address']);
        $objSheet->getCell('K'.$row)->setValue($usr_details_row['company_city']);
        $objSheet->getCell('L'.$row)->setValue($usr_details_row['province_area_english']);
        $objSheet->getCell('M'.$row)->setValue($usr_details_row['china_office_address']);
        $objSheet->getCell('N'.$row)->setValue($usr_details_row['china_office_city']);
        $objSheet->getCell('O'.$row)->setValue($usr_details_row['company_zipCode']);
        $objSheet->getCell('P'.$row)->setValue($usr_details_row['company_generalPhone']);
	$objSheet->getCell('Q'.$row)->setValue($usr_details_row['company_email']);
	$objSheet->getCell('R'.$row)->setValue($usr_details_row['company_website']);
        $objSheet->getCell('S'.$row)->setValue($usr_details_row['legal_entity']);
        $objSheet->getCell('T'.$row)->setValue($usr_details_row['no_of_employees']);
        $objSheet->getCell('U'.$row)->setValue($usr_details_row['is_company_swiss_registered']);
        $objSheet->getCell('V'.$row)->setValue($usr_details_row['is_company_registered_PRC']);
        $objSheet->getCell('W'.$row)->setValue($usr_details_row['headquarter_name']);
        $objSheet->getCell('X'.$row)->setValue($usr_details_row['headquarter_address']);
        $objSheet->getCell('Y'.$row)->setValue($usr_details_row['headquarter_city']);
        $objSheet->getCell('Z'.$row)->setValue($usr_details_row['headquarter_zipCode']);
        $objSheet->getCell('AA'.$row)->setValue($usr_details_row['headquarter_phone']);
        $objSheet->getCell('AB'.$row)->setValue($usr_details_row['headquarter_province_area_english']);
        $objSheet->getCell('AC'.$row)->setValue($usr_details_row['year_of_birth']);
        $objSheet->getCell('AD'.$row)->setValue($usr_details_row['family_name']);
        $objSheet->getCell('AE'.$row)->setValue($usr_details_row['given_name']);
        $objSheet->getCell('AF'.$row)->setValue($usr_details_row['chinese_name']);
        $objSheet->getCell('AG'.$row)->setValue($usr_details_row['nationality']);
        $objSheet->getCell('AH'.$row)->setValue($usr_details_row['positionIn_company']);
        $objSheet->getCell('AI'.$row)->setValue($usr_details_row['direct_phone']);
        $objSheet->getCell('AJ'.$row)->setValue($usr_details_row['direct_email']);
        $objSheet->getCell('AK'.$row)->setValue($usr_details_row['mobile_phone']);
        
              
         
     
         
         $rowexcelfetch = mysql_query("SELECT * FROM `sc_c_other_contact` WHERE userId='".$usr_details_row['userId']."'"); 
         $i=1;
         while($usr_details_row_othercontact = mysql_fetch_array($rowexcelfetch)){
         if($i==1)
         {
             
            $objSheet->getCell('AL'.$row)->setValue($usr_details_row_othercontact['other_contact_dob']);
            $objSheet->getCell('AM'.$row)->setValue($usr_details_row_othercontact['other_contact_familyName']);
            $objSheet->getCell('AN'.$row)->setValue($usr_details_row_othercontact['other_contact_givenName']);
            $objSheet->getCell('AO'.$row)->setValue($usr_details_row_othercontact['other_contact_chineseName']);
            $objSheet->getCell('AP'.$row)->setValue($usr_details_row_othercontact['other_contact_nationality']);
            $objSheet->getCell('AQ'.$row)->setValue($usr_details_row_othercontact['other_contact_position']);
            $objSheet->getCell('AR'.$row)->setValue($usr_details_row_othercontact['other_contact_mobile']);
            $objSheet->getCell('AS'.$row)->setValue($usr_details_row_othercontact['other_contact_directPhone']);
            $objSheet->getCell('AT'.$row)->setValue($usr_details_row_othercontact['other_contact_directEmail']);   
             
       
         }
         if($i==2)
         {
            $objSheet->getCell('AU'.$row)->setValue($usr_details_row_othercontact['other_contact_dob']);
            $objSheet->getCell('AV'.$row)->setValue($usr_details_row_othercontact['other_contact_familyName']);
            $objSheet->getCell('AW'.$row)->setValue($usr_details_row_othercontact['other_contact_givenName']);
            $objSheet->getCell('AX'.$row)->setValue($usr_details_row_othercontact['other_contact_chineseName']);
            $objSheet->getCell('AY'.$row)->setValue($usr_details_row_othercontact['other_contact_nationality']);
            $objSheet->getCell('AZ'.$row)->setValue($usr_details_row_othercontact['other_contact_position']);
            $objSheet->getCell('BA'.$row)->setValue($usr_details_row_othercontact['other_contact_mobile']);
            $objSheet->getCell('BB'.$row)->setValue($usr_details_row_othercontact['other_contact_directPhone']);
            $objSheet->getCell('BC'.$row)->setValue($usr_details_row_othercontact['other_contact_directEmail']);   
         }
         if($i==3)
         {
            $objSheet->getCell('BD'.$row)->setValue($usr_details_row_othercontact['other_contact_dob']);
            $objSheet->getCell('BE'.$row)->setValue($usr_details_row_othercontact['other_contact_familyName']);
            $objSheet->getCell('BF'.$row)->setValue($usr_details_row_othercontact['other_contact_givenName']);
            $objSheet->getCell('BG'.$row)->setValue($usr_details_row_othercontact['other_contact_chineseName']);
            $objSheet->getCell('BH'.$row)->setValue($usr_details_row_othercontact['other_contact_nationality']);
            $objSheet->getCell('BI'.$row)->setValue($usr_details_row_othercontact['other_contact_position']);
            $objSheet->getCell('BJ'.$row)->setValue($usr_details_row_othercontact['other_contact_mobile']);
            $objSheet->getCell('BK'.$row)->setValue($usr_details_row_othercontact['other_contact_directPhone']);
            $objSheet->getCell('BL'.$row)->setValue($usr_details_row_othercontact['other_contact_directEmail']);   
         }
         $i++;
         }
         
       
        
	$row++;
}

// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);
$objSheet->getColumnDimension('H')->setAutoSize(true);
$objSheet->getColumnDimension('I')->setAutoSize(true);
$objSheet->getColumnDimension('J')->setAutoSize(true);
$objSheet->getColumnDimension('K')->setAutoSize(true);
$objSheet->getColumnDimension('L')->setAutoSize(true);
$objSheet->getColumnDimension('M')->setAutoSize(true);
$objSheet->getColumnDimension('N')->setAutoSize(true);
$objSheet->getColumnDimension('O')->setAutoSize(true);
$objSheet->getColumnDimension('P')->setAutoSize(true);
$objSheet->getColumnDimension('Q')->setAutoSize(true);
$objSheet->getColumnDimension('R')->setAutoSize(true);
$objSheet->getColumnDimension('S')->setAutoSize(true);
$objSheet->getColumnDimension('T')->setAutoSize(true);
$objSheet->getColumnDimension('U')->setAutoSize(true);
$objSheet->getColumnDimension('V')->setAutoSize(true);
$objSheet->getColumnDimension('W')->setAutoSize(true);
$objSheet->getColumnDimension('X')->setAutoSize(true);
$objSheet->getColumnDimension('Y')->setAutoSize(true);
$objSheet->getColumnDimension('Z')->setAutoSize(true);
$objSheet->getColumnDimension('AA')->setAutoSize(true);
$objSheet->getColumnDimension('AB')->setAutoSize(true);
$objSheet->getColumnDimension('AC')->setAutoSize(true);
$objSheet->getColumnDimension('AD')->setAutoSize(true);
$objSheet->getColumnDimension('AE')->setAutoSize(true);
$objSheet->getColumnDimension('AF')->setAutoSize(true);
$objSheet->getColumnDimension('AG')->setAutoSize(true);
$objSheet->getColumnDimension('AH')->setAutoSize(true);
$objSheet->getColumnDimension('AI')->setAutoSize(true);
$objSheet->getColumnDimension('AJ')->setAutoSize(true);
$objSheet->getColumnDimension('AK')->setAutoSize(true);
$objSheet->getColumnDimension('AL')->setAutoSize(true);
$objSheet->getColumnDimension('AM')->setAutoSize(true);
$objSheet->getColumnDimension('AN')->setAutoSize(true);
$objSheet->getColumnDimension('AO')->setAutoSize(true);
$objSheet->getColumnDimension('AP')->setAutoSize(true);

$objSheet->getColumnDimension('AQ')->setAutoSize(true);
$objSheet->getColumnDimension('AR')->setAutoSize(true);
$objSheet->getColumnDimension('AS')->setAutoSize(true);
$objSheet->getColumnDimension('AT')->setAutoSize(true);
$objSheet->getColumnDimension('AU')->setAutoSize(true);
$objSheet->getColumnDimension('AV')->setAutoSize(true);
$objSheet->getColumnDimension('AW')->setAutoSize(true);
$objSheet->getColumnDimension('AX')->setAutoSize(true);
$objSheet->getColumnDimension('AY')->setAutoSize(true);
$objSheet->getColumnDimension('AZ')->setAutoSize(true);
$objSheet->getColumnDimension('BA')->setAutoSize(true);
$objSheet->getColumnDimension('BB')->setAutoSize(true);
$objSheet->getColumnDimension('BC')->setAutoSize(true);
$objSheet->getColumnDimension('BD')->setAutoSize(true);
$objSheet->getColumnDimension('BE')->setAutoSize(true);
$objSheet->getColumnDimension('BF')->setAutoSize(true);
$objSheet->getColumnDimension('BG')->setAutoSize(true);
$objSheet->getColumnDimension('BH')->setAutoSize(true);
$objSheet->getColumnDimension('BI')->setAutoSize(true);
$objSheet->getColumnDimension('BJ')->setAutoSize(true);
$objSheet->getColumnDimension('BK')->setAutoSize(true);
$objSheet->getColumnDimension('BL')->setAutoSize(true);








//$objSheet->getColumnDimension('H')->setAutoSize(true);


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="user_report.xlsx"');
header('Cache-Control: max-age=0');

$objWriter->save('php://output');
?>
